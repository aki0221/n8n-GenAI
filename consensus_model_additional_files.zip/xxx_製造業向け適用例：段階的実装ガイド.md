# 製造業向け適用例：段階的実装ガイド

コンセンサスモデルを製造業に適用する際の段階的な実装アプローチを以下に示します。この実装ガイドは、初期の小規模プロトタイプから完全な本番環境まで、段階的に機能を拡張していく方法を説明しています。

## フェーズ1：最小実装プロトタイプ（1-2ヶ月）

最初のフェーズでは、単一の製造ラインまたは工程に焦点を当て、基本的なコンセンサスモデルの概念実証を行います。

### ステップ1：データ収集基盤の構築

```javascript
// n8nでの基本的なデータ収集ワークフロー
{
  "nodes": [
    {
      "name": "Manufacturing Sensor Data Collector",
      "type": "n8n-nodes-base.httpRequest",
      "parameters": {
        "url": "http://manufacturing-api.internal/sensor-data",
        "method": "GET",
        "authentication": "basicAuth",
        "options": {
          "timeout": 5000
        }
      }
    },
    {
      "name": "Data Transformation",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// 基本的なデータ変換\nconst data = $input.item.json;\nreturn {\n  timestamp: new Date().toISOString(),\n  machineId: data.machine_id,\n  temperature: data.temp,\n  pressure: data.press,\n  vibration: data.vib\n};"
      }
    },
    {
      "name": "Database Storage",
      "type": "n8n-nodes-base.postgres",
      "parameters": {
        "operation": "insert",
        "table": "machine_sensor_data",
        "columns": "timestamp,machine_id,temperature,pressure,vibration",
        "values": "={{$node[\"Data Transformation\"].json[\"timestamp\"]}},{{$node[\"Data Transformation\"].json[\"machineId\"]}},{{$node[\"Data Transformation\"].json[\"temperature\"]}},{{$node[\"Data Transformation\"].json[\"pressure\"]}},{{$node[\"Data Transformation\"].json[\"vibration\"]}}"
      }
    }
  ]
}
```

このステップでは：
- 単一の製造ラインから基本的なセンサーデータ（温度、圧力、振動など）を収集
- 収集データを標準形式に変換
- リレーショナルデータベースに保存
- 1時間ごとのバッチ処理で実行

### ステップ2：基本的な分析モデルの実装

```javascript
// 基本的な分析モデルワークフロー
{
  "nodes": [
    {
      "name": "Fetch Recent Data",
      "type": "n8n-nodes-base.postgres",
      "parameters": {
        "operation": "select",
        "table": "machine_sensor_data",
        "query": "SELECT * FROM machine_sensor_data WHERE timestamp > NOW() - INTERVAL '24 HOURS'"
      }
    },
    {
      "name": "Simple Statistical Analysis",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// 基本的な統計分析\nconst data = $input.item.json;\n\n// 温度の平均と標準偏差を計算\nconst temperatures = data.map(d => d.temperature);\nconst avgTemp = temperatures.reduce((sum, val) => sum + val, 0) / temperatures.length;\nconst stdDevTemp = Math.sqrt(temperatures.map(t => Math.pow(t - avgTemp, 2)).reduce((sum, val) => sum + val, 0) / temperatures.length);\n\n// 圧力の平均と標準偏差を計算\nconst pressures = data.map(d => d.pressure);\nconst avgPress = pressures.reduce((sum, val) => sum + val, 0) / pressures.length;\nconst stdDevPress = Math.sqrt(pressures.map(p => Math.pow(p - avgPress, 2)).reduce((sum, val) => sum + val, 0) / pressures.length);\n\n// 振動の平均と標準偏差を計算\nconst vibrations = data.map(d => d.vibration);\nconst avgVib = vibrations.reduce((sum, val) => sum + val, 0) / vibrations.length;\nconst stdDevVib = Math.sqrt(vibrations.map(v => Math.pow(v - avgVib, 2)).reduce((sum, val) => sum + val, 0) / vibrations.length);\n\nreturn {\n  avgTemperature: avgTemp,\n  stdDevTemperature: stdDevTemp,\n  avgPressure: avgPress,\n  stdDevPressure: stdDevPress,\n  avgVibration: avgVib,\n  stdDevVibration: stdDevVib,\n  dataPoints: data.length,\n  analysisTimestamp: new Date().toISOString()\n};"
      }
    },
    {
      "name": "Simple Anomaly Detection",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// 基本的な異常検知\nconst stats = $input.item.json;\nconst data = $node[\"Fetch Recent Data\"].json;\n\n// 3シグマを超える値を異常として検出\nconst anomalies = data.filter(d => {\n  const tempAnomaly = Math.abs(d.temperature - stats.avgTemperature) > 3 * stats.stdDevTemperature;\n  const pressAnomaly = Math.abs(d.pressure - stats.avgPressure) > 3 * stats.stdDevPressure;\n  const vibAnomaly = Math.abs(d.vibration - stats.avgVibration) > 3 * stats.stdDevVibration;\n  \n  return tempAnomaly || pressAnomaly || vibAnomaly;\n});\n\nreturn {\n  anomalyCount: anomalies.length,\n  anomalyPercentage: (anomalies.length / data.length) * 100,\n  anomalies: anomalies,\n  detectionTimestamp: new Date().toISOString()\n};"
      }
    },
    {
      "name": "Alert If Anomalies",
      "type": "n8n-nodes-base.if",
      "parameters": {
        "conditions": {
          "number": [
            {
              "value1": "={{$node[\"Simple Anomaly Detection\"].json[\"anomalyCount\"]}}",
              "operation": "larger",
              "value2": 5
            }
          ]
        }
      }
    },
    {
      "name": "Send Email Alert",
      "type": "n8n-nodes-base.emailSend",
      "parameters": {
        "to": "maintenance-team@example.com",
        "subject": "Machine Anomaly Alert",
        "text": "={{\"Detected \" + $node[\"Simple Anomaly Detection\"].json[\"anomalyCount\"] + \" anomalies in the last 24 hours. Please check the manufacturing line.\"}}"
      }
    }
  ]
}
```

このステップでは：
- 収集したセンサーデータに対して基本的な統計分析（平均、標準偏差）を実行
- 単純な閾値ベースの異常検知を実装
- 異常が検出された場合のアラート通知を設定
- 日次バッチで実行

### ステップ3：基本的なコンセンサスモデルの構築

```javascript
// 基本的なコンセンサスモデルワークフロー
{
  "nodes": [
    {
      "name": "Fetch Multiple Analysis Results",
      "type": "n8n-nodes-base.postgres",
      "parameters": {
        "operation": "select",
        "table": "analysis_results",
        "query": "SELECT * FROM analysis_results WHERE machine_id = 'MACHINE001' AND analysis_timestamp > NOW() - INTERVAL '7 DAYS'"
      }
    },
    {
      "name": "Simple Consensus Formation",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// 基本的なコンセンサス形成\nconst results = $input.item.json;\n\n// 各分析結果の重み付け（単純な等重み）\nconst weights = results.map(() => 1 / results.length);\n\n// 加重平均による統合\nlet consensusAnomaly = 0;\nfor (let i = 0; i < results.length; i++) {\n  consensusAnomaly += results[i].anomaly_percentage * weights[i];\n}\n\n// 単純な閾値判定\nconst isAnomalous = consensusAnomaly > 10; // 10%以上の異常率でアラート\n\nreturn {\n  consensusAnomalyPercentage: consensusAnomaly,\n  isAnomalous: isAnomalous,\n  contributingResults: results.length,\n  consensusTimestamp: new Date().toISOString()\n};"
      }
    },
    {
      "name": "Take Action Based on Consensus",
      "type": "n8n-nodes-base.if",
      "parameters": {
        "conditions": {
          "boolean": [
            {
              "value1": "={{$node[\"Simple Consensus Formation\"].json[\"isAnomalous\"]}}",
              "value2": true
            }
          ]
        }
      }
    },
    {
      "name": "Schedule Maintenance",
      "type": "n8n-nodes-base.httpRequest",
      "parameters": {
        "url": "http://maintenance-api.internal/schedule",
        "method": "POST",
        "body": "={{\n  \"machineId\": \"MACHINE001\",\n  \"reason\": \"Consensus anomaly detection\",\n  \"anomalyPercentage\": $node[\"Simple Consensus Formation\"].json[\"consensusAnomalyPercentage\"],\n  \"requestedBy\": \"AutomatedSystem\",\n  \"priority\": \"Medium\"\n}}",
        "options": {
          "jsonParseResponse": true
        }
      }
    }
  ]
}
```

このステップでは：
- 複数の分析結果を取得
- 単純な等重みによるコンセンサス形成を実装
- コンセンサスに基づく基本的なアクション（保守スケジュールなど）を設定
- 週次バッチで実行

## フェーズ2：機能拡張と複数ソース統合（3-6ヶ月）

第2フェーズでは、複数の製造ラインからのデータ統合と、より高度な分析モデルの導入を行います。

### ステップ4：複数データソースの統合

```javascript
// 複数データソース統合ワークフロー
{
  "nodes": [
    {
      "name": "Sensor Data Collector",
      "type": "n8n-nodes-base.httpRequest",
      "parameters": {
        "url": "http://manufacturing-api.internal/sensor-data",
        "method": "GET",
        "authentication": "basicAuth",
        "options": {
          "timeout": 5000
        }
      }
    },
    {
      "name": "Quality Control Data",
      "type": "n8n-nodes-base.httpRequest",
      "parameters": {
        "url": "http://qc-api.internal/inspection-data",
        "method": "GET",
        "authentication": "basicAuth",
        "options": {
          "timeout": 5000
        }
      }
    },
    {
      "name": "Production Planning Data",
      "type": "n8n-nodes-base.httpRequest",
      "parameters": {
        "url": "http://erp-api.internal/production-schedule",
        "method": "GET",
        "authentication": "basicAuth",
        "options": {
          "timeout": 5000
        }
      }
    },
    {
      "name": "Data Integration",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// 複数データソースの統合\nconst sensorData = $node[\"Sensor Data Collector\"].json;\nconst qcData = $node[\"Quality Control Data\"].json;\nconst productionData = $node[\"Production Planning Data\"].json;\n\n// 製造ラインIDでデータを関連付け\nconst integratedData = [];\n\n// 各製造ラインについてデータを統合\nconst lineIds = [...new Set(sensorData.map(s => s.line_id))];\n\nfor (const lineId of lineIds) {\n  // 該当ラインのセンサーデータを取得\n  const lineSensors = sensorData.filter(s => s.line_id === lineId);\n  \n  // 該当ラインの品質管理データを取得\n  const lineQC = qcData.filter(q => q.line_id === lineId);\n  \n  // 該当ラインの生産計画データを取得\n  const lineProduction = productionData.filter(p => p.line_id === lineId);\n  \n  // データを統合\n  integratedData.push({\n    lineId: lineId,\n    timestamp: new Date().toISOString(),\n    sensorData: lineSensors,\n    qualityData: lineQC,\n    productionData: lineProduction\n  });\n}\n\nreturn integratedData;"
      }
    },
    {
      "name": "Store Integrated Data",
      "type": "n8n-nodes-base.postgres",
      "parameters": {
        "operation": "insert",
        "table": "integrated_manufacturing_data",
        "columns": "line_id,timestamp,sensor_data,quality_data,production_data",
        "values": "={{$node[\"Data Integration\"].json.map(item => `'${item.lineId}','${item.timestamp}','${JSON.stringify(item.sensorData)}','${JSON.stringify(item.qualityData)}','${JSON.stringify(item.productionData)}'`).join(\",\")}}"
      }
    }
  ]
}
```

このステップでは：
- センサーデータ、品質管理データ、生産計画データなど複数のデータソースを統合
- 製造ラインIDによるデータの関連付け
- 統合データの構造化保存
- 1時間ごとのバッチ処理で実行

### ステップ5：高度な分析モデルの導入

```javascript
// 高度な分析モデルワークフロー
{
  "nodes": [
    {
      "name": "Fetch Integrated Data",
      "type": "n8n-nodes-base.postgres",
      "parameters": {
        "operation": "select",
        "table": "integrated_manufacturing_data",
        "query": "SELECT * FROM integrated_manufacturing_data WHERE timestamp > NOW() - INTERVAL '7 DAYS'"
      }
    },
    {
      "name": "Prepare ML Input",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// 機械学習モデル用の入力準備\nconst data = $input.item.json;\n\n// 特徴量エンジニアリング\nconst mlInput = data.map(d => {\n  // センサーデータの集約（平均値）\n  const sensorData = JSON.parse(d.sensor_data);\n  const avgTemp = sensorData.reduce((sum, s) => sum + s.temperature, 0) / sensorData.length;\n  const avgPress = sensorData.reduce((sum, s) => sum + s.pressure, 0) / sensorData.length;\n  const avgVib = sensorData.reduce((sum, s) => sum + s.vibration, 0) / sensorData.length;\n  \n  // 品質データの集約\n  const qualityData = JSON.parse(d.quality_data);\n  const defectRate = qualityData.reduce((sum, q) => sum + q.defect_count, 0) / qualityData.reduce((sum, q) => sum + q.total_inspected, 0);\n  \n  // 生産データの集約\n  const productionData = JSON.parse(d.production_data);\n  const productionEfficiency = productionData.reduce((sum, p) => sum + p.actual_output, 0) / productionData.reduce((sum, p) => sum + p.planned_output, 0);\n  \n  return {\n    lineId: d.line_id,\n    timestamp: d.timestamp,\n    features: {\n      avgTemperature: avgTemp,\n      avgPressure: avgPress,\n      avgVibration: avgVib,\n      defectRate: defectRate,\n      productionEfficiency: productionEfficiency\n    }\n  };\n});\n\nreturn mlInput;"
      }
    },
    {
      "name": "Call ML Service",
      "type": "n8n-nodes-base.httpRequest",
      "parameters": {
        "url": "http://ml-service.internal/predict",
        "method": "POST",
        "body": "={{JSON.stringify($node[\"Prepare ML Input\"].json)}}",
        "options": {
          "jsonParseResponse": true
        }
      }
    },
    {
      "name": "Process ML Results",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// ML結果の処理\nconst mlResults = $input.item.json;\n\n// 各製造ラインの予測結果を処理\nconst processedResults = mlResults.predictions.map(pred => {\n  return {\n    lineId: pred.lineId,\n    timestamp: new Date().toISOString(),\n    anomalyProbability: pred.anomalyProbability,\n    predictedDefectRate: pred.predictedDefectRate,\n    maintenanceRecommended: pred.anomalyProbability > 0.7,\n    confidenceScore: pred.confidenceScore\n  };\n});\n\nreturn processedResults;"
      }
    },
    {
      "name": "Store ML Results",
      "type": "n8n-nodes-base.postgres",
      "parameters": {
        "operation": "insert",
        "table": "ml_analysis_results",
        "columns": "line_id,timestamp,anomaly_probability,predicted_defect_rate,maintenance_recommended,confidence_score",
        "values": "={{$node[\"Process ML Results\"].json.map(item => `'${item.lineId}','${item.timestamp}',${item.anomalyProbability},${item.predictedDefectRate},${item.maintenanceRecommended},${item.confidenceScore}`).join(\",\")}}"
      }
    }
  ]
}
```

このステップでは：
- 統合データから機械学習モデル用の特徴量を抽出
- 外部ML（機械学習）サービスを呼び出して予測を取得
- 異常検知確率、予測不良率などの高度な分析結果を保存
- 日次バッチで実行

### ステップ6：拡張コンセンサスモデルの構築

```javascript
// 拡張コンセンサスモデルワークフロー
{
  "nodes": [
    {
      "name": "Fetch Statistical Analysis",
      "type": "n8n-nodes-base.postgres",
      "parameters": {
        "operation": "select",
        "table": "statistical_analysis_results",
        "query": "SELECT * FROM statistical_analysis_results WHERE timestamp > NOW() - INTERVAL '7 DAYS'"
      }
    },
    {
      "name": "Fetch ML Analysis",
      "type": "n8n-nodes-base.postgres",
      "parameters": {
        "operation": "select",
        "table": "ml_analysis_results",
        "query": "SELECT * FROM ml_analysis_results WHERE timestamp > NOW() - INTERVAL '7 DAYS'"
      }
    },
    {
      "name": "Fetch Expert Rules",
      "type": "n8n-nodes-base.postgres",
      "parameters": {
        "operation": "select",
        "table": "expert_rule_results",
        "query": "SELECT * FROM expert_rule_results WHERE timestamp > NOW() - INTERVAL '7 DAYS'"
      }
    },
    {
      "name": "Advanced Consensus Formation",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// 拡張コンセンサス形成\nconst statResults = $node[\"Fetch Statistical Analysis\"].json;\nconst mlResults = $node[\"Fetch ML Analysis\"].json;\nconst expertResults = $node[\"Fetch Expert Rules\"].json;\n\n// 製造ラインごとにデータをグループ化\nconst lineIds = [...new Set([...statResults.map(r => r.line_id), ...mlResults.map(r => r.line_id), ...expertResults.map(r => r.line_id)])];\n\nconst consensusResults = [];\n\nfor (const lineId of lineIds) {\n  // 各分析手法の結果を取得\n  const lineStatResults = statResults.filter(r => r.line_id === lineId);\n  const lineMLResults = mlResults.filter(r => r.line_id === lineId);\n  const lineExpertResults = expertResults.filter(r => r.line_id === lineId);\n  \n  // 各手法の重み付け（信頼性スコアに基づく）\n  const statWeight = 0.2; // 統計分析の重み\n  const mlWeight = 0.5;   // 機械学習の重み\n  const expertWeight = 0.3; // 専門家ルールの重み\n  \n  // 各手法の異常確率を集約\n  let statAnomaly = lineStatResults.length > 0 ? \n    lineStatResults.reduce((sum, r) => sum + r.anomaly_probability, 0) / lineStatResults.length : 0;\n  \n  let mlAnomaly = lineMLResults.length > 0 ? \n    lineMLResults.reduce((sum, r) => sum + r.anomaly_probability, 0) / lineMLResults.length : 0;\n  \n  let expertAnomaly = lineExpertResults.length > 0 ? \n    lineExpertResults.reduce((sum, r) => sum + r.anomaly_probability, 0) / lineExpertResults.length : 0;\n  \n  // 加重平均によるコンセンサス形成\n  const consensusAnomaly = (statAnomaly * statWeight) + (mlAnomaly * mlWeight) + (expertAnomaly * expertWeight);\n  \n  // 信頼性スコアの計算\n  const reliabilityScore = Math.min(\n    (lineStatResults.length > 0 ? 1 : 0) * statWeight + \n    (lineMLResults.length > 0 ? 1 : 0) * mlWeight + \n    (lineExpertResults.length > 0 ? 1 : 0) * expertWeight,\n    1.0\n  );\n  \n  // 推奨アクションの決定\n  let recommendedAction = \"none\";\n  if (consensusAnomaly > 0.8) {\n    recommendedAction = \"immediate_maintenance\";\n  } else if (consensusAnomaly > 0.6) {\n    recommendedAction = \"schedule_maintenance\";\n  } else if (consensusAnomaly > 0.4) {\n    recommendedAction = \"increase_monitoring\";\n  }\n  \n  consensusResults.push({\n    lineId: lineId,\n    timestamp: new Date().toISOString(),\n    consensusAnomalyProbability: consensusAnomaly,\n    reliabilityScore: reliabilityScore,\n    recommendedAction: recommendedAction,\n    contributingSources: {\n      statistical: lineStatResults.length,\n      machineLearning: lineMLResults.length,\n      expertRules: lineExpertResults.length\n    }\n  });\n}\n\nreturn consensusResults;"
      }
    },
    {
      "name": "Store Consensus Results",
      "type": "n8n-nodes-base.postgres",
      "parameters": {
        "operation": "insert",
        "table": "consensus_results",
        "columns": "line_id,timestamp,consensus_anomaly_probability,reliability_score,recommended_action,contributing_sources",
        "values": "={{$node[\"Advanced Consensus Formation\"].json.map(item => `'${item.lineId}','${item.timestamp}',${item.consensusAnomalyProbability},${item.reliabilityScore},'${item.recommendedAction}','${JSON.stringify(item.contributingSources)}'`).join(\",\")}}"
      }
    },
    {
      "name": "Take Actions",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// コンセンサスに基づくアクション実行\nconst consensusResults = $input.item.json;\n\n// 各製造ラインに対するアクションを実行\nconst actionResults = [];\n\nfor (const result of consensusResults) {\n  let actionTaken = \"none\";\n  let actionSuccess = true;\n  \n  try {\n    if (result.recommendedAction === \"immediate_maintenance\") {\n      // 緊急保守の予約APIを呼び出す（実際の実装では外部APIを呼び出す）\n      actionTaken = \"scheduled_emergency_maintenance\";\n    } else if (result.recommendedAction === \"schedule_maintenance\") {\n      // 定期保守の予約APIを呼び出す\n      actionTaken = \"scheduled_regular_maintenance\";\n    } else if (result.recommendedAction === \"increase_monitoring\") {\n      // モニタリング頻度を上げる設定を行う\n      actionTaken = \"increased_monitoring_frequency\";\n    }\n  } catch (error) {\n    actionSuccess = false;\n  }\n  \n  actionResults.push({\n    lineId: result.lineId,\n    timestamp: new Date().toISOString(),\n    recommendedAction: result.recommendedAction,\n    actionTaken: actionTaken,\n    actionSuccess: actionSuccess\n  });\n}\n\nreturn actionResults;"
      }
    },
    {
      "name": "Store Action Results",
      "type": "n8n-nodes-base.postgres",
      "parameters": {
        "operation": "insert",
        "table": "action_results",
        "columns": "line_id,timestamp,recommended_action,action_taken,action_success",
        "values": "={{$node[\"Take Actions\"].json.map(item => `'${item.lineId}','${item.timestamp}','${item.recommendedAction}','${item.actionTaken}',${item.actionSuccess}`).join(\",\")}}"
      }
    }
  ]
}
```

このステップでは：
- 統計分析、機械学習、専門家ルールなど複数の分析手法の結果を統合
- 信頼性スコアに基づく重み付けによる高度なコンセンサス形成
- 異常確率に応じた推奨アクションの決定
- コンセンサスに基づくアクションの自動実行
- 日次バッチで実行

## フェーズ3：本番環境への展開と最適化（6-12ヶ月）

第3フェーズでは、全社的な展開とリアルタイム処理の導入、継続的な最適化を行います。

### ステップ7：リアルタイム処理の導入

```javascript
// リアルタイム処理ワークフロー
{
  "nodes": [
    {
      "name": "Sensor Data Webhook",
      "type": "n8n-nodes-base.webhook",
      "parameters": {
        "path": "manufacturing/sensor-data",
        "responseMode": "lastNode",
        "options": {
          "responseCode": 200,
          "responseData": "firstEntryJson"
        }
      }
    },
    {
      "name": "Realtime Data Validation",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// リアルタイムデータの検証\nconst data = $input.item.json;\n\n// 基本的なデータ検証\nconst isValid = (\n  data.machineId && \n  data.timestamp && \n  typeof data.temperature === 'number' && \n  typeof data.pressure === 'number' && \n  typeof data.vibration === 'number'\n);\n\nif (!isValid) {\n  return { valid: false, error: 'Invalid data format' };\n}\n\n// 異常値の検出（簡易チェック）\nconst tempInRange = data.temperature >= -50 && data.temperature <= 200;\nconst pressInRange = data.pressure >= 0 && data.pressure <= 1000;\nconst vibInRange = data.vibration >= 0 && data.vibration <= 100;\n\nif (!tempInRange || !pressInRange || !vibInRange) {\n  return { \n    valid: false, \n    error: 'Data out of expected range',\n    details: {\n      tempInRange,\n      pressInRange,\n      vibInRange\n    }\n  };\n}\n\nreturn { \n  valid: true, \n  data: {\n    machineId: data.machineId,\n    timestamp: data.timestamp,\n    temperature: data.temperature,\n    pressure: data.pressure,\n    vibration: data.vibration\n  }\n};"
      }
    },
    {
      "name": "Valid Data?",
      "type": "n8n-nodes-base.if",
      "parameters": {
        "conditions": {
          "boolean": [
            {
              "value1": "={{$node[\"Realtime Data Validation\"].json[\"valid\"]}}",
              "value2": true
            }
          ]
        }
      }
    },
    {
      "name": "Log Invalid Data",
      "type": "n8n-nodes-base.postgres",
      "parameters": {
        "operation": "insert",
        "table": "invalid_sensor_data_log",
        "columns": "timestamp,data,error",
        "values": "='{{$now}}','{{JSON.stringify($input.item.json)}}','{{$node[\"Realtime Data Validation\"].json[\"error\"]}}'"
      }
    },
    {
      "name": "Stream to Kafka",
      "type": "n8n-nodes-base.kafka",
      "parameters": {
        "authentication": "username",
        "topic": "manufacturing-sensor-data",
        "brokers": "kafka:9092",
        "value": "={{JSON.stringify($node[\"Realtime Data Validation\"].json[\"data\"])}}",
        "key": "={{$node[\"Realtime Data Validation\"].json[\"data\"][\"machineId\"]}}"
      }
    },
    {
      "name": "Realtime Anomaly Detection",
      "type": "n8n-nodes-base.httpRequest",
      "parameters": {
        "url": "http://realtime-ml-service.internal/detect-anomaly",
        "method": "POST",
        "body": "={{JSON.stringify($node[\"Realtime Data Validation\"].json[\"data\"])}}",
        "options": {
          "jsonParseResponse": true
        }
      }
    },
    {
      "name": "Is Anomaly?",
      "type": "n8n-nodes-base.if",
      "parameters": {
        "conditions": {
          "boolean": [
            {
              "value1": "={{$node[\"Realtime Anomaly Detection\"].json[\"isAnomaly\"]}}",
              "value2": true
            }
          ]
        }
      }
    },
    {
      "name": "Send Realtime Alert",
      "type": "n8n-nodes-base.httpRequest",
      "parameters": {
        "url": "http://alert-service.internal/send-alert",
        "method": "POST",
        "body": "={{\n  \"machineId\": $node[\"Realtime Data Validation\"].json[\"data\"][\"machineId\"],\n  \"timestamp\": $node[\"Realtime Data Validation\"].json[\"data\"][\"timestamp\"],\n  \"anomalyScore\": $node[\"Realtime Anomaly Detection\"].json[\"anomalyScore\"],\n  \"anomalyType\": $node[\"Realtime Anomaly Detection\"].json[\"anomalyType\"],\n  \"alertPriority\": \"high\"\n}}",
        "options": {
          "jsonParseResponse": true
        }
      }
    }
  ]
}
```

このステップでは：
- Webhookを使用したリアルタイムデータ受信
- データの即時検証と異常値チェック
- Kafkaなどのメッセージングシステムへのストリーミング
- リアルタイム異常検知と即時アラート
- イベント駆動型アーキテクチャの導入

### ステップ8：全社的な展開と統合

```javascript
// 全社的な展開と統合ワークフロー
{
  "nodes": [
    {
      "name": "Enterprise Integration Hub",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// 全社的な統合ハブ\nconst integrationConfig = {\n  // 工場ごとの設定\n  factories: [\n    {\n      id: 'FACTORY001',\n      name: 'Main Production Facility',\n      lines: ['LINE001', 'LINE002', 'LINE003'],\n      dataSourceEndpoints: {\n        sensors: 'http://factory001-api.internal/sensor-data',\n        quality: 'http://factory001-api.internal/quality-data',\n        production: 'http://factory001-api.internal/production-data'\n      }\n    },\n    {\n      id: 'FACTORY002',\n      name: 'Secondary Production Facility',\n      lines: ['LINE004', 'LINE005'],\n      dataSourceEndpoints: {\n        sensors: 'http://factory002-api.internal/sensor-data',\n        quality: 'http://factory002-api.internal/quality-data',\n        production: 'http://factory002-api.internal/production-data'\n      }\n    },\n    {\n      id: 'FACTORY003',\n      name: 'Assembly Facility',\n      lines: ['LINE006', 'LINE007', 'LINE008', 'LINE009'],\n      dataSourceEndpoints: {\n        sensors: 'http://factory003-api.internal/sensor-data',\n        quality: 'http://factory003-api.internal/quality-data',\n        production: 'http://factory003-api.internal/production-data'\n      }\n    }\n  ],\n  \n  // 全社的なシステム統合\n  enterpriseSystems: {\n    erp: 'http://erp-api.internal',\n    mes: 'http://mes-api.internal',\n    cmms: 'http://cmms-api.internal',\n    qms: 'http://qms-api.internal'\n  },\n  \n  // データウェアハウス設定\n  dataWarehouse: {\n    connectionString: 'postgresql://username:password@datawarehouse:5432/manufacturing_dw',\n    schemas: {\n      staging: 'stg',\n      production: 'prod',\n      reporting: 'rpt'\n    }\n  }\n};\n\nreturn { integrationConfig };"
      }
    },
    {
      "name": "Factory Data Collection",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// 全工場からのデータ収集\nconst config = $node[\"Enterprise Integration Hub\"].json.integrationConfig;\n\n// 各工場からデータを収集\nconst factoryData = [];\n\nfor (const factory of config.factories) {\n  try {\n    // センサーデータの収集（実際の実装では外部APIを呼び出す）\n    const sensorData = { factory: factory.id, type: 'sensor', data: [] };\n    \n    // 品質データの収集\n    const qualityData = { factory: factory.id, type: 'quality', data: [] };\n    \n    // 生産データの収集\n    const productionData = { factory: factory.id, type: 'production', data: [] };\n    \n    factoryData.push(sensorData, qualityData, productionData);\n  } catch (error) {\n    // エラーログ\n    console.error(`Error collecting data from factory ${factory.id}: ${error.message}`);\n  }\n}\n\nreturn { factoryData };"
      }
    },
    {
      "name": "Enterprise Data Integration",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// 全社データの統合\nconst config = $node[\"Enterprise Integration Hub\"].json.integrationConfig;\nconst factoryData = $node[\"Factory Data Collection\"].json.factoryData;\n\n// ERPからの生産計画データ取得（実際の実装では外部APIを呼び出す）\nconst productionPlans = [];\n\n// MESからの製造実行データ取得\nconst executionData = [];\n\n// CMMSからの保守データ取得\nconst maintenanceData = [];\n\n// QMSからの品質データ取得\nconst qualitySystemData = [];\n\n// 全社的なデータ統合\nconst enterpriseData = {\n  timestamp: new Date().toISOString(),\n  factories: factoryData.reduce((acc, curr) => {\n    if (!acc[curr.factory]) {\n      acc[curr.factory] = {};\n    }\n    acc[curr.factory][curr.type] = curr.data;\n    return acc;\n  }, {}),\n  enterpriseSystems: {\n    productionPlans,\n    executionData,\n    maintenanceData,\n    qualitySystemData\n  }\n};\n\nreturn enterpriseData;"
      }
    },
    {
      "name": "Load to Data Warehouse",
      "type": "n8n-nodes-base.postgres",
      "parameters": {
        "operation": "executeQuery",
        "query": "-- 統合データをデータウェアハウスのステージングエリアに挿入\nINSERT INTO stg.enterprise_integrated_data\n(timestamp, data)\nVALUES\n('{{$node[\"Enterprise Data Integration\"].json.timestamp}}', '{{JSON.stringify($node[\"Enterprise Data Integration\"].json)}}')"
      }
    },
    {
      "name": "Enterprise Consensus Model",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// 全社的なコンセンサスモデル\nconst enterpriseData = $node[\"Enterprise Data Integration\"].json;\n\n// 各工場の分析結果を取得（実際の実装では分析サービスを呼び出す）\nconst factoryAnalysisResults = Object.keys(enterpriseData.factories).map(factoryId => {\n  return {\n    factoryId,\n    analysisResults: {\n      anomalyScore: Math.random(), // ダミーデータ\n      qualityScore: Math.random(),\n      efficiencyScore: Math.random(),\n      maintenanceScore: Math.random()\n    }\n  };\n});\n\n// 全社的なコンセンサス形成\nconst enterpriseConsensus = {\n  timestamp: new Date().toISOString(),\n  overallHealthScore: factoryAnalysisResults.reduce((sum, factory) => {\n    return sum + (1 - factory.analysisResults.anomalyScore) / factoryAnalysisResults.length;\n  }, 0),\n  overallQualityScore: factoryAnalysisResults.reduce((sum, factory) => {\n    return sum + factory.analysisResults.qualityScore / factoryAnalysisResults.length;\n  }, 0),\n  overallEfficiencyScore: factoryAnalysisResults.reduce((sum, factory) => {\n    return sum + factory.analysisResults.efficiencyScore / factoryAnalysisResults.length;\n  }, 0),\n  factoryScores: factoryAnalysisResults.reduce((acc, factory) => {\n    acc[factory.factoryId] = factory.analysisResults;\n    return acc;\n  }, {}),\n  recommendations: []\n};\n\n// 全社的な推奨事項の生成\nif (enterpriseConsensus.overallHealthScore < 0.7) {\n  enterpriseConsensus.recommendations.push({\n    type: 'maintenance',\n    priority: 'high',\n    description: 'Schedule comprehensive maintenance across all facilities'\n  });\n}\n\nif (enterpriseConsensus.overallQualityScore < 0.8) {\n  enterpriseConsensus.recommendations.push({\n    type: 'quality',\n    priority: 'medium',\n    description: 'Review quality control processes and standards'\n  });\n}\n\nif (enterpriseConsensus.overallEfficiencyScore < 0.75) {\n  enterpriseConsensus.recommendations.push({\n    type: 'efficiency',\n    priority: 'medium',\n    description: 'Optimize production scheduling and resource allocation'\n  });\n}\n\nreturn enterpriseConsensus;"
      }
    },
    {
      "name": "Store Enterprise Consensus",
      "type": "n8n-nodes-base.postgres",
      "parameters": {
        "operation": "insert",
        "table": "enterprise_consensus_results",
        "columns": "timestamp,overall_health_score,overall_quality_score,overall_efficiency_score,factory_scores,recommendations",
        "values": "='{{$node[\"Enterprise Consensus Model\"].json.timestamp}}',{{$node[\"Enterprise Consensus Model\"].json.overallHealthScore}},{{$node[\"Enterprise Consensus Model\"].json.overallQualityScore}},{{$node[\"Enterprise Consensus Model\"].json.overallEfficiencyScore}},'{{JSON.stringify($node[\"Enterprise Consensus Model\"].json.factoryScores)}}','{{JSON.stringify($node[\"Enterprise Consensus Model\"].json.recommendations)}}'"
      }
    },
    {
      "name": "Generate Executive Dashboard",
      "type": "n8n-nodes-base.httpRequest",
      "parameters": {
        "url": "http://dashboard-service.internal/update-executive-dashboard",
        "method": "POST",
        "body": "={{JSON.stringify($node[\"Enterprise Consensus Model\"].json)}}",
        "options": {
          "jsonParseResponse": true
        }
      }
    }
  ]
}
```

このステップでは：
- 複数工場からのデータ統合
- ERP、MES、CMMS、QMSなど全社システムとの連携
- データウェアハウスへのデータロード
- 全社的なコンセンサスモデルの構築
- 経営層向けダッシュボードの生成

### ステップ9：継続的な最適化と自己学習

```javascript
// 継続的な最適化と自己学習ワークフロー
{
  "nodes": [
    {
      "name": "Fetch Historical Results",
      "type": "n8n-nodes-base.postgres",
      "parameters": {
        "operation": "select",
        "table": "consensus_results",
        "query": "SELECT cr.*, ar.action_taken, ar.action_success FROM consensus_results cr LEFT JOIN action_results ar ON cr.line_id = ar.line_id AND cr.recommended_action = ar.recommended_action WHERE cr.timestamp > NOW() - INTERVAL '90 DAYS'"
      }
    },
    {
      "name": "Evaluate Model Performance",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// モデルパフォーマンスの評価\nconst results = $input.item.json;\n\n// 各製造ラインごとの評価\nconst lineIds = [...new Set(results.map(r => r.line_id))];\n\nconst performanceMetrics = lineIds.map(lineId => {\n  // 該当ラインの結果を取得\n  const lineResults = results.filter(r => r.line_id === lineId);\n  \n  // アクションの成功率を計算\n  const actionsWithResults = lineResults.filter(r => r.action_taken !== null);\n  const successfulActions = actionsWithResults.filter(r => r.action_success === true);\n  const actionSuccessRate = actionsWithResults.length > 0 ? \n    successfulActions.length / actionsWithResults.length : 0;\n  \n  // 異常検知の精度を評価（実際の実装では実際の異常発生データと比較）\n  const anomalyDetectionAccuracy = 0.8; // ダミーデータ\n  \n  // 推奨アクションの適切さを評価\n  const appropriateActions = lineResults.filter(r => {\n    // 実際の実装では、アクションの結果と期待される結果を比較\n    return true; // ダミーデータ\n  });\n  const actionAppropriatenessRate = lineResults.length > 0 ? \n    appropriateActions.length / lineResults.length : 0;\n  \n  return {\n    lineId,\n    metrics: {\n      actionSuccessRate,\n      anomalyDetectionAccuracy,\n      actionAppropriatenessRate,\n      overallScore: (actionSuccessRate + anomalyDetectionAccuracy + actionAppropriatenessRate) / 3\n    }\n  };\n});\n\nreturn { performanceMetrics };"
      }
    },
    {
      "name": "Generate Optimization Recommendations",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// 最適化推奨事項の生成\nconst metrics = $node[\"Evaluate Model Performance\"].json.performanceMetrics;\n\n// 各製造ラインに対する推奨事項\nconst optimizationRecommendations = metrics.map(lineMetric => {\n  const recommendations = [];\n  \n  // アクション成功率が低い場合\n  if (lineMetric.metrics.actionSuccessRate < 0.7) {\n    recommendations.push({\n      type: 'action_improvement',\n      description: 'Review and refine action implementation process',\n      suggestedChanges: [\n        'Improve communication with maintenance team',\n        'Refine action timing and prioritization',\n        'Enhance action tracking and feedback loop'\n      ]\n    });\n  }\n  \n  // 異常検知精度が低い場合\n  if (lineMetric.metrics.anomalyDetectionAccuracy < 0.75) {\n    recommendations.push({\n      type: 'model_improvement',\n      description: 'Enhance anomaly detection models',\n      suggestedChanges: [\n        'Collect more training data for specific scenarios',\n        'Tune model hyperparameters',\n        'Consider ensemble approach with multiple detection methods'\n      ]\n    });\n  }\n  \n  // 推奨アクションの適切さが低い場合\n  if (lineMetric.metrics.actionAppropriatenessRate < 0.8) {\n    recommendations.push({\n      type: 'decision_logic_improvement',\n      description: 'Refine decision logic for action recommendations',\n      suggestedChanges: [\n        'Adjust thresholds for different action types',\n        'Incorporate more context in decision making',\n        'Implement feedback loop from maintenance outcomes'\n      ]\n    });\n  }\n  \n  return {\n    lineId: lineMetric.lineId,\n    overallScore: lineMetric.metrics.overallScore,\n    recommendations\n  };\n});\n\nreturn { optimizationRecommendations };"
      }
    },
    {
      "name": "Update Model Parameters",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// モデルパラメータの更新\nconst recommendations = $node[\"Generate Optimization Recommendations\"].json.optimizationRecommendations;\n\n// 各製造ラインのモデルパラメータを更新\nconst parameterUpdates = recommendations.map(rec => {\n  // 現在のパラメータを取得（実際の実装ではデータベースから取得）\n  const currentParameters = {\n    lineId: rec.lineId,\n    anomalyDetectionThreshold: 0.7,\n    actionThresholds: {\n      immediate_maintenance: 0.8,\n      schedule_maintenance: 0.6,\n      increase_monitoring: 0.4\n    },\n    modelWeights: {\n      statistical: 0.2,\n      machineLearning: 0.5,\n      expertRules: 0.3\n    }\n  };\n  \n  // 推奨事項に基づいてパラメータを調整\n  const updatedParameters = { ...currentParameters };\n  \n  for (const r of rec.recommendations) {\n    if (r.type === 'model_improvement') {\n      // 異常検知モデルの改善\n      if (rec.overallScore < 0.7) {\n        // 精度が低い場合、機械学習の重みを下げ、専門家ルールの重みを上げる\n        updatedParameters.modelWeights.machineLearning -= 0.1;\n        updatedParameters.modelWeights.expertRules += 0.1;\n      }\n    }\n    \n    if (r.type === 'decision_logic_improvement') {\n      // 決定ロジックの改善\n      if (rec.overallScore < 0.7) {\n        // 精度が低い場合、アクション閾値を調整\n        updatedParameters.actionThresholds.immediate_maintenance += 0.05;\n        updatedParameters.actionThresholds.schedule_maintenance += 0.05;\n      }\n    }\n  }\n  \n  // 重みの正規化（合計が1になるように）\n  const weightSum = Object.values(updatedParameters.modelWeights).reduce((sum, w) => sum + w, 0);\n  for (const key in updatedParameters.modelWeights) {\n    updatedParameters.modelWeights[key] /= weightSum;\n  }\n  \n  return {\n    lineId: rec.lineId,\n    currentParameters,\n    updatedParameters,\n    changeRationale: rec.recommendations.map(r => r.description).join('; ')\n  };\n});\n\nreturn { parameterUpdates };"
      }
    },
    {
      "name": "Apply Parameter Updates",
      "type": "n8n-nodes-base.postgres",
      "parameters": {
        "operation": "executeQuery",
        "query": "-- パラメータ更新をデータベースに適用\nINSERT INTO model_parameter_history\n(line_id, timestamp, previous_parameters, updated_parameters, change_rationale)\nVALUES\n{{$node[\"Update Model Parameters\"].json.parameterUpdates.map(update => `('${update.lineId}', NOW(), '${JSON.stringify(update.currentParameters)}', '${JSON.stringify(update.updatedParameters)}', '${update.changeRationale}')`).join(\",\")}};\n\n-- 現在のパラメータを更新\nUPDATE model_parameters\nSET \n  parameters = jsonb_set(parameters, '{anomalyDetectionThreshold}', '{{update.updatedParameters.anomalyDetectionThreshold}}'),\n  parameters = jsonb_set(parameters, '{actionThresholds}', '{{JSON.stringify(update.updatedParameters.actionThresholds)}}'),\n  parameters = jsonb_set(parameters, '{modelWeights}', '{{JSON.stringify(update.updatedParameters.modelWeights)}}')\nFROM (VALUES\n  {{$node[\"Update Model Parameters\"].json.parameterUpdates.map(update => `('${update.lineId}')`).join(\",\")}}\n) AS updates(line_id)\nWHERE model_parameters.line_id = updates.line_id;"
      }
    },
    {
      "name": "Schedule Model Retraining",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "// モデル再トレーニングのスケジュール\nconst parameterUpdates = $node[\"Update Model Parameters\"].json.parameterUpdates;\n\n// 再トレーニングが必要なラインを特定\nconst linesToRetrain = parameterUpdates.filter(update => {\n  // パラメータの変更が大きい場合に再トレーニングをスケジュール\n  const parameterChanges = [];\n  \n  // 異常検知閾値の変化を確認\n  const thresholdChange = Math.abs(update.updatedParameters.anomalyDetectionThreshold - update.currentParameters.anomalyDetectionThreshold);\n  if (thresholdChange > 0.05) {\n    parameterChanges.push(`anomalyDetectionThreshold changed by ${thresholdChange.toFixed(2)}`);\n  }\n  \n  // モデル重みの変化を確認\n  for (const key in update.updatedParameters.modelWeights) {\n    const weightChange = Math.abs(update.updatedParameters.modelWeights[key] - update.currentParameters.modelWeights[key]);\n    if (weightChange > 0.05) {\n      parameterChanges.push(`${key} weight changed by ${weightChange.toFixed(2)}`);\n    }\n  }\n  \n  return parameterChanges.length > 0;\n}).map(update => update.lineId);\n\n// 再トレーニングジョブのスケジュール（実際の実装ではジョブスケジューラーを呼び出す）\nconst retrainingJobs = linesToRetrain.map(lineId => {\n  return {\n    lineId,\n    jobId: `retrain_${lineId}_${Date.now()}`,\n    scheduledTime: new Date(Date.now() + 3600000).toISOString(), // 1時間後にスケジュール\n    status: 'scheduled'\n  };\n});\n\nreturn { retrainingJobs };"
      }
    },
    {
      "name": "Store Retraining Jobs",
      "type": "n8n-nodes-base.postgres",
      "parameters": {
        "operation": "insert",
        "table": "model_retraining_jobs",
        "columns": "line_id,job_id,scheduled_time,status",
        "values": "={{$node[\"Schedule Model Retraining\"].json.retrainingJobs.map(job => `'${job.lineId}','${job.jobId}','${job.scheduledTime}','${job.status}'`).join(\",\")}}"
      }
    }
  ]
}
```

このステップでは：
- 過去の結果データに基づくモデルパフォーマンスの評価
- 最適化推奨事項の自動生成
- モデルパラメータの自動調整
- 必要に応じたモデル再トレーニングのスケジュール
- 継続的な改善サイクルの確立

## 実装時の注意点と推奨事項

### データ品質と前処理

製造業のデータは、センサーの故障、通信エラー、人的ミスなどにより品質の問題が発生することがあります。以下の点に注意してください：

1. **データ検証と浄化**：すべての入力データに対して厳格な検証を行い、異常値や欠損値を適切に処理します。
2. **標準化と正規化**：異なるスケールのセンサーデータを適切に標準化し、分析モデルの精度を向上させます。
3. **特徴量エンジニアリング**：製造プロセスの特性を反映した有意義な特徴量を作成します。

### スケーラビリティとパフォーマンス

製造環境では、多数のセンサーから大量のデータが生成されるため、スケーラビリティが重要です：

1. **階層的データ処理**：エッジでの前処理、ゲートウェイでの集約、クラウドでの高度な分析という階層的アプローチを採用します。
2. **バッチ処理とストリーム処理の組み合わせ**：リアルタイム性が求められる異常検知にはストリーム処理、詳細な分析にはバッチ処理を使い分けます。
3. **リソース使用量の最適化**：n8nワークフローのスケジューリングとリソース割り当てを最適化し、システム全体のパフォーマンスを向上させます。

### セキュリティと規制遵守

製造データには機密情報が含まれることがあり、適切なセキュリティ対策が必要です：

1. **データ暗号化**：保存データと転送中のデータの両方を暗号化します。
2. **アクセス制御**：役割ベースのアクセス制御を実装し、必要最小限の権限原則を適用します。
3. **監査ログ**：すべてのシステムアクセスと変更を記録し、監査証跡を維持します。
4. **規制遵守**：業界固有の規制（例：ISO 9001、GMP）に準拠したデータ管理を行います。

### 変更管理とバージョン管理

コンセンサスモデルの進化に伴い、適切な変更管理が重要です：

1. **ワークフローのバージョン管理**：n8nワークフローの変更を追跡し、必要に応じて以前のバージョンに戻せるようにします。
2. **モデルのバージョン管理**：分析モデルのバージョンを管理し、パフォーマンスの変化を追跡します。
3. **A/Bテスト**：新しいモデルやパラメータを本番環境に適用する前に、限定的なA/Bテストを実施します。

### ユーザートレーニングとドキュメント

システムの効果的な利用と維持のために、適切なトレーニングとドキュメントが必要です：

1. **運用マニュアル**：システムの日常的な運用手順を文書化します。
2. **トラブルシューティングガイド**：一般的な問題と解決策を文書化します。
3. **ユーザートレーニング**：エンドユーザー（製造エンジニア、品質管理者など）に適切なトレーニングを提供します。

## まとめ

この段階的実装ガイドに従うことで、製造業におけるコンセンサスモデルを効果的に実装できます。小規模なプロトタイプから始め、徐々に機能を拡張し、最終的には全社的な展開と継続的な最適化を行うことで、製造プロセスの効率化、品質向上、コスト削減を実現できます。

各フェーズで得られた知見を次のフェーズに活かし、製造環境の特性に合わせてカスタマイズすることが成功の鍵となります。また、技術的な実装だけでなく、組織的な変更管理とユーザー受け入れも重要な成功要因です。
