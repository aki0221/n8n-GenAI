### 2.3. パフォーマンス最適化の考慮事項

コンセンサスモデルを実際の環境で運用する際には、特に大量のトピックや頻繁な更新が発生する場合、システムのパフォーマンスが重要な課題となります。このセクションでは、コンセンサス基準の適用と重み付け調整のパフォーマンスを最適化するための具体的な戦略と実装方法について詳細に解説します。

#### キャッシュ戦略の実装

コンセンサスモデルの運用において、頻繁にアクセスされるデータや計算結果をキャッシュすることで、システム全体のパフォーマンスを大幅に向上させることができます。特に、コンセンサスパラメータや計算済みの重みなど、短期間で頻繁に参照されるが更新頻度は比較的低いデータは、キャッシュの良い候補となります。

例えば、Redisのようなインメモリキャッシュシステムを活用することで、データベースへのアクセス回数を削減し、応答時間を短縮することができます。以下は、n8nワークフローでRedisキャッシュを実装する例です。

```javascript
// n8n Function Node: Redis Cache Implementation
const redis = require('redis');
const { promisify } = require('util');

// Redisクライアントの設定
const client = redis.createClient({
  host: 'redis-server',
  port: 6379
});

// promisifyでRedisコマンドをPromise化
const getAsync = promisify(client.get).bind(client);
const setAsync = promisify(client.set).bind(client);
const existsAsync = promisify(client.exists).bind(client);

async function getTopicWeightsWithCache(topicId) {
  try {
    // キャッシュキーの設定
    const cacheKey = `topic_weights:${topicId}`;
    
    // キャッシュ確認
    const exists = await existsAsync(cacheKey);
    if (exists) {
      // キャッシュヒット
      const cachedData = await getAsync(cacheKey);
      console.log(`Cache hit for topic ${topicId}`);
      return JSON.parse(cachedData);
    }
    
    // キャッシュミス - データベースからデータを取得
    const dbData = await getTopicWeightsFromDB(topicId);
    
    // 取得したデータをキャッシュに保存（有効期限30分）
    await setAsync(cacheKey, JSON.stringify(dbData), 'EX', 1800);
    console.log(`Cache miss for topic ${topicId}, data cached for 30 minutes`);
    
    return dbData;
  } catch (error) {
    console.error(`Error in cache operation: ${error.message}`);
    // キャッシュエラー時はデータベースから直接取得
    return await getTopicWeightsFromDB(topicId);
  }
}

// データベースからトピック重みを取得する関数（実際の実装はDBに依存）
async function getTopicWeightsFromDB(topicId) {
  // PostgreSQLなどからデータを取得する実装
  // ...
}

// 関数の使用例
const topicId = $input.item.json.topic_id;
const weights = await getTopicWeightsWithCache(topicId);

return {
  json: {
    topic_id: topicId,
    weights: weights,
    cache_status: weights._fromCache ? 'hit' : 'miss'
  }
};
```

このコードでは、トピックIDをキーとして、計算済みの重みをRedisキャッシュに保存しています。キャッシュの有効期限は30分に設定されていますが、この値はデータの更新頻度や鮮度の要件に応じて調整できます。キャッシュヒット時はデータベースアクセスをスキップし、キャッシュミス時やエラー時はデータベースから直接データを取得します。

キャッシュ戦略を実装する際は、キャッシュの一貫性と鮮度のバランスを考慮することが重要です。キャッシュの有効期限を短くすると鮮度は向上しますが、キャッシュヒット率が低下します。逆に、有効期限を長くするとヒット率は向上しますが、古いデータが使用される可能性が高まります。また、データが更新された際にキャッシュを明示的に無効化する仕組みも検討すべきです。

#### バッチ処理の実装

個別のトピックごとに重み調整を行うのではなく、複数のトピックをまとめて処理するバッチワークフローを設計することで、システム全体の効率を向上させることができます。特に、定期的な更新や大量のトピックを処理する場合に有効です。

以下は、n8nでバッチ処理を実装する例です。

```javascript
// n8n Function Node: Batch Weight Adjustment
// 複数のトピックIDを入力として受け取り、一括で重み調整を行う

const topicIds = $input.item.json.topic_ids; // トピックIDの配列
if (!Array.isArray(topicIds) || topicIds.length === 0) {
  throw new Error("Invalid or empty topic_ids array");
}

// バッチサイズの設定（一度に処理するトピック数）
const BATCH_SIZE = 50;
const results = [];

// トピックをバッチに分割して処理
for (let i = 0; i < topicIds.length; i += BATCH_SIZE) {
  const batchTopicIds = topicIds.slice(i, i + BATCH_SIZE);
  console.log(`Processing batch ${Math.floor(i/BATCH_SIZE) + 1}, topics: ${batchTopicIds.length}`);
  
  // バッチ内のトピック情報を一括取得
  const topicInfoBatch = await getTopicInfoBatch(batchTopicIds);
  
  // アクティブなコンセンサスパラメータを取得（バッチ内で共通）
  const consensusParameters = await getActiveConsensusParameters();
  
  // バッチ内の各トピックに対して重み調整を実行
  for (const topicId of batchTopicIds) {
    try {
      const topicInfo = topicInfoBatch[topicId];
      if (!topicInfo) {
        console.warn(`Topic info not found for topic ${topicId}`);
        continue;
      }
      
      // 重み調整処理（前述の関数を使用）
      const baseWeights = {
        technology: consensusParameters.perspectiveWeights.technology,
        market: consensusParameters.perspectiveWeights.market,
        business: consensusParameters.perspectiveWeights.business
      };
      
      const adjustedWeights = adjustWeightsByTopicNature(baseWeights, topicInfo);
      const furtherAdjustedWeights = adjustWeightsByChangeStage(adjustedWeights, topicInfo);
      const finalWeights = adjustWeightsByConfidence(furtherAdjustedWeights, topicInfo);
      const normalizedWeights = normalizeWeights(finalWeights);
      
      // 結果を配列に追加
      results.push({
        topic_id: topicId,
        topic_name: topicInfo.name,
        adjusted_weights: normalizedWeights
      });
    } catch (error) {
      console.error(`Error processing topic ${topicId}: ${error.message}`);
      results.push({
        topic_id: topicId,
        error: true,
        message: error.message
      });
    }
  }
}

// 処理結果をまとめて返す
return {
  json: {
    total_topics: topicIds.length,
    processed_topics: results.length,
    success_count: results.filter(r => !r.error).length,
    error_count: results.filter(r => r.error).length,
    results: results
  }
};

// トピック情報をバッチで取得する関数（実際の実装はDBに依存）
async function getTopicInfoBatch(topicIds) {
  // PostgreSQLなどから複数のトピック情報を一括取得する実装
  // ...
}
```

このコードでは、トピックIDの配列を入力として受け取り、バッチサイズ（例：50）ごとに分割して処理しています。各バッチ内では、トピック情報を一括取得し、共通のコンセンサスパラメータを使用して各トピックの重み調整を行います。これにより、データベースアクセスの回数を削減し、処理効率を向上させることができます。

バッチ処理を実装する際は、適切なバッチサイズの設定が重要です。バッチサイズが大きすぎると、メモリ使用量が増加し、処理時間も長くなる可能性があります。逆に、バッチサイズが小さすぎると、バッチ処理のメリットが十分に得られません。システムのリソース状況や処理の特性に応じて、最適なバッチサイズを実験的に決定することが望ましいです。

#### データベース最適化

コンセンサスモデルの運用において、データベースのパフォーマンスは全体の効率に大きな影響を与えます。特に、`topic_weights`テーブルや関連テーブルに適切なインデックスを作成し、定期的なメンテナンスを行うことで、クエリのパフォーマンスを向上させることができます。

以下は、PostgreSQLでのデータベース最適化の例です。

```sql
-- topic_weightsテーブルに適切なインデックスを作成
CREATE INDEX idx_topic_weights_topic_id ON topic_weights(topic_id);
CREATE INDEX idx_topic_weights_created_at ON topic_weights(created_at);

-- 複合インデックスの作成（特定の検索パターンに最適化）
CREATE INDEX idx_topic_weights_combined ON topic_weights(topic_id, created_at);

-- テーブル統計情報の更新（クエリプランナーの最適化に役立つ）
ANALYZE topic_weights;

-- 定期的なバキューム処理（不要な領域の回収と再利用）
VACUUM ANALYZE topic_weights;

-- 自動バキュームの設定調整
ALTER TABLE topic_weights SET (
  autovacuum_vacuum_threshold = 50,
  autovacuum_analyze_threshold = 50,
  autovacuum_vacuum_scale_factor = 0.1,
  autovacuum_analyze_scale_factor = 0.05
);
```

これらのSQLコマンドは、`topic_weights`テーブルのパフォーマンスを最適化するためのものです。適切なインデックスを作成することで、特定のカラムに基づく検索や並べ替えが高速化されます。また、定期的なANALYZEコマンドによってテーブル統計情報を更新し、クエリプランナーがより効率的な実行計画を生成できるようにします。VACUUMコマンドは、削除されたデータの領域を回収し、テーブルの肥大化を防ぎます。

さらに、自動バキュームの設定を調整することで、テーブルの特性に合わせた最適なメンテナンスサイクルを実現できます。例えば、更新頻度の高いテーブルでは、自動バキュームの閾値を低く設定することで、より頻繁にメンテナンスが行われるようにします。

データベース最適化を行う際は、実際のワークロードとクエリパターンを分析し、それに基づいて最適化戦略を立てることが重要です。例えば、頻繁に実行されるクエリを特定し、それらに最適化されたインデックスを作成することで、全体のパフォーマンスを効果的に向上させることができます。

#### 非同期処理の導入

重み調整プロセスのような計算負荷の高い処理を非同期キューに入れることで、Webhookの応答時間を短縮し、システム全体の応答性を向上させることができます。RabbitMQやBullMQなどのメッセージキューシステムを活用することで、効率的な非同期処理が実現できます。

以下は、n8nでRabbitMQを使用した非同期処理の例です。

```javascript
// n8n Function Node: Enqueue Weight Adjustment Task
// 重み調整タスクをRabbitMQキューに追加する

const amqp = require('amqplib');

async function enqueueWeightAdjustmentTask(topicId) {
  let connection;
  try {
    // RabbitMQに接続
    connection = await amqp.connect('amqp://rabbitmq-server:5672');
    const channel = await connection.createChannel();
    
    // キューの宣言
    const queue = 'weight_adjustment_tasks';
    await channel.assertQueue(queue, { durable: true });
    
    // タスクデータの作成
    const taskData = {
      topic_id: topicId,
      timestamp: new Date().toISOString(),
      priority: 'normal'
    };
    
    // キューにタスクを追加
    channel.sendToQueue(queue, Buffer.from(JSON.stringify(taskData)), {
      persistent: true
    });
    
    console.log(`Task for topic ${topicId} enqueued successfully`);
    return true;
  } catch (error) {
    console.error(`Error enqueueing task: ${error.message}`);
    throw error;
  } finally {
    // 接続のクローズ
    if (connection) await connection.close();
  }
}

// Webhook入力からトピックIDを取得
const topicId = $input.item.json.topic_id;

// タスクをキューに追加
const result = await enqueueWeightAdjustmentTask(topicId);

// 即時応答を返す
return {
  json: {
    topic_id: topicId,
    task_enqueued: result,
    message: 'Weight adjustment task has been queued for processing'
  }
};
```

このコードでは、Webhookから受け取ったトピックIDに対する重み調整タスクをRabbitMQキューに追加しています。タスクはキューに追加された後、別のワーカープロセスによって非同期に処理されます。これにより、Webhookは重み調整の完了を待たずに即座に応答を返すことができ、応答時間が大幅に短縮されます。

非同期処理を導入する際は、タスクの状態管理と結果の通知方法も考慮する必要があります。例えば、タスクの進捗状況や完了結果を別のデータベースやキャッシュに保存し、クライアントがそれを後で取得できるようにする仕組みが必要です。また、重要なタスクの場合は、処理結果をWebhookやメールなどで通知する機能も有用です。

#### 分散環境の構築

将来的なスケーラビリティを考慮して、n8nワーカーをスケールアウトし、並列処理能力を向上させる構成を検討することも重要です。特に、大規模な組織や多数のトピックを扱う環境では、単一のn8nインスタンスでは処理能力が不足する可能性があります。

分散環境の構築には、コンテナオーケストレーションツール（KubernetesやDocker Swarmなど）を活用することが効果的です。以下は、Kubernetesを使用したn8n分散環境の概念的な構成例です。

```yaml
# n8n-deployment.yaml (Kubernetes設定例)
apiVersion: apps/v1
kind: Deployment
metadata:
  name: n8n-workers
spec:
  replicas: 3  # ワーカー数
  selector:
    matchLabels:
      app: n8n-worker
  template:
    metadata:
      labels:
        app: n8n-worker
    spec:
      containers:
      - name: n8n
        image: n8nio/n8n:latest
        env:
        - name: N8N_MODE
          value: "queue"
        - name: QUEUE_BULL_REDIS_HOST
          value: "redis-service"
        - name: DB_TYPE
          value: "postgresdb"
        - name: DB_POSTGRESDB_HOST
          value: "postgres-service"
        # その他の環境変数...
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "1Gi"
            cpu: "1000m"
```

この設定例では、3つのn8nワーカーレプリカを作成し、それぞれが独立してキューからタスクを処理できるようにしています。ワーカーはRedisを使用してタスクキューを共有し、PostgreSQLデータベースを使用してワークフローデータを共有します。これにより、負荷が複数のワーカーに分散され、全体の処理能力が向上します。

分散環境を構築する際は、状態の共有と同期に注意する必要があります。例えば、同じトピックに対する複数の同時更新が競合しないように、適切なロック機構やバージョン管理を実装することが重要です。また、ワーカー間でのデータの一貫性を確保するために、共有ストレージやデータベースの設計も慎重に行う必要があります。

以上のように、キャッシュ戦略、バッチ処理、データベース最適化、非同期処理、分散環境の構築など、様々な最適化技術を組み合わせることで、コンセンサスモデルのパフォーマンスと拡張性を大幅に向上させることができます。これらの最適化は、システムの規模や要件に応じて段階的に導入することが望ましく、実際の運用データに基づいて継続的に改善していくことが重要です。
