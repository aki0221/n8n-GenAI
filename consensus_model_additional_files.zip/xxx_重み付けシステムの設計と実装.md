## 2. 重み付けシステムの設計と実装

**目的：読者が実際に重み付けシステムを設計・実装できるようにする**

コンセンサスモデルにおいて、テクノロジー、マーケット、ビジネスという3つの異なる視点からの情報を効果的に統合し、状況に応じた最適な判断を導き出すためには、洗練された重み付けシステムが不可欠です。単に固定的な重みを割り当てるだけでは、変化する状況や多様なトピックの特性に対応できません。本セクションでは、この課題に対応するため、基本となる重みの設定方法から、状況に応じて重みを動的に調整する洗練された仕組み、そしてそれらをn8nワークフローとして具体的に実装する方法まで、重み付けシステムの設計と実装に関する全体像を詳細に解説します。特に、トピックの性質（技術駆動型、市場駆動型など）や変化の段階（初期、成長期など）、さらには各視点から得られる情報の確信度の違いといった要因を考慮に入れた動的な重み調整メカニズムに焦点を当て、これにより、コンセンサスモデルが持つ適応性と精度を最大限に引き出す方法を提供します。

### 2.1. 基本重みの設定方法

重み付けシステムの出発点は、各視点（テクノロジー、マーケット、ビジネス）に基本的な重みを設定することです。この基本重みは、各視点が一般的に持つ役割と影響力を反映したデフォルト値として機能します。しかし、これは単なる初期値であり、後述する動的調整の基盤となるものです。

標準的な設定として、以下の基本重みを推奨します：

-   **マーケット視点：0.40**
-   **テクノロジー視点：0.30**
-   **ビジネス視点：0.30**

マーケット視点に最も高い重み（0.40）を設定する根拠は、多くの場合、市場の受容性や需要が意思決定の成否を左右する最も重要な要因となるためです。顧客が何を求めているか、市場がどのように変化しているかを的確に捉えることは、技術開発やビジネスモデル構築の方向性を決定づける上で不可欠です。マーケット視点は、しばしば変化の先行指標として機能し、早期に機会や脅威を察知するための重要なセンサーとなります。

テクノロジー視点とビジネス視点には、それぞれ同等の重み（0.30）を設定します。テクノロジー視点は、アイデアやコンセプトを実現するための技術的な基盤を提供します。その実現可能性、開発難易度、将来性などを評価する役割は、マーケット視点やビジネス視点と同等に重要です。一方、ビジネス視点は、市場機会と技術的可能性を、持続可能な事業として成立させるための実効性を評価します。収益性、コスト、戦略的適合性などを評価するこの視点もまた、他の2つの視点と同等の重要性を持つと考えられます。

| 視点       | 基本重み | 役割       | 重み付けの根拠                                           |
| :--------- | :------- | :--------- | :------------------------------------------------------- |
| マーケット | 0.40     | 先行指標   | 市場の受容性・需要が基点となるため、やや高い重みを設定 |
| テクノロジー | 0.30     | 基盤       | 技術的実現可能性が基盤となるため、中程度の重みを設定     |
| ビジネス   | 0.30     | 実効性評価 | 事業としての成立性を判断するため、中程度の重みを設定     |

**重要**: これらの基本重みは、あくまで標準的な出発点です。組織の特性、業界、あるいは特定の意思決定の文脈に応じて、これらの**基本重み自体を調整することが推奨されます**。例えば、研究開発に重点を置く組織であればテクノロジー視点の基本重みを高めに設定したり、規制の厳しい業界であればビジネス視点（コンプライアンス側面を含む）の基本重みを高めに設定したりすることが考えられます。組織内で議論し、合意形成を図った上で、自組織に最適な基本重みを設定することが、効果的なコンセンサスモデル運用の第一歩となります。

### 2.2. 動的重み付け調整の仕組み

設定した基本重みは、コンセンサスモデルの出発点ですが、真の適応性と精度を実現するためには、状況に応じてこれらの重みを動的に調整する仕組みが必要です。全ての意思決定シナリオで同じ重み付けが最適であるとは限らないからです。ここでは、重みを動的に調整するための主要な要因と、その具体的な調整メカニズムについて解説します。

動的調整において考慮すべき主要な要因は以下の3つです：

1.  **トピックの性質**：評価対象が技術革新中心か、市場変化中心か、ビジネスモデル変革中心かによって、重視すべき視点は異なります。
    *   **技術駆動型 (Technology-driven)**：量子コンピューティング、新素材開発など、技術的ブレークスルーが鍵となる場合。テクノロジー視点の重みを増加させます（例：基本0.30 → 調整後0.40）。
    *   **市場駆動型 (Market-driven)**：消費者行動の変化、新興市場の出現など、市場動向が鍵となる場合。マーケット視点の重みを増加させます（例：基本0.40 → 調整後0.50）。
    *   **ビジネス駆動型 (Business-driven)**：サブスクリプションモデルへの移行、サプライチェーン再編など、ビジネス構造の変革が鍵となる場合。ビジネス視点の重みを増加させます（例：基本0.30 → 調整後0.40）。

2.  **変化の段階**：技術や市場がどの発展段階にあるかによって、重視すべき視点は変化します。
    *   **初期段階 (Early Stage)**：アイデア創出、概念実証段階。技術的可能性（テクノロジー）と潜在的市場ニーズ（マーケット）が重要。テクノロジーとマーケットの重みを増加させます。
    *   **成長段階 (Growth Stage)**：市場拡大、競合激化段階。市場シェア獲得と顧客基盤拡大（マーケット）が最重要。マーケット視点の重みを最も高くします。
    *   **成熟段階 (Mature Stage)**：市場飽和、効率化・差別化段階。収益性最大化と持続可能性（ビジネス）が重要。ビジネス視点の重みを増加させます。

3.  **確信度の差異**：各視点から得られる情報の信頼性や確かさ（確信度）に差がある場合、より確信度の高い視点の重みを増加させることが合理的です。
    *   例えば、テクノロジー評価は確固たる実験データに基づいている（確信度 高）が、マーケット評価は限定的な調査に基づいている（確信度 低）場合、テクノロジー視点の重みを相対的に増加させ、マーケット視点の重みを減少させます。

これらの調整要因は、**複合的に作用**します。例えば、「初期段階」の「技術駆動型」トピックで、かつ「テクノロジー視点の確信度が特に高い」場合、テクノロジー視点の重みは基本値から大幅に増加することになります。この動的な調整メカニズムにより、コンセンサスモデルは画一的な評価ではなく、個々の状況に最適化された、柔軟で精度の高い評価を提供することが可能になります。

具体的な調整係数（例：技術駆動型ならテクノロジー重みを1.2倍、他を0.9倍するなど）は、組織の経験や過去のデータに基づいて設定・チューニングしていくことが望ましいです。初期段階では標準的な係数から始め、運用を通じて得られた知見をもとに継続的に見直していくことが重要です。

### 2.3. n8nによる実装方法

前述した動的な重み付け調整の仕組みを、n8nワークフローとして実装する方法を解説します。n8nの柔軟なノード構成とコード実行能力を活用することで、この比較的高度なロジックを自動化されたプロセスとして構築できます。

**ワークフローの全体構造**

動的重み付け調整ワークフローの基本的な流れは以下のようになります。これは、特定のトリガー（例：新しい評価トピックがデータベースに追加された時、定期的なバッチ処理など）によって起動され、必要な情報を収集し、重み調整計算を実行し、結果を保存するという一連のプロセスです。

```mermaid
graph LR
    A[Trigger: New Topic Added / Schedule] --> B(Get Topic Info from DB);
    B --> C(Get Active Consensus Parameters from DB);
    C --> D{Function: Adjust Weights};
    D -- Adjusted Weights --> E(Save Adjusted Weights to DB);
    D -- Error --> F(Log Error / Notify Admin);

    subgraph Function: Adjust Weights
        D1[Input: Topic Info, Base Weights, Adjustment Factors] --> D2{Determine Topic Nature};
        D2 --> D3{Determine Change Stage};
        D3 --> D4{Get Confidence Scores};
        D4 --> D5[Apply Adjustments based on Nature, Stage, Confidence];
        D5 --> D6[Normalize Weights (Sum = 1.0)];
        D6 --> D7[Output: Adjusted Weights];
    end
```

*図：n8n動的重み付け調整ワークフローの概念図*

このフローでは、まずトリガー (A) がワークフローを開始します。次に、データベースから評価対象のトピック情報 (B) と、現在有効なコンセンサスパラメータ（基本重みや調整係数など）(C) を取得します。これらの情報を入力として、中心的な役割を果たす「Function: Adjust Weights」ノード (D) が重み調整計算を実行します。このノード内では、トピックの性質、変化段階、確信度スコアを判定し、それに基づいて基本重みを調整し、最後に合計が1.0になるように正規化します。計算された調整後重みはデータベースに保存され (E)、もし計算中にエラーが発生した場合は、エラーログを記録し、管理者に通知するなどの処理 (F) が行われます。

**主要ノードの設定と連携**

-   **Trigger Node (A)**: Webhook、Schedule、またはデータベーストリガー（例：Postgres Trigger）など、ユースケースに合わせて選択します。
-   **Database Nodes (B, C, E)**: 使用しているデータベース（Postgres, MySQL, MongoDBなど）に対応するノードを使用し、必要な情報を取得・保存するクエリを設定します。
-   **Function Node (D)**: JavaScriptコードを実行し、重み調整ロジックを実装します。入力データ（トピック情報、パラメータ）を受け取り、調整後の重みを出力します。エラーハンドリングもこのノード内で実装します。
-   **Error Handling Nodes (F)**: IFノードでエラー発生を判定し、Logノードや通知ノード（Email, Slackなど）に接続します。

**重み調整ロジックの実装コード (Function Node)**

Functionノード (D) に実装するJavaScriptコードの骨子は以下のようになります。これは、入力データを受け取り、調整ロジックを適用し、結果を返す基本的な構造を示しています。（詳細な調整関数の実装例は前バージョンのコードや、組織独自のロジックに基づいて記述します）

```javascript
// n8n Function Node: Adjust Weights

// --- 入力データの取得 --- 
// 前のノードから渡されたトピック情報とコンセンサスパラメータを取得
// 例: const topicInfo = $input.item.json.topicData; 
// 例: const params = $input.item.json.consensusParams;
const topicInfo = $input.items[0].json.topicInfo; // 仮の入力パス
const params = $input.items[0].json.consensusParameters; // 仮の入力パス

let adjustedWeights = {};

try {
    // --- 入力データの検証 --- 
    if (!topicInfo || !params || !params.perspectiveWeights) {
        throw new Error("Input data (topicInfo or consensusParameters) is missing or invalid.");
    }

    // --- 基本重みの初期化 --- 
    let baseWeights = {
        technology: params.perspectiveWeights.technology,
        market: params.perspectiveWeights.market,
        business: params.perspectiveWeights.business
    };
    adjustedWeights = { ...baseWeights }; // 調整用コピーを作成

    // --- 調整ロジックの適用 --- 
    // 1. トピックの性質に基づく調整
    const topicNature = determineTopicNature(topicInfo, params.natureAdjustmentFactors);
    adjustedWeights = applyNatureAdjustment(adjustedWeights, topicNature, params.natureAdjustmentFactors);

    // 2. 変化の段階に基づく調整
    const changeStage = determineChangeStage(topicInfo, params.stageAdjustmentFactors);
    adjustedWeights = applyStageAdjustment(adjustedWeights, changeStage, params.stageAdjustmentFactors);

    // 3. 確信度の差異に基づく調整
    const confidenceScores = getConfidenceScores(topicInfo);
    adjustedWeights = applyConfidenceAdjustment(adjustedWeights, confidenceScores, params.confidenceAdjustmentFactors);

    // --- 重みの正規化 (合計を1.0にする) --- 
    adjustedWeights = normalizeWeights(adjustedWeights);

    // --- 成功時の出力 --- 
    // デバッグ用に中間結果を含めることも可能
    return {
        json: {
            success: true,
            topic_id: topicInfo.id,
            base_weights: baseWeights,
            adjusted_weights: adjustedWeights,
            adjustment_details: {
                topic_nature: topicNature,
                change_stage: changeStage,
                confidence_scores: confidenceScores
            }
        }
    };

} catch (error) {
    // --- エラーハンドリング --- 
    console.error(`Error adjusting weights for topic ${topicInfo ? topicInfo.id : 'N/A'}: ${error.message}`);
    // エラー情報を次のノードに渡す (エラー処理フローへ)
    return {
        json: {
            success: false,
            error: error.message,
            topic_id: topicInfo ? topicInfo.id : null,
            // エラー発生時のデフォルト重みなどを返すことも検討
            adjusted_weights: params ? params.perspectiveWeights : { technology: 0.3, market: 0.4, business: 0.3 } 
        }
    };
}

// --- ヘルパー関数群 (別途定義) --- 
// function determineTopicNature(topicInfo, factors) { /* ... */ }
// function applyNatureAdjustment(weights, nature, factors) { /* ... */ }
// function determineChangeStage(topicInfo, factors) { /* ... */ }
// function applyStageAdjustment(weights, stage, factors) { /* ... */ }
// function getConfidenceScores(topicInfo) { /* ... */ }
// function applyConfidenceAdjustment(weights, scores, factors) { /* ... */ }
// function normalizeWeights(weights) { /* ... */ }

```

**エラー処理と例外管理**

堅牢なワークフローを構築するためには、エラー処理が不可欠です。Functionノード内の `try...catch` ブロックで計算中のエラーを捕捉し、エラーが発生した場合には、エラーメッセージを含むオブジェクトを返すようにします。後続のIFノードで `success: false` または `error` フィールドの存在を確認し、エラー処理フロー（ログ記録、管理者への通知など）に分岐させます。入力データの欠損や不正な形式、データベース接続エラーなども考慮に入れる必要があります。

**パフォーマンス最適化のポイント**

-   **データベースアクセス**：必要なデータのみを取得するようにクエリを最適化します。インデックスを適切に設定することも重要です。
-   **Functionノードの効率**：複雑な計算やループ処理は効率的に記述します。可能であれば、n8nの組み込みノード（例：SplitInBatches, Merge）を活用して処理を分割・並列化します。
-   **外部API呼び出し**：もし重み調整に外部APIの情報が必要な場合は、API呼び出しのタイムアウト設定やリトライ処理を適切に行います。
-   **ワークフローの分割**：非常に複雑なロジックや長時間かかる処理は、別のワークフローとして分割し、Execute Workflowノードで呼び出すことも検討します。

このn8nによる実装により、動的な重み付け調整という高度なロジックを自動化し、コンセンサスモデルの運用効率と精度を大幅に向上させることができます。
