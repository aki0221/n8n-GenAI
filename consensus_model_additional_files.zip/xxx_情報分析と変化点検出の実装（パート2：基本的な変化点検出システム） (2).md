# 情報分析と変化点検出の実装（パート2：基本的な変化点検出システム）

## 変化点検出システムの概要

変化点検出システムは、トリプルパースペクティブ型戦略AIレーダーの中核機能の一つであり、収集・分析したデータから重要な変化やシフトを検出する役割を担います。このシステムは、ビジネス環境の変化を早期に察知し、意思決定者に適切なタイミングで通知することで、戦略的な意思決定を支援します。

変化点検出システムの基本アーキテクチャは以下の通りです：

1. **データ前処理モジュール**
   - ノイズ除去
   - 正規化
   - 特徴抽出

2. **統計的変化点検出モジュール**
   - 時系列データの変化点検出
   - 異常値検出
   - トレンド変化検出

3. **意味的変化点検出モジュール**
   - コンテキスト考慮型変化検出
   - 意味的シフト分析
   - 関連性変化分析

4. **コンセンサスモジュール**
   - 複数検出結果の統合
   - 重要度評価
   - 確信度計算

## 基本的な変化点検出の実装

基本的な変化点検出は、主に統計的手法を用いて時系列データの変化を検出します。n8nを活用して、基本的な変化点検出システムを実装する方法を解説します。

### データ前処理ワークフロー

変化点検出の前に、データの前処理を行うワークフローです。

```javascript
// n8n workflow: Data Preprocessing for Change Detection
// Trigger: Schedule (Daily)
[
  {
    "id": "schedule",
    "type": "n8n-nodes-base.scheduleTrigger",
    "parameters": {
      "rule": "0 1 * * *" // Daily at 1:00 AM
    }
  },
  {
    "id": "getYesterdayDate",
    "type": "n8n-nodes-base.function",
    "parameters": {
      "functionCode": `
        // Get yesterday's date
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        
        // Format as YYYY-MM-DD
        const year = yesterday.getFullYear();
        const month = String(yesterday.getMonth() + 1).padStart(2, '0');
        const day = String(yesterday.getDate()).padStart(2, '0');
        
        const formattedDate = \`\${year}-\${month}-\${day}\`;
        
        return {
          json: {
            date: formattedDate,
            start_timestamp: \`\${formattedDate}T00:00:00Z\`,
            end_timestamp: \`\${formattedDate}T23:59:59Z\`
          }
        };
      `
    }
  },
  {
    "id": "getTimeSeriesData",
    "type": "n8n-nodes-base.postgres",
    "parameters": {
      "operation": "executeQuery",
      "query": `
        -- Get time series data for the past 90 days
        SELECT
          date,
          topic_aggregations,
          perspective_aggregations
        FROM
          time_series_aggregations
        WHERE
          date <= '{{ $json.date }}'
          AND date >= (DATE '{{ $json.date }}' - INTERVAL '90 days')
        ORDER BY
          date ASC
      `
    }
  },
  {
    "id": "preprocessTimeSeriesData",
    "type": "n8n-nodes-base.function",
    "parameters": {
      "functionCode": `
        const timeSeriesData = $input.item.json;
        
        // Extract topic time series
        const topicTimeSeries = {};
        
        for (const dataPoint of timeSeriesData) {
          const date = dataPoint.date;
          const topicAggs = dataPoint.topic_aggregations;
          
          for (const topic of topicAggs) {
            const topicId = topic.topic_id;
            
            if (!topicTimeSeries[topicId]) {
              topicTimeSeries[topicId] = {
                topic_id: topicId,
                topic_name: topic.topic_name,
                perspective_id: topic.perspective_id,
                data: []
              };
            }
            
            topicTimeSeries[topicId].data.push({
              date,
              content_count: parseInt(topic.content_count)
            });
          }
        }
        
        // Normalize and fill missing values
        const normalizedTopicTimeSeries = {};
        
        for (const topicId in topicTimeSeries) {
          const series = topicTimeSeries[topicId];
          const data = series.data;
          
          // Skip if less than 7 data points
          if (data.length < 7) continue;
          
          // Calculate statistics
          let sum = 0;
          let max = data[0].content_count;
          let min = data[0].content_count;
          
          for (const point of data) {
            sum += point.content_count;
            max = Math.max(max, point.content_count);
            min = Math.min(min, point.content_count);
          }
          
          const mean = sum / data.length;
          const range = max - min;
          
          // Normalize data
          const normalizedData = data.map(point => {
            // Avoid division by zero
            const normalizedValue = range > 0 
              ? (point.content_count - min) / range 
              : 0;
            
            return {
              date: point.date,
              raw_value: point.content_count,
              normalized_value: normalizedValue,
              z_score: mean > 0 
                ? (point.content_count - mean) / Math.sqrt(mean) // Using Poisson approximation
                : 0
            };
          });
          
          normalizedTopicTimeSeries[topicId] = {
            ...series,
            statistics: {
              mean,
              min,
              max,
              range
            },
            normalized_data: normalizedData
          };
        }
        
        return {json: {normalizedTopicTimeSeries}};
      `
    }
  },
  {
    "id": "savePreprocessedData",
    "type": "n8n-nodes-base.postgres",
    "parameters": {
      "operation": "executeQuery",
      "query": `
        -- Create preprocessed_time_series table if not exists
        CREATE TABLE IF NOT EXISTS preprocessed_time_series (
          date DATE PRIMARY KEY,
          normalized_topic_time_series JSONB NOT NULL,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Insert or update preprocessed data
        INSERT INTO preprocessed_time_series (date, normalized_topic_time_series)
        VALUES (
          '{{ $json.date }}',
          '{{ $json.normalizedTopicTimeSeries | json | replace("'", "''") }}'::jsonb
        )
        ON CONFLICT (date) DO UPDATE
        SET
          normalized_topic_time_series = '{{ $json.normalizedTopicTimeSeries | json | replace("'", "''") }}'::jsonb,
          created_at = CURRENT_TIMESTAMP
      `
    }
  },
  {
    "id": "triggerChangePointDetection",
    "type": "n8n-nodes-base.httpRequest",
    "parameters": {
      "url": "http://localhost:5678/webhook/detect-change-points",
      "method": "POST",
      "jsonParameters": true,
      "bodyParameters": {
        "parameters": [
          {
            "name": "date",
            "value": "={{ $json.date }}"
          }
        ]
      }
    }
  }
]
```

### 統計的変化点検出ワークフロー

統計的手法を用いて時系列データの変化点を検出するワークフローです。

```javascript
// n8n workflow: Statistical Change Point Detection
// Trigger: Webhook
[
  {
    "id": "webhook",
    "type": "n8n-nodes-base.webhook",
    "parameters": {
      "path": "detect-change-points",
      "responseMode": "onReceived",
      "options": {}
    }
  },
  {
    "id": "getPreprocessedData",
    "type": "n8n-nodes-base.postgres",
    "parameters": {
      "operation": "executeQuery",
      "query": `
        -- Get preprocessed data for the target date
        SELECT
          date,
          normalized_topic_time_series
        FROM
          preprocessed_time_series
        WHERE
          date = '{{ $json.date }}'
      `
    }
  },
  {
    "id": "detectChangePoints",
    "type": "n8n-nodes-base.function",
    "parameters": {
      "functionCode": `
        const preprocessedData = $input.item.json;
        const date = preprocessedData.date;
        const normalizedTopicTimeSeries = preprocessedData.normalized_topic_time_series;
        
        // Detect change points for each topic
        const changePoints = {};
        
        for (const topicId in normalizedTopicTimeSeries) {
          const series = normalizedTopicTimeSeries[topicId];
          const normalizedData = series.normalized_data;
          
          // Skip if less than 14 data points (need history for detection)
          if (normalizedData.length < 14) continue;
          
          // Initialize change point results
          changePoints[topicId] = {
            topic_id: topicId,
            topic_name: series.topic_name,
            perspective_id: series.perspective_id,
            change_points: []
          };
          
          // 1. Detect level shifts using CUSUM
          const cusumResults = detectCUSUM(normalizedData);
          if (cusumResults.isChangePoint) {
            changePoints[topicId].change_points.push({
              type: 'level_shift',
              date: normalizedData[cusumResults.changePointIndex].date,
              confidence: cusumResults.confidence,
              before_mean: cusumResults.beforeMean,
              after_mean: cusumResults.afterMean,
              change_magnitude: cusumResults.changeMagnitude
            });
          }
          
          // 2. Detect trend changes
          const trendResults = detectTrendChange(normalizedData);
          if (trendResults.isChangePoint) {
            changePoints[topicId].change_points.push({
              type: 'trend_change',
              date: normalizedData[trendResults.changePointIndex].date,
              confidence: trendResults.confidence,
              before_trend: trendResults.beforeTrend,
              after_trend: trendResults.afterTrend,
              change_magnitude: trendResults.changeMagnitude
            });
          }
          
          // 3. Detect volatility changes
          const volatilityResults = detectVolatilityChange(normalizedData);
          if (volatilityResults.isChangePoint) {
            changePoints[topicId].change_points.push({
              type: 'volatility_change',
              date: normalizedData[volatilityResults.changePointIndex].date,
              confidence: volatilityResults.confidence,
              before_volatility: volatilityResults.beforeVolatility,
              after_volatility: volatilityResults.afterVolatility,
              change_magnitude: volatilityResults.changeMagnitude
            });
          }
          
          // 4. Detect outliers
          const outlierResults = detectOutliers(normalizedData);
          for (const outlier of outlierResults.outliers) {
            changePoints[topicId].change_points.push({
              type: 'outlier',
              date: normalizedData[outlier.index].date,
              confidence: outlier.confidence,
              expected_value: outlier.expectedValue,
              actual_value: outlier.actualValue,
              z_score: outlier.zScore
            });
          }
        }
        
        // Helper function: CUSUM change point detection
        function detectCUSUM(data) {
          const values = data.map(d => d.normalized_value);
          const n = values.length;
          
          // Parameters
          const h = 0.5; // Threshold for detection
          const k = 0.5; // Reference value (sensitivity parameter)
          
          // CUSUM calculation
          let maxCUSUM = 0;
          let maxIndex = -1;
          let cusum = 0;
          
          for (let i = 0; i < n; i++) {
            cusum = Math.max(0, cusum + values[i] - k);
            if (cusum > maxCUSUM) {
              maxCUSUM = cusum;
              maxIndex = i;
            }
          }
          
          // Determine if change point is significant
          const isChangePoint = maxCUSUM > h && maxIndex > 0 && maxIndex < n - 1;
          
          // Calculate statistics if change point detected
          let beforeMean = 0;
          let afterMean = 0;
          let changeMagnitude = 0;
          let confidence = 0;
          
          if (isChangePoint) {
            // Calculate means before and after change point
            for (let i = 0; i < maxIndex; i++) {
              beforeMean += values[i];
            }
            beforeMean /= maxIndex;
            
            for (let i = maxIndex; i < n; i++) {
              afterMean += values[i];
            }
            afterMean /= (n - maxIndex);
            
            // Calculate change magnitude and confidence
            changeMagnitude = Math.abs(afterMean - beforeMean);
            confidence = Math.min(1, changeMagnitude * 2); // Simple confidence calculation
          }
          
          return {
            isChangePoint,
            changePointIndex: maxIndex,
            beforeMean,
            afterMean,
            changeMagnitude,
            confidence
          };
        }
        
        // Helper function: Trend change detection
        function detectTrendChange(data) {
          const n = data.length;
          const halfPoint = Math.floor(n / 2);
          
          // Calculate trends in first and second half
          let beforeTrend = 0;
          for (let i = 1; i < halfPoint; i++) {
            beforeTrend += data[i].normalized_value - data[i-1].normalized_value;
          }
          beforeTrend /= (halfPoint - 1);
          
          let afterTrend = 0;
          for (let i = halfPoint + 1; i < n; i++) {
            afterTrend += data[i].normalized_value - data[i-1].normalized_value;
          }
          afterTrend /= (n - halfPoint - 1);
          
          // Calculate change magnitude and confidence
          const changeMagnitude = Math.abs(afterTrend - beforeTrend);
          const threshold = 0.05; // Minimum change to be considered significant
          const isChangePoint = changeMagnitude > threshold;
          const confidence = Math.min(1, changeMagnitude * 10); // Simple confidence calculation
          
          return {
            isChangePoint,
            changePointIndex: halfPoint,
            beforeTrend,
            afterTrend,
            changeMagnitude,
            confidence
          };
        }
        
        // Helper function: Volatility change detection
        function detectVolatilityChange(data) {
          const n = data.length;
          const halfPoint = Math.floor(n / 2);
          
          // Calculate volatility in first and second half
          let beforeSum = 0;
          let beforeMean = 0;
          for (let i = 0; i < halfPoint; i++) {
            beforeSum += data[i].normalized_value;
          }
          beforeMean = beforeSum / halfPoint;
          
          let beforeVolatility = 0;
          for (let i = 0; i < halfPoint; i++) {
            beforeVolatility += Math.pow(data[i].normalized_value - beforeMean, 2);
          }
          beforeVolatility = Math.sqrt(beforeVolatility / halfPoint);
          
          let afterSum = 0;
          let afterMean = 0;
          for (let i = halfPoint; i < n; i++) {
            afterSum += data[i].normalized_value;
          }
          afterMean = afterSum / (n - halfPoint);
          
          let afterVolatility = 0;
          for (let i = halfPoint; i < n; i++) {
            afterVolatility += Math.pow(data[i].normalized_value - afterMean, 2);
          }
          afterVolatility = Math.sqrt(afterVolatility / (n - halfPoint));
          
          // Calculate change magnitude and confidence
          const changeMagnitude = Math.abs(afterVolatility - beforeVolatility) / Math.max(0.001, beforeVolatility);
          const threshold = 0.5; // Minimum change to be considered significant
          const isChangePoint = changeMagnitude > threshold;
          const confidence = Math.min(1, changeMagnitude / 2); // Simple confidence calculation
          
          return {
            isChangePoint,
            changePointIndex: halfPoint,
            beforeVolatility,
            afterVolatility,
            changeMagnitude,
            confidence
          };
        }
        
        // Helper function: Outlier detection
        function detectOutliers(data) {
          const values = data.map(d => d.z_score);
          const n = values.length;
          const outliers = [];
          
          // Parameters
          const threshold = 2.5; // Z-score threshold for outlier detection
          
          // Detect outliers
          for (let i = 0; i < n; i++) {
            const zScore = values[i];
            if (Math.abs(zScore) > threshold) {
              // Calculate expected value based on neighboring points
              let expectedValue = 0;
              let count = 0;
              
              // Use up to 3 points before and after
              for (let j = Math.max(0, i - 3); j <= Math.min(n - 1, i + 3); j++) {
                if (j !== i) {
                  expectedValue += data[j].normalized_value;
                  count++;
                }
              }
              
              expectedValue /= count;
              
              outliers.push({
                index: i,
                zScore: zScore,
                expectedValue: expectedValue,
                actualValue: data[i].normalized_value,
                confidence: Math.min(1, (Math.abs(zScore) - threshold) / 3)
              });
            }
          }
          
          return {
            outliers
          };
        }
        
        return {
          json: {
            date,
            change_points: changePoints
          }
        };
      `
    }
  },
  {
    "id": "saveChangePoints",
    "type": "n8n-nodes-base.postgres",
    "parameters": {
      "operation": "executeQuery",
      "query": `
        -- Create change_points table if not exists
        CREATE TABLE IF NOT EXISTS change_points (
          date DATE PRIMARY KEY,
          change_points JSONB NOT NULL,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Insert or update change points
        INSERT INTO change_points (date, change_points)
        VALUES (
          '{{ $json.date }}',
          '{{ $json.change_points | json | replace("'", "''") }}'::jsonb
        )
        ON CONFLICT (date) DO UPDATE
        SET
          change_points = '{{ $json.change_points | json | replace("'", "''") }}'::jsonb,
          created_at = CURRENT_TIMESTAMP
      `
    }
  },
  {
    "id": "triggerSemanticChangeDetection",
    "type": "n8n-nodes-base.httpRequest",
    "parameters": {
      "url": "http://localhost:5678/webhook/detect-semantic-changes",
      "method": "POST",
      "jsonParameters": true,
      "bodyParameters": {
        "parameters": [
          {
            "name": "date",
            "value": "={{ $json.date }}"
          }
        ]
      }
    }
  }
]
```

## 意味的変化点検出の実装

意味的変化点検出は、コンテンツの意味的な変化を検出するための手法です。n8nとAIを組み合わせて、意味的変化点検出システムを実装する方法を解説します。

### 意味的変化点検出ワークフロー

コンテンツの意味的な変化を検出するワークフローです。

```javascript
// n8n workflow: Semantic Change Detection
// Trigger: Webhook
[
  {
    "id": "webhook",
    "type": "n8n-nodes-base.webhook",
    "parameters": {
      "path": "detect-semantic-changes",
      "responseMode": "onReceived",
      "options": {}
    }
  },
  {
    "id": "getDateRange",
    "type": "n8n-nodes-base.function",
    "parameters": {
      "functionCode": `
        // Get date range for analysis
        const targetDate = new Date($json.date);
        const startDate = new Date(targetDate);
        startDate.setDate(startDate.getDate() - 30); // 30 days before
        
        // Format as YYYY-MM-DD
        const formatDate = (date) => {
          const year = date.getFullYear();
          const month = String(date.getMonth() + 1).padStart(2, '0');
          const day = String(date.getDate()).padStart(2, '0');
          return \`\${year}-\${month}-\${day}\`;
        };
        
        const formattedTargetDate = formatDate(targetDate);
        const formattedStartDate = formatDate(startDate);
        
        return {
          json: {
            target_date: formattedTargetDate,
            start_date: formattedStartDate,
            start_timestamp: \`\${formattedStartDate}T00:00:00Z\`,
            end_timestamp: \`\${formattedTargetDate}T23:59:59Z\`
          }
        };
      `
    }
  },
  {
    "id": "getTopicContent",
    "type": "n8n-nodes-base.postgres",
    "parameters": {
      "operation": "executeQuery",
      "query": `
        -- Get content for each topic in the date range
        WITH topic_content AS (
          SELECT
            t.id AS topic_id,
            t.name AS topic_name,
            t.perspective_id,
            c.id AS content_id,
            c.title,
            c.normalized_body,
            c.summary,
            c.published_at,
            c.collected_at
          FROM
            content c
          JOIN
            content_topics ct ON c.id = ct.content_id
          JOIN
            topics t ON ct.topic_id = t.id
          WHERE
            c.collected_at >= '{{ $json.start_timestamp }}'
            AND c.collected_at <= '{{ $json.end_timestamp }}'
        )
        SELECT
          topic_id,
          topic_name,
          perspective_id,
          jsonb_agg(
            jsonb_build_object(
              'content_id', content_id,
              'title', title,
              'normalized_body', normalized_body,
              'summary', summary,
              'published_at', published_at,
              'collected_at', collected_at
            )
            ORDER BY collected_at
          ) AS content_items
        FROM
          topic_content
        GROUP BY
          topic_id, topic_name, perspective_id
      `
    }
  },
  {
    "id": "detectSemanticChanges",
    "type": "n8n-nodes-base.httpRequest",
    "parameters": {
      "url": "http://localhost:8000/api/detect_semantic_changes",
      "method": "POST",
      "jsonParameters": true,
      "bodyParameters": {
        "parameters": [
          {
            "name": "topic_content",
            "value": "={{ $json }}"
          }
        ]
      }
    }
  },
  {
    "id": "processSemanticChanges",
    "type": "n8n-nodes-base.function",
    "parameters": {
      "functionCode": `
        const semanticChanges = $input.item.json.results;
        const targetDate = $input.item.json.target_date;
        
        // Process semantic changes
        const processedChanges = {};
        
        for (const topicId in semanticChanges) {
          const changes = semanticChanges[topicId];
          
          processedChanges[topicId] = {
            topic_id: changes.topic_id,
            topic_name: changes.topic_name,
            perspective_id: changes.perspective_id,
            semantic_changes: []
          };
          
          // Process each type of semantic change
          if (changes.topic_drift && changes.topic_drift.is_significant) {
            processedChanges[topicId].semantic_changes.push({
              type: 'topic_drift',
              confidence: changes.topic_drift.confidence,
              before_keywords: changes.topic_drift.before_keywords,
              after_keywords: changes.topic_drift.after_keywords,
              drift_magnitude: changes.topic_drift.magnitude
            });
          }
          
          if (changes.sentiment_shift && changes.sentiment_shift.is_significant) {
            processedChanges[topicId].semantic_changes.push({
              type: 'sentiment_shift',
              confidence: changes.sentiment_shift.confidence,
              before_sentiment: changes.sentiment_shift.before_sentiment,
              after_sentiment: changes.sentiment_shift.after_sentiment,
              shift_magnitude: changes.sentiment_shift.magnitude
            });
          }
          
          if (changes.narrative_change && changes.narrative_change.is_significant) {
            processedChanges[topicId].semantic_changes.push({
              type: 'narrative_change',
              confidence: changes.narrative_change.confidence,
              before_narrative: changes.narrative_change.before_narrative,
              after_narrative: changes.narrative_change.after_narrative,
              change_description: changes.narrative_change.description
            });
          }
          
          if (changes.entity_relationship_change && changes.entity_relationship_change.is_significant) {
            processedChanges[topicId].semantic_changes.push({
              type: 'entity_relationship_change',
              confidence: changes.entity_relationship_change.confidence,
              changed_entities: changes.entity_relationship_change.changed_entities,
              change_description: changes.entity_relationship_change.description
            });
          }
        }
        
        return {
          json: {
            date: targetDate,
            semantic_changes: processedChanges
          }
        };
      `
    }
  },
  {
    "id": "saveSemanticChanges",
    "type": "n8n-nodes-base.postgres",
    "parameters": {
      "operation": "executeQuery",
      "query": `
        -- Create semantic_changes table if not exists
        CREATE TABLE IF NOT EXISTS semantic_changes (
          date DATE PRIMARY KEY,
          semantic_changes JSONB NOT NULL,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Insert or update semantic changes
        INSERT INTO semantic_changes (date, semantic_changes)
        VALUES (
          '{{ $json.date }}',
          '{{ $json.semantic_changes | json | replace("'", "''") }}'::jsonb
        )
        ON CONFLICT (date) DO UPDATE
        SET
          semantic_changes = '{{ $json.semantic_changes | json | replace("'", "''") }}'::jsonb,
          created_at = CURRENT_TIMESTAMP
      `
    }
  },
  {
    "id": "triggerConsensusFormation",
    "type": "n8n-nodes-base.httpRequest",
    "parameters": {
      "url": "http://localhost:5678/webhook/form-consensus",
      "method": "POST",
      "jsonParameters": true,
      "bodyParameters": {
        "parameters": [
          {
            "name": "date",
            "value": "={{ $json.date }}"
          }
        ]
      }
    }
  }
]
```

## 変化点検出システムの評価と最適化

変化点検出システムの性能を評価し、最適化するための方法を解説します。

### 評価指標

変化点検出システムの評価には、以下の指標が用いられます：

1. **検出精度**
   - 真陽性率（TPR）：実際の変化点を正しく検出できた割合
   - 偽陽性率（FPR）：変化点でないものを誤って検出した割合
   - F1スコア：精度と再現率の調和平均

2. **検出遅延**
   - 変化点発生から検出までの時間的遅延

3. **実用性指標**
   - 検出された変化点の重要度評価の正確さ
   - 検出結果の解釈可能性

### 最適化ワークフロー

変化点検出システムのパラメータを最適化するワークフローです。

```javascript
// n8n workflow: Change Detection Optimization
// Trigger: Manual
[
  {
    "id": "start",
    "type": "n8n-nodes-base.manualTrigger",
    "parameters": {}
  },
  {
    "id": "getHistoricalData",
    "type": "n8n-nodes-base.postgres",
    "parameters": {
      "operation": "executeQuery",
      "query": `
        -- Get historical data for optimization
        SELECT
          date,
          normalized_topic_time_series
        FROM
          preprocessed_time_series
        ORDER BY
          date ASC
      `
    }
  },
  {
    "id": "getKnownChangePoints",
    "type": "n8n-nodes-base.postgres",
    "parameters": {
      "operation": "executeQuery",
      "query": `
        -- Get manually labeled change points for evaluation
        SELECT
          *
        FROM
          labeled_change_points
      `
    }
  },
  {
    "id": "optimizeParameters",
    "type": "n8n-nodes-base.function",
    "parameters": {
      "functionCode": `
        const historicalData = $input.item.json;
        const labeledChangePoints = $input.item.json;
        
        // Parameter ranges to test
        const parameterRanges = {
          cusum_threshold: [0.3, 0.4, 0.5, 0.6, 0.7],
          cusum_sensitivity: [0.3, 0.4, 0.5, 0.6, 0.7],
          trend_threshold: [0.03, 0.04, 0.05, 0.06, 0.07],
          volatility_threshold: [0.3, 0.4, 0.5, 0.6, 0.7],
          outlier_threshold: [2.0, 2.5, 3.0, 3.5]
        };
        
        // Grid search for optimal parameters
        let bestParameters = {};
        let bestF1Score = 0;
        
        // Simplified grid search (in practice, this would be more comprehensive)
        for (const cusumThreshold of parameterRanges.cusum_threshold) {
          for (const cusumSensitivity of parameterRanges.cusum_sensitivity) {
            for (const trendThreshold of parameterRanges.trend_threshold) {
              for (const volatilityThreshold of parameterRanges.volatility_threshold) {
                for (const outlierThreshold of parameterRanges.outlier_threshold) {
                  // Create parameter set
                  const parameters = {
                    cusum_threshold: cusumThreshold,
                    cusum_sensitivity: cusumSensitivity,
                    trend_threshold: trendThreshold,
                    volatility_threshold: volatilityThreshold,
                    outlier_threshold: outlierThreshold
                  };
                  
                  // Evaluate parameters
                  const evaluationResults = evaluateParameters(
                    historicalData,
                    labeledChangePoints,
                    parameters
                  );
                  
                  // Update best parameters if better F1 score
                  if (evaluationResults.f1Score > bestF1Score) {
                    bestF1Score = evaluationResults.f1Score;
                    bestParameters = parameters;
                  }
                }
              }
            }
          }
        }
        
        // Helper function to evaluate parameters
        function evaluateParameters(historicalData, labeledChangePoints, parameters) {
          // In a real implementation, this would run the change detection algorithm
          // with the given parameters and compare results with labeled data
          
          // Placeholder for evaluation logic
          // This would calculate true positives, false positives, false negatives
          // and derive precision, recall, and F1 score
          
          // Simplified placeholder implementation
          const truePositives = 10;
          const falsePositives = 2;
          const falseNegatives = 3;
          
          const precision = truePositives / (truePositives + falsePositives);
          const recall = truePositives / (truePositives + falseNegatives);
          const f1Score = 2 * (precision * recall) / (precision + recall);
          
          return {
            precision,
            recall,
            f1Score
          };
        }
        
        return {
          json: {
            best_parameters: bestParameters,
            best_f1_score: bestF1Score
          }
        };
      `
    }
  },
  {
    "id": "saveOptimalParameters",
    "type": "n8n-nodes-base.postgres",
    "parameters": {
      "operation": "executeQuery",
      "query": `
        -- Create change_detection_parameters table if not exists
        CREATE TABLE IF NOT EXISTS change_detection_parameters (
          id SERIAL PRIMARY KEY,
          parameters JSONB NOT NULL,
          f1_score FLOAT NOT NULL,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Insert optimal parameters
        INSERT INTO change_detection_parameters (parameters, f1_score)
        VALUES (
          '{{ $json.best_parameters | json | replace("'", "''") }}'::jsonb,
          {{ $json.best_f1_score }}
        )
      `
    }
  },
  {
    "id": "updateActiveParameters",
    "type": "n8n-nodes-base.postgres",
    "parameters": {
      "operation": "executeQuery",
      "query": `
        -- Create active_parameters table if not exists
        CREATE TABLE IF NOT EXISTS active_parameters (
          id INTEGER PRIMARY KEY DEFAULT 1,
          parameters JSONB NOT NULL,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Update active parameters
        INSERT INTO active_parameters (id, parameters)
        VALUES (
          1,
          '{{ $json.best_parameters | json | replace("'", "''") }}'::jsonb
        )
        ON CONFLICT (id) DO UPDATE
        SET
          parameters = '{{ $json.best_parameters | json | replace("'", "''") }}'::jsonb,
          updated_at = CURRENT_TIMESTAMP
      `
    }
  }
]
```

## まとめ

このセクションでは、トリプルパースペクティブ型戦略AIレーダーの基本的な変化点検出システムの実装方法について解説しました。n8nを活用することで、データ前処理、統計的変化点検出、意味的変化点検出、システム評価と最適化を実装し、ビジネス環境の重要な変化を検出することができます。

次のセクションでは、コンセンサスモデルの実装方法について詳しく解説します。



## コンセンサスモジュールの実装

コンセンサスモジュールは、統計的変化点検出と意味的変化点検出の結果を統合し、最終的な変化点の重要度と確信度を評価する役割を担います。これにより、ノイズを除去し、真に重要な変化のみを意思決定者に提示することが可能になります。

### コンセンサス形成ワークフロー

統計的変化点と意味的変化点の情報を統合し、最終的な変化点レポートを生成するワークフローです。

```javascript
// n8n workflow: Consensus Formation
// Trigger: Webhook
[
  {
    "id": "webhook",
    "type": "n8n-nodes-base.webhook",
    "parameters": {
      "path": "form-consensus",
      "responseMode": "onReceived",
      "options": {}
    }
  },
  {
    "id": "getStatisticalChanges",
    "type": "n8n-nodes-base.postgres",
    "parameters": {
      "operation": "executeQuery",
      "query": `
        -- Get statistical change points for the target date
        SELECT
          date,
          change_points
        FROM
          change_points
        WHERE
          date = '{{ $json.date }}'
      `
    }
  },
  {
    "id": "getSemanticChanges",
    "type": "n8n-nodes-base.postgres",
    "parameters": {
      "operation": "executeQuery",
      "query": `
        -- Get semantic changes for the target date
        SELECT
          date,
          semantic_changes
        FROM
          semantic_changes
        WHERE
          date = '{{ $json.date }}'
      `
    }
  },
  {
    "id": "formConsensus",
    "type": "n8n-nodes-base.function",
    "parameters": {
      "functionCode": `
        const statisticalChangesData = $input.item.json.statisticalChanges;
        const semanticChangesData = $input.item.json.semanticChanges;
        const date = $json.date;
        
        const statisticalChanges = statisticalChangesData.change_points;
        const semanticChanges = semanticChangesData.semantic_changes;
        
        const consensusResults = {};
        
        // Combine statistical and semantic changes by topic
        const allTopicIds = new Set([
          ...Object.keys(statisticalChanges),
          ...Object.keys(semanticChanges)
        ]);
        
        for (const topicId of allTopicIds) {
          const statChanges = statisticalChanges[topicId] ? statisticalChanges[topicId].change_points : [];
          const semChanges = semanticChanges[topicId] ? semanticChanges[topicId].semantic_changes : [];
          const topicName = statisticalChanges[topicId]?.topic_name || semanticChanges[topicId]?.topic_name;
          const perspectiveId = statisticalChanges[topicId]?.perspective_id || semanticChanges[topicId]?.perspective_id;

          if (!topicName) continue; // Skip if topic info is missing
          
          consensusResults[topicId] = {
            topic_id: topicId,
            topic_name: topicName,
            perspective_id: perspectiveId,
            consensus_changes: []
          };
          
          // Simple consensus logic: Combine confidence scores
          // In a real system, this would involve more sophisticated rules or models
          
          const combinedChanges = {};

          // Process statistical changes
          for (const change of statChanges) {
            const changeKey = `\${change.type}_\${change.date}`;
            if (!combinedChanges[changeKey]) {
              combinedChanges[changeKey] = { ...change, sources: ['statistical'], total_confidence: 0 };
            }
            combinedChanges[changeKey].total_confidence += change.confidence || 0;
            combinedChanges[changeKey].statistical_details = change;
          }

          // Process semantic changes
          for (const change of semChanges) {
             // Assuming semantic changes are daily summaries, use target date
            const changeKey = `\${change.type}_\${date}`;
             if (!combinedChanges[changeKey]) {
              combinedChanges[changeKey] = { ...change, date: date, sources: ['semantic'], total_confidence: 0 };
            }
            if (!combinedChanges[changeKey].sources.includes('semantic')) {
                 combinedChanges[changeKey].sources.push('semantic');
            }
            combinedChanges[changeKey].total_confidence += change.confidence || 0;
            combinedChanges[changeKey].semantic_details = change;
          }

          // Calculate final confidence and importance
          for (const key in combinedChanges) {
            const change = combinedChanges[key];
            const numSources = change.sources.length;
            const avgConfidence = change.total_confidence / numSources;
            
            // Simple importance score based on confidence and number of sources
            const importance = avgConfidence * (1 + (numSources - 1) * 0.5); // Boost score if detected by both
            
            consensusResults[topicId].consensus_changes.push({
              type: change.type,
              date: change.date,
              confidence: avgConfidence,
              importance: Math.min(1, importance), // Cap importance at 1
              sources: change.sources,
              details: {
                statistical: change.statistical_details,
                semantic: change.semantic_details
              }
            });
          }
          
          // Sort changes by importance
          consensusResults[topicId].consensus_changes.sort((a, b) => b.importance - a.importance);
        }
        
        return {
          json: {
            date,
            consensus_results: consensusResults
          }
        };
      `
    }
  },
  {
    "id": "saveConsensusResults",
    "type": "n8n-nodes-base.postgres",
    "parameters": {
      "operation": "executeQuery",
      "query": `
        -- Create consensus_results table if not exists
        CREATE TABLE IF NOT EXISTS consensus_results (
          date DATE PRIMARY KEY,
          consensus_results JSONB NOT NULL,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Insert or update consensus results
        INSERT INTO consensus_results (date, consensus_results)
        VALUES (
          '{{ $json.date }}',
          '{{ $json.consensus_results | json | replace("\'", "\'\'") }}'::jsonb
        )
        ON CONFLICT (date) DO UPDATE
        SET
          consensus_results = '{{ $json.consensus_results | json | replace("\'", "\'\'") }}'::jsonb,
          created_at = CURRENT_TIMESTAMP
      `
    }
  },
  {
    "id": "notifyDecisionMakers",
    "type": "n8n-nodes-base.if",
    "parameters": {
      "conditions": {
        "boolean": [
          {
            "value1": "={{ Object.values($json.consensus_results).some(topic => topic.consensus_changes.some(change => change.importance > 0.7)) }}",
            "operation": "boolean",
            "value2": true
          }
        ]
      }
    }
  },
  {
    "id": "formatNotification",
    "type": "n8n-nodes-base.function",
    "parameters": {
      "functionCode": `
        const consensusResults = $input.item.json.consensus_results;
        const date = $input.item.json.date;
        let message = ":warning: Significant Changes Detected on \${date}:\n\n";
        let highImportanceChanges = [];

        for (const topicId in consensusResults) {
          const topic = consensusResults[topicId];
          const importantChanges = topic.consensus_changes.filter(change => change.importance > 0.7);
          
          if (importantChanges.length > 0) {
            message += ">*Topic: \${topic.topic_name}* (Perspective ID: \${topic.perspective_id})\n";
            for (const change of importantChanges) {
              message += 	- Type: \${change.type}, Importance: \${change.importance.toFixed(2)}, Sources: [\${change.sources.join(', ')}]\n";
              // Add more details if needed
            }
            message += "\n";
            highImportanceChanges = highImportanceChanges.concat(importantChanges);
          }
        }
        
        // Only proceed if there are high importance changes
        if (highImportanceChanges.length === 0) {
             return null; // Stop workflow if no significant changes
        }

        return { json: { message } };
      `
    }
  },
  {
    "id": "sendSlackNotification",
    "type": "n8n-nodes-base.slack",
    "parameters": {
      "text": "={{ $json.message }}",
      "channel": "#strategic-radar-alerts"
      // Add credentials
    }
  }
]
```

このワークフローは、統計的変化点と意味的変化点の両方の結果を取得し、それらを統合して各変化点の確信度と重要度を計算します。重要度が特定の閾値を超えた変化点については、Slackなどの通知チャネルを通じて意思決定者にアラートを送信します。



## 読者のための実装ガイド

変化点検出システムを実際に構築するための段階的なガイドを提供します。このガイドに従うことで、トリプルパースペクティブ型戦略AIレーダーの変化点検出機能を効率的に実装することができます。

### ステップ1: 環境準備

まず、必要な環境を準備します。

1. **n8nのセットアップ**
   ```bash
   # Dockerを使用したn8nのセットアップ
   docker run -it --rm \
     --name n8n \
     -p 5678:5678 \
     -v ~/.n8n:/home/node/.n8n \
     n8nio/n8n
   ```

2. **データベースの準備**
   ```sql
   -- PostgreSQLデータベースの作成
   CREATE DATABASE strategic_radar;
   
   -- 必要なテーブルの作成
   CREATE TABLE time_series_aggregations (
     date DATE PRIMARY KEY,
     topic_aggregations JSONB NOT NULL,
     perspective_aggregations JSONB NOT NULL,
     created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
   );
   
   -- 変化点検出用のテーブル
   CREATE TABLE preprocessed_time_series (
     date DATE PRIMARY KEY,
     normalized_topic_time_series JSONB NOT NULL,
     created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
   );
   
   CREATE TABLE change_points (
     date DATE PRIMARY KEY,
     change_points JSONB NOT NULL,
     created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
   );
   
   CREATE TABLE semantic_changes (
     date DATE PRIMARY KEY,
     semantic_changes JSONB NOT NULL,
     created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
   );
   
   CREATE TABLE consensus_results (
     date DATE PRIMARY KEY,
     consensus_results JSONB NOT NULL,
     created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
   );
   ```

3. **外部サービスの準備**
   - 意味的変化点検出用のAIサービス（OpenAI API、Anthropic API、Google Cloud AIなど）のアカウント作成とAPIキーの取得
   - Slackなどの通知サービスのセットアップ（Webhook URLの取得）

### ステップ2: データ前処理モジュールの実装

1. **n8nワークフローの作成**
   - n8n管理画面にアクセス（http://localhost:5678）
   - 新規ワークフローを作成し、「Data Preprocessing for Change Detection」と名付ける
   - 前述のデータ前処理ワークフローのコードを参考に、各ノードを設定

2. **データベース接続の設定**
   - PostgreSQLの認証情報を設定
   - 接続テストを実行して正常に動作することを確認

3. **スケジュール設定**
   - 毎日実行されるようにスケジュールを設定（例：毎日午前1時）

### ステップ3: 統計的変化点検出モジュールの実装

1. **Webhookエンドポイントの作成**
   - 新規ワークフローを作成し、「Statistical Change Point Detection」と名付ける
   - Webhookノードを設定し、エンドポイントを作成（例：detect-change-points）

2. **変化点検出アルゴリズムの実装**
   - 前述の統計的変化点検出ワークフローのコードを参考に、各ノードを設定
   - 特に、CUSUM、トレンド変化、ボラティリティ変化、外れ値検出の各アルゴリズムを実装

3. **パラメータの調整**
   - 検出感度を調整するパラメータ（閾値など）を環境に合わせて設定

### ステップ4: 意味的変化点検出モジュールの実装

1. **外部AIサービスの統合**
   - 選択したAIサービス（OpenAI API、Anthropic API、Google Cloud AIなど）との連携設定
   - APIキーの安全な管理方法を確立（環境変数の使用など）

2. **意味的変化点検出ワークフローの作成**
   - 新規ワークフローを作成し、「Semantic Change Detection」と名付ける
   - 前述の意味的変化点検出ワークフローのコードを参考に、各ノードを設定

3. **AIプロンプトの最適化**
   - 意味的変化を効果的に検出するためのプロンプトを設計
   - 例：「以下のコンテンツセットにおける意味的な変化、トピックのドリフト、感情の変化を分析してください」

### ステップ5: コンセンサスモジュールの実装

1. **コンセンサス形成ワークフローの作成**
   - 新規ワークフローを作成し、「Consensus Formation」と名付ける
   - 前述のコンセンサス形成ワークフローのコードを参考に、各ノードを設定

2. **通知設定**
   - Slack、メール、またはその他の通知チャネルの設定
   - 重要な変化点のみが通知されるよう、閾値を適切に設定

3. **ダッシュボードの作成（オプション）**
   - 検出された変化点を可視化するためのダッシュボードを作成
   - Grafana、Tableau、Power BIなどのツールを活用

### ステップ6: テストと最適化

1. **テストデータによる検証**
   - 既知の変化点を含むテストデータを用意
   - システム全体の動作を検証

2. **パラメータの最適化**
   - 前述のパラメータ最適化ワークフローを実行
   - 検出精度と実用性のバランスを取りながら最適なパラメータを設定

3. **本番環境への展開**
   - テスト環境での検証が完了したら、本番環境に展開
   - 初期段階は手動監視を行い、必要に応じて調整

## トラブルシューティングと最適化のヒント

変化点検出システムの実装時によく発生する問題とその解決策、およびパフォーマンス最適化のヒントを紹介します。

### データ処理関連の問題

1. **大量データ処理時のメモリ不足**
   
   **問題**: 大量のデータを処理する際にn8nのメモリ不足エラーが発生する
   
   **解決策**:
   - データを時間窓で分割して処理
   - n8nのメモリ割り当てを増やす
   ```bash
   # Dockerでn8nを実行する場合のメモリ割り当て増加
   docker run -it --rm \
     --name n8n \
     -p 5678:5678 \
     -v ~/.n8n:/home/node/.n8n \
     --memory="4g" \
     n8nio/n8n
   ```
   - 大量データ処理はPythonスクリプトに委譲し、n8nからHTTPリクエストで呼び出す
   ```javascript
   // n8nからPythonスクリプトを呼び出す例
   {
     "id": "callPythonProcessor",
     "type": "n8n-nodes-base.httpRequest",
     "parameters": {
       "url": "http://localhost:8000/api/process_large_dataset",
       "method": "POST",
       "jsonParameters": true,
       "bodyParameters": {
         "parameters": [
           {
             "name": "data",
             "value": "={{ $json.data }}"
           }
         ]
       }
     }
   }
   ```

2. **データベース接続の問題**
   
   **問題**: データベースへの接続が断続的に失敗する
   
   **解決策**:
   - 接続プールの設定を最適化
   - リトライロジックを実装
   ```javascript
   // リトライロジックの実装例
   {
     "id": "retryDatabaseOperation",
     "type": "n8n-nodes-base.function",
     "parameters": {
       "functionCode": `
         const maxRetries = 3;
         let retryCount = 0;
         let success = false;
         let result;
         
         while (!success && retryCount < maxRetries) {
           try {
             // データベース操作を試行
             // 成功したらsuccess = true
             success = true;
           } catch (error) {
             retryCount++;
             if (retryCount >= maxRetries) {
               throw new Error(\`Database operation failed after \${maxRetries} attempts\`);
             }
             // 指数バックオフ
             await new Promise(resolve => setTimeout(resolve, 1000 * Math.pow(2, retryCount)));
           }
         }
         
         return {json: result};
       `
     }
   }
   ```

3. **データ整合性の問題**
   
   **問題**: 複数のワークフロー間でデータの整合性が取れない
   
   **解決策**:
   - トランザクション管理の導入
   - データバージョニングの実装
   ```sql
   -- データバージョニングの例
   CREATE TABLE data_versions (
     id SERIAL PRIMARY KEY,
     dataset_name VARCHAR(255) NOT NULL,
     version INT NOT NULL,
     valid_from TIMESTAMP WITH TIME ZONE NOT NULL,
     valid_to TIMESTAMP WITH TIME ZONE,
     metadata JSONB,
     UNIQUE(dataset_name, version)
   );
   
   -- データ処理時にバージョンを参照
   INSERT INTO data_versions (dataset_name, version, valid_from, metadata)
   VALUES ('topic_time_series', 1, CURRENT_TIMESTAMP, '{"source": "daily_aggregation"}');
   ```

### スケーラビリティの確保

1. **水平スケーリング**
   
   複数のn8nインスタンスを並列で実行し、負荷を分散させる方法です。
   
   ```bash
   # Docker Composeを使用した複数インスタンスの起動
   version: '3'
   services:
     n8n-1:
       image: n8nio/n8n
       ports:
         - "5678:5678"
       environment:
         - N8N_PORT=5678
         - N8N_QUEUE_BULL_REDIS_HOST=redis
       volumes:
         - ~/.n8n-1:/home/node/.n8n
     
     n8n-2:
       image: n8nio/n8n
       ports:
         - "5679:5678"
       environment:
         - N8N_PORT=5678
         - N8N_QUEUE_BULL_REDIS_HOST=redis
       volumes:
         - ~/.n8n-2:/home/node/.n8n
     
     redis:
       image: redis:alpine
       ports:
         - "6379:6379"
   ```

2. **キューイングシステムの導入**
   
   大量のタスクを効率的に処理するためのキューイングシステムを導入します。
   
   ```javascript
   // Redisキューを使用したタスク処理の例
   {
     "id": "enqueueTask",
     "type": "n8n-nodes-base.httpRequest",
     "parameters": {
       "url": "http://localhost:3000/api/enqueue",
       "method": "POST",
       "jsonParameters": true,
       "bodyParameters": {
         "parameters": [
           {
             "name": "task",
             "value": "detect_changes"
           },
           {
             "name": "payload",
             "value": "={{ $json }}"
           }
         ]
       }
     }
   }
   ```

3. **データベース最適化**
   
   大規模データセットを効率的に処理するためのデータベース最適化技術です。
   
   ```sql
   -- インデックスの作成
   CREATE INDEX idx_preprocessed_time_series_date ON preprocessed_time_series(date);
   CREATE INDEX idx_change_points_date ON change_points(date);
   CREATE INDEX idx_semantic_changes_date ON semantic_changes(date);
   
   -- パーティショニングの導入
   CREATE TABLE time_series_aggregations_partitioned (
     date DATE NOT NULL,
     topic_aggregations JSONB NOT NULL,
     perspective_aggregations JSONB NOT NULL,
     created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
   ) PARTITION BY RANGE (date);
   
   -- 月次パーティションの作成
   CREATE TABLE time_series_aggregations_y2025m01 
     PARTITION OF time_series_aggregations_partitioned
     FOR VALUES FROM ('2025-01-01') TO ('2025-02-01');
   
   CREATE TABLE time_series_aggregations_y2025m02 
     PARTITION OF time_series_aggregations_partitioned
     FOR VALUES FROM ('2025-02-01') TO ('2025-03-01');
   ```

### 外部AIサービスの最適化

1. **OpenAI API (ChatGPT) の最適化**
   
   ```javascript
   // OpenAI APIを効率的に使用する例
   {
     "id": "semanticAnalysisWithOpenAI",
     "type": "n8n-nodes-base.httpRequest",
     "parameters": {
       "url": "https://api.openai.com/v1/chat/completions",
       "method": "POST",
       "authentication": "genericCredentialType",
       "genericAuthType": "httpHeaderAuth",
       "jsonParameters": true,
       "headerParameters": {
         "parameters": [
           {
             "name": "Content-Type",
             "value": "application/json"
           },
           {
             "name": "Authorization",
             "value": "Bearer {{$credentials.openAiApi.apiKey}}"
           }
         ]
       },
       "bodyParameters": {
         "parameters": [
           {
             "name": "model",
             "value": "gpt-4"
           },
           {
             "name": "messages",
             "value": [
               {
                 "role": "system",
                 "content": "あなたは時系列データの意味的変化を検出する専門家です。提供されたコンテンツの意味的変化、トピックのドリフト、感情の変化を分析してください。"
               },
               {
                 "role": "user",
                 "content": "={{ '以下のコンテンツを分析し、意味的な変化を検出してください: ' + JSON.stringify($json.content_items) }}"
               }
             ]
           },
           {
             "name": "temperature",
             "value": 0.1
           },
           {
             "name": "max_tokens",
             "value": 1000
           }
         ]
       }
     }
   }
   ```

2. **Anthropic API (Claude) の最適化**
   
   ```javascript
   // Anthropic APIを効率的に使用する例
   {
     "id": "semanticAnalysisWithClaude",
     "type": "n8n-nodes-base.httpRequest",
     "parameters": {
       "url": "https://api.anthropic.com/v1/messages",
       "method": "POST",
       "authentication": "genericCredentialType",
       "genericAuthType": "httpHeaderAuth",
       "jsonParameters": true,
       "headerParameters": {
         "parameters": [
           {
             "name": "Content-Type",
             "value": "application/json"
           },
           {
             "name": "x-api-key",
             "value": "{{$credentials.anthropicApi.apiKey}}"
           },
           {
             "name": "anthropic-version",
             "value": "2023-06-01"
           }
         ]
       },
       "bodyParameters": {
         "parameters": [
           {
             "name": "model",
             "value": "claude-2"
           },
           {
             "name": "messages",
             "value": [
               {
                 "role": "user",
                 "content": "={{ '以下のコンテンツを分析し、意味的な変化を検出してください。特に長文の理解と倫理的判断を重視してください: ' + JSON.stringify($json.content_items) }}"
               }
             ]
           },
           {
             "name": "temperature",
             "value": 0.1
           },
           {
             "name": "max_tokens",
             "value": 1000
           }
         ]
       }
     }
   }
   ```

3. **APIコスト管理**
   
   外部AIサービスのAPIコストを管理するための戦略です。
   
   ```javascript
   // APIコスト管理の例
   {
     "id": "costAwareAIRequest",
     "type": "n8n-nodes-base.function",
     "parameters": {
       "functionCode": `
         // 簡易的なコスト計算
         const estimateTokens = (text) => {
           // 英語の場合、単語数の約1.3倍がトークン数の目安
           // 日本語の場合、文字数の約0.5倍がトークン数の目安
           return Math.ceil(text.length * 0.5);
         };
         
         const content = $json.content;
         const estimatedTokens = estimateTokens(content);
         const estimatedCost = (estimatedTokens / 1000) * 0.03; // $0.03 per 1K tokens
         
         // コスト閾値を超える場合は要約して送信
         if (estimatedCost > 0.10) {
           // 長いコンテンツを要約
           const summarizedContent = content.substring(0, 1000) + "...";
           return {
             json: {
               content: summarizedContent,
               original_length: content.length,
               estimated_tokens: estimatedTokens,
               estimated_cost: estimatedCost,
               was_summarized: true
             }
           };
         }
         
         return {
           json: {
             content,
             estimated_tokens: estimatedTokens,
             estimated_cost: estimatedCost,
             was_summarized: false
           }
         };
       `
     }
   }
   ```


## 具体的なユースケース

変化点検出システムの実際の応用例を業界別に紹介します。これらのユースケースは、トリプルパースペクティブ型戦略AIレーダーを様々なビジネスシナリオで活用する方法を示しています。

### 製造業における技術トレンド監視

製造業では、新技術の出現や競合他社の技術開発動向を早期に察知することが重要です。

**設定例**:
```javascript
// 製造業向け変化点検出パラメータ設定
const manufacturingParameters = {
  // 統計的変化点検出パラメータ
  statistical: {
    cusum_threshold: 0.4,      // 技術トレンドは比較的緩やかに変化するため、やや低めの閾値
    cusum_sensitivity: 0.5,
    trend_threshold: 0.04,     // 長期的なトレンド変化を検出するため、低めの閾値
    volatility_threshold: 0.6,
    outlier_threshold: 3.0     // ノイズを除去するため、高めの閾値
  },
  
  // 意味的変化点検出パラメータ
  semantic: {
    topic_drift_threshold: 0.3,  // 技術用語の微妙な変化も検出するため、低めの閾値
    sentiment_threshold: 0.5,
    narrative_threshold: 0.4,
    entity_relationship_threshold: 0.3
  },
  
  // 監視対象トピック
  topics: [
    "半導体製造技術",
    "電気自動車バッテリー",
    "工場自動化",
    "3Dプリンティング",
    "サプライチェーン最適化"
  ],
  
  // 情報源設定
  sources: [
    { type: "technical_papers", weight: 0.8 },
    { type: "patents", weight: 0.9 },
    { type: "industry_news", weight: 0.7 },
    { type: "competitor_announcements", weight: 0.8 },
    { type: "social_media", weight: 0.4 }  // 技術情報源としての信頼性は低め
  ]
};
```

**活用例**:
1. **競合他社の特許出願パターンの変化検出**
   - 特定の技術分野における特許出願数の急増を検出
   - 競合他社の研究開発方向性の変化を早期に察知

2. **新技術の普及速度の監視**
   - 3Dプリンティングなどの新技術に関する言及の増加率を追跡
   - 技術の成熟度と市場受容性の変化点を検出

3. **サプライチェーンリスクの早期警告**
   - 特定の部品や材料に関するネガティブな言及の増加を検出
   - 供給不足や品質問題の兆候を早期に察知

### 小売業における消費者トレンド分析

小売業では、消費者の嗜好や購買行動の変化を迅速に把握することが競争力の源泉となります。

**設定例**:
```javascript
// 小売業向け変化点検出パラメータ設定
const retailParameters = {
  // 統計的変化点検出パラメータ
  statistical: {
    cusum_threshold: 0.3,      // 消費者トレンドは急速に変化することがあるため、低めの閾値
    cusum_sensitivity: 0.4,
    trend_threshold: 0.05,
    volatility_threshold: 0.4, // 季節変動を考慮して低めに設定
    outlier_threshold: 2.5     // プロモーションなどによる一時的なスパイクも検出するため、低めの閾値
  },
  
  // 意味的変化点検出パラメータ
  semantic: {
    topic_drift_threshold: 0.25, // 消費者の関心の微妙な変化も検出
    sentiment_threshold: 0.3,    // ブランド認識の変化を敏感に検出
    narrative_threshold: 0.35,
    entity_relationship_threshold: 0.4
  },
  
  // 監視対象トピック
  topics: [
    "サステナビリティ",
    "オンラインショッピング体験",
    "価格感応度",
    "ブランドロイヤルティ",
    "商品カテゴリートレンド"
  ],
  
  // 情報源設定
  sources: [
    { type: "social_media", weight: 0.9 },      // 消費者トレンドの主要情報源
    { type: "review_platforms", weight: 0.8 },
    { type: "search_trends", weight: 0.7 },
    { type: "competitor_promotions", weight: 0.6 },
    { type: "industry_reports", weight: 0.5 }
  ]
};
```

**活用例**:
1. **消費者の環境意識の高まりの検出**
   - サステナブル製品に関する肯定的言及の増加を検出
   - 環境に配慮した包装や材料への関心の変化点を特定

2. **価格感応度の変化の監視**
   - 経済状況の変化に伴う消費者の価格に対する言及パターンの変化を検出
   - 割引やプロモーションへの反応の変化を分析

3. **新興ブランドの台頭の早期発見**
   - ソーシャルメディアでの新興ブランドへの言及の急増を検出
   - 競合ブランドとの比較言及パターンの変化を分析

### 金融業における市場リスク監視

金融業では、市場の変動や規制環境の変化を早期に察知し、リスク管理に活かすことが重要です。

**設定例**:
```javascript
// 金融業向け変化点検出パラメータ設定
const financeParameters = {
  // 統計的変化点検出パラメータ
  statistical: {
    cusum_threshold: 0.35,     // 金融市場の変動を適切に検出するバランスの取れた閾値
    cusum_sensitivity: 0.45,
    trend_threshold: 0.03,     // 長期的な市場トレンドの変化を検出するため、低めの閾値
    volatility_threshold: 0.5,
    outlier_threshold: 2.8     // 市場の異常値を検出するための閾値
  },
  
  // 意味的変化点検出パラメータ
  semantic: {
    topic_drift_threshold: 0.3,
    sentiment_threshold: 0.25, // 市場センチメントの微妙な変化を検出するため、低めの閾値
    narrative_threshold: 0.3,
    entity_relationship_threshold: 0.35
  },
  
  // 監視対象トピック
  topics: [
    "金利動向",
    "規制環境",
    "市場センチメント",
    "地政学的リスク",
    "セクター別パフォーマンス"
  ],
  
  // 情報源設定
  sources: [
    { type: "financial_news", weight: 0.9 },
    { type: "regulatory_announcements", weight: 0.9 },
    { type: "analyst_reports", weight: 0.8 },
    { type: "central_bank_communications", weight: 0.9 },
    { type: "social_media", weight: 0.5 }  // 金融情報源としての信頼性は中程度
  ]
};
```

**活用例**:
1. **規制環境の変化の早期検出**
   - 金融規制に関する言及パターンの変化を検出
   - 規制当局の発言や文書における調子の変化を分析

2. **市場センチメントの転換点の特定**
   - 特定の資産クラスに対する感情分析の結果の変化点を検出
   - 市場のナラティブの変化を早期に察知

3. **新興リスク要因の監視**
   - これまで注目されていなかった要因への言及の急増を検出
   - 地政学的イベントと市場動向の関連性の変化を分析

## 変化点検出の視覚化

変化点検出の結果を効果的に理解し、意思決定に活かすためには、適切な視覚化が重要です。以下に、変化点検出システムの主要な視覚化手法を紹介します。

### 時系列データと検出された変化点

時系列データ上に検出された変化点を視覚的に表示することで、変化の文脈と重要性を理解しやすくなります。

```
[図3-4-1: 時系列データと検出された変化点の視覚化例]

    トピック言及量
    ^
    |                                            * 変化点（レベルシフト）
    |                                          /
    |                                        /
    |                                      /
    |                                    /
    |                                  /
    |                                /
    |              * 変化点（トレンド変化）
    |            /
    |          /
    |        /
    |      /
    |    /
    |  /
    |/
    +-----------------------------------------------------> 時間
       Jan  Feb  Mar  Apr  May  Jun  Jul  Aug  Sep  Oct
```

この図では、時系列データ上に検出された2つの変化点（トレンド変化とレベルシフト）が表示されています。視覚化により、変化の性質と規模を直感的に理解することができます。

### 変化点の確信度と重要度のヒートマップ

複数のトピックや視点にわたる変化点の確信度と重要度をヒートマップで表示することで、注目すべき変化を一目で把握できます。

```
[図3-4-2: 変化点の確信度と重要度のヒートマップ例]

    トピック
    ^
    |
    | 半導体製造技術   ■■■□□   ■■□□□   ■■■■■
    | 電気自動車       ■□□□□   ■■■■□   ■■□□□
    | 工場自動化       ■■■■□   ■□□□□   ■■■□□
    | 3Dプリンティング ■■□□□   ■■■□□   ■□□□□
    | サプライチェーン ■■■■■   ■■□□□   ■■■■□
    |
    +-----------------------------------------------------> 変化点タイプ
         レベルシフト  トレンド変化  異常値

    ■■■■■ 非常に高い確信度/重要度
    ■■■■□ 高い確信度/重要度
    ■■■□□ 中程度の確信度/重要度
    ■■□□□ 低い確信度/重要度
    ■□□□□ 非常に低い確信度/重要度
```

このヒートマップでは、各トピックと変化点タイプの組み合わせにおける確信度と重要度が色の濃さで表現されています。これにより、「サプライチェーン」のレベルシフトが最も注目すべき変化であることが一目でわかります。

### 意味的変化の関係ネットワーク

意味的変化点検出によって特定された概念やエンティティ間の関係の変化を、ネットワーク図で視覚化します。

```
[図3-4-3: 意味的変化の関係ネットワーク例]

    [電気自動車] ---- 強化された関係 ----> [バッテリー技術]
        |                                     |
        |                                     |
    弱まった関係                          新たな関係
        |                                     |
        v                                     v
    [内燃機関]                           [リサイクル技術]
        |                                     |
        |                                     |
    弱まった関係                          強化された関係
        |                                     |
        v                                     v
    [石油産業] ---- 弱まった関係 ----> [環境規制]
```

この関係ネットワーク図では、電気自動車に関連する概念間の関係の変化が視覚化されています。バッテリー技術との関係が強化され、内燃機関との関係が弱まるなど、業界の変化の方向性を把握することができます。

### 変化点検出ダッシュボード

実際の運用では、上記の視覚化要素を組み合わせたダッシュボードを作成することで、変化点検出システムの結果を総合的に把握することができます。

```
[図3-4-4: 変化点検出ダッシュボードの構成例]

+------------------------------------------------------------------+
|                                                                  |
|  [時系列グラフと変化点]                 [重要度ランキング]       |
|                                                                  |
|  トピック言及量                         1. サプライチェーン (0.92) |
|  ^                                     2. 半導体製造技術 (0.85)  |
|  |    *    *                           3. 工場自動化 (0.78)      |
|  |   /\   /\                           4. 電気自動車 (0.65)      |
|  |  /  \ /  \                          5. 3Dプリンティング (0.52) |
|  | /    V    \                                                  |
|  |/           \                                                 |
|  +-------------->                                               |
|                                                                  |
|  [変化点の確信度ヒートマップ]           [意味的変化ネットワーク]  |
|                                                                  |
|  トピック                               [概念A] --- [概念B]       |
|  ^                                        |          |           |
|  |  ■■■□□ ■■□□□ ■■■■■                    |          |           |
|  |  ■□□□□ ■■■■□ ■■□□□                    v          v           |
|  |  ■■■■□ ■□□□□ ■■■□□                 [概念C] --- [概念D]       |
|  |  ■■□□□ ■■■□□ ■□□□□                                          |
|  |  ■■■■■ ■■□□□ ■■■■□                                          |
|  |                                                              |
|  +-------------->                                               |
|                                                                  |
+------------------------------------------------------------------+
```

このダッシュボードでは、時系列グラフと変化点、重要度ランキング、確信度ヒートマップ、意味的変化ネットワークを一つの画面に統合しています。これにより、意思決定者は変化点検出システムの結果を多角的に分析し、適切な戦略的判断を下すことができます。

## パラメータ最適化の詳細実装

変化点検出システムの性能は、使用するパラメータに大きく依存します。ここでは、パラメータ最適化の詳細な実装方法を解説します。

### クロスバリデーションによるパラメータ評価

過去のデータを訓練セットと検証セットに分割し、パラメータの性能を評価します。

```javascript
// n8n workflow: Parameter Optimization with Cross-Validation
// Trigger: Manual
[
  {
    "id": "start",
    "type": "n8n-nodes-base.manualTrigger",
    "parameters": {}
  },
  {
    "id": "getHistoricalData",
    "type": "n8n-nodes-base.postgres",
    "parameters": {
      "operation": "executeQuery",
      "query": `
        -- Get historical data for optimization
        SELECT
          date,
          normalized_topic_time_series
        FROM
          preprocessed_time_series
        WHERE
          date >= '2024-01-01' AND date <= '2024-12-31'
        ORDER BY
          date ASC
      `
    }
  },
  {
    "id": "getKnownChangePoints",
    "type": "n8n-nodes-base.postgres",
    "parameters": {
      "operation": "executeQuery",
      "query": `
        -- Get manually labeled change points for evaluation
        SELECT
          *
        FROM
          labeled_change_points
        WHERE
          date >= '2024-01-01' AND date <= '2024-12-31'
      `
    }
  },
  {
    "id": "performCrossValidation",
    "type": "n8n-nodes-base.function",
    "parameters": {
      "functionCode": `
        const historicalData = $input.item.json.historicalData;
        const labeledChangePoints = $input.item.json.labeledChangePoints;
        
        // Parameter ranges to test
        const parameterRanges = {
          cusum_threshold: [0.3, 0.4, 0.5, 0.6, 0.7],
          cusum_sensitivity: [0.3, 0.4, 0.5, 0.6, 0.7],
          trend_threshold: [0.03, 0.04, 0.05, 0.06, 0.07],
          volatility_threshold: [0.3, 0.4, 0.5, 0.6, 0.7],
          outlier_threshold: [2.0, 2.5, 3.0, 3.5]
        };
        
        // Prepare data for cross-validation
        const dates = Object.keys(historicalData).sort();
        const folds = 5; // 5-fold cross-validation
        const foldSize = Math.floor(dates.length / folds);
        
        // Store results for each parameter combination
        const results = [];
        
        // Perform grid search with cross-validation
        for (const cusumThreshold of parameterRanges.cusum_threshold) {
          for (const cusumSensitivity of parameterRanges.cusum_sensitivity) {
            for (const trendThreshold of parameterRanges.trend_threshold) {
              for (const volatilityThreshold of parameterRanges.volatility_threshold) {
                for (const outlierThreshold of parameterRanges.outlier_threshold) {
                  // Create parameter set
                  const parameters = {
                    cusum_threshold: cusumThreshold,
                    cusum_sensitivity: cusumSensitivity,
                    trend_threshold: trendThreshold,
                    volatility_threshold: volatilityThreshold,
                    outlier_threshold: outlierThreshold
                  };
                  
                  // Cross-validation
                  let totalPrecision = 0;
                  let totalRecall = 0;
                  let totalF1Score = 0;
                  
                  for (let fold = 0; fold < folds; fold++) {
                    // Split data into training and validation sets
                    const validationStartIdx = fold * foldSize;
                    const validationEndIdx = (fold + 1) * foldSize;
                    
                    const validationDates = dates.slice(validationStartIdx, validationEndIdx);
                    const trainingDates = dates.filter(date => !validationDates.includes(date));
                    
                    // Extract training and validation data
                    const trainingData = {};
                    for (const date of trainingDates) {
                      trainingData[date] = historicalData[date];
                    }
                    
                    const validationData = {};
                    for (const date of validationDates) {
                      validationData[date] = historicalData[date];
                    }
                    
                    // Extract labeled change points for validation set
                    const validationLabels = labeledChangePoints.filter(
                      cp => validationDates.includes(cp.date)
                    );
                    
                    // Train model on training data (in a real implementation)
                    // ...
                    
                    // Detect change points on validation data using parameters
                    const detectedChangePoints = detectChangePoints(validationData, parameters);
                    
                    // Evaluate performance
                    const evaluation = evaluatePerformance(detectedChangePoints, validationLabels);
                    
                    totalPrecision += evaluation.precision;
                    totalRecall += evaluation.recall;
                    totalF1Score += evaluation.f1Score;
                  }
                  
                  // Calculate average performance across folds
                  const avgPrecision = totalPrecision / folds;
                  const avgRecall = totalRecall / folds;
                  const avgF1Score = totalF1Score / folds;
                  
                  // Store results
                  results.push({
                    parameters,
                    precision: avgPrecision,
                    recall: avgRecall,
                    f1Score: avgF1Score
                  });
                }
              }
            }
          }
        }
        
        // Sort results by F1 score
        results.sort((a, b) => b.f1Score - a.f1Score);
        
        // Get best parameters
        const bestResult = results[0];
        
        // Helper function to detect change points (simplified)
        function detectChangePoints(data, parameters) {
          // In a real implementation, this would use the parameters to detect change points
          // This is a placeholder
          return [];
        }
        
        // Helper function to evaluate performance
        function evaluatePerformance(detectedChangePoints, labeledChangePoints) {
          // In a real implementation, this would calculate true positives, false positives, false negatives
          // This is a placeholder
          return {
            precision: 0.8,
            recall: 0.7,
            f1Score: 0.75
          };
        }
        
        return {
          json: {
            best_parameters: bestResult.parameters,
            best_f1_score: bestResult.f1Score,
            all_results: results.slice(0, 10) // Top 10 results
          }
        };
      `
    }
  },
  {
    "id": "visualizeResults",
    "type": "n8n-nodes-base.function",
    "parameters": {
      "functionCode": `
        const results = $input.item.json.all_results;
        
        // Generate data for parameter sensitivity visualization
        const parameterSensitivity = {
          cusum_threshold: {},
          cusum_sensitivity: {},
          trend_threshold: {},
          volatility_threshold: {},
          outlier_threshold: {}
        };
        
        // Calculate average F1 score for each parameter value
        for (const param in parameterSensitivity) {
          const values = [...new Set(results.map(r => r.parameters[param]))];
          
          for (const value of values) {
            const matchingResults = results.filter(r => r.parameters[param] === value);
            const avgF1Score = matchingResults.reduce((sum, r) => sum + r.f1Score, 0) / matchingResults.length;
            
            parameterSensitivity[param][value] = avgF1Score;
          }
        }
        
        // Generate HTML report
        const htmlReport = `
          <html>
          <head>
            <title>Parameter Optimization Results</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              table { border-collapse: collapse; width: 100%; }
              th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
              th { background-color: #f2f2f2; }
              tr:nth-child(even) { background-color: #f9f9f9; }
              .chart { width: 100%; height: 300px; margin-top: 20px; }
            </style>
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
          </head>
          <body>
            <h1>Parameter Optimization Results</h1>
            
            <h2>Best Parameters</h2>
            <table>
              <tr>
                <th>Parameter</th>
                <th>Value</th>
              </tr>
              <tr>
                <td>CUSUM Threshold</td>
                <td>${$json.best_parameters.cusum_threshold}</td>
              </tr>
              <tr>
                <td>CUSUM Sensitivity</td>
                <td>${$json.best_parameters.cusum_sensitivity}</td>
              </tr>
              <tr>
                <td>Trend Threshold</td>
                <td>${$json.best_parameters.trend_threshold}</td>
              </tr>
              <tr>
                <td>Volatility Threshold</td>
                <td>${$json.best_parameters.volatility_threshold}</td>
              </tr>
              <tr>
                <td>Outlier Threshold</td>
                <td>${$json.best_parameters.outlier_threshold}</td>
              </tr>
            </table>
            
            <h2>Performance</h2>
            <p>F1 Score: ${$json.best_f1_score.toFixed(4)}</p>
            
            <h2>Parameter Sensitivity</h2>
            <div class="chart">
              <canvas id="sensitivityChart"></canvas>
            </div>
            
            <script>
              // Create chart data
              const ctx = document.getElementById('sensitivityChart').getContext('2d');
              const chart = new Chart(ctx, {
                type: 'line',
                data: {
                  labels: ${JSON.stringify(Object.keys(parameterSensitivity.cusum_threshold))},
                  datasets: [
                    {
                      label: 'CUSUM Threshold',
                      data: ${JSON.stringify(Object.values(parameterSensitivity.cusum_threshold))},
                      borderColor: 'rgb(255, 99, 132)',
                      tension: 0.1
                    },
                    {
                      label: 'CUSUM Sensitivity',
                      data: ${JSON.stringify(Object.values(parameterSensitivity.cusum_sensitivity))},
                      borderColor: 'rgb(54, 162, 235)',
                      tension: 0.1
                    },
                    {
                      label: 'Trend Threshold',
                      data: ${JSON.stringify(Object.values(parameterSensitivity.trend_threshold))},
                      borderColor: 'rgb(255, 206, 86)',
                      tension: 0.1
                    },
                    {
                      label: 'Volatility Threshold',
                      data: ${JSON.stringify(Object.values(parameterSensitivity.volatility_threshold))},
                      borderColor: 'rgb(75, 192, 192)',
                      tension: 0.1
                    },
                    {
                      label: 'Outlier Threshold',
                      data: ${JSON.stringify(Object.values(parameterSensitivity.outlier_threshold))},
                      borderColor: 'rgb(153, 102, 255)',
                      tension: 0.1
                    }
                  ]
                },
                options: {
                  responsive: true,
                  plugins: {
                    title: {
                      display: true,
                      text: 'Parameter Sensitivity Analysis'
                    }
                  },
                  scales: {
                    y: {
                      title: {
                        display: true,
                        text: 'F1 Score'
                      }
                    },
                    x: {
                      title: {
                        display: true,
                        text: 'Parameter Value'
                      }
                    }
                  }
                }
              });
            </script>
          </body>
          </html>
        `;
        
        return {
          json: {
            html_report: htmlReport,
            best_parameters: $json.best_parameters,
            best_f1_score: $json.best_f1_score
          }
        };
      `
    }
  },
  {
    "id": "saveHtmlReport",
    "type": "n8n-nodes-base.writeFile",
    "parameters": {
      "fileName": "parameter_optimization_report.html",
      "fileContent": "={{ $json.html_report }}",
      "directory": "/reports"
    }
  },
  {
    "id": "saveOptimalParameters",
    "type": "n8n-nodes-base.postgres",
    "parameters": {
      "operation": "executeQuery",
      "query": `
        -- Create change_detection_parameters table if not exists
        CREATE TABLE IF NOT EXISTS change_detection_parameters (
          id SERIAL PRIMARY KEY,
          parameters JSONB NOT NULL,
          f1_score FLOAT NOT NULL,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Insert optimal parameters
        INSERT INTO change_detection_parameters (parameters, f1_score)
        VALUES (
          '{{ $json.best_parameters | json | replace("'", "''") }}'::jsonb,
          {{ $json.best_f1_score }}
        )
      `
    }
  },
  {
    "id": "updateActiveParameters",
    "type": "n8n-nodes-base.postgres",
    "parameters": {
      "operation": "executeQuery",
      "query": `
        -- Create active_parameters table if not exists
        CREATE TABLE IF NOT EXISTS active_parameters (
          id INTEGER PRIMARY KEY DEFAULT 1,
          parameters JSONB NOT NULL,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Update active parameters
        INSERT INTO active_parameters (id, parameters)
        VALUES (
          1,
          '{{ $json.best_parameters | json | replace("'", "''") }}'::jsonb
        )
        ON CONFLICT (id) DO UPDATE
        SET
          parameters = '{{ $json.best_parameters | json | replace("'", "''") }}'::jsonb,
          updated_at = CURRENT_TIMESTAMP
      `
    }
  }
]
```

このワークフローでは、5分割交差検証を用いてパラメータの性能を評価し、最適なパラメータセットを特定します。また、パラメータ感度分析のための可視化レポートも生成します。

## 次のステップ：コンセンサスモデルの実装

このセクションでは、トリプルパースペクティブ型戦略AIレーダーの基本的な変化点検出システムの実装方法について解説しました。変化点検出システムは、ビジネス環境の重要な変化を早期に察知し、意思決定者に適切なタイミングで通知する役割を担います。

次のセクションでは、複数の視点からの情報を統合し、より包括的な戦略的洞察を生成するコンセンサスモデルの実装方法について詳しく解説します。コンセンサスモデルは、以下の要素で構成されます：

1. **マルチパースペクティブ統合**
   - 異なる視点からの情報を重み付けして統合
   - 視点間の矛盾や補完関係の分析
   - 統合された洞察の生成

2. **戦略的重要度評価**
   - 検出された変化の戦略的重要度の評価
   - 組織の目標や優先事項に基づく重み付け
   - アクション可能な洞察への変換

3. **意思決定支援機能**
   - 戦略的選択肢の生成
   - 各選択肢のリスクと機会の評価
   - 意思決定者向けのレポート生成

コンセンサスモデルの実装により、トリプルパースペクティブ型戦略AIレーダーは単なる変化点検出ツールから、包括的な戦略的意思決定支援システムへと進化します。次のセクションでは、このコンセンサスモデルの詳細な実装方法と活用例を紹介します。
