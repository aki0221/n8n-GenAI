#!/usr/bin/env python3
"""
DCO理論100万レコード実験
真の大規模性能データの取得
"""
import numpy as np
import time
import json
import logging
from concurrent.futures import ProcessPoolExecutor
from typing import Dict, List, Tuple
import psutil
import os

# ログ設定
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class MillionRecordDCOExperiment:
    """100万レコードDCO実験クラス"""
    
    def __init__(self):
        self.perspectives = ["Business", "Market", "Technology"]
        self.dimensions = ["Cognitive", "Value", "Temporal", "Spatial", 
                          "Social", "Technological", "Economic", "Strategic"]
        self.total_dimensions = len(self.perspectives) * len(self.dimensions)
        
    def generate_synthetic_data(self, num_records: int) -> np.ndarray:
        """合成データの生成（メモリ効率版）"""
        logger.info(f"100万レコード合成データ生成開始")
        
        # メモリ効率のため、チャンク単位で生成
        chunk_size = 100_000
        num_chunks = (num_records + chunk_size - 1) // chunk_size
        
        # 最初のチャンクで配列を初期化
        np.random.seed(42)  # 再現性確保
        data = np.empty((num_records, self.total_dimensions), dtype=np.float32)
        
        for chunk_idx in range(num_chunks):
            start_idx = chunk_idx * chunk_size
            end_idx = min(start_idx + chunk_size, num_records)
            chunk_records = end_idx - start_idx
            
            # チャンクデータ生成
            chunk_data = np.random.beta(2, 5, size=(chunk_records, self.total_dimensions)).astype(np.float32)
            
            # 相関の導入
            for i in range(0, self.total_dimensions, 3):
                if i + 2 < self.total_dimensions:
                    correlation_factor = 0.3
                    chunk_data[:, i+1] = chunk_data[:, i+1] * (1 - correlation_factor) + chunk_data[:, i] * correlation_factor
                    chunk_data[:, i+2] = chunk_data[:, i+2] * (1 - correlation_factor) + chunk_data[:, i] * correlation_factor
            
            data[start_idx:end_idx] = chunk_data
            
            if (chunk_idx + 1) % 2 == 0:
                logger.info(f"  データ生成進捗: {chunk_idx + 1}/{num_chunks} チャンク完了")
        
        logger.info(f"100万レコード合成データ生成完了：形状 {data.shape}")
        return data
    
    def calculate_dco_value_batch(self, data_batch: np.ndarray) -> Tuple[float, Dict]:
        """DCO価値関数のバッチ計算（最適化版）"""
        batch_size = len(data_batch)
        
        # メモリ使用量監視
        process = psutil.Process(os.getpid())
        memory_before = process.memory_info().rss / 1024 / 1024  # MB
        
        start_time = time.time()
        
        # 3視点×8次元の構造で計算（ベクトル化最適化）
        perspective_values = np.empty((batch_size, len(self.perspectives)), dtype=np.float32)
        
        for p_idx in range(len(self.perspectives)):
            # 各視点の8次元データを抽出
            start_dim = p_idx * len(self.dimensions)
            end_dim = start_dim + len(self.dimensions)
            perspective_data = data_batch[:, start_dim:end_dim]
            
            # 次元内統合（幾何平均で数値安定性確保）
            perspective_values[:, p_idx] = np.exp(np.mean(np.log(perspective_data + 1e-10), axis=1))
        
        # 視点間統合（乗算統合）
        final_values = np.exp(np.mean(np.log(perspective_values + 1e-10), axis=1))
        
        computation_time = time.time() - start_time
        
        # メモリ使用量計測
        memory_after = process.memory_info().rss / 1024 / 1024  # MB
        memory_used = memory_after - memory_before
        
        # 統計情報
        stats = {
            'mean_value': float(np.mean(final_values)),
            'std_value': float(np.std(final_values)),
            'min_value': float(np.min(final_values)),
            'max_value': float(np.max(final_values)),
            'computation_time': computation_time,
            'memory_used_mb': memory_used,
            'batch_size': batch_size
        }
        
        return float(np.mean(final_values)), stats
    
    def run_million_record_experiment(self) -> Dict:
        """100万レコード実験の実行"""
        logger.info("=== DCO理論100万レコード実験開始 ===")
        
        num_records = 1_000_000
        
        results = {
            'experiment_timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'total_records': num_records,
            'experiment_results': {},
            'performance_analysis': {}
        }
        
        # システムリソース監視開始
        process = psutil.Process(os.getpid())
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB
        
        experiment_start_time = time.time()
        
        # データ生成
        logger.info("ステップ1: データ生成")
        data_gen_start = time.time()
        data = self.generate_synthetic_data(num_records)
        data_gen_time = time.time() - data_gen_start
        
        # バッチ処理設定
        batch_size = 50_000  # メモリ効率を考慮
        num_batches = (num_records + batch_size - 1) // batch_size
        
        logger.info(f"ステップ2: DCO価値計算（{num_batches}バッチ）")
        
        # バッチ処理実行
        processing_start = time.time()
        batch_values = []
        batch_stats = []
        total_computation_time = 0
        
        for batch_idx in range(num_batches):
            start_idx = batch_idx * batch_size
            end_idx = min(start_idx + batch_size, num_records)
            batch_data = data[start_idx:end_idx]
            
            batch_value, batch_stat = self.calculate_dco_value_batch(batch_data)
            batch_values.append(batch_value)
            batch_stats.append(batch_stat)
            total_computation_time += batch_stat['computation_time']
            
            if (batch_idx + 1) % 5 == 0:
                progress = (batch_idx + 1) / num_batches * 100
                logger.info(f"  処理進捗: {batch_idx + 1}/{num_batches} バッチ完了 ({progress:.1f}%)")
        
        processing_time = time.time() - processing_start
        total_experiment_time = time.time() - experiment_start_time
        
        # 最終メモリ使用量
        final_memory = process.memory_info().rss / 1024 / 1024  # MB
        peak_memory_used = final_memory - initial_memory
        
        # 結果の集計
        overall_mean = np.mean(batch_values)
        overall_std = np.std(batch_values)
        
        # 詳細統計
        all_means = [stat['mean_value'] for stat in batch_stats]
        all_stds = [stat['std_value'] for stat in batch_stats]
        
        results['experiment_results'] = {
            'data_generation_time': data_gen_time,
            'processing_time': processing_time,
            'total_experiment_time': total_experiment_time,
            'total_computation_time': total_computation_time,
            'num_batches': num_batches,
            'batch_size': batch_size,
            'overall_mean_value': overall_mean,
            'overall_std_value': overall_std,
            'batch_statistics': {
                'mean_values': all_means,
                'std_values': all_stds,
                'mean_of_means': np.mean(all_means),
                'std_of_means': np.std(all_means)
            }
        }
        
        # 性能分析
        results['performance_analysis'] = {
            'records_per_second': num_records / processing_time,
            'time_per_record_ms': (processing_time / num_records) * 1000,
            'time_per_million_records': processing_time,
            'memory_efficiency': {
                'initial_memory_mb': initial_memory,
                'final_memory_mb': final_memory,
                'peak_memory_used_mb': peak_memory_used,
                'memory_per_record_bytes': (peak_memory_used * 1024 * 1024) / num_records
            },
            'computational_efficiency': {
                'pure_computation_time': total_computation_time,
                'overhead_time': processing_time - total_computation_time,
                'computation_ratio': total_computation_time / processing_time
            }
        }
        
        return results

def main():
    """メイン実行関数"""
    experiment = MillionRecordDCOExperiment()
    
    logger.info("DCO理論100万レコード実験開始")
    
    try:
        results = experiment.run_million_record_experiment()
        
        # 結果の保存
        output_file = 'million_record_dco_results.json'
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        
        # サマリー表示
        print("\n" + "="*70)
        print("DCO理論100万レコード実験結果")
        print("="*70)
        
        exp_results = results['experiment_results']
        perf_analysis = results['performance_analysis']
        
        print(f"【実験規模】")
        print(f"総レコード数: {results['total_records']:,}")
        print(f"バッチ数: {exp_results['num_batches']}")
        print(f"バッチサイズ: {exp_results['batch_size']:,}")
        
        print(f"\n【処理時間】")
        print(f"データ生成時間: {exp_results['data_generation_time']:.2f}秒")
        print(f"処理時間: {exp_results['processing_time']:.2f}秒")
        print(f"総実験時間: {exp_results['total_experiment_time']:.2f}秒")
        
        print(f"\n【性能指標】")
        print(f"レコード/秒: {perf_analysis['records_per_second']:,.0f}")
        print(f"レコードあたり: {perf_analysis['time_per_record_ms']:.3f}ms")
        print(f"100万レコード処理時間: {perf_analysis['time_per_million_records']:.2f}秒")
        
        print(f"\n【DCO値統計】")
        print(f"全体平均値: {exp_results['overall_mean_value']:.6f}")
        print(f"全体標準偏差: {exp_results['overall_std_value']:.6f}")
        print(f"バッチ間平均値変動: {exp_results['batch_statistics']['std_of_means']:.8f}")
        
        print(f"\n【メモリ効率】")
        print(f"ピークメモリ使用量: {perf_analysis['memory_efficiency']['peak_memory_used_mb']:.1f}MB")
        print(f"レコードあたりメモリ: {perf_analysis['memory_efficiency']['memory_per_record_bytes']:.1f}bytes")
        
        print(f"\n✅ 100万レコード実験完了：結果は '{output_file}' に保存されました")
        
    except Exception as e:
        logger.error(f"実験中にエラーが発生: {e}")
        raise

if __name__ == "__main__":
    main()

