#!/usr/bin/env python3
"""
DCO理論大規模実験：段階的検証（1万→5万→10万レコード）
計算値の安定性とスケーラビリティの評価
"""
import numpy as np
import time
import json
import logging
from concurrent.futures import ProcessPoolExecutor
from typing import Dict, List, Tuple
import psutil
import os

# ログ設定
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class LargeScaleDCOExperiment:
    """大規模DCO実験クラス"""
    
    def __init__(self):
        self.perspectives = ["Business", "Market", "Technology"]
        self.dimensions = ["Cognitive", "Value", "Temporal", "Spatial", 
                          "Social", "Technological", "Economic", "Strategic"]
        self.total_dimensions = len(self.perspectives) * len(self.dimensions)
        
    def generate_synthetic_data(self, num_records: int) -> np.ndarray:
        """合成データの生成"""
        logger.info(f"合成データ生成開始：{num_records:,}レコード")
        
        # 現実的な企業データを模擬した分布
        np.random.seed(42)  # 再現性確保
        
        # 各次元のデータを生成（0-1の正規化済み値）
        data = np.random.beta(2, 5, size=(num_records, self.total_dimensions))
        
        # 一部の次元に相関を導入（現実的な企業データの特性）
        for i in range(0, self.total_dimensions, 3):
            if i + 2 < self.total_dimensions:
                correlation_factor = 0.3
                data[:, i+1] = data[:, i+1] * (1 - correlation_factor) + data[:, i] * correlation_factor
                data[:, i+2] = data[:, i+2] * (1 - correlation_factor) + data[:, i] * correlation_factor
        
        logger.info(f"合成データ生成完了：形状 {data.shape}")
        return data
    
    def calculate_dco_value_batch(self, data_batch: np.ndarray) -> Tuple[float, Dict]:
        """DCO価値関数のバッチ計算"""
        batch_size = len(data_batch)
        
        # メモリ使用量監視
        process = psutil.Process(os.getpid())
        memory_before = process.memory_info().rss / 1024 / 1024  # MB
        
        start_time = time.time()
        
        # 3視点×8次元の構造で計算
        perspective_values = []
        
        for p_idx, perspective in enumerate(self.perspectives):
            # 各視点の8次元データを抽出
            start_dim = p_idx * len(self.dimensions)
            end_dim = start_dim + len(self.dimensions)
            perspective_data = data_batch[:, start_dim:end_dim]
            
            # 次元内統合（幾何平均で数値安定性確保）
            dimension_values = np.exp(np.mean(np.log(perspective_data + 1e-10), axis=1))
            perspective_values.append(dimension_values)
        
        # 視点間統合（乗算統合）
        perspective_array = np.array(perspective_values).T  # (batch_size, 3)
        final_values = np.exp(np.mean(np.log(perspective_array + 1e-10), axis=1))
        
        computation_time = time.time() - start_time
        
        # メモリ使用量計測
        memory_after = process.memory_info().rss / 1024 / 1024  # MB
        memory_used = memory_after - memory_before
        
        # 統計情報
        stats = {
            'mean_value': float(np.mean(final_values)),
            'std_value': float(np.std(final_values)),
            'min_value': float(np.min(final_values)),
            'max_value': float(np.max(final_values)),
            'computation_time': computation_time,
            'memory_used_mb': memory_used,
            'batch_size': batch_size
        }
        
        return float(np.mean(final_values)), stats
    
    def run_scalability_experiment(self, record_counts: List[int]) -> Dict:
        """スケーラビリティ実験の実行"""
        logger.info("=== DCO理論大規模スケーラビリティ実験開始 ===")
        
        results = {
            'experiment_timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'record_counts': record_counts,
            'stage_results': [],
            'scalability_analysis': {}
        }
        
        processing_times = []
        memory_usages = []
        value_means = []
        value_stds = []
        
        for stage, num_records in enumerate(record_counts, 1):
            logger.info(f"ステージ{stage}: {num_records:,}レコード実験開始")
            
            # データ生成
            data = self.generate_synthetic_data(num_records)
            
            # バッチサイズの決定（メモリ効率考慮）
            batch_size = min(10000, num_records)
            num_batches = (num_records + batch_size - 1) // batch_size
            
            stage_start_time = time.time()
            stage_values = []
            stage_stats = []
            
            # バッチ処理
            for batch_idx in range(num_batches):
                start_idx = batch_idx * batch_size
                end_idx = min(start_idx + batch_size, num_records)
                batch_data = data[start_idx:end_idx]
                
                batch_value, batch_stat = self.calculate_dco_value_batch(batch_data)
                stage_values.append(batch_value)
                stage_stats.append(batch_stat)
                
                if (batch_idx + 1) % 10 == 0:
                    logger.info(f"  バッチ {batch_idx + 1}/{num_batches} 完了")
            
            stage_total_time = time.time() - stage_start_time
            
            # ステージ結果の集計
            stage_result = {
                'stage': stage,
                'record_count': num_records,
                'total_time': stage_total_time,
                'time_per_record': stage_total_time / num_records,
                'mean_value': np.mean(stage_values),
                'std_value': np.std(stage_values),
                'total_memory_mb': sum(stat['memory_used_mb'] for stat in stage_stats),
                'num_batches': num_batches,
                'batch_size': batch_size
            }
            
            results['stage_results'].append(stage_result)
            
            # スケーラビリティ分析用データ
            processing_times.append(stage_total_time)
            memory_usages.append(stage_result['total_memory_mb'])
            value_means.append(stage_result['mean_value'])
            value_stds.append(stage_result['std_value'])
            
            logger.info(f"ステージ{stage}完了: {stage_total_time:.2f}秒, "
                       f"平均値: {stage_result['mean_value']:.6f}")
        
        # スケーラビリティ分析
        results['scalability_analysis'] = self._analyze_scalability(
            record_counts, processing_times, memory_usages, value_means, value_stds
        )
        
        return results
    
    def _analyze_scalability(self, record_counts: List[int], times: List[float], 
                           memories: List[float], means: List[float], 
                           stds: List[float]) -> Dict:
        """スケーラビリティ分析"""
        
        # 時間複雑性の分析
        time_ratios = []
        for i in range(1, len(times)):
            ratio = times[i] / times[i-1]
            record_ratio = record_counts[i] / record_counts[i-1]
            time_ratios.append(ratio / record_ratio)
        
        # 数値安定性の分析
        value_stability = {
            'mean_variation': np.std(means) / np.mean(means),
            'std_variation': np.std(stds) / np.mean(stds),
            'means': means,
            'stds': stds
        }
        
        # メモリ効率の分析
        memory_per_record = [mem / count for mem, count in zip(memories, record_counts)]
        
        return {
            'time_complexity_ratios': time_ratios,
            'avg_time_complexity_ratio': np.mean(time_ratios) if time_ratios else 0,
            'value_stability': value_stability,
            'memory_efficiency': {
                'memory_per_record_mb': memory_per_record,
                'memory_scaling_factor': memories[-1] / memories[0] if len(memories) > 1 else 1
            },
            'performance_summary': {
                'largest_scale_time': times[-1],
                'largest_scale_records': record_counts[-1],
                'time_per_million_records_estimate': (times[-1] / record_counts[-1]) * 1_000_000
            }
        }

def main():
    """メイン実行関数"""
    experiment = LargeScaleDCOExperiment()
    
    # 3段階検証：1万→5万→10万レコード
    record_counts = [10_000, 50_000, 100_000]
    
    logger.info("DCO理論大規模実験開始")
    logger.info(f"検証段階: {record_counts}")
    
    try:
        results = experiment.run_scalability_experiment(record_counts)
        
        # 結果の保存
        output_file = 'large_scale_dco_results.json'
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        
        # サマリー表示
        print("\n" + "="*60)
        print("DCO理論大規模実験結果サマリー")
        print("="*60)
        
        for stage_result in results['stage_results']:
            print(f"【ステージ{stage_result['stage']}】{stage_result['record_count']:,}レコード")
            print(f"  処理時間: {stage_result['total_time']:.2f}秒")
            print(f"  レコードあたり: {stage_result['time_per_record']*1000:.3f}ms")
            print(f"  平均DCO値: {stage_result['mean_value']:.6f}")
            print(f"  メモリ使用量: {stage_result['total_memory_mb']:.1f}MB")
        
        analysis = results['scalability_analysis']
        print(f"\n【スケーラビリティ分析】")
        print(f"時間複雑性比率: {analysis['avg_time_complexity_ratio']:.3f}")
        print(f"数値安定性(平均値変動): {analysis['value_stability']['mean_variation']:.6f}")
        print(f"100万レコード推定時間: {analysis['performance_summary']['time_per_million_records_estimate']:.1f}秒")
        
        print(f"\n✅ 実験完了：結果は '{output_file}' に保存されました")
        
    except Exception as e:
        logger.error(f"実験中にエラーが発生: {e}")
        raise

if __name__ == "__main__":
    main()

