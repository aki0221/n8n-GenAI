#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
付録D：評価指標分析プログラム

フェーズ2.2企業環境実証実験における評価指標の統計分析を実行するプログラム
DCO理論とOPSBC法の効果測定のための包括的データ分析機能を提供

作成日: 2025年1月7日
作成者: ManusAI
対象: フェーズ2.2企業環境実証実験
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from scipy.stats import ttest_ind, wilcoxon, shapiro, levene
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
import warnings
warnings.filterwarnings('ignore')

# 日本語フォント設定
plt.rcParams['font.family'] = 'DejaVu Sans'
sns.set_style("whitegrid")

class DCOEvaluationAnalyzer:
    """
    DCO理論評価指標分析クラス
    
    企業環境実証実験で収集されたデータの統計分析を実行し、
    DCO理論とOPSBC法の効果を定量的に評価する。
    """
    
    def __init__(self, data_file_path):
        """
        分析クラスの初期化
        
        Args:
            data_file_path (str): 分析対象データファイルのパス
        """
        self.data_file_path = data_file_path
        self.data = None
        self.quantitative_indicators = [
            'decision_accuracy_score', 'decision_speed_index', 'decision_consistency_index',
            'processing_time_24d', 'system_uptime_rate', 'data_quality_score',
            'process_efficiency_improvement', 'resource_optimization_rate',
            'roi_system_investment', 'operational_cost_reduction'
        ]
        self.qualitative_indicators = [
            'system_usability_score', 'satisfaction_index', 'learning_ease_score',
            'data_driven_culture_index', 'change_acceptance_index',
            'process_quality_improvement', 'strategic_thinking_improvement'
        ]
        
    def load_data(self):
        """
        実証実験データの読み込みと前処理
        
        CSVファイルからデータを読み込み、基本的な前処理を実行する。
        欠損値の処理、データ型の変換、異常値の検出を行う。
        """
        try:
            self.data = pd.read_csv(self.data_file_path, encoding='utf-8')
            print(f"データ読み込み完了: {len(self.data)}件のレコード")
            
            # 基本統計情報の表示
            print("\n=== データ基本情報 ===")
            print(f"データ形状: {self.data.shape}")
            print(f"欠損値数: {self.data.isnull().sum().sum()}")
            
            # 欠損値の処理
            self._handle_missing_values()
            
            # データ型の確認と変換
            self._convert_data_types()
            
            # 異常値の検出
            self._detect_outliers()
            
            return True
            
        except FileNotFoundError:
            print(f"エラー: ファイル '{self.data_file_path}' が見つかりません")
            return False
        except Exception as e:
            print(f"データ読み込みエラー: {str(e)}")
            return False
    
    def _handle_missing_values(self):
        """
        欠損値の処理
        
        定量的指標は平均値で補完、定性的指標は中央値で補完する。
        欠損率が50%を超える変数は分析から除外する。
        """
        missing_ratio = self.data.isnull().sum() / len(self.data)
        high_missing_cols = missing_ratio[missing_ratio > 0.5].index.tolist()
        
        if high_missing_cols:
            print(f"警告: 以下の変数は欠損率が50%を超えるため除外します: {high_missing_cols}")
            self.data = self.data.drop(columns=high_missing_cols)
        
        # 定量的指標の欠損値を平均値で補完
        for col in self.quantitative_indicators:
            if col in self.data.columns and self.data[col].isnull().any():
                mean_value = self.data[col].mean()
                self.data[col].fillna(mean_value, inplace=True)
                print(f"{col}の欠損値を平均値{mean_value:.3f}で補完")
        
        # 定性的指標の欠損値を中央値で補完
        for col in self.qualitative_indicators:
            if col in self.data.columns and self.data[col].isnull().any():
                median_value = self.data[col].median()
                self.data[col].fillna(median_value, inplace=True)
                print(f"{col}の欠損値を中央値{median_value:.3f}で補完")
    
    def _convert_data_types(self):
        """
        データ型の変換
        
        数値データの型を適切に設定し、カテゴリカルデータを処理する。
        """
        # 数値列の型変換
        numeric_cols = self.quantitative_indicators + self.qualitative_indicators
        for col in numeric_cols:
            if col in self.data.columns:
                self.data[col] = pd.to_numeric(self.data[col], errors='coerce')
        
        # 日付列の変換
        date_cols = ['measurement_date', 'decision_date', 'implementation_date']
        for col in date_cols:
            if col in self.data.columns:
                self.data[col] = pd.to_datetime(self.data[col], errors='coerce')
        
        print("データ型変換完了")
    
    def _detect_outliers(self):
        """
        異常値の検出
        
        IQR法とZ-score法を用いて異常値を検出し、レポートする。
        """
        outlier_summary = {}
        
        for col in self.quantitative_indicators + self.qualitative_indicators:
            if col not in self.data.columns:
                continue
                
            # IQR法による異常値検出
            Q1 = self.data[col].quantile(0.25)
            Q3 = self.data[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            iqr_outliers = self.data[(self.data[col] < lower_bound) | (self.data[col] > upper_bound)]
            
            # Z-score法による異常値検出
            z_scores = np.abs(stats.zscore(self.data[col]))
            z_outliers = self.data[z_scores > 3]
            
            outlier_summary[col] = {
                'iqr_outliers': len(iqr_outliers),
                'z_outliers': len(z_outliers),
                'total_records': len(self.data)
            }
        
        print("\n=== 異常値検出結果 ===")
        for col, summary in outlier_summary.items():
            iqr_ratio = summary['iqr_outliers'] / summary['total_records'] * 100
            z_ratio = summary['z_outliers'] / summary['total_records'] * 100
            print(f"{col}: IQR法 {summary['iqr_outliers']}件({iqr_ratio:.1f}%), Z-score法 {summary['z_outliers']}件({z_ratio:.1f}%)")
    
    def descriptive_statistics(self):
        """
        記述統計分析
        
        各評価指標の基本統計量を算出し、分布特性を分析する。
        """
        print("\n=== 記述統計分析 ===")
        
        # 定量的指標の記述統計
        quant_data = self.data[self.quantitative_indicators].dropna()
        quant_stats = quant_data.describe()
        
        print("\n定量的指標の記述統計:")
        print(quant_stats.round(3))
        
        # 定性的指標の記述統計
        qual_data = self.data[self.qualitative_indicators].dropna()
        qual_stats = qual_data.describe()
        
        print("\n定性的指標の記述統計:")
        print(qual_stats.round(3))
        
        # 正規性検定
        print("\n=== 正規性検定結果 ===")
        for col in self.quantitative_indicators + self.qualitative_indicators:
            if col in self.data.columns:
                statistic, p_value = shapiro(self.data[col].dropna())
                distribution = "正規分布" if p_value > 0.05 else "非正規分布"
                print(f"{col}: W={statistic:.4f}, p={p_value:.4f} ({distribution})")
        
        return quant_stats, qual_stats
    
    def comparative_analysis(self, group_column='treatment_group'):
        """
        比較分析
        
        DCO理論適用群と対照群の比較分析を実行する。
        
        Args:
            group_column (str): グループ分けに使用する列名
        """
        if group_column not in self.data.columns:
            print(f"エラー: グループ列 '{group_column}' が見つかりません")
            return None
        
        print(f"\n=== 比較分析 ({group_column}による群分け) ===")
        
        groups = self.data[group_column].unique()
        print(f"分析対象グループ: {groups}")
        
        comparison_results = {}
        
        for indicator in self.quantitative_indicators + self.qualitative_indicators:
            if indicator not in self.data.columns:
                continue
            
            group_data = []
            group_names = []
            
            for group in groups:
                group_subset = self.data[self.data[group_column] == group][indicator].dropna()
                if len(group_subset) > 0:
                    group_data.append(group_subset)
                    group_names.append(group)
            
            if len(group_data) < 2:
                print(f"{indicator}: 比較に十分なデータがありません")
                continue
            
            # 等分散性の検定
            levene_stat, levene_p = levene(*group_data)
            equal_var = levene_p > 0.05
            
            # 正規性の確認
            normal_dist = all(shapiro(data)[1] > 0.05 for data in group_data if len(data) >= 3)
            
            # 適切な統計検定の選択
            if normal_dist and equal_var:
                # 対応のないt検定
                statistic, p_value = ttest_ind(group_data[0], group_data[1], equal_var=True)
                test_name = "対応のないt検定"
            elif normal_dist and not equal_var:
                # Welchのt検定
                statistic, p_value = ttest_ind(group_data[0], group_data[1], equal_var=False)
                test_name = "Welchのt検定"
            else:
                # Mann-WhitneyのU検定
                statistic, p_value = stats.mannwhitneyu(group_data[0], group_data[1], alternative='two-sided')
                test_name = "Mann-WhitneyのU検定"
            
            # 効果量の計算（Cohen's d）
            pooled_std = np.sqrt(((len(group_data[0]) - 1) * group_data[0].var() + 
                                 (len(group_data[1]) - 1) * group_data[1].var()) / 
                                (len(group_data[0]) + len(group_data[1]) - 2))
            cohens_d = (group_data[0].mean() - group_data[1].mean()) / pooled_std
            
            comparison_results[indicator] = {
                'test_name': test_name,
                'statistic': statistic,
                'p_value': p_value,
                'cohens_d': cohens_d,
                'group_means': [data.mean() for data in group_data],
                'group_stds': [data.std() for data in group_data],
                'group_names': group_names
            }
            
            significance = "有意" if p_value < 0.05 else "非有意"
            effect_size = "大" if abs(cohens_d) >= 0.8 else "中" if abs(cohens_d) >= 0.5 else "小"
            
            print(f"\n{indicator}:")
            print(f"  {test_name}: 統計量={statistic:.4f}, p値={p_value:.4f} ({significance})")
            print(f"  効果量(Cohen's d): {cohens_d:.4f} ({effect_size})")
            for i, name in enumerate(group_names):
                print(f"  {name}: 平均={comparison_results[indicator]['group_means'][i]:.3f}, 標準偏差={comparison_results[indicator]['group_stds'][i]:.3f}")
        
        return comparison_results
    
    def correlation_analysis(self):
        """
        相関分析
        
        評価指標間の相関関係を分析し、相関行列とヒートマップを生成する。
        """
        print("\n=== 相関分析 ===")
        
        # 数値データのみを抽出
        numeric_data = self.data[self.quantitative_indicators + self.qualitative_indicators].dropna()
        
        # 相関行列の計算
        correlation_matrix = numeric_data.corr()
        
        print("相関行列:")
        print(correlation_matrix.round(3))
        
        # 強い相関関係の特定
        print("\n強い相関関係 (|r| >= 0.7):")
        strong_correlations = []
        for i in range(len(correlation_matrix.columns)):
            for j in range(i+1, len(correlation_matrix.columns)):
                corr_value = correlation_matrix.iloc[i, j]
                if abs(corr_value) >= 0.7:
                    var1 = correlation_matrix.columns[i]
                    var2 = correlation_matrix.columns[j]
                    strong_correlations.append((var1, var2, corr_value))
                    print(f"  {var1} - {var2}: r = {corr_value:.3f}")
        
        if not strong_correlations:
            print("  強い相関関係は検出されませんでした")
        
        # 相関行列のヒートマップ生成
        plt.figure(figsize=(12, 10))
        sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0,
                    square=True, fmt='.2f', cbar_kws={'shrink': 0.8})
        plt.title('評価指標間相関行列ヒートマップ')
        plt.tight_layout()
        plt.savefig('correlation_heatmap.png', dpi=300, bbox_inches='tight')
        plt.show()
        
        return correlation_matrix, strong_correlations
    
    def trend_analysis(self, time_column='measurement_date'):
        """
        時系列トレンド分析
        
        評価指標の時間的変化を分析し、改善トレンドを可視化する。
        
        Args:
            time_column (str): 時間軸に使用する列名
        """
        if time_column not in self.data.columns:
            print(f"エラー: 時間列 '{time_column}' が見つかりません")
            return None
        
        print(f"\n=== トレンド分析 ({time_column}による時系列分析) ===")
        
        # 時間順にソート
        time_data = self.data.sort_values(time_column)
        
        # 主要指標のトレンド可視化
        key_indicators = ['decision_accuracy_score', 'decision_speed_index', 
                         'system_usability_score', 'satisfaction_index']
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        axes = axes.ravel()
        
        for i, indicator in enumerate(key_indicators):
            if indicator in time_data.columns:
                axes[i].plot(time_data[time_column], time_data[indicator], 
                           marker='o', linewidth=2, markersize=4)
                axes[i].set_title(f'{indicator}の時系列変化')
                axes[i].set_xlabel('測定日')
                axes[i].set_ylabel(indicator)
                axes[i].grid(True, alpha=0.3)
                
                # トレンドライン追加
                x_numeric = pd.to_numeric(time_data[time_column])
                z = np.polyfit(x_numeric, time_data[indicator].dropna(), 1)
                p = np.poly1d(z)
                axes[i].plot(time_data[time_column], p(x_numeric), 
                           "r--", alpha=0.8, linewidth=2, label=f'トレンド (傾き: {z[0]:.4f})')
                axes[i].legend()
        
        plt.tight_layout()
        plt.savefig('trend_analysis.png', dpi=300, bbox_inches='tight')
        plt.show()
        
        # トレンド統計の計算
        trend_stats = {}
        for indicator in self.quantitative_indicators + self.qualitative_indicators:
            if indicator in time_data.columns:
                x_numeric = pd.to_numeric(time_data[time_column])
                y_values = time_data[indicator].dropna()
                if len(y_values) > 1:
                    slope, intercept, r_value, p_value, std_err = stats.linregress(x_numeric, y_values)
                    trend_stats[indicator] = {
                        'slope': slope,
                        'r_squared': r_value**2,
                        'p_value': p_value,
                        'trend_direction': '上昇' if slope > 0 else '下降' if slope < 0 else '横ばい'
                    }
        
        print("トレンド統計:")
        for indicator, stats_dict in trend_stats.items():
            significance = "有意" if stats_dict['p_value'] < 0.05 else "非有意"
            print(f"  {indicator}: {stats_dict['trend_direction']} (傾き: {stats_dict['slope']:.6f}, "
                  f"R²: {stats_dict['r_squared']:.3f}, p値: {stats_dict['p_value']:.4f}, {significance})")
        
        return trend_stats
    
    def generate_comprehensive_report(self, output_file='dco_evaluation_report.html'):
        """
        包括的分析レポートの生成
        
        全ての分析結果を統合した包括的なHTMLレポートを生成する。
        
        Args:
            output_file (str): 出力ファイル名
        """
        print(f"\n=== 包括的分析レポート生成 ===")
        
        # 分析実行
        desc_stats = self.descriptive_statistics()
        comparison_results = self.comparative_analysis()
        correlation_matrix, strong_correlations = self.correlation_analysis()
        trend_stats = self.trend_analysis()
        
        # HTMLレポート生成
        html_content = f"""
        <!DOCTYPE html>
        <html lang="ja">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>DCO理論評価指標分析レポート</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }}
                h1, h2, h3 {{ color: #333; }}
                table {{ border-collapse: collapse; width: 100%; margin: 10px 0; }}
                th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                th {{ background-color: #f2f2f2; }}
                .summary {{ background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 10px 0; }}
                .significant {{ color: #d32f2f; font-weight: bold; }}
                .non-significant {{ color: #666; }}
            </style>
        </head>
        <body>
            <h1>DCO理論評価指標分析レポート</h1>
            <p>生成日時: {pd.Timestamp.now().strftime('%Y年%m月%d日 %H:%M:%S')}</p>
            
            <div class="summary">
                <h2>分析サマリー</h2>
                <ul>
                    <li>分析対象レコード数: {len(self.data)}件</li>
                    <li>評価指標数: {len(self.quantitative_indicators + self.qualitative_indicators)}指標</li>
                    <li>測定期間: {self.data['measurement_date'].min()} ～ {self.data['measurement_date'].max()}</li>
                </ul>
            </div>
            
            <h2>1. 記述統計分析結果</h2>
            <h3>定量的指標</h3>
            {desc_stats[0].to_html()}
            
            <h3>定性的指標</h3>
            {desc_stats[1].to_html()}
            
            <h2>2. 比較分析結果</h2>
        """
        
        if comparison_results:
            for indicator, result in comparison_results.items():
                significance_class = "significant" if result['p_value'] < 0.05 else "non-significant"
                html_content += f"""
                <h3>{indicator}</h3>
                <ul>
                    <li>検定手法: {result['test_name']}</li>
                    <li class="{significance_class}">p値: {result['p_value']:.4f}</li>
                    <li>効果量(Cohen's d): {result['cohens_d']:.4f}</li>
                </ul>
                """
        
        html_content += f"""
            <h2>3. 相関分析結果</h2>
            <h3>強い相関関係 (|r| >= 0.7)</h3>
            <ul>
        """
        
        for var1, var2, corr in strong_correlations:
            html_content += f"<li>{var1} - {var2}: r = {corr:.3f}</li>"
        
        html_content += """
            </ul>
            
            <h2>4. トレンド分析結果</h2>
            <ul>
        """
        
        if trend_stats:
            for indicator, stats_dict in trend_stats.items():
                significance_class = "significant" if stats_dict['p_value'] < 0.05 else "non-significant"
                html_content += f"""
                <li>{indicator}: {stats_dict['trend_direction']} 
                    <span class="{significance_class}">(p値: {stats_dict['p_value']:.4f})</span>
                </li>
                """
        
        html_content += """
            </ul>
            
            <h2>5. 結論と推奨事項</h2>
            <div class="summary">
                <p>本分析結果に基づき、DCO理論とOPSBC法の効果について以下の結論が得られました：</p>
                <ul>
                    <li>統計的に有意な改善効果が確認された指標の特定</li>
                    <li>継続的な監視が必要な指標の特定</li>
                    <li>さらなる改善のための推奨事項の提示</li>
                </ul>
            </div>
        </body>
        </html>
        """
        
        # HTMLファイルの保存
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print(f"包括的分析レポートを '{output_file}' に保存しました")
        
        return output_file

def main():
    """
    メイン実行関数
    
    分析プログラムの実行例を示す。
    """
    print("DCO理論評価指標分析プログラム")
    print("=" * 50)
    
    # 分析クラスのインスタンス化
    analyzer = DCOEvaluationAnalyzer('evaluation_data.csv')
    
    # データ読み込み
    if analyzer.load_data():
        # 包括的分析の実行
        report_file = analyzer.generate_comprehensive_report()
        print(f"\n分析完了。詳細レポートは '{report_file}' をご確認ください。")
    else:
        print("データ読み込みに失敗しました。ファイルパスを確認してください。")

if __name__ == "__main__":
    main()

