# Wainfan (2010) - Multi-perspective Strategic Decision Making: Complete Chapter 3

## Chapter 3 - Methodology and Toolset of Multi-perspective Strategic Decision Making

### 学際的アプローチの理論的基盤

From policy analysis literature comes the methodology of identifying options, facilitating discussion of those considerations for which high-level decision makers' experience and judgment are most useful, and selecting an action-based option (e.g. "invest in that set of capabilities"). Some of the data mining applications and tools used in Exploratory Analysis come from policy domains. As discussed earlier, the MPSDM approach builds on Davis' line of research, the RDM methodology, as well as Dewar's work in policy analysis.

### 経済学・意思決定科学からの貢献

Economics and decision science seek to describe ways in which people choose. Much work has been done on the different models describing human choice. The initial framework chosen here, the scorecard methodology used frequently in multi-attribute decision theory, allows decision makers to view the performance of a few options to discussion. The so-called balanced scorecard methodology (Kaplan and Norton 1996) has been used in a variety of organizations over the years.

### 金融理論からの簡素化手法

Financial theory often works to simplify complex financial measures into a few simple metrics, such as expected risk and return, as well as to create two-dimensional representation of complex market behavior for decision makers. As described earlier, portfolio theory and its variants seek to simplify and reduce total risk exposure through diversification, a type of hedge.

### 心理学的洞察と認知的制約

Psychology researchers recognize that people are not always rational actors—that decisions are sometimes made not on the basis of increasing expected return, but rather on rules of thumb, biases, and heuristics used (sometimes without being explicit about the basis of the decision). Psychology literature also discusses the amount of complexity that people can usefully absorb, and encourages useful simplification of a problem. The author has been involved with psychological experiments aiming to help us understand how people prefer to characterize uncertainty, as well as some additional experiments involving high-level decision makers. One of the most interesting findings is that the problem must be simplified usefully, in order for the decision maker to not only understand it, but to communicate it to his or her superiors or stakeholders. Finally, the recent brain research involving imagery of different parts of the brain during decision

