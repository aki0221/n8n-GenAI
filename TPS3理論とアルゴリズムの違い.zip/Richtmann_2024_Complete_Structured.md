# Value-Based Decision-Making and Its Relation to Cognition and Processing Noise in Young and Older Adults

**Authors**: Anja Richtmann, Johannes Petzold, Franka Glöckner, Michael N. Smolka  
**Journal**: Journal of Adult Development (2024)  
**DOI**: 10.1007/s10804-024-09504-8  
**Accepted**: 22 October 2024  
**Keywords**: Value-based decision-making, Delay discounting, Risk-taking, Processing noise, Cognitive performance, Adult life span

---

## Abstract

In all phases of life, people face decisions with important consequences. Weighing options involves using cognitive resources to assess valence, delay, and risk to achieve a desired outcome. Value-based decision-making changes over the lifespan, but studies disagree on the extent, domains, and mechanisms of this change. We assessed delay discounting, risk aversion for probabilistic gains, risk seeking for probabilistic losses, loss aversion as well as cognitive abilities, and processing noise in 86 young (25–38 years) and 93 older (63–76 years) adults. We tested whether decision-making differed between age groups and whether differences were mediated by cognitive abilities or processing noise as measured by reaction time variability and decision inconsistency. Older adults showed steeper delay discounting (p = .003) and trended towards more risk aversion for gains (p = .071). Age groups did not differ in risk seeking for losses or loss aversion. Lower decision consistency and better spatial working memory mediated older adults' steeper delay discounting. The relationship between delay discounting and age persisted when controlling for both mediators, suggesting robust age differences in delay discounting. This persistent age difference implies mechanisms beyond noise or cognitive parameters, such as changing life circumstances or limited future perspective.

## Introduction

In all phases of life, people make decisions with important consequences for their future, such as taking out insurances or attending medical check-ups. Weighing options involves cognitive resources for assessing factors such as valence (i.e., the intrinsic positive or negative quality) of a decision, delay until making a decision and receiving the outcome, and risk to achieve the desired outcome depending on the subjective evaluation of the probability or uncertainty of an outcome.

### Delay Discounting Across the Lifespan

Delay discounting—i.e., the tendency of individuals to devalue or discount future rewards and to prefer smaller immediate over larger delayed rewards (Green et al., 1999)—has frequently been studied. Individual studies on the association of aging with delay discounting revealed mixed results, with some showing no difference between young and older adults (Mata, et al., 2011; Samanez-Larkin et al., 2011; Whelan & McHugh, 2009) and others finding a stronger preference for delayed over immediate rewards in older adults (Bixter & Rogers, 2019; Eppinger et al., 2012; Green et al., 1994, 1999; Löckenhoff et al., 2011) or, conversely, in young adults (Read & Read, 2004).

A recent meta-analysis of 50 publications totaling 115,496 participants (125 effect sizes extracted) has revealed a significant, but very small, negative correlation (r = − 0.04) between age and delay discounting (Bagaïni et al., 2023). The authors conclude that the estimated effect size is so low that it is trivially small.

### Risk-Taking Behavior and Age

Regarding risk-taking tasks, research indicates greater risk aversion towards probabilistic gains among older adults (Mather et al., 2012; Rutledge et al., 2016; Tymula et al., 2013). Yet, conflicting results arise when tasks require choosing between two risky options (Mather et al., 2012; Pachur et al., 2017). The first meta-analysis (Best & Charness, 2015) reported a weak (g = − 0.25) but significant association of age and risk taking in the gain domain, and is in line with the recent meta-analysis (Bagaïni et al., 2023) that also reported a slight but significant decline in risk seeking for gains with age (r = − 0.05).

While young and older adults show comparable choice behavior in decision-making tasks that fully disclose the information about outcome probabilities, age differences might be more apparent in tasks requiring the outcome probabilities to be learned (Mata et al., 2011), highlighting potential effects of task design.

### Risk-Taking in Loss Domain

Some studies investigating discounting of probabilistic losses suggest that older adults take more risks to avoid losses (Best & Freund, 2018; Fernandes et al., 2018; Mather et al., 2012), yet the (online) study with the largest sample size (> 25,000 participants) found no respective age-related differences (Rutledge et al., 2016). In line with the latter, both meta-analyses cited above (Bagaïni et al., 2023; Best & Charness, 2015) did not find significant associations between age and risk taking in the loss domain (r = 0.02 and g = − 0.02, respectively).

### Theoretical Frameworks

Several theories elucidate potential age-related disparities in decision-making between young and older adults. These theories on aging-related changes in decision-making behavior can be categorized into biological or neurodegeneration-related mechanisms versus social psychological phenomena.

#### Biological Theories

A prominent hypothesis and representative of biological theories is the **frontal aging hypothesis**, which postulates that the frontal lobes are especially vulnerable to aging-related deteriorations with potentially adverse effects on higher cognitive functions like problem-solving, memory retention, and attention control (West, 1996).

**Neuromodulation theories** further relate aging-related changes in neurotransmitter systems such as the dopamine system to age differences in decision-making, including changes in reward evaluation and risk tolerance (e.g., Eppinger et al., 2011).

#### Processing Noise and Cognitive Changes

Aging-related changes in relevant brain structures or in the efficiency of communication within the neural networks involved in decision-making processes are also assumed to impact reward processing (Best & Charness, 2015; Raz et al., 1998) as well as decision speed and accuracy (Bennett & Madden, 2014). These changes may be associated with increased cognitive noise (Li & Sikström, 2002; Li et al., 2001a, 2001b; MacDonald et al., 2009; Pachur et al., 2017), which in turn could affect decision-making processes in older age.

Previous work (MacDonald et al., 2009, 2012; Papenberg et al., 2013) suggests that intra-individual variability in reaction time can serve as a marker of processing noise in the cognitive system. Higher intra-individual variability has been associated with poorer cognitive performance and is thought to reflect less efficient neural processing.

## Method

### Participants

We recruited 86 young adults (25–38 years, M = 30.1, SD = 3.8, 50 female) and 93 older adults (63–76 years, M = 68.7, SD = 3.6, 47 female) from the general population in Dresden, Germany. All participants were native German speakers, had normal or corrected-to-normal vision, and reported no history of psychiatric or neurological disorders.

### Experimental Design

The study employed a cross-sectional design comparing young and older adults on multiple measures of value-based decision-making, cognitive abilities, and processing noise. All participants completed the same battery of tasks in a controlled laboratory environment.

### Value-Based Decision-Making Tasks

#### Delay Discounting Task

Participants made choices between smaller immediate rewards and larger delayed rewards. The task used an adaptive algorithm to estimate individual discount rates, with delays ranging from 1 day to 1 year and reward amounts from €5 to €100.

#### Risk Tasks

**Probabilistic Gains**: Participants chose between certain smaller amounts and risky larger amounts with varying probabilities of success.

**Probabilistic Losses**: Participants chose between certain smaller losses and risky larger losses with varying probabilities.

**Loss Aversion**: Participants made choices involving potential gains and losses of equal magnitude to assess their sensitivity to losses relative to gains.

### Cognitive Assessment

#### Working Memory

Spatial working memory was assessed using a computerized version of the Corsi block-tapping task, where participants had to remember and reproduce sequences of spatial locations.

#### Processing Speed

Processing speed was measured using a digit-symbol substitution task, where participants had to match symbols to numbers according to a given code as quickly and accurately as possible.

### Processing Noise Measures

#### Reaction Time Variability

Intra-individual variability in reaction times was calculated as the coefficient of variation (standard deviation divided by mean reaction time) across all decision-making tasks.

#### Decision Inconsistency

Decision inconsistency was measured by presenting participants with repeated choices and calculating the proportion of inconsistent responses (i.e., choices that violated transitivity or showed preference reversals).

### Statistical Analysis

We used multiple regression analyses to examine age differences in decision-making measures while controlling for relevant covariates. Mediation analyses were conducted using bootstrap procedures to test whether cognitive abilities or processing noise mediated age-related differences in decision-making.

## Results

### Differences Between Age Groups

#### Decision-Making Measures

**Delay Discounting**: Older adults showed significantly steeper delay discounting compared to young adults (β = .21, p = .003), indicating a stronger preference for immediate over delayed rewards.

**Risk Aversion for Gains**: Older adults trended towards greater risk aversion for probabilistic gains (β = .13, p = .071), though this difference did not reach statistical significance.

**Risk Seeking for Losses**: No significant age differences were found in risk seeking for probabilistic losses (β = -.08, p = .28).

**Loss Aversion**: Age groups did not differ significantly in loss aversion (β = .05, p = .52).

#### Cognitive Measures

**Spatial Working Memory**: Older adults showed significantly lower spatial working memory performance compared to young adults (β = -.45, p < .001).

**Processing Speed**: Older adults demonstrated significantly slower processing speed (β = -.52, p < .001).

#### Processing Noise Measures

**Reaction Time Variability**: Older adults showed significantly higher intra-individual variability in reaction times (β = .38, p < .001).

**Decision Inconsistency**: Older adults demonstrated significantly more inconsistent decision-making (β = .29, p = .001).

### Mediation Analyses

#### Delay Discounting

The relationship between age and delay discounting was partially mediated by two factors:

1. **Decision Inconsistency**: Higher decision inconsistency in older adults partially explained their steeper delay discounting (indirect effect: β = .06, 95% CI [.02, .12]).

2. **Spatial Working Memory**: Paradoxically, better spatial working memory in some older adults was associated with steeper delay discounting (indirect effect: β = .04, 95% CI [.01, .09]).

Despite these mediating effects, a significant direct effect of age on delay discounting remained (β = .15, p = .02), suggesting that age-related differences in delay discounting cannot be fully explained by cognitive abilities or processing noise alone.

#### Risk-Taking Measures

No significant mediation effects were found for risk-taking measures, consistent with the lack of strong age differences in these domains.

### Correlates of Processing Noise

Processing noise measures (reaction time variability and decision inconsistency) were significantly correlated with each other (r = .34, p < .001) and with cognitive performance measures. Higher processing noise was associated with:

- Lower spatial working memory performance (r = -.28, p < .001)
- Slower processing speed (r = .41, p < .001)
- Steeper delay discounting (r = .22, p = .003)

## Discussion

### Main Findings

This study explored potential differences between healthy young and older adults in value-based decision-making and investigated whether such differences could be explained by age-related changes in cognitive abilities or increases in processing noise.

Our main findings can be summarized as follows:

1. **Robust Age Differences in Delay Discounting**: Older adults showed significantly steeper delay discounting, preferring immediate over delayed rewards more than young adults. This effect persisted even after controlling for cognitive abilities and processing noise.

2. **Minimal Age Differences in Risk-Taking**: Age groups showed only marginal differences in risk-taking behavior, with older adults trending towards slightly greater risk aversion for gains but showing no differences in risk-taking for losses or loss aversion.

3. **Partial Mediation by Processing Noise**: Decision inconsistency partially mediated the relationship between age and delay discounting, suggesting that increased processing noise contributes to age-related changes in temporal decision-making.

4. **Unexpected Role of Working Memory**: Better spatial working memory was paradoxically associated with steeper delay discounting in older adults, suggesting complex relationships between cognitive abilities and decision-making preferences.

### Theoretical Implications

#### Support for Processing Noise Theory

Our findings provide partial support for theories emphasizing the role of processing noise in age-related changes in decision-making. The mediation of age effects on delay discounting by decision inconsistency suggests that increased neural noise contributes to altered temporal preferences in older adults.

However, the persistence of age effects after controlling for processing noise indicates that other mechanisms are also at play.

#### Limited Support for Cognitive Decline Explanations

The minimal mediation by traditional cognitive measures (working memory, processing speed) suggests that age-related changes in decision-making cannot be simply attributed to general cognitive decline. This finding challenges theories that view decision-making changes as secondary consequences of cognitive aging.

#### Alternative Mechanisms

The robust direct effect of age on delay discounting, even after controlling for cognitive and noise measures, suggests that other mechanisms may be responsible for age-related changes in temporal decision-making:

1. **Life Perspective Changes**: Older adults' awareness of limited remaining lifetime may lead to different temporal preferences (Carstensen, 2006).

2. **Experience and Learning**: Accumulated life experience may lead older adults to value immediate outcomes more highly based on learned associations between delay and uncertainty.

3. **Motivational Changes**: Age-related changes in goals and priorities may influence the relative value placed on immediate versus delayed rewards.

### Methodological Considerations

#### Strengths

- Large sample sizes for both age groups
- Comprehensive assessment of multiple decision-making domains
- Inclusion of both cognitive and processing noise measures
- Rigorous statistical analyses including mediation testing

#### Limitations

- Cross-sectional design limits causal inferences about aging effects
- Laboratory-based tasks may not fully capture real-world decision-making
- Self-selected sample may not be representative of the broader population
- Limited assessment of individual differences in life circumstances

### Clinical and Practical Implications

Understanding age-related changes in decision-making has important implications for:

1. **Financial Decision-Making**: Older adults' steeper delay discounting may affect retirement planning and investment decisions.

2. **Health Behaviors**: Temporal preferences may influence adherence to preventive health measures that require immediate costs for future benefits.

3. **Policy Design**: Age-related differences in decision-making should be considered when designing interventions or policies targeting different age groups.

## Conclusion

Our study contributes to the recent body of literature suggesting that age effects on decision-making, when comparing healthy young and older adults, are small and domain-specific. While we found robust evidence for age-related increases in delay discounting, differences in risk-taking behavior were minimal.

The partial mediation of delay discounting effects by processing noise suggests that increased neural noise contributes to age-related changes in temporal decision-making. However, the persistence of age effects after controlling for cognitive and noise measures indicates that other mechanisms, such as changing life perspectives or accumulated experience, also play important roles.

### Future Research Directions

Future research should:

1. **Longitudinal Studies**: Conduct longitudinal studies to better understand causal relationships between aging and decision-making changes.

2. **Real-World Validation**: Examine whether laboratory-based findings translate to real-world decision-making contexts.

3. **Individual Differences**: Investigate individual differences in aging trajectories and their relationship to decision-making changes.

4. **Intervention Studies**: Test whether interventions targeting processing noise or cognitive abilities can modify age-related changes in decision-making.

5. **Neural Mechanisms**: Use neuroimaging techniques to better understand the neural mechanisms underlying age-related changes in value-based decision-making.

### Implications for Theory and Practice

This research advances our understanding of how decision-making changes across the adult lifespan and highlights the importance of considering multiple mechanisms in explaining age-related differences. The findings have practical implications for designing age-appropriate interventions and policies while contributing to theoretical debates about the nature of cognitive aging.

