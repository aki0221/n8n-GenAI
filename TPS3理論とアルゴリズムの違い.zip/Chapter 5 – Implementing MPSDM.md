Chapter 5 – Implementing MPSDM

Practical considerations
In this work, strategic decision making considers longer time frames and shapes the
course of an organization more than tactical, or operational decision making. The topic of
multi-perspective strategic decision making (MPSDM) is of interest to a variety of US and
global organizations who are finding that the decision-making group includes, or must
consider, a wider set of perspectives--values, beliefs, and expectations--than ever before.
This research draws from literatures in policy analysis, economics and decision science,
financial analysis, psychology, and system thinking. It extends the concept of exploratory
analysis to explicitly include parameters representing perspectives (including those used
to score and aggregate factors in a multiresolution model) in parallel with more objective
factors. This dissertation contributes to the state of the art by providing and illustrating the
principles, methods and tools to explicitly consider diverse perspectives of stakeholders
and decision makers in creating strategy upon which they can agree.
The MPSDM approach is envisioned to fit into a high-level decision-making process
that involves multiple contributors to a decision who attempt to achieve a significant
degree of consensus. The approach also would fit in organizations in which decisions are
made by votes. It would be applicable to a group that seeks consensus but—if need be—
proceeds with the decision of a single leader. Much of the approach could be adapted for
use by a single decision maker who aims to get input from others, or who wishes to
communicate a rationale for the decision in order to gain alignment. In particular, the
iterative nature of the process could be of use when individuals identify issues that affect
their support.
The MPSDM approach presupposes that analytical support resources are available
to evaluate options. This support could come from a staff organization, a consulting
arrangement, or perhaps a group of analysts representing the different decision-making
constituencies or areas of expertise. The decision makers are envisioned to meet as a
139

group at least twice. The first session would cover the approach, Relative Option
Superiority as it relates to the evaluation of the initial criteria, and would develop
strategies and option modifications using the time frame/controllability heuristic. The
subsequent session(s) would finalize the strategy after at least one iteration of the
MPSDM methodology. More group discussions may be needed, and that many
communications occur outside the strategic planning sessions, in chance meetings or via
informal means.
It is recognized that some organizations do not have a strong tradition of analysisbased strategic planning. A scorecard is a relatively simple thing to construct, perhaps
even real time if needed, and it is conceivable that criteria and forces driving the system
could be elicited from expert judgment. However, to be truly effective, a strategy should
consider a broad set of options in a wide parameter space, which is difficult to do
systematically without analytical support. One of the aims of the MPSDM approach is that
the simplified depictions of the problem in scorecards, box-and-whisker plots or the time
frame/controllability heuristic will appeal to a variety of organizational cultures.
Finally, an effective strategic decision-making methodology takes into account the
fact that decision makers are often not the final judges of their strategy. Executives have
boards, elected officials have voters, and almost everyone has constituencies and bill
payers. One of the most important results from the qualitative portion of RDM research is
that strategic decision-makers must be able to communicate the reasons for the group’s
decisions to their constituencies. Typically, the constituents have narrower views of the
system than the decision makers, so the graphical aids in the MPSDM toolset may be
useful outside of the group.
The frequency of strategic planning exercises varies by organization; it is not
uncommon to have a five-year strategy which is revisited every few years, although some
organizations evaluate strategy yearly. It is hoped that the more straightforward the
process, the less cumbersome it will become and the more likely organizations will be to
perform strategic planning on a regular basis. One of the biggest challenges of the
MPSDM process is creating the model of the system. Using a multiresolution model may
encourage re-use of important elements rather than “starting from scratch” every time.
140

How does MPSDM help decision makers agree on strategy despite diverse
perspectives?
MPSDM offers several ways to explicitly address different values, beliefs, and
expectations without requiring the individuals in the group to agree on them. First, the
framework chosen is an analytical one, based on a multiresolution model that includes
representations of many different types of perspectives and uncertain factors. Second,
options are chosen to be action oriented, as in “invest here,” “watch for that sign post,”
etc. Third, so-called perspective parameters are explored simultaneously with more
objective factors. This allows the effect of different perspectives to be determined. Fourth,
the recommended figure of merit is relative option superiority for specific criteria. Although
the group may never agree on the absolute expected return or risk of an option, or which
score deserves a “red” rating, agreement is more likely when this more qualitative
concept is discussed using an annotated box-and-whisker plot. In addition, this decision
aid can elicit discussion of the relative importance of the different criteria in the face of
computational experimental results.
Fifth, exploratory analysis identifies the most important values, beliefs, and
expectations that drive the outcomes of interest. This is not to say that an individual’s
perspectives are not important to the individual—in fact the judgment of high-level
decision makers is an important asset they bring to the table. However, not all values,
beliefs, and expectations affect the return, risk, or cost by the same magnitude. The
MPSDM analytical methodology and discussion aids help groups glean and share
insights about the system and each other: return/risk/cost performance, which criteria
differentiate the options, which options may be relatively inferior or superior to others, and
which values are of highest priority. MPSDM proposes discussion aids such as annotated
box-and-whisker plots to focus the discussion on factors which the exploratory analysis
determines are the ones driving the outcomes of interest.
In addition, the time frame/controllability heuristic guides the strategy discussion to
address those driving factors, suggesting circumstances where it is wise to invest in
shifting resources, sign posts, shaping actions, or adaptiveness.
141

Finally, there may always be minority opinions on expectations of the future or
beliefs about adversary’s capability. As decision-making groups grow more
heterogeneous, it is reasonable to imagine that the group’s range of views of the future
may be very wide. Traditional management literature prescribes coming to agreement on
expected futures, or defining some average among the group that may represent the
group’s expectation. MPSDM, on the other hand, views these minority views as one way
to identify a broad array of possible futures. Another tool to explore the extreme corners
of outcome space is the computational experiment, wherein assumptions are varied
simultaneously, with the resulting outcomes covering the plausible futures. If one of these
combinations of assumptions, or some minority view of the future, proves prescient, it is
better to plan for it early while the option set is relatively broad. Thus, a difference in
perspectives doesn’t have to be associated with a clash in consensus, but rather an
opportunity to plan for some force that may drive outcomes in the most favorable way.
Minority opinions, rather than being a barrier to agreement, can be an opportunity to plan
hedges “just in case” the opinion is prescient.
The preceding discussion is supported by the following principle:
Principle #6: Groups can agree on strategic actions without agreeing on values,
beliefs, and expectations.

142

Bibliography
Arrow, K. (1951). Social Choice and Individual Values, John Wiley, New York.
Baird, I. S. and H. Thomas (1985). “Toward a Contingency Model of Strategic Risk
Taking.” The Academy of Management Review, 10:2, 230-243.
Bankes, S. C. (1993). “Exploratory Modeling for Policy Analysis.” Operations Research,
41:3, 435-449.
Bankes, S. C. (2003). “Tools and Techniques for Developing Policies for Complex and
Uncertain Systems.” Proceedings of the National Academy of Sciences, 99:3,
7263-7266.
Bardach, E. (2000). A Practical Guide for Policy Analysis. Seven Bridges Press, New
York.
Baysinger, B. D. and H.E. Butler (1985). “Corporate governance and the board of
directors: Performance effects of changes in board composition.” Journal of Law
and Economics, 1, 101-125.
M. Beer and R. Eisenstat (2000). “The Silent Killers of Strategy Implementation and
Learning.” Sloan Management Review.
Bell, D.E. (1995). “Risk, Return, and Utility.” Management Science, 41:1, 23-30.
Bettman, J. (1979). An Information Processing Theory of Consumer Choice, Reading,
Addison-Wesley, Readington, MA.
Bigelow, J.H. and P.K. Davis (2003). Implications for Model Validation of Multiresolution,
Multi-perspective Modeling (MRMPM) and Exploratory Analysis, RAND
Corporation, Santa Monica, CA.
Bradbury, J. A. (1989). “The Policy Implications of Differing Concepts of Risk.”
Science Technology Human Values, 14, 380-399.
Bracken, P. (1990). Strategic Planning for National Security: Lessons from Business
Experience, RAND Corporation, Santa Monica, CA.
Bracken, P., J. Birkler, and A. Slomovik (1996). Shaping and Integrating the Next Military:
Organization Options for Defense, RAND Corporation, Santa Monica, CA.
Brans, J., B. Mareschal, and P. Vincke (1986). “How to select and how to rank projects:
The PROMETHEE method for MCDM.” European Journal of Operational Research,
24, 228–238.
Brewer, G.D. (2009). “Five ‘Easy’ Questions.” Science, 325, 1075-1076.
Brieman L., J. Friedman, R. Olshen, and C. Stone (1984). Classification and Regression
Trees. Chapman & Hall, London.
143

Bryant, B. (2009) “sdtoolkit: Scenario Discovery Tools to Support Robust Decision
Making.” in Users’ Manual Package ‘sdtoolkit’, RAND Corporation. Available for
download at: http://CRAN.R-project.org/package=sdtoolkit
Bryant, B.P. and R. J. Lempert (2009). “Thinking Inside the Box: A Participatory,
Computer-Assisted Approach for Scenario Discovery.” Technological Forecasting
and Social Change, Oct, 2009.
Camerer, C.F. (2008). “The Potential of Neuroeconomics.” Economics and Philosophy,
24, 369-379.
Chaffe, E. E. (1985). “Three Models of Strategy.” Academy of Management Review, 10:1,
89-98.
Chermack, T.J., S.A. Lynham, W.E.A. Ruona (2001). “A Review of Scenario Planning
Literature.” Futures Research Quarterly, summer.
Chesler, L.G. and B.F. Goeler (1973). The STAR Methodology for Short-Haul
Transportation: Transportation System Impact Assessment, RAND Corporation,
Santa Monica, CA.
Cohen, D., A. Dey, and T. Lys (2007). “The Sarbanes Oxley “Act of 2002: Implications for
Compensation Contracts and Managerial Risk-Taking.” Available at
http://ssm.com/abstract=568483
Cooper, R. G., S. J. Edgett, and E. K. Kleinschmidt (1998). Portfolio Management for new
products, Addison-Wesley, Readington, MA.
Cyert, R. M. and J. G. Marsh (1963). A Behavioral Theory of the Firm, Prentice-Hall,
Englewood Cliffs, NJ.
Davis, P.K. (1988). The Role of Uncertainty in Assessing the NATO/Pact Central Region
Balance, RAND Corporation, Santa Monica, CA.
Davis, P.K. (1988). National Security Planning in an Era of Uncertainty, RAND
Corporation, Santa Monica, CA.
Davis, P. K. (1993). An Introduction to Variable-Resolution Modeling and CrossResolution Model Connection, RAND Corporation, Santa Monica, CA.
Davis, P.K. (1994), “Institutionalizing Planning for Adaptiveness.” in P.K. Davis (ed.), New
Challenges in Defense Planning: Rethinking How Much Is Enough, RAND
Corporation, Santa Monica, CA.
Davis, P. K. (2000). “Exploratory Analysis Enabled by Multiresolution, Multi-perspective
Modeling.” Proceedings of the 2000 Winter Simulation Conference, R. R. Barton, K.
Kang, and P. A. Fishwick (editors).
Davis, P. K. (2002). Analytical Architecture for Capabilities-Based Planning, MissionSystem Analysis, and Transformation, RAND Corporation, Santa Monica, CA.

144

Davis, P.K. (2003). “Exploratory Analysis and Implications for Modeling.” In New
Challenges, New Tools for Defense Decisionmaking, S. Johnson, M. Libicki, and G.
Treverton (eds), RAND Corporation, Santa Monica, CA.
Davis, P. K. (2005). “Introduction to Multiresolution, Multi-perspective Modeling (MRMPM)
and Exploratory Analysis.” Working paper WR-224, RAND, Santa Monica, CA.
Davis, P.K., S. C. Bankes, and M. Egner (2007). Enhancing Strategic Planning with
Massive Scenario Generation: Theory and Experiments, RAND Corporation, Santa
Monica, CA.
Davis, P.K. and J.H. Bigelow (1998). Experiments in Multiresolution Modeling (MRM),
RAND Corporation, Santa Monica, CA.
Davis, P.K. and J.H. Bigelow (2003). Motivated Metamodels: Synthesis of Cause-Effect
Resoning and Statistical Metamodeling, RAND Corporation, Santa Monica, CA.
Davis, P.K., J.H. Bigelow, and J. McEver (2000). Reprinted from Proceedings of the 2000
Winter Simulation conference, J. A. Joines, R. R. Barton, K. Kang, and P.A.
Fishwick (editors), 2000 and Proceedings of the SPIE, Vol. 4026.
Davis, P.K., and M.J. Carrillo (1997). Exploratory Analysis of ‘The Halt Problem’: A
briefing on Methods and Initial Insights, RAND Corporation, Santa Monica, CA.
Davis, P.K. and P. Dreyer (2009). RAND’s Portfolio Analysis Tool: Theory, References,
and Reference Manual, RAND Corporation, Santa Monica, CA.
Davis, P. K., D. Gompert, and R. Kugler (1996). Adaptiveness for National Defense: the
Basis of a New Framework, RAND Issue Paper IP-155, RAND Corporation, Santa
Monica, CA.
Davis, P. K. and R. Hilestad (2002). Exploratory Analysis for Strategy Problems with
Massive Uncertainty, RAND Corporation, Santa Monica, CA.
Davis, P. K., S. Johnson, D. Long and D.C. Gompert (2008). Developing ResourceInformed Strategic Assessments and Recommendations, RAND Corporation,
Santa Monica, CA.
Davis, K. P., J. Kulick, and M. Egner (2005). Implications of modern decision science for
military decision support systems. RAND Corporation, Santa Monica, CA.
Davis, P.K., J. McEver, and B. Wilson (2002). Measuring Interdiction Capabilities in the
Presence of Anti-Access Strategies: Exploratory Analysis to Inform Adaptive
Strategy for the Persian Gulf, RAND Corporation, Santa Monica, CA.
Davis, P.K. and J.A. Winnefeld (1983). The RAND Strategic Assessment Center: An
Overview and Interim Conclusions about Utility and Development Options, RAND
Corporation, Santa Monica, CA.
Davis, P.K, R.D. Shaver, and J. Beck (2008). Portfolio Analysis Methods for Assessing
Capability Options, RAND Corporation, Santa Monica, CA.
145

Davis, P.L., R. D. Shaver, G. Gvineria, and J. Beck (2008). Finding Candidate Options for
Investment Analysis: A tool for Moving from Building Blocks to Composite Options
(BCOT), RAND Corporation, Santa Monica, CA.
Dean, J. and M. Sharfman, (1996). “Does Decision Process Matter? A Study of
Strategic Decision-Making Effectiveness.” Academy of Management Journal, 39:2,
368-396.
Dewar, J.A. (2001). Assumption-Based Planning – A Tool for Reducing Available
Surprises, Cambridge University Press, Santa Monica, CA.
Dewar, J. A., C.H. Builder, W.M. Hix, and M.H. Levin (1993). Assumption-Based
Planning: A Tool for Very Uncertain Times, RAND Corporation, Santa Monica, CA
Dewar, J. A., and M. H. Levin (1992). Assumption-Based Planning for Army-21, RAND
Corporation, Santa Monica, CA.
DeWeerd, H. A. (1967). Political-Military Scenarios, RAND Corporation, Santa Monica,
CA.
Downey, H.K. and J. W. Slocum (1975). “Uncertainty: Measures, Research, and Sources
of Variation.” Academy of Management Journal, 18:3, 562-578.
Dreyer, P. and P.K. Davis (2005). Portfolio Analysis Tool for Ballistic Missile Defense
(PAT-MD): Methodology and User’s Guide, RAND Corporation, Santa Monica, CA.
Dreyer, P. and P.K. Davis (2009). RAND’s Portfolio Analysis Tool: Theory, Methods and
Users’ Manual (2nd Edition), TR262-2, RAND Corporation, Santa Monica, CA.
Eherenberg, R. G. (2004). Governing Academia, Who’s in Charge at the Modern
University? Cornell Press, Ithaca, NY.
Eisenhardt, K. (1989). “Making Fast Strategic Decisions in High-Velocity Environments.”
Academy of Management Journal, 32:3, 543-576.
Eisenhardt, K. M., and M. J. Zbaracki (1992). “Strategic Decision Making.” Strategic
Management Journal, 13, 17-37.
Elton, E.J., and M.J. Gruber (1991). Modern Portfolio Theory and Investment Analysis,
Wiley, New York.
Elton, E. J., M. J. Gruber, S. J. Brown, and W. N. Goetzmann (2006). Modern Portfolio
Theory and Investment Analysis, Wiley, New York.
Entman, R. M. (1993). “Framing: Toward Clarification of a Fractured Paradigm.” Journal
of Communication, 43, 51-58.
Figueira, J., S. Greco, M. Ehrgott, eds (2005). Multiple Criteria Decision Analysis: State of
the Art Surveys, Springer’s International Series in Operations Research and
Management Science. Springer Science and Business Media, New York.
Fishburn, P.C. (1984). “Foundations of Risk Measurement. 1. Risk as Probable Loss.”
Management Science, 30:4, 396-406.
146

Fortune, J. and G. Peters (1994). “Systems Analysis of Failures as a Quality
Management Tool.” British Journal of Management, 5, 205-213.
Friedman, J.H. and N.I. Fisher (1999). “Bump Hunting in High Dimensional Data.”
Statistical Computing, 9, 123-143.
Gigerenzer, P., M. Todd, and the ABC Research Group (1999). Simple heuristics That
Make Us Smart, Oxford University Press, Oxford, UK.
Goeller, B. F., A. Abrahamse, J.H. Bigelow, J. G. Bolten, D. M. De Ferranti, J. C.
DeHaven, T. F. Kirkwood, and R. Petruschell (1977). Protecting an Estuary from
Floods—A Policy Analysis of the Oosterschelde, Vol. 1, Summary Report, RAND
Corporation, Santa Monica, CA.
Hammond, K. R., R.M. Hamm, J. Grassia, and T. Pearson (1997). “Direct comparison of
the Efficacy of Intuitive and Analytical Cognition in Expert Judgment.” In Research
on Judgment and Decision Making: Currents, Connections, and Controversies,
W.M. Goldstein and R. M. Hogarth, eds. Cambridge University Press, Cambridge,
MA.
Goodstein, J., K. Gautan, and W. Boeker (1995). “The Effects of Board Size and Diversity
on Strategic Change.” Strategic Management Journal, 15:3, 241-250.
Graham, J. D., and J. B. Wiener (1995). Risk versus risk tradeoffs in protecting health and
the environment, Harvard University Press, Cambridge, MA.
Groves, D. G. (2005). New Methods for Identifying Robust Long-term Water Resources
Management Strategies for California. Doctoral Dissertation, Pardee-RAND
Graduate School, Santa Monica, CA.
Groves, D.G., D. Knopman, R. Lempert, S. Berry, and L. Wainfan (2008), Identifying and
Reducing Climate-Change Vulnerabilities in Water Management Plans, RAND
Corporation, Santa Monica, CA.
Groves, D. G. and R. J. Lempert (2007). “A New Analytic Method for Finding PolicyRelevant Scenarios.” Global Environment Change, 17, 73-85.
Gupta, S. K., and J. Rosenhead (1972), “Robustness in Sequential Investment
Decisions.” Management Science, 15:2, 18–29.
Hagstrom, R. G. (1999). The Warren Buffett Portfolio: Mastering the Power of the Focus
Investment Strategy, John Wiley & Sons, New York.
Hastie, T., and R. Tibshirani (2009). The Elements of Statistical Learning: Data Mining,
Inference, and Prediction, Second Edition, Springer, New York.
Heifetz, Ronald (1994). Leadership Without Easy Answers, Harvard University Press,
Cambridge, MA.
Hillestad, R.J. and P.K. Davis (1998). Resource Allocation for the New Defense Strategy:
The DynaRank Decision Support System, RAND Corporation, Santa Monica, CA.
147

Hitt, M.A. and B.B. Tyler (1991). “Strategic Decision Models: Integrating Different
Perspectives.” Strategic Management Journal, 2:5, 327-351.
Hitt, M.A., R. D. Ireland, and R.E. Hoskisson (2009). Strategic Management:
Competitiveness and Globalization (Concepts and Cases), 8th edition, SouthWestern Cengage Learning, Mason OH.
Hofer, C. W. (1973). “Some Preliminary Research on Patterns of Strategic Behavior.”
Academy of Management Proceedings, 46-59.
Horn, R.E. and R.P. Weber (2007). New Tools for Resolving Wicked Problems: Mess
Mapping and Resolution Mapping Processes, Strategy Kinetics: Watertown, MA.
R. E. Hoskisson, M.A. Hitt, W.P. Wan, and D. Yiu (1999). “Theory and research in
strategic management: Swings of a pendulum.” Journal of Management, 25:3, 417456.
Hough, P. (2008). Understanding National Security, Routledge, London.
Ihaka, R. and R. Gentleman, (1996). “R: A Language for Data Analysis and Graphics.”
Journal of Computational and Graphical Statistics, 5:3, 299-314.
Jia, J., J. S. Dyer, and J. C. Butler (1999). “Measures of Perceived Risk.” Management
Science, 45:4, 519-532.
Janis, I. L. (1982). Groupthink: Psychological Studies of Policy Decisions and Fiascos (2nd
edition), Houghton-Mifflin Company, Boston, MA.
Kahn, H. and A.J. Wiener (1967). The Year 2000: A Framework for Speculation on the
Next Thirty-Three Years, MacMillan Publishing Company, New York.
Kaplan, R. S. and D. P. Norton (1996). The Balanced Scorecard: Translating Strategy
Into Action, Harvard Business School Press, Boston, MA.
Keeney, R.L. (1992) Value-Focused Thinking: A Path to Creative Decisionmaking,
Harvard University Press, Cambridge, MA.
Keeney, R. and H. Raffia (1976). Decisions with Multiple Objectives, Cambridge
University Press, Cambridge, MA.
Khaneman, D., A. Tversky, and P. Slovic, eds (1982). Judgment under Uncertainty:
Heuristics & Biases, Cambridge University Press, UK.
Khaneman, D. and A. Tversky (1984). “Choice, Values, and Frames.” American
Psychologist, 39, 341-350.
Khatri, N. and H.A. Ng, (2000). “The Role of Intuition in Strategic Decision Making.”
Human Relations, 53, 57-86.
Kosnik, R. D. (1987). “Greenmail: A study of board performance in corporate
governance.” Administrative Science Quarterly, 32, 163-185.
Kosnik, R. D. (1990). “Effects of board demography and directors' incentives on corporate
greenmail decisions.” Academy of Management Journal, 33, 129-151.
148

Lempert, R. J., and J. Bonomo, (1998). "New Methods for Robust Science and
Technology Planning." RAND Corporation, Santa Monica.
Lempert, R.J., B.P. Bryant, and S. C. Bankes (2007), “Thinking Inside the Box:
Comparing Algorithms that Identify Policy-Relevant Scenarios in Spaces of
Computational Experiments.” In work.
Lempert, R. J., D. G. Groves, S. W. Popper, and S. C. Bankes (2006). “A General,
Analytic Method for Generating Robust Strategies and Narrative Scenarios.”
Management Science 52:4, 514-528.
Lempert, R.J., N. Nakicenovic, D. Sarewitz, and M. Schlesinger, M. (2004).
"Characterizing Climate-Change Uncertainties for Decision-Makers." Climatic
Change, 65, 1-9.
Lempert, R.J. and S. Popper (2005). “High Performance Government in an Uncertain
World.” In High Performance Government: Structure, Leadership, Incentives, R.
Klitgaard and P.C. Light, eds.
Lempert, R. J., S. W. Popper, and S. C. Bankes (2003). Shaping the Next One Hundred
Years: New methods for quantitative, long-term policy analysis, RAND Corporation,
Santa Monica, CA.
Lempert, R. J., and M.E. Schlesinger (2000). "Robust Strategies for Abating Climate
Change." Climatic Change, 45(3/4), 387-401.
Lempert, R. J., M.E. Schlesinger, and S. C. Bankes (1996). “When we don’t know the
costs or the benefits: adaptive strategies for abating climate change.” Climatic
Change 33:2.
Lempert, R. J., M. E. Schlesinger, S.C. Bankes, and N.G. Andronova (2000). "The
Impact of Variability on Near-Term Climate-Change Policy Choices." Climatic
Change, 45(1).
Longo, J.M. (2009). Hedge Fund Alpha: A Framework for Generating and
Understanding Investment Performance, World Scientific, Singapore.
Loomes, G., and R. Sugden (1982). "Regret Theory: An Alternative Theory of Rational
Choice Under Uncertainty." The Economic Journal, 92(368), 805-824.
Loomes, G. and R. Sugden (1987). “Some Implications of a More General Form of
Regret Theory." Journal of Economic Theory, 41, 270-287.
Mador, M. (2000). “Strategic Decision Making: Opportunities for Research.” Kingston
Business School Working Paper Series No. 11.
Mahnovski, S. (2006). Robust Decisions and Deep Uncertainty: An Application of Real
Options to Public and Private Investment in Hydrogen and Fuel Cell Technologies.
Doctoral Dissertation, Pardee-RAND Graduate School, Santa Monica, CA.

149

Martens, J. and J.E. Samels & Associates, (2009). Turnaround: Leading Stressed
Colleges and Universities to Excellence, The Johns Hopkins University Press,
Baltimore, MD.
Matos, M. A. (2007). “Decision Under Risk as a Multicriteria Problem.” European Journal
of Operational Research, 181:3, 1516-1529.
March, J. G. and Z. Shapira (1987). “Managerial Perspectives on Risk and Risk Taking.”
Management Science, 33:11, 1404-1418.
Markowitz, H. M. (1952). “Portfolio Selection.” Journal of Finance, 7:1, 77-91.
Martel, J.M., N.T. Khoury, and M. Bergeron (1988). "An Application of Multicriteria
Approach to Portfolio Comparisons." Journal of the Operational Research Society,
39:7, 617-28.
Mintzberg, H., D. Rainsinghani, and A. Theoret (1976) “The Structure of ‘Unstructured’
Decision Processes.” Administrative Science Quarterly, 21, 246-275.
National Research Council Committee of the National Academies on Conventional
Prompt Global Strike Capability (2008). US Conventional Prompt Global Strike:
Issues for 2008 and Beyond. National Academies Press: Washington D.C.
National Research Council Committee on Improving Risk Analysis Approaches Used by
the U.S. EPA (2009). Science and Decisions, National Academies Press:
Washington DC.
Nguyen, M. (2003). Some Prioritisation methods for Defence Planning, DSTO Information
Sciences Laboratory, Edinburgh, Australia.
Miller, K.D. and P. Bromiley (1990). “Strategic Risk and Corporate Performance: An
Analysis of Alternative Risk Measures.” Academy of Management Journal, 33:4,
756-779.
Mun, J. (2006). Real Options Analysis: Tools and Techniques for Valuing Strategic
Investments and Decisions, Wiley, Hoboken, NJ.
Nisbet, R., J. Elder, and G. Miner (2009), Handbook of Statistical Analysis and Data
Mining Applications, Academic Press, Burlington MA.
Nutt, P. (1998). “Framing Strategic Decisions.” Organizational Science, 9:2, 195-216.
Park, G., and R.J. Lempert, (1998). The Class of 2014: Preserving Access to California
Higher Education, RAND Corporation, Santa Monica, California.
Pfeffer, J. (1973). “Size, composition and function of hospital boards of directors: A study
of organization-environment linkage.” Administrative Science Quarterly, 18, 349364.
Poh, K. L., B. W. Ang, and F. Bai (2001). “A Comparative Analysis of R&D Project
Evaluation Methods.” R&D Management, 31:1, 63-75.
Post, T. and P. van Vliet (2002). “Downside Risk and Upside Potential.” Erasmus
Research Institute of Management (ERIM) Working Paper.
150

Powell, W. W. (1991). “Expanding the scope of institutional analysis.” In W. W. Powell
and P. J. DiMaggio (eds.), The New Institutionalism in Organizational Analysis.
University of Chicago Press, Chicago, IL, 183-203.
Quinn, J.B. (1980) Strategies for Change: Logical Incrementalism, Irwin, Homewood,
Illinois.
Rabin, M. and G. Weizsacker (2009). “Narrow Bracketing and Dominated Choices.”
American Economic Review, 99:4, 1508-1543.
Rosenhead, M. J., M. Elton, and S. K. Gupta (1972). “Robustness and Optimality as
Criteria for Strategic Decisions.” Operational Research Quarterly, 23:4, 413–430.
Roy, B. and D. Bouyssou (1993). “Aide Multicrite’re a la Decision: Methods et Cas.”
Economica.
Saaty, T. (1980). The Analytic Hierarchy Process: Planning, Priority Setting, Resource
Allocation, McGraw-Hill, New York.
Savage, L. J. (1950). The Foundations of Statistics, Wiley, New York.
Schwenk, C.R. (1995). “Strategic decision making-Special Issue: Yearly Review of
Management.”Journal of Management, Fall 1996.
Shoemaker, J.H. (1993). “Multiple Scenario Development: Its Conceptual and Behavioral
Foundation.” Strategic Management Journal, 14:3, 193-213.
Simon, H.A. and A. Newell (1958). “Heuristic Problem Solving: The Next Advance in
Operations Research.” Operations Research, 6:1, 1-10.
Singh, H. and F. Harianto (1989). “Management- board relationships, takeover risk, and
the adoption of golden parachutes.” Academy of Management Journal, 32, 7-24.
Sjoberg, L., B. Moen, and T. Rundmo (2004). Explaining Risk Perception, Rotonde,
Trondheim, Norway.
Smithson, M. (1989). Ignorance and Uncertainty – Emerging Paradigms, Springer-Verlag,
New York, NY.
Steuer, R.E. and P. Na (2003). “Multiple Criteria Decision Making Combined with
Finance: A Categorized Bibliographic Study.” European Journal of Operational
Research, 150,496-515.
Swisher, P., and G. W. Kasten (2005). "Post-Modern Portfolio Theory." Journal of
Financial Planning, 18:9, 74-85.
Tchankova, L. (2002). “Risk Identification - Basic Stage in Risk Management.”
Environmental Management and Health, 13:3, 290-297.
Thompson, J. D. (1967). Organizations in Action, McGraw-Hill, New York.
Tversky, A. and D. Kahneman (1973). “Availability: a Heuristic for Judging Frequency and
Probability.” Cognitive Psychology, 5, 207-232.
151

White, D. (1995). “Application of Systems Thinking to Risk Management: A Review of the
Literature.” Management Decision, 33:10, 35-45.
Zeleny, M. (1982). Multiple Criteria Decision Making, McGraw-Hill, New York.
Zopounidis, C. and M. Doumpos (2002). “Multicriteria Decision Aid in Financial Decision
Making: Methodologies and Literature Review.” Journal of Multicriteria Decision
Analysis, 11, 167-18

152

