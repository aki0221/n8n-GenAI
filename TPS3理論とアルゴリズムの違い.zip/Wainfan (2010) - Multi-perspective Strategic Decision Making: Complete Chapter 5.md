# Wainfan (2010) - Multi-perspective Strategic Decision Making: Complete Chapter 5

## Chapter 5 - Implementing MPSDM

### オプションと基準の簡素化プロセス

Of course it will not always be the case that options and criteria can be eliminated. For instance, some criteria may differentiate some of the options. It is possible that, once the preliminary scenarios are developed, one or more option may be created to deal with the particular challenges or opportunities suggested by some of the scenarios. Similarly, options won't always be dominated in every case that is run in the computational experiment; some cases may emphasize a relative strength of an option compared to the others, some may point out a relative weakness. The approach advocated here is to look for simplifications. If the number of options and criteria can be reduced, so much the better. If they can't, the remaining methodology remains the same.

### 集約重みの再定式化

Recall that the relative value for each scenario was defined as a set of four "focuses", each representing a set of scenario weights corresponding to a particular perspective. Since some of those scenarios have been eliminated, it makes sense to go back and revisit these focuses for the three existing scenarios. The table below shows the new formulation of sets of aggregation weights for each focus.

**Table 4.9 - Reformulation of Aggregation Weight Sets for Each Focus of the Differentiating Scenarios**

From the table above, the first focus represents the perspective that the remaining scenarios are equally valuable in choosing an option. The next three rows include a variable X, which corresponds to the relative preference for one scenario over the other two. When X=0.67, Focus 2 puts all the weight on Scenario S1n and none on the other two scenarios. This corresponds to a strong belief that Scenario S1n be the most

