# Zhang et al. (2025) - Human-AI coordination for large-scale group decision making with heterogeneous feedback strategies

## Abstract

In group decision making, human experts are usually susceptible to cognitive biases and information overload. Artificial intelligence (AI) has capabilities in data processing and analysis, but is limited by issues such as interpretability and human adoption. Humans and AI have different problem-solving capabilities, they can benefit from each other. Thus, there is a need to leverage a mechanism to tap into the intelligence of both parties and achieve mutually shared outcomes. In this study, we propose a large-scale group decision-making model with human-AI consensus. First, an improved density-peak clustering algorithm is utilized to classify experts into subgroups based on the Similarity-Trust-Attitude score. Then, weights of experts and subgroups are obtained based on the internal influence of experts and the intuitionistic fuzzy entropy of subgroup preferences. Further, considering three different strategies of human-AI interaction, subgroup consensus and subgroup-AI consensus are calculated. Finally, a minimum cost consensus model with heterogeneous feedback strategies is proposed. The usability of the proposed model is verified through a medical diagnosis case. This study found that the human-AI coordination with heterogeneous feedback strategies can reduce adjustment costs, and different interaction mechanisms have different effects.

## 1. Introduction

Group decision making (GDM) aims to facilitate the optimal ranking of a set of alternatives to a specific problem through the collaborative effort of multiple experts (Meng et al., 2024). With the increasing complexity of decision-making settings and the rising demand for cross-disciplinary expertise to tackle decision-making problems, large-scale group decision making (LSGDM) has become a focal point of research (Tang & Liao, 2021). To fully leverage the role of a large group, scholars have proposed many models from various perspectives to extract and harness human intelligence, such as expert behaviours (Gou et al., 2021), subgroup classification (Liang et al., 2024; Tang et al., 2020), consensus-building method (Meng et al., 2023) and preference information aggregation (Chen et al., 2022). Thus, traditional LSGDM relies mostly on the experience and intuition of human experts. However, human experts may be influenced by subjective biases (Liang et al., 2024), information overload (Laker et al., 2018), and limited learning capacity (Boyacı et al., 2024), resulting in uncertainty and bias in decision-making outcomes.

Nowadays, with the development in computational power of information technologies and data analytics, artificial intelligence (AI) has shown great potential in decision-making tasks. AI can process large amounts of data, identify patterns, and provide objective analysis without being affected by emotional or cognitive biases (Duan et al., 2019). However, AI also has limitations, such as lack of interpretability, difficulty in handling uncertain or incomplete information, and challenges in gaining human trust and adoption (Ribeiro et al., 2016). Therefore, combining human intelligence with AI capabilities can potentially overcome the limitations of both and achieve better decision-making outcomes.

Human-AI coordination has emerged as a promising approach to leverage the complementary strengths of humans and AI in decision-making processes. This coordination can take various forms, from AI providing recommendations to humans making final decisions, to more integrated approaches where humans and AI work together throughout the decision-making process. The key challenge is to design effective mechanisms that can harness the intelligence of both parties while addressing their respective limitations.

In the context of large-scale group decision making, the coordination between humans and AI becomes even more complex due to the involvement of multiple experts with diverse backgrounds, preferences, and expertise levels. Traditional consensus-building methods may not be sufficient to handle the heterogeneity of feedback strategies that emerge when AI is introduced into the group decision-making process. Therefore, there is a need for new models and approaches that can effectively coordinate human experts and AI systems in large-scale group decision-making scenarios.

This study addresses this gap by proposing a comprehensive framework for human-AI coordination in large-scale group decision making with heterogeneous feedback strategies. The proposed model considers different roles that AI can play in the decision-making process and provides mechanisms for achieving consensus between human experts and AI systems while minimizing adjustment costs.

## 2. Literature review

### 2.1. Human-AI decision making

The integration of human intelligence and artificial intelligence in decision-making processes has gained significant attention in recent years. Human-AI collaboration represents a paradigm shift from traditional approaches where either humans or AI systems operate independently to more integrated approaches that leverage the complementary strengths of both.

Human experts bring valuable qualities to decision-making processes, including domain expertise, contextual understanding, creativity, and the ability to handle ambiguous or incomplete information. However, humans are also subject to various cognitive biases, such as confirmation bias, anchoring bias, and availability heuristic, which can lead to suboptimal decisions (Kahneman, 2011). Additionally, humans have limited information processing capacity and may experience fatigue or stress that can affect their decision-making performance.

On the other hand, AI systems excel at processing large volumes of data, identifying patterns, and performing consistent analysis without being affected by emotional or psychological factors. AI can also operate continuously without fatigue and can provide objective analysis based on data-driven approaches. However, AI systems often lack the ability to understand context, handle unexpected situations, or provide explanations for their recommendations that are easily understood by humans.

The concept of human-AI collaboration recognizes that the combination of human and AI capabilities can potentially overcome the limitations of both and achieve superior decision-making outcomes. This collaboration can take various forms, ranging from AI-assisted decision making where AI provides recommendations to human decision makers, to more integrated approaches where humans and AI work together throughout the decision-making process.

Recent research has explored different models of human-AI collaboration in decision-making contexts. Some studies have focused on the design of AI systems that can provide explanations for their recommendations to increase human trust and adoption (Ribeiro et al., 2016). Others have investigated the optimal allocation of tasks between humans and AI based on their respective strengths and limitations (Dellermann et al., 2019).

In the context of group decision making, human-AI collaboration introduces additional complexity due to the need to coordinate not only between humans and AI but also among multiple human experts with diverse backgrounds and preferences. This requires new approaches that can effectively manage the heterogeneity of feedback strategies and achieve consensus among all participants.

### 2.2. LSGDM and MCC models

Large-scale group decision making (LSGDM) has emerged as an important research area due to the increasing complexity of modern decision-making problems and the need to involve multiple experts with diverse expertise. LSGDM typically involves a large number of decision makers (usually more than 20) who need to evaluate alternatives and reach consensus on the best solution.

Traditional group decision-making methods often face challenges when applied to large-scale scenarios due to issues such as information overload, communication difficulties, and the complexity of achieving consensus among a large number of participants. To address these challenges, researchers have developed various approaches for LSGDM, including clustering methods to group similar experts, weight determination techniques to reflect the importance of different experts, and consensus-building mechanisms to facilitate agreement among participants.

Clustering is a fundamental component of many LSGDM models as it helps to manage the complexity of large groups by organizing experts into smaller, more manageable subgroups. Various clustering algorithms have been proposed for LSGDM, including k-means clustering, hierarchical clustering, and density-based clustering methods. The choice of clustering algorithm and the criteria used for grouping experts can significantly impact the effectiveness of the LSGDM process.

Weight determination is another critical aspect of LSGDM as it reflects the relative importance or influence of different experts in the decision-making process. Various methods have been proposed for determining expert weights, including approaches based on expert competence, consistency of preferences, and social network analysis. The weight determination method should be appropriate for the specific context and characteristics of the decision-making problem.

Consensus building is essential in LSGDM to ensure that the final decision reflects the collective wisdom of the group and has the support of the participants. Traditional consensus measures may not be sufficient for large-scale scenarios due to the diversity of expert preferences and the complexity of achieving agreement among a large number of participants. Therefore, new consensus measures and building mechanisms are needed for LSGDM.

Minimum cost consensus (MCC) models have been developed to address the challenge of achieving consensus in group decision making while minimizing the cost of adjustments required to reach agreement. These models typically involve identifying the minimum changes needed to expert preferences to achieve a desired level of consensus. MCC models are particularly relevant in LSGDM scenarios where the cost of making adjustments can be significant due to the large number of participants involved.

The integration of AI into LSGDM introduces new opportunities and challenges for consensus building. AI can potentially help to identify optimal adjustment strategies and facilitate consensus building by providing objective analysis and recommendations. However, the introduction of AI also creates new forms of heterogeneity in feedback strategies that need to be addressed in the consensus-building process.

## 3. LSGDM model based on human-AI coordination

### 3.1. Model setup

The proposed LSGDM model with human-AI coordination is designed to address the challenges of achieving consensus in large-scale group decision-making scenarios while leveraging the complementary strengths of human experts and AI systems. The model consists of several key components that work together to facilitate effective decision making and consensus building.

The model begins with a set of human experts E = {e₁, e₂, ..., eₙ} who need to evaluate a set of alternatives A = {a₁, a₂, ..., aₘ} for a specific decision-making problem. Each expert provides their initial preferences in the form of preference relations or utility values for the alternatives. In addition to human experts, the model includes an AI system that can provide its own evaluation of the alternatives based on data analysis and algorithmic processing.

The decision-making process involves multiple stages, including expert clustering, weight determination, consensus measurement, and feedback adjustment. The model is designed to handle heterogeneous feedback strategies that emerge when human experts and AI systems interact in the decision-making process.

The objective of the model is to achieve consensus among human experts and the AI system while minimizing the cost of adjustments required to reach agreement. The model considers different roles that AI can play in the decision-making process, ranging from a decisive role where AI has significant influence on the final decision, to an auxiliary role where AI provides support and recommendations to human experts.

The model framework incorporates several innovative features, including an improved clustering algorithm based on Similarity-Trust-Attitude scores, a weight determination method that considers both expert influence and subgroup preference entropy, and a minimum cost consensus mechanism that accommodates heterogeneous feedback strategies.

### 3.2. Group clustering

Group clustering is a critical component of the proposed LSGDM model as it helps to manage the complexity of large-scale decision making by organizing experts into smaller, more manageable subgroups. The clustering process is based on an improved density-peak clustering algorithm that considers multiple factors relevant to group decision making.

The clustering algorithm utilizes a Similarity-Trust-Attitude (STA) score to measure the relationships between experts. The similarity component reflects the degree to which experts have similar preferences for the alternatives. The trust component captures the level of confidence that experts have in each other's judgments. The attitude component represents the general disposition or approach that experts take toward the decision-making problem.

The STA score is calculated using a combination of preference similarity measures, trust indicators, and attitude assessments. The preference similarity is typically measured using correlation coefficients or distance measures between expert preference vectors. Trust indicators can be derived from historical interactions, expert credentials, or explicit trust ratings provided by experts. Attitude assessments capture factors such as risk tolerance, optimism/pessimism, and decision-making style.

The improved density-peak clustering algorithm identifies cluster centers based on the density of experts in the STA space and the distance to other high-density points. This approach is particularly suitable for LSGDM scenarios as it can automatically determine the number of clusters and handle clusters of different shapes and sizes.

The clustering process results in the formation of subgroups G = {G₁, G₂, ..., Gₖ} where each subgroup contains experts with similar STA characteristics. This grouping facilitates more effective consensus building as experts within each subgroup are more likely to have compatible preferences and decision-making approaches.

The subgroup structure also enables the model to handle the complexity of large-scale decision making by reducing the number of entities that need to be coordinated in the consensus-building process. Instead of trying to achieve consensus among all individual experts, the model focuses on achieving consensus among subgroups and between subgroups and the AI system.

### 3.3. Weight determination and consensus

#### 3.3.1. Weight determination

Weight determination is essential in LSGDM to reflect the relative importance or influence of different experts and subgroups in the decision-making process. The proposed model employs a two-level weight determination approach that considers both individual expert weights within subgroups and subgroup weights in the overall decision-making process.

Individual expert weights within subgroups are determined based on the internal influence of experts, which reflects their ability to affect the preferences and decisions of other experts within their subgroup. The internal influence is calculated using social network analysis techniques that consider factors such as the number of connections an expert has with other experts, the strength of these connections, and the expert's position in the network structure.

The internal influence measure captures both direct and indirect influence relationships. Direct influence reflects the immediate impact that an expert has on other experts through direct interactions or communications. Indirect influence captures the broader impact that an expert can have through their connections to other influential experts in the network.

Subgroup weights are determined based on the intuitionistic fuzzy entropy of subgroup preferences. Intuitionistic fuzzy sets provide a framework for handling uncertainty and imprecision in preference information by considering both membership and non-membership degrees. The entropy measure reflects the level of uncertainty or disagreement within each subgroup.

Subgroups with lower entropy (higher consensus) are assigned higher weights as they represent more coherent and reliable collective judgments. Conversely, subgroups with higher entropy (lower consensus) are assigned lower weights as their preferences are more uncertain and potentially less reliable.

The weight determination process also considers the size of each subgroup, with larger subgroups generally receiving higher weights due to their broader representation. However, the size factor is balanced with the entropy measure to ensure that quality of consensus is also considered in the weight assignment.

#### 3.3.2. Consensus measure

Consensus measurement is crucial for determining the level of agreement among experts and identifying areas where adjustments may be needed to achieve satisfactory consensus. The proposed model employs a multi-level consensus measurement approach that considers consensus within subgroups, consensus between subgroups, and consensus between subgroups and the AI system.

Within-subgroup consensus is measured using traditional consensus indices that reflect the degree of agreement among experts within each subgroup. These measures typically consider the variance or standard deviation of expert preferences within the subgroup, with lower variance indicating higher consensus.

Between-subgroup consensus is measured by comparing the aggregated preferences of different subgroups. This involves calculating distance measures between subgroup preference vectors and determining the overall level of agreement among subgroups.

Subgroup-AI consensus is measured by comparing the aggregated preferences of each subgroup with the preferences provided by the AI system. This measurement is particularly important in the human-AI coordination framework as it reflects the level of alignment between human expert judgments and AI recommendations.

The overall consensus level is calculated as a weighted combination of these different consensus measures, with weights reflecting the relative importance of different types of consensus in the specific decision-making context.

The consensus measurement process also considers the heterogeneous feedback strategies that may emerge when human experts and AI systems interact. Different experts may have different levels of willingness to adjust their preferences based on AI recommendations, and the consensus measurement needs to account for these differences.

### 3.4. Heterogeneous feedback strategies and minimum cost consensus

#### 3.4.1. Feedback scenarios

The proposed model considers three different scenarios for human-AI interaction, each representing a different role that AI can play in the decision-making process. These scenarios reflect the heterogeneous feedback strategies that may emerge when human experts and AI systems work together in large-scale group decision making.

**Scenario I: GenAI as the decisive role**

In this scenario, the AI system plays a decisive role in the decision-making process, with significant influence on the final decision. Human experts are expected to give considerable weight to AI recommendations and may be required to justify deviations from AI suggestions. This scenario is appropriate when the AI system has access to comprehensive data and advanced analytical capabilities that exceed human expert capabilities in the specific domain.

The feedback mechanism in this scenario involves the AI system providing detailed recommendations and explanations for its preferences. Human experts are encouraged to align their preferences with AI recommendations, and the consensus-building process prioritizes achieving agreement with the AI system. The cost of deviating from AI recommendations is set relatively high to reflect the decisive role of AI.

This scenario may be particularly suitable for decision-making problems where objective data analysis is crucial and human biases may negatively impact decision quality. Examples include financial investment decisions based on market data analysis or medical diagnosis based on comprehensive patient data and medical literature.

**Scenario II: GenAI as the equal role**

In this scenario, the AI system is treated as an equal participant in the decision-making process, with its preferences given similar weight to those of human expert subgroups. The AI system provides recommendations and participates in the consensus-building process on an equal footing with human experts.

The feedback mechanism involves bidirectional communication between human experts and the AI system. Human experts can provide feedback to the AI system about the appropriateness of its recommendations, and the AI system can adjust its preferences based on human input. The consensus-building process seeks to achieve agreement among all participants, including both human experts and the AI system.

This scenario is appropriate when both human expertise and AI capabilities are valuable for the decision-making problem, and neither has a clear advantage over the other. The equal treatment of human and AI participants encourages collaborative decision making and mutual learning.

**Scenario III: GenAI as the auxiliary role**

In this scenario, the AI system plays an auxiliary role, providing support and recommendations to human experts while leaving the final decision authority with human participants. The AI system serves as a decision support tool rather than a decision maker.

The feedback mechanism involves the AI system providing recommendations and analysis to support human expert decision making. Human experts can choose to accept, modify, or reject AI recommendations based on their own judgment and expertise. The consensus-building process focuses primarily on achieving agreement among human experts, with AI recommendations serving as additional input.

This scenario is suitable when human expertise and judgment are considered paramount, but AI analysis can provide valuable additional insights. Examples include strategic business decisions where human intuition and experience are crucial, or ethical decisions where human values and judgment are essential.

#### 3.4.2. Feedback model setup

The feedback model is designed to facilitate consensus building while accommodating the heterogeneous feedback strategies that emerge in different human-AI interaction scenarios. The model considers the costs associated with preference adjustments and seeks to minimize these costs while achieving satisfactory consensus levels.

The feedback model incorporates several key components:

**Cost function**: The cost function quantifies the expense associated with adjusting expert preferences to achieve consensus. Different types of adjustments may have different costs, reflecting factors such as the magnitude of change required, the importance of the expert making the adjustment, and the specific feedback scenario being employed.

**Adjustment mechanisms**: The model provides different mechanisms for adjusting expert preferences, including direct preference modification, weight adjustment, and hybrid approaches that combine multiple adjustment strategies.

**Consensus thresholds**: The model defines minimum consensus levels that must be achieved for different types of consensus (within-subgroup, between-subgroup, and subgroup-AI consensus). These thresholds may vary depending on the specific decision-making context and the feedback scenario being employed.

**Optimization algorithm**: The model employs optimization algorithms to identify the minimum cost combination of adjustments needed to achieve the required consensus levels. The optimization process considers the constraints imposed by the feedback scenario and the preferences of participants.

#### 3.4.3. Selection process

The selection process determines which feedback scenario is most appropriate for a given decision-making situation. This selection is based on several factors, including the nature of the decision-making problem, the capabilities of the AI system, the expertise of human participants, and the preferences of stakeholders.

The selection process considers factors such as:

**Problem characteristics**: The complexity, urgency, and importance of the decision-making problem may influence the appropriate feedback scenario. Complex problems requiring extensive data analysis may favor scenarios where AI plays a more decisive role, while problems requiring human judgment and creativity may favor scenarios where human experts have more authority.

**AI capabilities**: The sophistication and reliability of the AI system influence the appropriate level of AI involvement. More advanced AI systems with proven track records may be suitable for decisive roles, while less mature systems may be more appropriate for auxiliary roles.

**Human expertise**: The level and relevance of human expert knowledge affect the optimal balance between human and AI involvement. Highly experienced experts may prefer scenarios where they retain decision authority, while less experienced experts may benefit from more AI guidance.

**Stakeholder preferences**: The preferences and comfort levels of stakeholders regarding AI involvement influence the selection of appropriate feedback scenarios. Some organizations may have policies or cultural preferences that favor human decision authority, while others may be more open to AI-driven decision making.

### 3.5. Summarization of the proposed model

The proposed LSGDM model with human-AI coordination provides a comprehensive framework for addressing the challenges of large-scale group decision making while leveraging the complementary strengths of human experts and AI systems. The model integrates several innovative components that work together to facilitate effective decision making and consensus building.

The key features of the proposed model include:

**Improved clustering algorithm**: The model employs an enhanced density-peak clustering algorithm based on Similarity-Trust-Attitude scores to organize experts into coherent subgroups. This clustering approach is specifically designed for LSGDM scenarios and can handle the complexity and heterogeneity of large expert groups.

**Multi-level weight determination**: The model uses a two-level approach for determining weights, considering both individual expert influence within subgroups and subgroup importance in the overall decision-making process. This approach ensures that the relative importance of different participants is appropriately reflected in the decision-making process.

**Comprehensive consensus measurement**: The model employs a multi-level consensus measurement approach that considers consensus within subgroups, between subgroups, and between subgroups and the AI system. This comprehensive approach ensures that all relevant aspects of consensus are considered.

**Heterogeneous feedback strategies**: The model accommodates three different scenarios for human-AI interaction, allowing for flexible adaptation to different decision-making contexts and stakeholder preferences. This flexibility is crucial for the practical implementation of human-AI coordination in diverse organizational settings.

**Minimum cost consensus mechanism**: The model includes a sophisticated mechanism for achieving consensus while minimizing adjustment costs. This mechanism considers the heterogeneous feedback strategies and provides optimal solutions for different interaction scenarios.

The proposed model addresses several important gaps in the existing literature on LSGDM and human-AI coordination. It provides a practical framework that can be implemented in real-world decision-making scenarios while maintaining theoretical rigor and methodological soundness.

## 4. Case study: Medical diagnosis

[Content continues with case study details...]

## 5. Results and analysis

[Content continues with results and analysis...]

## 6. Conclusion

[Content continues with conclusion...]

## References

[Content continues with references...]

