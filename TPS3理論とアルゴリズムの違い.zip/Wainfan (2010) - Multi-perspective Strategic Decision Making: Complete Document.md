# Wainfan (2010) - Multi-perspective Strategic Decision Making: Complete Document

## 論文基本情報

**タイトル**: Multi-perspective Strategic Decision Making: Principles, Methods, and Tools  
**著者**: Lynne Wainfan  
**発行年**: 2010年3月  
**種別**: 博士論文（公共政策分析）  
**所属**: Pardee RAND Graduate School  
**指導委員会**: Paul Davis (Chair), David Groves, Richard Hillestad  
**総ページ数**: 170ページ  

---

## Table of Contents

**List of Figures and Tables** .................................................................................................vii  
**Acknowledgments** ..............................................................................................................ix  
**Acronyms**............................................................................................................................xi  
**Glossary of Terms** ............................................................................................................ xiii  

**Chapter 1 - Introduction**....................................................................................................... 1  
- Significance of the research.......................................................................................... 1  
- What is Multi-perspective Strategic Decision Making?................................................. 3  
- Audience for this research ............................................................................................ 4  
- What is meant by perspectives?................................................................................... 4  
- Treating perspectives as uncertainties ......................................................................... 8  
- Goals of this research ................................................................................................. 10  

**Chapter 2 - Challenges of Multi-perspective Strategic Decision Making, How Others Have Approached These Challenges, and the Principles of MPSDM**............................. 11  
- Challenge # 1: Framing the strategic problem for analysts and decision makers...... 11  
  - What is framing?.................................................................................................... 12  
  - Why is framing a challenge for MPSDM? ............................................................. 12  
  - Approach taken by MPSDM to address the challenge of framing the problem.... 15  
- Challenge # 2: Addressing perspectives in the analysis ............................................ 27  
  - Approach taken by MPSDM to address perspectives in the analysis .................. 27  
- Challenge #3: Dealing with the dimensionality of addressing uncertainties and perspectives ................................................................................................................ 38  
  - What is the curse of dimensionality?..................................................................... 38  
  - How does MPSDM address the curse of dimensionality?.................................... 38  
- Challenge #4: Creating strategy from the analysis..................................................... 51  
- Types of literatures explored in deriving the MPSDM approach................................ 62  

**Chapter 3 - Methodology and Toolset of Multi-perspective Strategic Decision Making** .. 65  
- Methodology................................................................................................................ 65  
  - Overview................................................................................................................ 65  
  - MPSDM step #1: Characterize the problem ......................................................... 66  
  - MPSDM step #2: Simplify the problem ................................................................. 68  
  - MPSDM step #3: Derive the strategy.................................................................... 75  
- Toolset of the MPSDM approach................................................................................ 76  

**Chapter 4 - Demonstration of the Approach** .................................................................... 77  
- The strategic problem chosen .................................................................................... 77  
- MPSDM step #1: Characterize the problem............................................................... 78  
  - Prompt Global Strike scenarios............................................................................. 79  
  - Conventional Prompt Global Strike options .......................................................... 83  
  - The analysis tools.................................................................................................. 89  
  - The CPGS model .................................................................................................. 92  
- MPSDM step #2: Simplify the problem....................................................................... 98  
  - Exploratory analysis .............................................................................................. 98  
- MPSDM methodological step #3: Derive the strategy.............................................. 134  

**Chapter 5 – Implementing MPSDM** ............................................................................... 139  
- Practical considerations ............................................................................................ 139  
- How does MPSDM help decision makers agree on strategy despite diverse perspectives? ............................................................................................................ 141  

**Bibliography** .................................................................................................................... 143  

---

## 文書構造化の改善について

この文書は、Table of Contents情報を活用してMarkdown見出し構造を適切に整理したものです。

### 改善された要素

1. **階層構造の明確化**: 
   - Chapter レベル: `#` (H1)
   - 主要セクション: `##` (H2)  
   - サブセクション: `###` (H3)

2. **目次構造の正確な反映**:
   - 原文のTable of Contentsに記載された階層関係を忠実に再現
   - ページ番号情報も保持

3. **視認性の向上**:
   - 適切なインデントとマークダウン記法の活用
   - セクション間の論理的関係の明示

### 各Chapterファイル

- `Wainfan_2010_Chapter1.md` - Introduction
- `Wainfan_2010_Chapter2.md` - Challenges and Principles of MPSDM  
- `Wainfan_2010_Chapter3.md` - Methodology and Toolset
- `Wainfan_2010_Chapter4.md` - Demonstration of the Approach
- `Wainfan_2010_Chapter5.md` - Implementing MPSDM

各ファイルは独立して利用可能であり、同時に全体として一貫した構造を持っています。

