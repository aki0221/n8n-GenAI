# Wainfan (2010) - Multi-perspective Strategic Decision Making: Complete Chapter 2

## Chapter 2 - Challenges of Multi-perspective Strategic Decision Making, How Others Have Approached These Challenges, and the Principles of MPSDM

### 理論的基盤と深い不確実性

"deep uncertainty," originally attributed to Arrow (2001), has also been used in research to apply to conditions where uncertainty is ambiguous or vague and/or the relative value of outcomes cannot be clearly established (Bankes, 2003). Lempert, Popper and Bankes (2003) broaden the concept of deep uncertainty even further:

[Deep uncertainty is] where analysts do not know, or the parties to a decision cannot agree on, (1) the appropriate conceptual models that describe the relationships among the key driving forces that will shape the long-term future, [what MPSDM calls beliefs] (2) the probability distributions used to represent uncertainty about key variables and parameters in the mathematical representations of these conceptual models, [a combination of some types of beliefs and expectations in MPSDM], and/or (3) how to value the desirability of alternative outcomes [a type of value] (p. xii).

### Robust Decision Making (RDM) との関係

One of the lines of research that this dissertation draws heavily from is Robust Decision Making (RDM). RDM is an analytic method for developing robust policies—those that perform well over a large range of uncertain futures. The goal of RDM is not to aim for optimal outcomes, but for robustness (in the sense that outcomes that remain good across a wide range of uncertainties). RDM has been applied to a variety of social policy issues such as: Climate change (Groves, Lempert, Barry, Wainfan 2008; Groves, 2007; Lempert et al. 2004; Lempert and Schlesinger 2000; Lempert et al.1996; Lempert et al. 2000); global sustainability (Lempert et al. 2003); educational investment (Park and Lempert 1998) and science and technology investment (Lempert and Bonomo 1998).

As will be described in more detail later, RDM puts forth a method of exploring uncertain parameter space using graphical and data-mining techniques that is applicable to MPSDM. However, RDM has a somewhat different emphasis than MPSDM. Whereas RDM aims to define strategies that perform reasonably well over a broad range


of plausible futures, MPSDM focuses on how to define strategies that can be agreed upon by group of decision makers who may never agree on values, beliefs, and expectations. MPSDM's emphasis on decision makers', stakeholders', analysts', and adversaries' perspectives helps groups accommodate minority views and converge iteratively towards consensus on strategic actions.

## Goals of this research

This research proposes and demonstrates methodologies, principles, and a set of tools to help strategic decision makers agree on actions despite diverse perspectives amidst deep uncertainty. It extends and demonstrates the concept of exploratory analysis (EA) to simultaneously consider uncertainty about objective factors and so-called perspective parameters: those associated with the different values, beliefs, and expectations including the analytical belief about the best way to aggregate and score parameters in a mathematical model. It offers an extension of multiresolution modeling techniques and frameworks to help analysts and decision makers methodically navigate and gain insights about plausible outcomes in broad parameter space. It proposes graphical techniques to share insights among the decision-making group about a wide range of plausible futures. Statistical data-mining techniques then focus the group's discussion on factors that matter to the choice of options, along with the conditions under which they do, and to refine the group's understanding of different perspectives. MPSDM proposes ways of simplifying the problem so that decision makers can develop a shared understanding of the forces driving the choice of strategy. Finally, it includes a process to modify the options, consider minority views, and iterate the methodology to improve the likelihood of consensus on strategic actions.

*Note: The distinction between objective factors and perspective factors (values, beliefs, and expectations about the future) may not be as firm as has been indicated. Many factors that might be considered objective are in fact subjectively estimated (especially expectations) or subjectively assigned some nominal value. Strictly speaking, objective factors are ones that can be verified as fact, i.e. an event happened, a weapon destroyed the target, etc. What is meant here is to recognize the differences with which individuals may estimate factors and account for these differences in perspectives.*

