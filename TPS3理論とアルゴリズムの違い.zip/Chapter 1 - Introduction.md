# Chapter 1 - Introduction

## Significance of the research

In the 21st century, organizations governing every type of institution are experiencing unprecedented demands to consider alternative viewpoints from outside stakeholders, the decision makers themselves, and from new types of adversaries. One factor that contributes to this trend is the information age. Widespread access and rapid dissemination of information brings a high level of scrutiny from public stakeholders to government, business, and civil organizations. Marten and Samuels (2009) report that vulnerable colleges and universities experience "unprecedented external demands for accountability and quality assurance by the public, donors, accreditors, legislative bodies, and the U.S. Department of Education." Decision makers, becoming accountable to a wider group of stakeholders, external to the group must increasingly take these diverse perspectives into account when devising strategy.

In the educational sector, Eherenberg (2004) reports that wealthier institutions of higher education are seeing a dramatic shift in the makeup of their Boards of Trustees. In his book, Governing Academia, Who's in Charge at the Modern University? Eherenberg explores the effect of Educational Boards of Trustees becoming more heterogeneous, as they admit the alumni "insiders' voice." Goodstein, Gautan, and Boeker (1994) found that board diversity may be a significant constraint on strategic change.

U.S. Defense policy makers must adjust to a wider scope of considerations as well. Adversaries now include diffuse, non-governmental entities as well as nation states. These new adversaries are fundamentally different than nation states in terms of capabilities, tactics, motivations, strengths, and vulnerabilities. In addition, adversaries will search for and exploit combinations of vulnerable assumptions--combinations that may be hard to predict as systems become more complex. Defense policy must maintain the capability to deal with traditional adversary nations, while adding the capability to protect against non-government opponents (Hough 2008).

In addition to a fundamentally broader set of adversaries to consider, defense strategists must, as always, consider large number of factors that contribute to creating and maintaining alliances with other countries. Domestically, defense policymakers must continue to take into account the perspective of Congress, consider the likelihood of continued funding levels, and predict the political stability of programs in the midst of increased transparency and accountability from the public.

Another factor affecting the heterogeneity of governing institutions is regulatory. In response to perceived financial misdeeds, the Sarbanes-Oxley Act was passed by Congress in 2002. This, along with other, state-specific legislation requires governors of for-profit institutions, and to some extent non-profit institutions, to include more "outsiders" on their Boards of Directors.

U.S. government, for-profit, and non-profit institutions are not the only ones feeling the pressure driving them to consider more diverse perspectives. According to a recent RAND Pardee Center workshop report, regional and international institutions, facing pressure from economic, environmental, and activist forces, "may need substantial modification to contribute towards a stable, free, and just world in the 21st century."

How do high-level decision makers proceed with the difficult challenge of creating strategy which addresses these diverse perspectives? Classical management theory prescribes methodology for the decision-making group to agree on objectives, often from a shared understanding of the organization's vision and mission (Hitt, Ireland, and Hoskisson 2009). When groups are homogenous, consensus on objectives is relatively likely. As perspectives within the decision-making group diverge, or when decision makers must consider a wide range of stakeholder, analyst, and adversary viewpoints, consensus on objectives grows less likely. If objectives cannot be agreed upon, then it is improbable that the group will agree on strategies to accomplish those objectives.

There is clear evidence of so-called dissonance when values conflict (Heifitz 1994). Although governing groups rarely break out into fistfights as the Continental Congress did in 1787, the dissonance can be quite disruptive to the decision-making process. Dissonance can manifest itself in a variety of ways. For example, the decision-making group may be unable to reach consensus on the problem definition, the objectives, the criteria for evaluating alternatives, or the alternatives themselves. In some cases, the group may reach consensus on the problem definition and objectives, but disagree on the criteria for evaluating alternatives. In other cases, the group may agree on the problem definition, objectives, and criteria, but disagree on the alternatives.

## What is Multi-perspective Strategic Decision Making?

Multi-perspective Strategic Decision Making (MPSDM) is a methodology for creating strategy when decision makers must consider diverse perspectives. The methodology is designed to help decision makers reach consensus on strategy despite diverse perspectives. MPSDM is based on the premise that decision makers can reach consensus on strategy even when they disagree on objectives, criteria, or alternatives.

The MPSDM methodology consists of three steps:
1. Characterize the problem
2. Simplify the problem
3. Derive the strategy

The first step, characterize the problem, involves identifying the perspectives that must be considered and the uncertainties that must be addressed. The second step, simplify the problem, involves reducing the dimensionality of the problem to make it more tractable. The third step, derive the strategy, involves using the simplified problem to identify strategies that are robust across perspectives and uncertainties.

## Audience for this research

This research is intended for decision makers, analysts, and researchers who are interested in strategic decision making under conditions of diverse perspectives and deep uncertainty. The research is particularly relevant for decision makers in government, business, and non-profit organizations who must consider the perspectives of multiple stakeholders.

The research is also relevant for analysts who support decision makers in strategic decision making. The MPSDM methodology provides a framework for analysts to structure their analysis and communicate their findings to decision makers.

Finally, the research is relevant for researchers who are interested in strategic decision making, multi-criteria decision analysis, and decision making under uncertainty. The research contributes to the literature on these topics by providing a methodology that explicitly addresses the challenge of diverse perspectives.

## What is meant by perspectives?

In the context of this research, a perspective is a particular way of viewing a problem or situation. Perspectives can differ in terms of objectives, criteria, assumptions, or values. For example, in a business context, the marketing department may have a different perspective on a new product launch than the finance department. The marketing department may focus on market share and customer satisfaction, while the finance department may focus on profitability and return on investment.

Perspectives can also differ in terms of the time horizon considered. For example, some stakeholders may focus on short-term results, while others may focus on long-term sustainability. Perspectives can also differ in terms of the level of risk tolerance. Some stakeholders may be risk-averse, while others may be risk-seeking.

In the context of strategic decision making, perspectives are important because they can lead to different conclusions about what strategy is best. If decision makers do not explicitly consider different perspectives, they may make decisions that are not robust across stakeholders.

## Treating perspectives as uncertainties

One of the key insights of this research is that perspectives can be treated as uncertainties. Just as decision makers must consider uncertainty about future events, they must also consider uncertainty about which perspective is "correct" or most important.

Treating perspectives as uncertainties has several advantages. First, it allows decision makers to use existing tools and techniques for decision making under uncertainty. Second, it provides a framework for explicitly considering the robustness of strategies across different perspectives. Third, it allows decision makers to identify strategies that perform well even when there is disagreement about objectives or criteria.

The approach of treating perspectives as uncertainties is consistent with the literature on robust decision making (RDM). RDM is a methodology for making decisions under deep uncertainty, where deep uncertainty refers to situations where decision makers do not know or cannot agree on the appropriate models, probability distributions, or values to use in analyzing a decision.

## Goals of this research

The primary goal of this research is to develop and demonstrate a methodology for strategic decision making when decision makers must consider diverse perspectives. The methodology should help decision makers reach consensus on strategy despite disagreement on objectives, criteria, or alternatives.

Specific goals of this research include:

1. Develop a theoretical framework for multi-perspective strategic decision making
2. Develop practical tools and techniques for implementing the framework
3. Demonstrate the framework through a real-world case study
4. Evaluate the effectiveness of the framework in helping decision makers reach consensus

The research contributes to the literature on strategic decision making, multi-criteria decision analysis, and decision making under uncertainty. The research also has practical implications for decision makers in government, business, and non-profit organizations who must consider diverse perspectives in their strategic decision making.

