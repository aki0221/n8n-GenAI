# Wang et al. (2025) - Granular computing-driven two-stage consensus model for large-scale group decision-making

## Abstract

As new technical paradigms like electronic democracy and e-governance have emerged quickly, large-scale group decision-making (LSGDM) has become a significant area of research. In LSGDM, conflicting interests and divergent viewpoints have grown especially widespread, making it challenging to bring individual preferences into line with a productive group consensus. This paper uses the concept of information granules to design a granular LSGDM consensus framework that addresses two core aspects of LSGDM: the clustering process and the consensus reaching process. First, granular hierarchical clustering is designed based on the principle of justifiable granularity, with a novel division index introduced to determine the optimal number of subgroups. Next, the fuzzy consensus measure is defined by the specificity and coverage of information granule, and a two-stage granule consensus model is proposed by integrating the maximum consensus rule and minimum consensus cost to optimize individual opinions and achieve an efficient group consensus. Finally, an illustrative example with detailed experiments is conducted to demonstrate the practicality and effectiveness of the granular LSGDM consensus model in enhancing consensus and group division among DMs.

## 1. Introduction

Group decision-making (GDM) is crucial for addressing practical problems, as it incorporates the diverse perspectives of different decision-makers (DMs) to arrive at reasonable decision results. GDM considers the preferences of DMs to identify the ideal solution from a set of possible alternatives, with the final solution derived from the adjusted preference information of the group members. Currently, GDM has been widely applied in fields such as connected autonomous vehicles, supply chain investment, renewable energy, medical diagnosis, and emergency plans making.

The traditional method of having DMs participate in live activities and numerically express their choices has evolved into more diverse and complex forms of interaction. With advancements in network technology and the widespread use of social media, DMs can now engage in the decision-making process through multiple channels, leading to the emergence of large-scale group decision-making (LSGDM).

If the number of DMs involved in solving a decision problem exceeds 20, it may be classified as an LSGDM problem. However, there are two challenges associated with the implementation of LSGDM. One challenge is managing a large number of participants and their inputs, which can be quite intricate and time-consuming. Another is that the effectiveness of decision-making in LSGDM can be influenced by various factors, including the level of expertise and knowledge of the participants, as well as the potential for biases and groupthink.

To address LSGDM issues, it is crucial to establish a decision-making model that considers both individual perspectives and group opinions. The ultimate aim is to enhance the effectiveness of GDM and overall group satisfaction by identifying potential problems and achieving consensus or agreement. Currently, numerous approaches have been established to address LSGDM issues.

The LSGDM resolution typically consists of two significant processes: (1) The group clustering process seeks to divide numerous DMs into smaller groups to reduce the complexity and cost of LSGDM. (2) The consensus reaching process (CRP) enables DMs to adjust their preferences or those of their groups, contributing to higher satisfaction with the final outcome.

## 2. Literature Review

### 2.1. Clustering Methods in LSGDM

In the clustering process, DMs can be categorized into several subgroups based on their individual preferences. The goal is to group DMs by their similarities, ensuring that those with similar opinions are placed in the same group. Various clustering algorithms have been designed to categorize DMs in LSGDM problems.

Liang et al. proposed a novel clustering model based on opinion similarity and trust relationships among DMs, maximizing the combined cohesion of the subgroups. Ding et al. developed a conflict-relationship-based clustering method to effectively address opinion conflicts in LSGDM. Liang et al. presented a clustering method based on the similarity-trust score between DMs to reduce the complexity of decision-making. Wang et al. designed a dual-attribute affinity propagation algorithm to divide the large group into manageable subgroups.

### 2.2. Consensus Reaching Process

The consensus reaching process is essential for achieving agreement among diverse participants in LSGDM. Various approaches have been developed to facilitate consensus building while managing the complexity of large groups.

Traditional consensus measures may not be sufficient for large-scale scenarios due to the diversity of expert preferences and the complexity of achieving agreement among a large number of participants. Therefore, new consensus measures and building mechanisms are needed for LSGDM.

### 2.3. Granular Computing Applications

Granular computing provides a framework for handling uncertainty and complexity in decision-making processes. Information granules can represent clusters of similar data points or concepts, making them particularly suitable for managing the complexity of large-scale group decision-making.

The principle of justifiable granularity offers a systematic approach to determining optimal granule structures that balance coverage and specificity. This principle can be effectively applied to both clustering and consensus measurement in LSGDM contexts.

## 3. Methodology

### 3.1. Granular Hierarchical Clustering

The proposed granular hierarchical clustering method is based on the principle of justifiable granularity. This approach leverages both local and global information to create meaningful clusters of decision-makers.

The clustering process involves several key steps:

1. **Initial granule formation**: Decision-makers are initially grouped based on preference similarity measures.

2. **Hierarchical refinement**: The clustering structure is refined through iterative processes that consider both local cohesion and global optimization.

3. **Optimal cluster determination**: A novel division index is introduced to determine the optimal number of subgroups.

The granular hierarchical clustering method ensures that the resulting subgroups are both meaningful and manageable, reducing the complexity of the subsequent consensus reaching process.

### 3.2. Fuzzy Consensus Measurement

A fuzzy consensus measurement method is developed based on the specificity and coverage of information granules. This approach provides a more nuanced understanding of consensus levels compared to traditional binary measures.

The fuzzy consensus measure considers:

- **Specificity**: The degree to which a granule represents a specific set of preferences
- **Coverage**: The extent to which a granule covers the preference space
- **Granule quality**: The balance between specificity and coverage

This measurement approach allows for more flexible and accurate assessment of consensus levels in complex LSGDM scenarios.

### 3.3. Two-Stage Consensus Model

A two-stage granule consensus model is proposed that integrates the maximum consensus rule and minimum consensus cost to optimize individual opinions and achieve efficient group consensus.

#### 3.3.1. Stage 1: Maximum Consensus Rule

The first stage focuses on maximizing consensus among decision-makers within and between subgroups. This involves:

- Identifying areas of high agreement
- Strengthening consensus where possible
- Minimizing conflicts between subgroups

#### 3.3.2. Stage 2: Minimum Consensus Cost

The second stage optimizes the consensus reaching process by minimizing the cost of adjustments needed to achieve satisfactory consensus levels. This includes:

- Cost-benefit analysis of preference adjustments
- Optimal adjustment strategies
- Balancing consensus level with adjustment costs

## 4. Granular LSGDM Framework

### 4.1. Framework Overview

The granular LSGDM framework integrates the clustering process and consensus reaching process through a unified granular computing approach. The framework consists of several interconnected components:

1. **Input processing**: Collection and preprocessing of decision-maker preferences
2. **Granular clustering**: Application of granular hierarchical clustering
3. **Consensus measurement**: Fuzzy consensus assessment using granular measures
4. **Two-stage optimization**: Implementation of the two-stage consensus model
5. **Output generation**: Final decision and consensus report

### 4.2. Information Granule Construction

Information granules are constructed to represent clusters of similar preferences and opinions. The construction process considers:

- **Preference similarity**: Degree of alignment between decision-maker preferences
- **Trust relationships**: Level of confidence between decision-makers
- **Expertise levels**: Relative knowledge and experience of participants
- **Contextual factors**: Situational elements affecting decision-making

### 4.3. Granular Aggregation Method

A granular aggregation method is developed to combine individual preferences within and across granules. This method ensures that:

- Individual voices are preserved within the aggregation process
- Subgroup characteristics are maintained
- Overall group consensus is facilitated
- Computational efficiency is optimized

## 5. Experimental Validation

### 5.1. Experimental Design

An illustrative example with detailed experiments is conducted to demonstrate the practicality and effectiveness of the granular LSGDM consensus model. The experimental design includes:

- **Participant selection**: Large group of decision-makers with diverse backgrounds
- **Problem scenarios**: Multiple decision-making contexts
- **Performance metrics**: Consensus level, adjustment costs, satisfaction measures
- **Comparative analysis**: Comparison with existing LSGDM methods

### 5.2. Results Analysis

The experimental results demonstrate significant improvements in:

- **Consensus achievement**: Higher levels of agreement among participants
- **Efficiency**: Reduced time and cost for consensus reaching
- **Satisfaction**: Improved participant satisfaction with the process and outcomes
- **Scalability**: Effective performance with varying group sizes

### 5.3. Validation of Granular Approach

The granular computing approach shows particular advantages in:

- **Complexity management**: Effective handling of large-scale decision problems
- **Flexibility**: Adaptation to different decision-making contexts
- **Robustness**: Stable performance across various scenarios
- **Interpretability**: Clear understanding of consensus formation process

## 6. Discussion

### 6.1. Theoretical Contributions

The research makes several theoretical contributions to the field of LSGDM:

- **Granular computing integration**: Novel application of granular computing principles to LSGDM
- **Two-stage optimization**: Innovative approach to balancing consensus and cost
- **Fuzzy consensus measurement**: Advanced measurement techniques for complex consensus scenarios
- **Hierarchical clustering enhancement**: Improved clustering methods for large groups

### 6.2. Practical Implications

The practical implications of the research include:

- **Organizational decision-making**: Enhanced group decision processes in organizations
- **Democratic participation**: Improved mechanisms for large-scale democratic decision-making
- **Technology implementation**: Practical frameworks for e-governance and electronic democracy
- **Conflict resolution**: Better approaches to managing conflicting interests in large groups

### 6.3. Limitations and Future Work

Several limitations and areas for future research are identified:

- **Computational complexity**: Further optimization needed for very large groups
- **Cultural factors**: Consideration of cultural differences in decision-making
- **Dynamic environments**: Adaptation to changing decision contexts
- **Integration challenges**: Seamless integration with existing decision support systems

## 7. Conclusion

This paper presents a comprehensive granular computing-driven framework for large-scale group decision-making that effectively addresses the challenges of clustering and consensus reaching in complex decision environments. The proposed two-stage consensus model successfully balances the need for high consensus levels with practical cost considerations.

The key contributions include:

1. **Granular hierarchical clustering**: A novel clustering approach based on justifiable granularity principles
2. **Fuzzy consensus measurement**: Advanced measurement techniques using granular computing concepts
3. **Two-stage optimization**: Integrated approach to consensus reaching that considers both effectiveness and efficiency
4. **Practical validation**: Demonstrated effectiveness through comprehensive experimental analysis

The research provides a solid foundation for future developments in large-scale group decision-making and offers practical solutions for organizations and institutions dealing with complex group decision scenarios.

## References

[References would be listed here in the actual paper]

