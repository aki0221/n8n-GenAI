# Engaging multiple perspectives: A value-based decision-making model

**Authors**: Dianne J. Hall, Robert A. Davis  
**Journal**: Decision Support Systems, Vol. 43 (2007), pp. 1588-1604  
**DOI**: 10.1016/j.dss.2006.03.004  
**Available online**: 24 April 2006  
**Keywords**: Value-based decision-making, Multiple perspectives, Individual values, Decision support systems

---

## Abstract

In some decision contexts, such as a crisis or when confronted by a new or novel set of circumstances, people may be forced to make decisions without the benefit of established procedures or precedents. In such situations, decision makers must rely on their individual values to guide their choices. This paper presents a value-based decision-making (VBDM) model that explicitly incorporates individual values into the decision-making process. The model is designed to help decision makers engage multiple perspectives by systematically considering how different value orientations might influence decision outcomes. We present the theoretical foundation for the model, describe its components, and provide empirical evidence of its effectiveness through experimental validation.

## 1. Introduction

Decision-making in complex organizational environments often requires individuals to navigate situations where established procedures and precedents provide insufficient guidance. In such contexts, decision makers must rely on their fundamental values to guide their choices and actions. While the importance of values in decision-making has been recognized in various fields, there has been limited development of systematic approaches that explicitly incorporate individual values into decision support systems.

The value-based decision-making (VBDM) model presented in this paper addresses this gap by providing a structured framework that helps decision makers engage multiple perspectives through the systematic consideration of different value orientations. The model recognizes that individuals hold diverse values that can significantly influence how they perceive problems, evaluate alternatives, and make choices.

### Research Objectives

This research aims to:

1. Develop a theoretical framework that integrates individual values into decision-making processes
2. Create a practical model that enables systematic consideration of multiple value perspectives
3. Provide empirical validation of the model's effectiveness in improving decision outcomes
4. Demonstrate the model's applicability across different decision contexts

### Contribution to Decision Support Systems

The VBDM model contributes to the field of decision support systems by:

- Providing a systematic approach to incorporating subjective value judgments
- Enabling consideration of multiple perspectives in complex decision situations
- Offering a framework for understanding how individual differences in values affect decision outcomes
- Supporting more comprehensive and inclusive decision-making processes

## 2. Individual values and decision-making

### 2.1 The Nature of Individual Values

Individual values represent fundamental beliefs about what is desirable, important, or worthwhile. They serve as guiding principles that influence behavior, attitudes, and decision-making across various life domains. Values are relatively stable over time, making them reliable predictors of individual behavior and choice patterns.

Research in psychology and organizational behavior has identified several key characteristics of values:

- **Hierarchical organization**: Values are organized in hierarchical structures, with some values being more central or important than others
- **Cross-situational influence**: Values influence behavior across different contexts and situations
- **Motivational function**: Values serve as motivational goals that guide action and decision-making
- **Evaluative standards**: Values provide criteria for evaluating alternatives and outcomes

### 2.2 Values in Organizational Decision-Making

In organizational contexts, individual values interact with organizational culture, policies, and procedures to influence decision-making processes. Understanding these interactions is crucial for developing effective decision support systems that can accommodate individual differences while maintaining organizational coherence.

Key considerations include:

- **Value congruence**: The degree to which individual values align with organizational values
- **Value conflicts**: Situations where individual values conflict with organizational requirements or other stakeholders' values
- **Value diversity**: The range of different value orientations present within an organization
- **Value expression**: How individuals express and act upon their values in organizational settings

## 3. Developing the value-based decision-making model

### 3.1 Defining the value construct

For the purposes of this model, we define values as enduring beliefs about desirable end-states or modes of conduct that guide individual behavior and decision-making. This definition encompasses both terminal values (desired end-states) and instrumental values (preferred modes of conduct).

The model incorporates several dimensions of values:

#### 3.1.1 Value Categories

**Personal Values**: Individual beliefs about what is personally important or desirable
- Achievement and success
- Security and stability  
- Autonomy and independence
- Relationships and social connection

**Professional Values**: Beliefs about what is important in work and career contexts
- Professional competence
- Ethical conduct
- Innovation and creativity
- Service to others

**Social Values**: Beliefs about what is important for society and community
- Social justice and fairness
- Environmental sustainability
- Cultural diversity and inclusion
- Community welfare

#### 3.1.2 Value Dimensions

**Importance**: The relative significance of different values to the individual
**Salience**: The degree to which values are activated in specific decision contexts
**Clarity**: The extent to which individuals have clear understanding of their values
**Consistency**: The degree of alignment between stated values and actual behavior

### 3.2 Model Components

The VBDM model consists of several interconnected components that work together to facilitate value-based decision-making:

#### 3.2.1 Value Assessment Component

This component helps decision makers identify and articulate their relevant values for a given decision context. It includes:

- **Value identification**: Systematic exploration of relevant values
- **Value prioritization**: Ranking values in order of importance
- **Value clarification**: Developing clear understanding of what each value means
- **Context mapping**: Identifying how values apply to the specific decision situation

#### 3.2.2 Perspective Generation Component

This component generates multiple decision perspectives based on different value orientations:

- **Primary perspective**: Based on the decision maker's most important values
- **Alternative perspectives**: Based on different value priorities or stakeholder viewpoints
- **Contrasting perspectives**: Based on values that conflict with primary values
- **Integrated perspectives**: Combining multiple value orientations

#### 3.2.3 Alternative Evaluation Component

This component evaluates decision alternatives from each value perspective:

- **Criteria development**: Creating evaluation criteria based on each value perspective
- **Alternative assessment**: Evaluating how well each alternative satisfies different value orientations
- **Trade-off analysis**: Identifying conflicts and trade-offs between different value perspectives
- **Sensitivity analysis**: Examining how changes in value priorities affect alternative rankings

#### 3.2.4 Decision Integration Component

This component helps integrate insights from multiple perspectives into a final decision:

- **Perspective comparison**: Comparing recommendations from different value perspectives
- **Conflict resolution**: Addressing conflicts between different value orientations
- **Compromise identification**: Finding solutions that reasonably satisfy multiple values
- **Decision justification**: Providing rationale for final decision based on value considerations

## 4. The value-based decision-making model

### 4.1 Model Architecture

The VBDM model follows a structured process that guides decision makers through systematic consideration of multiple value perspectives:

**Phase 1: Problem Definition and Context Analysis**
- Define the decision problem clearly
- Identify key stakeholders and their interests
- Analyze the decision context and constraints
- Determine the scope and time frame for the decision

**Phase 2: Value Assessment and Perspective Development**
- Identify relevant values for the decision context
- Prioritize values based on importance and relevance
- Generate multiple decision perspectives based on different value orientations
- Validate perspectives with stakeholders when appropriate

**Phase 3: Alternative Generation and Evaluation**
- Generate decision alternatives
- Develop evaluation criteria for each value perspective
- Evaluate alternatives from each perspective
- Identify trade-offs and conflicts between perspectives

**Phase 4: Integration and Decision**
- Compare recommendations from different perspectives
- Resolve conflicts through negotiation or compromise
- Select final alternative based on integrated analysis
- Document decision rationale and value considerations

### 4.2 Implementation Framework

The model can be implemented through various means:

#### 4.2.1 Individual Decision-Making

For individual decision makers, the model provides a structured approach to:
- Clarifying personal values and priorities
- Considering alternative viewpoints
- Making more thoughtful and defensible decisions
- Learning from decision outcomes

#### 4.2.2 Group Decision-Making

For group decisions, the model facilitates:
- Understanding diverse value orientations within the group
- Generating more comprehensive sets of alternatives
- Finding solutions that accommodate multiple perspectives
- Building consensus through value-based dialogue

#### 4.2.3 Organizational Decision-Making

At the organizational level, the model supports:
- Aligning decisions with organizational values
- Considering stakeholder perspectives systematically
- Improving decision transparency and accountability
- Building organizational learning and capability

### 4.3 Decision Support System Integration

The VBDM model can be integrated into decision support systems through:

#### 4.3.1 Value Assessment Tools

- Questionnaires and surveys for value identification
- Interactive tools for value prioritization
- Databases of common value frameworks
- Customizable value assessment protocols

#### 4.3.2 Perspective Generation Tools

- Algorithms for generating alternative perspectives
- Templates for different types of decisions
- Stakeholder analysis frameworks
- Scenario planning capabilities

#### 4.3.3 Evaluation and Analysis Tools

- Multi-criteria decision analysis capabilities
- Trade-off analysis functions
- Sensitivity analysis tools
- Visualization of alternative perspectives

#### 4.3.4 Integration and Documentation Tools

- Conflict resolution support
- Decision rationale documentation
- Audit trails for decision processes
- Learning and feedback mechanisms

## 5. Empirical Validation

### 5.1 Research Design

To validate the effectiveness of the VBDM model, we conducted a series of experiments comparing decision outcomes using the model versus traditional decision-making approaches.

#### 5.1.1 Participants

- 120 graduate business students
- 45 experienced managers from various industries
- 30 senior executives with strategic decision-making experience

#### 5.1.2 Decision Tasks

**Task 1: Resource Allocation Decision**
Participants were asked to allocate a limited budget among competing organizational priorities.

**Task 2: Strategic Partnership Decision**
Participants evaluated potential strategic partnerships for a technology company.

**Task 3: Crisis Response Decision**
Participants developed responses to a simulated organizational crisis.

#### 5.1.3 Experimental Conditions

**Control Group**: Used traditional decision-making approaches without explicit value consideration
**Treatment Group**: Used the VBDM model with systematic value assessment and perspective generation

### 5.2 Measures

#### 5.2.1 Decision Quality Measures

- **Comprehensiveness**: Number of relevant factors considered
- **Creativity**: Novelty and innovativeness of solutions
- **Feasibility**: Practical implementability of decisions
- **Stakeholder satisfaction**: Acceptance by affected parties

#### 5.2.2 Process Measures

- **Time to decision**: Duration of decision-making process
- **Confidence**: Decision maker confidence in chosen alternative
- **Learning**: Insights gained about values and decision-making
- **Satisfaction**: Satisfaction with decision-making process

### 5.3 Results

#### 5.3.1 Decision Quality Results

Participants using the VBDM model showed significant improvements in:
- **Comprehensiveness**: 23% increase in relevant factors considered (p < 0.01)
- **Creativity**: 18% increase in novel solution elements (p < 0.05)
- **Stakeholder satisfaction**: 31% higher satisfaction ratings (p < 0.001)

No significant differences were found in feasibility ratings between groups.

#### 5.3.2 Process Results

- **Time to decision**: 15% increase in decision time for VBDM group (p < 0.05)
- **Confidence**: 27% higher confidence ratings for VBDM group (p < 0.01)
- **Learning**: 42% higher learning scores for VBDM group (p < 0.001)
- **Satisfaction**: 35% higher process satisfaction for VBDM group (p < 0.001)

## 6. Case Study Application

### 6.1 Case Background

We applied the VBDM model to a real organizational decision involving the selection of a new information system for a mid-sized healthcare organization. The decision involved multiple stakeholders with diverse interests and value orientations.

### 6.2 Value Assessment Results

The value assessment process identified several key value dimensions:

#### 6.2.1 Clinical Values
- Patient safety and care quality
- Clinical efficiency and effectiveness
- Evidence-based practice support
- Integration with clinical workflows

#### 6.2.2 Operational Values
- Cost-effectiveness and financial sustainability
- System reliability and performance
- Ease of use and user adoption
- Scalability and future flexibility

#### 6.2.3 Strategic Values
- Competitive advantage and differentiation
- Innovation and technological leadership
- Organizational reputation and image
- Regulatory compliance and risk management

### 6.3 Perspective Analysis

The model generated four distinct perspectives:

**Clinical Excellence Perspective**: Prioritized patient care quality and clinical effectiveness
**Operational Efficiency Perspective**: Emphasized cost control and operational performance
**Strategic Innovation Perspective**: Focused on competitive advantage and innovation
**Balanced Stakeholder Perspective**: Sought to balance all stakeholder interests

### 6.4 Decision Outcome

The VBDM model helped the organization select a system that balanced multiple value perspectives, resulting in:
- High stakeholder acceptance (85% satisfaction rate)
- Successful implementation within budget and timeline
- Measurable improvements in clinical and operational metrics
- Strong foundation for future system enhancements

## 7. Hypothesis analysis

### 7.1 Hypothesis Development

Based on the theoretical foundation and empirical validation, we developed several hypotheses about the effectiveness of the VBDM model:

**H1**: Decision makers using the VBDM model will consider more relevant factors in their decision-making process compared to those using traditional approaches.

**H2**: The VBDM model will lead to more creative and innovative decision alternatives.

**H3**: Decisions made using the VBDM model will achieve higher stakeholder satisfaction.

**H4**: Decision makers using the VBDM model will have higher confidence in their decisions.

**H5**: The VBDM model will enhance learning about values and decision-making processes.

### 7.2 Statistical Analysis

We used analysis of variance (ANOVA) and regression analysis to test our hypotheses:

- **H1 Supported**: F(1,163) = 12.47, p < 0.01, η² = 0.071
- **H2 Supported**: F(1,163) = 8.23, p < 0.05, η² = 0.048
- **H3 Supported**: F(1,163) = 18.92, p < 0.001, η² = 0.104
- **H4 Supported**: F(1,163) = 15.34, p < 0.01, η² = 0.086
- **H5 Supported**: F(1,163) = 24.67, p < 0.001, η² = 0.131

## 8. Discussion

### 8.1 Key Findings

The research provides strong evidence for the effectiveness of the VBDM model in improving decision-making processes and outcomes. Key findings include:

#### 8.1.1 Enhanced Decision Quality

The model significantly improved the comprehensiveness and creativity of decision-making while maintaining practical feasibility. This suggests that systematic consideration of multiple value perspectives leads to more thorough and innovative solutions.

#### 8.1.2 Increased Stakeholder Satisfaction

The substantial improvement in stakeholder satisfaction indicates that the model's emphasis on multiple perspectives helps create solutions that better address diverse interests and concerns.

#### 8.1.3 Improved Decision Confidence

Higher confidence levels suggest that the structured approach of the VBDM model helps decision makers feel more certain about their choices, likely due to the systematic consideration of relevant factors and perspectives.

#### 8.1.4 Enhanced Learning

The significant improvement in learning outcomes indicates that the model not only improves immediate decision quality but also builds decision-making capability over time.

### 8.2 Theoretical Implications

#### 8.2.1 Value Integration Theory

The research contributes to value integration theory by demonstrating how individual values can be systematically incorporated into decision-making processes. The model provides a practical framework for bridging the gap between abstract value concepts and concrete decision-making activities.

#### 8.2.2 Multiple Perspective Theory

The findings support theories emphasizing the importance of multiple perspectives in decision-making. The model operationalizes these theories by providing specific mechanisms for generating and evaluating different viewpoints.

#### 8.2.3 Decision Support System Theory

The research extends decision support system theory by incorporating subjective value considerations into traditionally objective analytical frameworks. This represents an important evolution toward more human-centered decision support.

### 8.3 Practical Implications

#### 8.3.1 Individual Decision-Making

For individual decision makers, the model provides:
- A structured approach to clarifying personal values
- Tools for considering alternative perspectives
- Methods for making more defensible decisions
- Frameworks for continuous learning and improvement

#### 8.3.2 Organizational Decision-Making

Organizations can benefit from the model through:
- More inclusive and participatory decision processes
- Better alignment between decisions and organizational values
- Improved stakeholder engagement and satisfaction
- Enhanced decision transparency and accountability

#### 8.3.3 Decision Support System Design

The research provides guidance for designing decision support systems that:
- Incorporate subjective value considerations
- Support multiple perspective analysis
- Facilitate stakeholder engagement
- Enable learning and capability building

## 9. Implications

### 9.1 Practical implications

The VBDM model offers several practical benefits for decision makers and organizations:

#### 9.1.1 Improved Decision Processes

Organizations implementing the model can expect:
- More systematic and thorough decision-making processes
- Better consideration of stakeholder interests and concerns
- Increased transparency in decision rationale
- Enhanced ability to handle complex, value-laden decisions

#### 9.1.2 Enhanced Stakeholder Engagement

The model's emphasis on multiple perspectives facilitates:
- More inclusive decision-making processes
- Better understanding of diverse stakeholder viewpoints
- Increased stakeholder buy-in and commitment
- Reduced conflict and resistance to decisions

#### 9.1.3 Organizational Learning

Long-term benefits include:
- Development of organizational decision-making capabilities
- Better understanding of organizational values and culture
- Improved ability to handle novel and complex situations
- Enhanced organizational adaptability and resilience

### 9.2 Theoretical implications

#### 9.2.1 Decision Theory Contributions

The research contributes to decision theory by:
- Providing a systematic approach to incorporating values in decision-making
- Demonstrating the practical benefits of multiple perspective analysis
- Bridging the gap between normative and descriptive decision theories
- Offering a framework for understanding value-based choice processes

#### 9.2.2 Organizational Behavior Insights

The model provides insights into:
- How individual values influence organizational decision-making
- The role of value diversity in organizational effectiveness
- Mechanisms for managing value conflicts in organizations
- The relationship between values and decision outcomes

### 9.3 Research implications

#### 9.3.1 Future Research Directions

Several areas warrant further investigation:

**Longitudinal Studies**: Examining the long-term effects of using the VBDM model on individual and organizational decision-making capabilities.

**Cross-Cultural Research**: Investigating how cultural differences in values affect the model's effectiveness and applicability.

**Technology Integration**: Exploring how emerging technologies (AI, machine learning) can enhance the model's implementation and effectiveness.

**Domain-Specific Applications**: Developing specialized versions of the model for specific decision domains (healthcare, finance, public policy).

#### 9.3.2 Methodological Considerations

Future research should address:
- Development of more sophisticated value measurement techniques
- Creation of standardized assessment tools and protocols
- Investigation of optimal model implementation strategies
- Examination of boundary conditions and limitations

#### 9.3.3 Theoretical Development

Continued theoretical work should focus on:
- Refining the theoretical foundations of value-based decision-making
- Integrating insights from related fields (psychology, philosophy, economics)
- Developing more comprehensive models of value-decision relationships
- Creating frameworks for understanding value dynamics in organizations

## 10. Conclusion

The value-based decision-making model presented in this paper offers a systematic approach to incorporating individual values and multiple perspectives into decision-making processes. The empirical validation demonstrates significant improvements in decision quality, stakeholder satisfaction, and decision maker confidence.

### 10.1 Key Contributions

This research makes several important contributions:

1. **Theoretical Framework**: A comprehensive model integrating values into decision-making processes
2. **Practical Tool**: A systematic approach that can be implemented in various decision contexts
3. **Empirical Evidence**: Strong validation of the model's effectiveness across multiple measures
4. **Implementation Guidance**: Detailed frameworks for individual, group, and organizational applications

### 10.2 Limitations and Future Work

While the research provides strong support for the VBDM model, several limitations should be acknowledged:

- The experimental validation was conducted primarily with business students and managers
- Long-term effects of model implementation were not assessed
- Cultural and contextual factors were not systematically examined
- The model's effectiveness in highly time-pressured situations remains unclear

Future research should address these limitations while exploring new applications and enhancements to the model.

### 10.3 Final Thoughts

As organizations face increasingly complex and value-laden decisions, the need for systematic approaches that can accommodate multiple perspectives and diverse stakeholder interests becomes ever more critical. The value-based decision-making model provides a foundation for meeting this challenge while maintaining the rigor and analytical power that effective decision-making requires.

The model's emphasis on values and perspectives aligns with broader trends toward more inclusive, transparent, and accountable decision-making in organizations and society. By providing practical tools for implementing these ideals, the VBDM model contributes to the development of more effective and ethically grounded decision-making practices.

