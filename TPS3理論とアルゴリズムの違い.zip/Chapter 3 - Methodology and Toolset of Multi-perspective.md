Chapter 3 - Methodology and Toolset of Multi-perspective
Strategic Decision Making
Methodology
Overview
Classical management thinking prescribes group discussions about objectives,
followed by development of corresponding strategies and plans (Hitt, Ireland, and
Hoskisson 2009). This traditional approach includes on an underlying assumption that the
risk, returns, and cost of options being considered can be predicted with a relatively high
level of confidence, and that uncertain variables can be identified and characterized.
MPSDM seeks to be more realistic about uncertainty, and about the existence and
importance of differing perspectives. It develops strategies and plans focused on actions
(options) while accommodating diverse and sometimes uncertain perspectives. The figure
below illustrates the MPSDM methodology.

Figure 3.1 - MPSDM Methodology

65

MPSDM calls for 1) Characterizing the problem for analysts and decision makers
using a return/risk/cost framework and an initial set of criteria in a multiresolution model;
choosing a feasible, action-oriented initial set of strategic options; and evaluating
perspective parameters explicitly; 2) Simplifying the problem using a multi-pronged
approach; 3) using the driving forces’ controllability and time frame to determine type of
strategy which best addresses the choice of options, and modifying options and criteria as
required. Once insights about the problem are gained and shared, the problem is iterated,
repeating the analysis on the revised set of criteria and options based on initial
experience. At any phase of this methodology, decision makers can be consulted for
their perspectives, but experience shows that high-level decision makers want a
combination of credible results and discussion at a level where their expertise and
judgment can be most useful.
At the top level, the MPSDM methodology looks similar to other three-phase
strategic decision making process models (Schwenk 1995), although the phases are
sometimes described using different words. MPSDM, more specifically than other
approaches, focuses on decision makers’, stakeholders’, and adversaries’ different
perspectives. This different focus is more evident in the detailed description of the
methodology
MPSDM step #1: Characterize the problem
The management and policy analysis literature proposes several ways to frame
problems but, as discussed earlier, in order to derive strategy, MPSDM starts with
return/risk/cost framework and an initial set of criteria, against which options will be
evaluated. There are many ways to identify an initial set of criteria, for example by
defining some capability desired in the future and assessing the current capability.
Closing the capabilities gap could be one criterion. Other criteria could the highest
considerations held important by different constituencies. Typically constraints are
identified at this early stage of characterizing the problem.
Although the MPSDM methodology can use any type of returns or risk measures,
performance in scenarios is a good starting criterion for assessing different strategic
options, for reasons described earlier.
66

Davis et al. (2008) define an analytical approach for devising a so-called spanning
set of scenarios.27 This approach is similar to how a design engineer would specify a set
of design points which, together, would stress the key requirements for a system. The
approach follows careful thinking about the entire scenario/parameter space and identifies
the critical dimensions of the problem. If well chosen, the spanning set of scenarios
stresses the options in all critical dimensions. Often these critical dimensions can be
identified before the more detailed analysis, sometimes not. RDM methodology (Groves
and Lempert 2007) includes a procedure for discovering so-called policy-relevant
scenarios: sets of assumptions which are most relevant to the policies. As will be shown
later, MPSDM starts with the criteria of option performance in a spanning set of scenarios,
and allows for iteration of the scenarios if new critical dimensions are discovered in the
exploratory analysis.
As mentioned before, MPSDM assumes that an initial set of feasible options has
already been identified. How might this be accomplished? Perhaps decision makers or
analysts have already identified a list of possible strategic actions to take. In some cases
stakeholders or advocates have identified their preferred options.
Davis et al. (2008) define a methodical approach for developing this list of options
that expands the possibilities beyond what analysts or decision makers may initially
consider. The procedure identifies multiple objectives with the intention of generating a
portfolio of investment options; identifies building-block options that address a portions of
the problem (i.e. individual objectives), generates all combinations of building blocks (i.e.
all composite options), and then performs a screening evaluation to winnow the list to
those that perform relatively reasonably well (e.g. that are close to the efficient frontier)
across multiple objectives, by at least one perspective. Good strategic options are almost

27

In mathematics, a spanning set has a somewhat different definition than used by Davis et al. Mathematically, a
spanning set is a set of points from which all other points in a set can be constructed by a linear combination of those
points. A spanning set of scenarios is not meant to imply that would could construct all other scenarios by linear
combinations of the spanning set. Davis, Shaver and Beck (2008) define a spanning set of scenarios as “a small set
of scenarios chosen to stress a design or investment plan in all critical dimensions. An option that does well across the
spanning set of cases should do well in real-world situations (assuming good use of resources at the time), even
though those situations will usually differ from the test cases” (p. xxxviii).

67

always composite options because of the multiple objectives and considerations. This
method ensures that a broad set of possibilities is considered initially.
A key principle of MPSDM is evaluating the options using both traditional, objective
criteria, simultaneously with decision makers’ perspectives (values, beliefs, and
expectations). As was described in the previous chapter, many types of perspectives can
be identified and characterized analytically and included in a multiresolution model to
assess the options.
MPSDM step #2: Simplify the problem
The second step of the MPSDM methodology is to simplify the problem. This is
challenging because of the curse of dimensionality—the number of options, the profound
uncertainty inherent in strategic decision making (especially when adversary’s capabilities
and responses must be considered), and the wide range of perspectives that have been
incorporated into the problem. The approach taken by MPSDM to simplify the problem
using a multiresolution return/risk/cost framework and six useful simplifications:
1. defining Relative Option Superiority as a figure of merit;
2. starting with an initial, relatively small set of feasible options;
3. extending EA methodologies to discover forces (including perspectives and
MRM aggregation techniques) driving the system;
4. using an aggregation/disentangling process to efficiently navigate uncertain
parameter space;
5. eliminating dominated options; and
6. eliminating criteria that don’t differentiate options
The first few of these simplifications—using a multiresolution return/risk/cost
framework, using Relative Option Superiority as a figure of merit, and starting with an
initial, finite set of feasible options--has been described earlier. The next sections
describe the other simplifications.
68

Exploratory analysis
EA is described in the Figure below.

Figure 3.2 - Steps in Exploratory Analysis
(Figure Adapted From Bankes 1993)
The first exploratory analysis step is to design the computational experiment. As
mentioned earlier, the dependent variables are the outcomes of interest, i.e. performance
in a number of scenarios and risk dimensions. Each “run” of the computational
experiment produces risk and return results at different resolutions as a function of
independent variables (sets of assumptions). Consider an aggregated return measure,
such Overall Effectiveness which could be calculated as a weighted sum of performance
in multiple scenarios.
The independent variables, or assumptions, can include continuous, discrete, or
logical variables indicating uncertainty or different perspectives. The variables consist of
objective factors and the more subjective perspective parameters which represent
different values, beliefs, and expectations of decision makers, stakeholders, and
adversaries. The design of the computational experiment includes determining the
independent variables, and establishing the plausible range they will take in the multiple
analytical runs of the experiment. In addition, the independent variable sampling
technique must be established. It is important to cover the full range of parameter space,
defined as the assumptions and outcomes associated with the extreme ends of
assumption plausibility. For instance, if one assumption can plausibly take on a value
between zero and one, and another assumption can plausibly be between 10 and 100,
then all four combinations (0,10; 0,100; 1,10; 1,100) should be evaluated. It may turn out
that, due to nonlinear effects, some middle-ground combinations produce more extreme
69

combinations than the points on the extremes. The sampling methodology is left to the
experimental designer.28
The next step in designing the computational experiment is to set up a table of the
independent variables, or sets of assumptions that will be considered. The variables are
not varied one at a time as in traditional sensitivity analysis, but all together according to
the computational experimental design. During the computational experiment, the
independent variables are set to different values within their plausible range, and the
mathematical model produces a suite of plausible outcomes corresponding to each set of
assumptions.
Running the computational experiment involves taking the table of independent
variables, running it through a model of the system, and a set of outcomes for each set of
independent variables. Several tools currently exist to model the system in support of EA;
the most common appear to be Analytica, developed by Lumina Systems (Davis, McEver,
and Wilson 2002) and the Computer Assisted Reasoning System (CARs) developed by
Steven Bankes and maintained by Evolving Logic (Lempert et al. 2003). Both tools
include the capability for initial graphical exploration of the parameter space.
The resulting matrix of independent variables and dependent variables (outcomes)
is of dimension (X, [Ni+Nd]) where X is the number of “runs”, or combinations of
independent variables considered in the computational experiment; Ni is the number of
independent variables, and Nd is the number of dependent variables.
The third step in EA is graphical (visual) exploration of the results of the
computational experiment. Here is another area where the multiresolution model helps
provide structure and clarity to the problem. Sometimes a visual inspection or “drilling
down” within the multiresolution model or suite of results from the computational
experiment points to input assumptions (or combinations) that produced extreme
28

As mentioned earlier, deep uncertainty includes the case where the distribution of uncertain parameters cannot be
determined or agreed upon. There may be cases where a distribution of one or more parameters can be assumed
and used in the experimental design. The resulting “probabilistic EA” would be significantly complicated if the
parameters were not independent. The presumption here is that the analyst will use good judgment about
representing the distribution of input parameters, but the important point for MPSDM is that the extremes of plausible
parameter space should be explored. After the exploration, the analyst can determine whether a particular
combination of parameters that produces extreme results is plausible, but in many types of problems, adversaries will
seek to find and exploit these extreme conditions.

70

outcomes. In addition, simple graphical techniques include histograms of the frequency of
certain outcomes, box-and-whisker plots, or scatter plots of assumptions vs. outcomes
can be used to find the forces that drive extreme outcomes. In the process of this
graphical exploration, the goal is to gain insight and understanding about what drives the
complex, multidimensional system at hand. As described earlier, annotated box-andwhisker plots show the distributions for outcomes of interest for the different options and
criteria and serve as a useful starting place for gaining insight into the relative
performance of the options.
Finally, statistical data mining techniques can be employed to determine the driving
forces, or independent variables that most strongly affected the outcomes, and under
what circumstances they do. A number of data-mining techniques exist, most recently
documented in Nisbet, Elder, and Miner (2009) and Hastie and Tibshirani (2009).
Lempert, Bryant, and Bankes (2007) identify two that are particularly useful for policy
applications. (See also Bryant and Lempert 2009). The Classification and Regression
Tree method (CART: Brieman et al. 1984) and the Patient Rule Induction Method (PRIM:
Friedman and Fisher 1999) both start with the results from the multiple runs of the
computational experiment: a matrix consisting of several independent variables and at
least one outcome for each run. Each independent variable defines a dimension in
multidimensional parameter space. For the moment, consider each point (i.e. value of the
independent variables in that space) to be associated with an outcome that is either
above or below a threshold. These outcomes can be considered “good” or “bad”
outcomes, or visualized as black and white points in space, where the dimensions of
space correspond to each input assumption.
To understand the data mining process, it is helpful to imagine a set of points in
multidimensional space. Each dimension corresponds to one independent variable (input
assumption). The points are either black or white, with black points being defined as
points of interest. For example, black points are associated with performance above a
specific threshold. We wish to find the input assumptions, or dimensions, associated with
primarily black points. Not only do we wish to find which assumptions are associated with
black points, but we wish to draw “boxes” around the black points such that the space
71

inside the box (defined values of assumptions) contains primarily black—or good--points.
These boxes would define which assumptions, and the range of those assumptions, that
are associated with the points of interest.
Both the PRIM and the CART algorithms place limiting restrictions on the
dimensions that can be used to form sets of boxes characterizing the independent
variables and their range that are most associated with the cases of interest.
Lempert et al. (2006) identify three goals that the algorithm should seek when
defining boxes:
1. Good coverage: a high ratio of “good” cases in the box to the total number of
cases in the database
2. High density: a high ratio of “good” cases to total cases within the box set.
3. Interpretability: fewer boxes and dimensions in each box to make it easier to
understand and characterize the boxes conceptually.
The CART algorithm doesn’t produce the boxes explicitly, but produces output in the
form of a decision tree that can be used to identify box sets. The algorithm divides up the
multidimensional input space, one parameter at a time (although multiple splits of the
same parameter are allowed), with the goal of creating multiple regions of space
containing only “good” or “bad” outcomes. The algorithm partitions the parameter space
in series of binary splits, creating sets of boxes that are orthogonal to the independent
variable axes. The series of splits, or regression tree, can be continued until it defines
regions of purely “good” or “bad” outcomes. For most applications, however, these
regions would be quite complicated (hurting the interpretability measure), and noise in the
data may cause over-fitting.
After growing the initial tree, the CART algorithm “prunes” the tree to find the
combinations with the best predictive power, accounting for statistical noise. Thus,
several boxes are produced by CART: the initial, complicated one and one or more
pruned trees. The user can choose the one that best balances coverage, density, and
interpretability.
72

Like CART, PRIM starts with the full range of input parameter space and
successively restricts the size of the space, but uses a so-called “peeling” and “covering”
process. Consider the ratio of the number of “good” cases to the number of total cases, or
the mean in the unrestricted parameter space box. The PRIM algorithm identifies and
removes a thin layer of whatever “face” from the current box will increase the mean in the
new (restricted) box. This series of restrictions is called a “peeling trajectory.”
A number of boxes are produced by this step, and the user is presented a plot of
density for each box vs. its “support” (the fraction of good points inside the box to the total
number of points—a factor related to coverage). As Lempert, Bryant, and Bankes (2007)
point out, coverage is a better figure of merit than support for the type of policy
applications they considered. The user then selects the boxes of interest, balancing the
competing goals of density and support. In a process called pasting, the candidate boxes
can then be expanded by allowing the dimensions that may have been overly restricted to
relax.
The user then chooses from the set of pasted boxes, and the PRIM algorithm can be
iterated using what is known as a covering process: the data within the selected box are
removed from consideration and the peeling/pasting process is repeated for the
remaining data. The user can continue this two-step process until the algorithm no longer
finds useful box sets.
Lempert, Bryant and Bankes compared the CART and PRIM algorithms using
known shapes of points of interest and determined that neither algorithm provides a
perfect description. To be fair, the known parameter spaces were not simple rectilinear
boxes, or the shape that both algorithms return, but rather more complex regions. They
found that PRIM has a tendency to restrict too many dimensions and span disjoint
regions with single boxes. CART tends to generate too many and inappropriately
asymmetric boxes. For simple parameter space regions, CART generated boxes with
better coverage/density performance than PRIM, but the authors noted that PRIM was
generally more useful for actual policy analysis because CART required an unfeasibly
large number of boxes before reaching acceptable levels of coverage.
MPSDM recommends the PRIM algorithm be used for the following reasons:
73

• PRIM’s general applicability to higher-dimensional parameter space regions noted
above
• PRIM offers more interactivity than CART, allowing the user to balance the
sometimes-competing figures of merit (coverage, density, and interpretability). This
interactivity advantage could be somewhat offset by the resulting variation of
results from analyst to analyst.
• PRIM has been updated by Evolving Logic (Bryant, 2009) to address some of the
weaknesses noted, including
o even more interactivity and graphical indications to help the user select
boxes
o tests associated with statistical significance of variables
o reproducibility calculations, performed by comparing results from two
box sets generated on different resamplings relative to the number of
points in their union.
o the ability to generate data for post-processing.
Other simplifications
Recall the MPSDM methodology shown in Figure 3.1, and the six-pronged approach
to simplifying the problem. The fourth prong is to a process that includes a mix of
aggregating (to represent top-level results) and disentangling (to parse out the key factors
driving the top-level results) in order to navigate the uncertain parameter space and share
insights gained along the way. The disentangling is accomplished by adding more fidelity
to the models of underlying factors that drive the choice of options. Once these driving
forces are understood and modeled in sufficient detail, another exploration can find even
lower-level factors driving the choice of options. At some point, the fundamental factors
driving Relative Option Superiority of one option over another (or a retained option’s
vulnerability) are sufficiently characterized. The resulting insight can be used with the time
frame/controllability heuristic to modify the options. Alternatively, the factor can be
identified to decision makers to aid a discussion of the likelihood of this factor behaving as
characterized.
74

The fifth simplification technique is identifying and eliminating any dominated
options. Dominance in one dimension (risk, return, or cost) occurs when one option is
inferior to others for almost the complete set of plausible outcomes. If an option is
superior to another option, for example, in 98% of the cases considered, it is a matter of
judgment whether it is truly dominated. However, examining the 2% of the cases where
the option is not dominated can sometimes provide useful insights. For instance, this
combination of assumptions may be considered sufficiently unlikely to warrant further
consideration of the option.
Similarly, by examining the results of the computational experiment, the criteria
which differentiate the options can be identified. Differentiating criteria are the criteria for
which one or more option is superior to others. If all options perform relatively the same
for a particular criterion, then that criterion is of little use in helping decision makers
choose between strategic options. Although it may be useful to know that the current
options do not address a particular criterion, that criterion can be eliminated in the current
iteration of the MPSDM methodology. This winnowing down of the criteria represents the
sixth prong of the simplification approach.
MPSDM step #3: Derive the strategy
The third step in the MPSDM methodology as illustrated in Figure 3.1 is to derive the
strategy. One type of strategy would be to simply choose the option that performs “best”
for the criteria identified. MPSDM proposes using the insights gained about the forces
driving relative option superiority to guide selection of the type of strategy. As described in
the previous chapter, by mapping the time frame and controllability of the driving forces
onto the two-dimensional heuristic described earlier, the best type of strategy to account
for that driving force can be discovered.
Once the strategies are developed to affect or respond to the driving forces, the
options that are the most attractive can be modified according to the prescribed strategy
type. EA can be repeated using the new option set. The criteria can either be the original
set, or, if new understandings about the relative value of the criteria have been revealed
during the previous iteration, the criteria can be modified. As before, the criteria that do
75

not affect relative option superiority can be winnowed down, along with dominated
options. The iterative process can continue as resources permit, or until an agreed-upon
option and strategy (for instance, option 3 plus hedges) emerges.
Toolset of the MPSDM approach
The toolset of the multi-perspective strategic decision making approach builds on
tools developed in other policy domains; the exploratory analysis tools used by RDM in
the social issues sector (Lempert et al. 1996; Lempert and Bonomo 1998, Lempert and
Schlesinger 2000, Lempert et al. 2004, Lempert et al. 2005, Groves 2005), and the
multiresolution modeling tools used by Davis et al. in the defense sector (Davis 1993,
Davis and Bigelow 1998, Davis 2000, Davis 2003, Davis 2005, Davis and Dreyer 2009).
Tools developed or refined for MPSDM include:
• Methodology to characterize and model some types of perspectives
• Multiresolution models for rapid, clear assessments at levels appropriate to the
problem and to structure a methodical exploratory analysis
• Exploratory analysis techniques to simplify the problem to its important parts (nondominated options, differentiating criteria, and driving forces)
• Annotated box-and-whisker charts to focus discussion on values, beliefs, and
expectations that affect choice of options
• A heuristic that suggests strategy type as a function of driving forces’
controllability and timeframe
• The method to use the heuristic to modify options for iteration
Thus far, this chapter has described the methodology, principles, and the toolset of
MPSDM. The next chapter illustrates the methodology and principles defined here for
MPSDM with a more concrete example.

76

