Chapter 4 - Demonstration of the Approach
The strategic problem chosen
To illustrate the principles, methodology, and toolset of the MPSDM approach, the
procurement strategy of achieving capabilities to deliver conventional prompt global strike
(CPGS) was chosen. This problem represents a long-term policy decision involving large
resources and illustrates many of the features of MPSDM.
A 2007 report to Congress by the Secretary of Defense and Secretary of State
identified the CPGS mission, which is to plan and execute small, discrete, conventionalweapon (non-nuclear) strikes around the globe within one hour as authorized by the
President. The United States does not currently have military capabilities to carry out this
mission (National Research Council of the National Academies, 2008, hereafter called
NRC 2008), unless the target is a relatively short distance and then only if existing aircraft
(tactical aircraft and cruise missiles, bombers, unmanned aerial vehicles (UAVs)) are prepositioned and have extensive mission support resources available. The NRC Committee
also concluded that the development of sophisticated air defenses may cause problems
for forward-deployed forces unless defense-suppression attacks could be developed to
disable the air defenses.
What is the value of achieving CPGS capability beyond what is currently available?
The NRC (2008) concluded that the U.S. could gain meaningful political and strategic
advantages by developing this capability. Specifically, in some scenarios, CPGS
capability would eliminate the dilemma of being forced to choose between responding
with nuclear weapons and not responding at all.
Several factors make achieving CPGS capability a challenge. These include the US
restructuring of its forces based overseas, the need to fight adversaries further away from
US Bases, and the broader set of possible adversaries.
In addition to the above mission challenges, the CPGS requirements themselves are
somewhat soft. In the NRC 2008 report, the Committee on CPGS Capability did not
interpret the term “global” literally. They anticipated that attacks in Antarctica, Patagonia,
77

or Tasmania will not be likely, and that there would be time for redeployment if the world
situation changed in that regard. With respect to promptness, the NRC committee
concluded that “setting a goal of one hour for execution time in a conventional strike is
sensible when viewed in terms of feasibility, value, and affordability. Although the report
deemed the one-hour goal “sensible”, it was not considered a strict criterion. Davis,
Shaver, and Beck (2008) considered activities that precede the strike in the timeline and
concluded that “Most currently plausible Global Strike scenarios involve many hours or
days of warning and preparation, and the time to actually execute a mission is much less
important than the ability to achieve surprise or avoid detection.” However, some targets
might be vulnerable for only a short time, in which case the timeline would be very
important.
Certain considerations were not included in this illustrative example, as they do not
appear to be within the traditional scope of CPGS analysis: network attacks and other
matters related to cyber war; and other non-kinetic attack mechanisms. In addition, the
mathematical model is intended to illustrate the MPSDM approach using a real-world
application, not to give a definitive answer to a strategic policy question. The author’s
judgment was used to simulate expert judgment to: Select initial options from previous
research that were “generally” the most cost-effective (where effectiveness is a matter of
perspective); temporarily drop three options with the least cost but relative inferior
performance and define an aggregation method for one variable (scenario effectiveness)
that balanced the desire for clarity against other plausible aggregation algorithms.
MPSDM step #1: Characterize the problem
Recall from Figure 3.1 that the MPSDM methodology can be represented as a
three-step process: Characterize the problem; simplify the problem; and derive the
strategy. For the first step, the recommended framework includes evaluating a number of
feasible, action-based options against a set of return, risk, and cost criteria in a
multiresolution model. The evaluation explicitly considers perspectives simultaneously
with more objective factors.
78

Prompt Global Strike scenarios
Although the measure “return” could be any of several types of measures,
performance in a number of scenarios was chosen as the high-level return measure for
this demonstration because scenarios bring concreteness and clarity to the capabilities
being evaluated. The term “scenario” here is meant to refer to a specification of a
potential mission and the conditions of that mission.
Two studies define sets of scenarios evaluated for CPGS acquisition research:
Davis, Shaver, and Beck (2008); and NRC (2008) report. Although they are quite similar,
the scenarios chosen for this demonstration of MPSDM were Davis Shaver and Beck’s
(2008) spanning set of scenarios. This choice was driven by two considerations. The first
was that the NRC committee included a scenario in which a CPGS strike would serve as
the leading edge of a larger global strike. Since the criteria for that scenario would consist
of effectiveness against a set of goals that is broader than CPGS as defined in the
literature, it was not included in this illustrative problem. The second consideration was
that Davis, Shaver, Beck defined three sets of scenario classes, against which relatively
benign and more challenging conditions could be explored. This ability to vary the
assumptions within a scenario class was deemed useful to gaining insights about the
effect of these assumptions.
Davis, Shaver, and Beck (2008) describe a procedure for defining a set of scenarios
and related parameter values that span the critical dimensions of the problem at hand. In
what could be called preliminary exploratory analysis, or exploratory thinking, they
evaluated several dimensions considered in developing this set of scenarios. These
dimensions included: target type (in increasing order of difficulty they are: point target;
hard point target; large, deep, underground; large, deep, underground, ambiguous); the
number of targets; whether there was a time sensitivity for the strike; whether the targets
were mobile; level of enemy air defense (low, medium, high); and strategic issues (bases
and permissions; collateral damage; perceptions; escalation risk; and overall
“plausibility”).
After considering the various dimensions listed above, Davis, Shaver, and Beck (and
the NRC, 2008) concluded that three classes of scenarios would be represented by
79

attacks on: 1) mobile missiles, 2) terrorist leaders in an urban meeting; and 3) weapons of
mass destruction (WMD) facilities. These test cases stress sensors and detection
systems, timeliness, and ability to attack hard targets, respectively.
The first scenario class is an attack on enemy mobile targets, such as a
transshipment of one or more mobile intercontinental ballistic missiles (ICBMs) by truck or
by ship. This scenario assumes that there may be more than one target, that the targets
may be weapons of mass destruction, perhaps nuclear, and that the targets are
stationary at the time of the strike.
The definition of a successful outcome for this scenario provides an example of a
perspective affecting the assessment. In addition to evaluating the objective effectiveness
of a weapon system option, the decision makers must evaluate the following subjective
questions:
• What if all but one of the targets is destroyed, but the remaining weapon is used
in retaliation for the strike?
• How likely is the site to be protected by air defenses?
• What if part of the force could be attacked successfully but the strike had little
effect on other parts?

This first scenario of this class stresses the ability to find and strike the target
accurately since the targets are to be found in a large land area and there may be ground
clutter. The effectiveness of that response is likely to be related to the effectiveness of the
original strike.
The second class of scenario is a strike on fleeting targets, which are only
vulnerable for brief periods. A representative example would be a meeting of high-ranking
terrorist leaders. The U.S. would know in advance that the meeting is planned to take
place in a particular city, but may not know until close to the meeting time the exact time
or location of the meeting. This intelligence may come from electronic intercepts or from
operatives on the ground.
80

For this second class of scenarios, we have two different types of challenges, both
of which are a matter of perspective:
• Since the setting is urban, what is considered “acceptable” collateral damage
risk?
• How firm are the requirements for one-hour response time?
This second scenario class has a historical basis. Various strikes have been aimed
at killing al-Qaeda leaders during brief times of vulnerability, including a 1998 strike on an
Al Qaeda training camp reportedly narrowly missing Osama bin Laden. The firmness of
the requirements for a one-hour response time is not only a matter of decision makers’
expectations, but also adversaries’ perspectives on U.S. capabilities at the time.
The third scenario class is an attack on facilities for weapons of mass destruction
(WMD) such as a nuclear-weapon facility or one involving biological or chemical
weapons. A strike may need the assistance of on-the-ground intelligence agents or
Special Operations Forces (SOF). Here the following questions must be addressed:
• What type of air defenses might be encountered?
• Will the facility be above ground and well located, or below ground and not
precisely known?
• Will U.S. resources be deployed near the facility?
This third class of scenarios stresses the ability to penetrate air defenses and
locate the target accurately, since its position may not be known precisely. It also risks
the leak of toxic materials and/or damage to international perceptions.

81

For each of these classes of scenarios, Davis, Shaver and Beck identified a
nominal, along with a more challenging (or “hard”) scenario. For instance, for the first
class, an attack on mobile missile weapon systems, the more challenging case
assumed a reactive adversary with technical and tactical countermeasures. For the
second class, an attack on terrorist leaders in urban setting, the more challenging case
assumed that the terrorist leaders would be vulnerable for a shorter time than the less
challenging case. For the third class, an attack on a WMD facility, the baseline case
assumes that intelligence information would be sufficient for a successful attack
involving a hypothetical joint operation. This type of attack would have more precision
and therefore might be able to avoid collateral damage caused by unintended release of
materials. The more challenging WMD-facilities case assumes intelligence would be
inadequate or that a number of facilities were invulnerable to a modest attack of any
sort. The table below summarizes these scenarios.
Scenario Name
S1n
S1h
S2n
S2h
S3n
S3h

Description
Mobile missiles
Mobile missiles, reactive threat
Terrorist site
Terrorist site, fleeting target
Weapons of mass destruction facilities
Weapons of mass destruction facilities, hard case

Table 4.1 – Summary of Scenarios Used for
Illustrative Example
The idea of choosing a spanning set of scenarios is that they cover a broad range of
factors that are critical to the outcomes of interest. These factors can sometimes be
analyzed and identified in advance of the computational experiment, and sometimes not.
The problem may have so many uncertain variables that it is not obvious ahead of the EA
which factors affect relative option superiority. To address this issue, RDM proposes a
process of “scenario discovery” that employs exploratory analysis and to identify the
critical factors. The factors are then combined into a set (or a scenario) and decision
makers are asked to rate the importance of the scenario. MPSDM proposes starting with
82

an initial set of scenarios (or criteria), including perspective parameters in the EA along
with uncertainties, and the use of discussion aids to elicit additional criteria that decision
makers may not have identified before the EA. The additional criteria can be iterated
along with the options themselves as more information is revealed.
The relative advantages of each approach depend, in part, on the ability to define, a
priori, a broad set of factors and criteria that may be important to the decision makers.
Sometimes decision makers might say “it depends” if asked before the analysis which
criterion was more important. Their relative values may depend on how one option
performs relative to another; if one option offers a “game changing” capability, then that
criterion may suddenly become very compelling. As the range of perspectives within the
decision-making group grows broader, criteria may be more difficult to anticipate, and the
iterative approach proposed by MPSDM may be very helpful.
An example of the usefulness of this iterative approach comes from the NRC (2008)
assessment of CPGS options. It was noted that some committee members differed as to
the value of the illustrative scenarios chosen. Some members thought that the mobile
missiles and terrorist site scenarios were more useful than a third scenario class,
representing immediate response or preemption of imminent attack. Others thought that
the deterrent value of achieving capability for the third scenario class would be most
useful and were less convinced about the usefulness of classes one and two. This
difference in values can be addressed analytically by treating relative weights of the
different scenarios as perspective variables, running a range of numerical values in the
computational experiment, and finding how these relative preferences “matter” in the
choice of options.
Having established the mission and the criteria for evaluating outcomes for each
option, we next turn to choosing an initial set of options.
Conventional Prompt Global Strike options
For the CPGS illustrative example, several options are discussed in the most recent
unclassified literature. Woolf (2008) focused on long-range ballistic missiles and the NRC
committee (2008) evaluated a broader set of seven options, including hypersonic cruise
83

missiles and a ballistic missile option that the committee created. Their so-called
Conventional Trident Modification-2 would be a modification of the Conventional Trident
Modification, a system proposed by the U.S. Navy to replace the nuclear warhead on its
submarine-launched Trident missile with a conventional warhead.
Davis, Shaver, and Beck (2008) describe a method of ensuring that a broad set of
options is considered initially, and then methodically evaluated. They started by
identifying the building blocks that might help to achieve CPGS capability, such as
penetration aids to overcome enemy air defenses, space-based radar to enhance
detection of mobile targets, a variety of vehicles to carry weapons including a Special
Operations Forces (SOF) vehicle and a number of weapons types. Next, they performed
a preliminary cost/benefit analysis of every combination of building blocks (sets of socalled building block composite options), focusing on those options that were “closest” to
the efficient frontier (plus the baseline option which used current capability). Their
analysis showed that the proximity to the efficient frontier depended on the relative
emphasis placed on the different scenarios, and thus even if an option performed well for
only one set of scenarios, it was retained.
Next, they computed effectiveness of each of these thirteen options against their six
scenarios. For this illustration of the MPSDM approach, the six most effective of Davis,
Shaver, and Beck’s options were chosen29. Several considerations went into this choice:
First, it offered a broader capability range than Woolf’s (2008) focus on long-range
ballistic missiles. Secondly, both Woolf and the NRC included options such as the
hypersonic cruise missile which the NRC found to be a higher risk and longer-term
solution than other options. Thus, the choice reflected a broader set of feasible options
than the NRC or Woolf research, and appeared to better demonstrate the MPSDM
approach than other sets.
As will be seen later, the MPSDM iteration methodology in the present work led to
creating essentially the same option that the NRC devised in its study. This convergence

29 More precisely, nine of the Davis, Shaver, and Beck options were chosen, because three of their options consisted of

building blocks identical to other options, but forward based. As will be shown later, forward basing was treated in this
research as an uncertain parameter, to be varied simultaneously with other variables in the computational experiment.

84

demonstrates two benefits of the MPSDM approach: First, that the initial set of options
doesn’t necessarily eliminate possibilities. Using insights about the factors that drive one
option to be superior to another, plus the time frame/controllability heuristic, new options
can be created using the MPSDM methodology that improve return, risk, and/or cost
performance. The second benefit this demonstrates is that the MPSDM methodology
leads to the same novel idea that a high-level task force of experts created.
The first option, and in fact a recommended generic Option #1 is the baseline case;
i.e. no change to status quo. This option includes existing B-2B bombers, Air Force and
Navy tactical aircraft, advanced conventional cruise missiles, Tomahawk missiles, or
gravity bombs, (or a combination of both), Special Operations Forces, precision weapons,
satellite communications, national intelligence systems, regional command, control,
communications, computer, intelligence, surveillance and reconnaissance systems such
as J-STARS, etc. These systems have the range and payload necessary to strike targets
globally. These capabilities, including satellite communications, exist today so the
development risk is minimal and operations concepts have been developed and tested.
These baseline systems may be vulnerable to enemy air defenses, which could limit
access to certain target areas and put aircraft and crew at risk. In addition, they could
take hours or days to reach remote targets, depending on whether the resources were
forward based. Other concerns raised by this long flight time are the issue of crew fatigue
and the need for tanker support to refuel the strike aircraft during the missions. Manned
systems such as included in Option 1 also carry risk to crew during ingress and egress,
as do options such as this one that use Special Operations Forces (SOF). In addition to
locating targets, SOF forces are currently used for small leading-edge attacks such as
defeating or disrupting the enemy’s air defense; command, control, and communications;
or most-feared weapons.
Each of the additional options adds capability to Option 1. Option 2 includes
penetration aids to increase the ability of an Air Force or Navy strike vehicle to penetrate
the enemy’s advanced surface-to-air missiles.
Option 3 adds a Navy submarine-launched ballistic missile (SLBM), the first of which
would be the conventional Trident Modification (CTM) to Option 2. The CTM is the
85

proposed near-term solution to CPGS capability by the U.S. Strategic Command. The
CTM program would convert two submarine-launched Trident II (D5) ballistic missiles on
each of the U.S. Navy’s twelve nuclear-powered ballistic missile submarines from
nuclear-armed to conventionally-armed warheads. Each missile would nominally carry
four MK4 reentry vehicles, modified by the addition of a “backpack” consisting of an
aerodynamic control system, a Global Positioning System (GPS) receiver, and an inertial
navigation package to improve weapon accuracy.30 Each re-entry vehicle would contain a
kinetic energy projectile (KEP) warhead, consisting of multiple tungsten rods deployed by
an explosive charge. This altitude-determined explosion allows the warhead to attack an
area of soft targets if their position is known with accuracy on the order of meters (NRC
2008). Alternatively, the warhead can be set to not explode, giving the capability to
penetrate somewhat harder targets, again if their position is known. Using this mode, the
CTM would have better (but still limited) ability to penetrate buried or hardened structures
such as command-and-control bunkers and hardened aircraft or missile shelters.
Because the submarines are mobile and the missiles are long range, the system can
reach targets around the world, provided the submarines are positioned in the area.
Development risk, although not as low as the baseline option, is not severe. The main
development items include the backpack. Although GPS receivers can be jammed, the
combination of an inertial navigation system and GPS updates, when available, to
account for location drift, is considered sufficient for navigational accuracy within a few
meters (NRC 2008). The delivery vehicle and command and control systems have been
developed for nuclear use amidst the need for prompt decision making and launch during
a crisis.
The fact that conventional warheads would be carried along with nuclear warheads
on the same submarine gives rise to two types of risks. First, a third-party potential
adversary, for example Russia or China, which was not the target of the strike, might
misinterpret the launch of a non-nuclear warhead as a nuclear attack. This is of particular
concern if the third party was a nuclear-armed nation with delivery systems that could
30 The existing nuclear Trident warheads are unguided after they leave the third stage, since not as much accuracy is

required for nuclear weapons as it is for conventional weapons.

86

strike the U.S. In fact Congress rejected most of the Department of Defense’s 2007
Conventional Trident Modification (CTM) budget request because of concerns about
“nuclear ambiguity” along with the belief that other systems would better address the
political, military, and technical issues surrounding CTM. A national-academy report
described that Congressional decision as a mistake and disputed key elements of the
underlying reasoning in considerable detail (NRC 2008).
Secondly, if conventional weapons are launched from the same submarine as
missiles with nuclear warheads, questions may arise as to the command and control of
those missiles. As will be discussed later, various mitigations have been proposed.
Option 4 adds an enhanced insertion vehicle for Special Operations Forces to
Option 3 to enhance deep, covert penetration into defended areas. Currently, a variety of
SOF vehicles are in different stages of research and development (R&D) within the
aerospace industry, involving different levels of technological risk. What is envisioned for
this option are capabilities for stealthy SOF penetration which is achieved by a
combination of factors, including the launch platform, low detectability of the insertion
vehicles, and the tactics of choosing flight paths. Examples of SOF vehicles include
armed unmanned Predators or stealthy helicopters.
Option 5 starts with Option 3 and adds two types of sensors onboard penetrating
aircraft. The first is an automated target recognition (ATR) system to enhance detection
and identification of targets by distinguishing them from ground clutter. The second type
of sensor included in Option 5 is a space-based synthetic-aperture radar (SAR) which
would enhance detection and tracking of semi-mobile targets. Semi-mobile missiles
would leave casernes (military barracks or garrisons) and then sit in unknown positions.
This option of course assumes that the aircraft could penetrate to a level where the
sensors would be useful.
Option 6 starts with the sensors described in Option 5, adds the SOF vehicle from
Option 4, and includes an advanced bomber to increase penetration of even the most
advanced surface-to-air missile and to avoid discovery and aid egress. This bomber could
either be a very stealthy, high-capacity, long-range bomber or a medium-range aircraft.
A summary of Options chosen for this demonstration is shown in the table below.
87

Option
1

2
3
4
5
6

Name

Description

Base Case

uses existing systems: tactical & long-range stealth
aircraft, cruise missiles, special operations forces
(SOF) and cruise missiles command, control,
communications,
computers,
intelligence,
surveillance, and reconnaissance, combat search
and rescue, and suppression of enemy air defenses.
Penaids
adds penetration aids to Option 1 to overcome
adversary’s air defenses
SLBM + Penaids
adds submarine-launched ballistic missile (SLBM) to
Option 2. The SLBM would be a modification of the
conventional trident missile:
SLBM+ Penaids + adds a special operations force vehicle to option 3.
SOF Vehicle
This vehicle is stealthy for deep, covert penetration
into defended areas
SLBM + Penaids + starts with option 3 and adds sensors to detect,
Sensors
identify, and track targets among ground clutter
Adv.
Bomber
+ Uses Option 1 and adds advanced bomber +
Sensors + SOF Veh sensors + SOF vehicle. The advanced bomber
increases penetration of advanced air defenses and
avoids detection
Table 4.2 – Summary of Options Used for
Illustrative Example
Other options from Davis, Shaver and Beck (2008) were not included in this

example, for one of two reasons. First, it was judged that they did not score as well in
performance against the six scenarios described above. Second, because they simply
added forward basing to another option. For this research, the consideration of whether
the aircraft is forward based (or near the strike location) was included in this analysis, but
treated as a variable, as described below. This approach helped to reduce the
dimensionality of the problem.
The decision making process must address wide variations in expectations of the
capabilities of both friendly and adversarial forces. Some of the critical option-related
questions that are a matter of perspective include:
• Will the option be able to strike within the time that the target is vulnerable,
especially in the terrorist site scenarios?
88

• Will the option be sufficient to overcome enemy air defenses at the time of the
strike?
• Is the payload capability sufficient, especially for the WMD scenarios where the
target may be hardened or deeply buried?
• What is the level of collateral damage that will likely occur with the intended
warhead, and how acceptable is that level?
• What is the likelihood that the systems that are being considered for development
now will be ready when needed, i.e. what is the development risk?
• What is the likelihood that the program will remain funded through
operationalization?
The analysis tools
There are two conceptually distinct types of tools used in the mathematical analysis
for MPSDM. The first is a model to run the computational experiment. The second type
of tool is one to perform statistical data mining in order to identify the factors most
affecting the outcomes of interest.
A few tools exist to create multiresolution models of the type described above. One
of the earliest such tools was Hillestad and Davis’ (1998) DynaRank Decision Support
System, and PAT, the Portfolio Analysis Tool (Dreyer and Davis 2005, Davis and Dreyer
2009). In PAT, there are separate worksheets for each level in the multiresolution model.
Macros perform the aggregation and scoring process to fold variables to successively
higher levels in the model.
For the PGS illustration, careful consideration was given to the choice of tools for
running the computational experiment. One of the goals was to create a model which
could easily be shared with other analysts. Sometimes a specialized tool is developed
that uses an operating system that is difficult to learn, or contains embedded macros.
These naturally make it difficult for others to contribute to the model, and it is not
uncommon to find that only one person in the organization really understands how to
89

make changes to the model, despite the existence of carefully written users’ manuals.
Perhaps even more relevant to strategic decision making, models that are mysterious to
the decision makers or their staff are easily discounted, and results met with suspicion. As
experienced analysts would agree, it may be essential to convince staff to the decision
makers along the way. When budgets and timeframes are tight, this can be a critical road
block.
An additional challenge occurs when two or more models of different types are used
in sequence. For instance, in exploratory analysis, one model is sometimes created to do
a single projection on a combination of input assumptions. Then another tool generates
the suite of plausible outcomes, and then a third tool performs the exploratory analysis on
that suite of plausible outcomes. Every interface between these tools creates an
opportunity for technical difficulties.
For the PGS illustration, the PAT model was chosen as a starting point. Davis and
Dreyer (2009) incorporated several features that allowed PAT to be extended for the
purposes of running a computational experiment. The first one was the clear structure of
the Microsoft excel-based tool that matched the structure of the multiresolution model; a
separate worksheet existed for every level of the model, with rules-based aggregation
algorithms rolling up results from one level to the next. To set up the computational
experiment, the first extension to PAT was replacing the scoring and aggregating macros
with embedded equations. This was necessitated by the second extension to PAT, using
the data table function to creating a suite of plausible outcomes from tables of input
parameters. These extensions continue the theme throughout this dissertation of useful
simplifications and building on earlier work.31 A number of considerations went into the
selection of Microsoft Excel-based PAT for this illustration:

31

The author is grateful that such extensibility was designed into PAT’s capabilities (Davis and Dreyer 2009)

90

• Microsoft Excel is commercially available, known to a large number of analysts
(and high-level decision makers), and has substantial product support and online
documentation.32
• Excel allows almost instantaneous drill downs into underlying variables that may
affect aggregate measures. If a decision maker wants to understand why one
option in one scenario resulted in a surprisingly low or high effectiveness, it is a
simple matter to go to a different worksheet in the file.
• Excel has a capability for data tables, which were extremely simple and quick for
running the computational experiment.33 In essence, a data table works as follows:
an indicator variable is defined which points to a row in a spreadsheet containing a
set of independent variables. The data table then computes the outcomes of interest
as a function of the set of independent variables automatically. Outcomes can be
plotted, and for subsequent experiments, the plots are automatically updated.
• Excel now has the dimensional capability to handle very complex models. Excel’s
row and column limits have been extended for Excel 2007. The total number of rows
allowed has been increased from 64,000 to 1,000,000. The total number of columns
available has been increased from 256 to 16,000. 34 Although the number of cases
run in the illustrative model was relatively small, it is not uncommon to run tens of
thousands of cases. In the event that a model exceeds these capabilities, additional
worksheets can be created. The multiresolution modeling approach makes this
relatively simple; different levels of the model can be represented in different
worksheets.
• PAT has been documented and tested for CPGS and other applications, and
support was available at RAND.
32 Analytica is quite capable and is also used by a number of analysts, although decision makers and their staff may not

be as familiar with it as they are with Microsoft Excel.
33

For a very useful tutorial on Microsoft Excel data tables, refer to
http://www.homeandlearn.co.uk/excel2007/excel2007s7p1.html.

34 In addition to the row and column capability, Microsoft Excel accommodates many worksheets which can be used to

model hierarchical “levels” in a multiresolution model.

91

The model used to run the computational experiment will be described in more detail
in the next section.
The second type of tool, used to perform statistical data mining on the results of the
computational experiment, incorporates the PRIM algorithm. Chapter 3 describes the
reasons for selecting the PRIM algorithm for MPSDM. Currently, there are two versions of
PRIM that are free for download, the original algorithm (Friedman and Fisher 1999)
version 2.035 and another version that has been modified by RAND (Bryant, 2009).36 For
reasons described in Chapter 3, the modified version was chosen for MPSDM.
PRIM runs in an operating system called R, which includes a language and a runtime environment (Ihaka and Gentleman 1996). R is available as a free download and
fairly straightforward to learn.37 R includes the capabilities to write scripts (or sets of
commands), call the PRIM algorithm, and produce statistical and graphical results.
The CPGS model
The multiresolution model used to run the computational experiment for the CPGS
example is shown below.

35

Rev 2.0 is available at http://wareseeker.com/download/prim-algorithm-rev-2.0.rar/3508740.

36

Version 2.22 was used in this research and is available at http://cran.r-project.org/web/packages/sdtoolkit/index.html.

37

R is available here: http://cran.r-project.org/

92

Figure 4.1 - Multiresolution Model for Prompt Global
Strike
For each of the six options considered, the same model structure is used, although
parameters vary from option to option. Starting top of the figure above, recall MPSDM
defines generic dimensions of return, risk, and cost. Return for each option here is
operationalized as the overall effectiveness, a result obtained by taking the weighted sum
of effectiveness in each scenario (Mobile Missiles, Mobile Missiles Reactive Threat, etc.).
The left side of the figure above indicates the level of each variable in the model. The
summary level includes Overall Effectiveness, Effectiveness in each scenario, an Overall
Risk measure, and Cost relative to the baseline. This summary level can be represented
to decision makers as a scorecard where each column represents scores for each
effectiveness dimension or overall risk, and each row is the score for each option.
Continuing down the left side of the diagram, we see that the summary level
effectiveness scores for each scenario are comprised of weighted-sum aggregations of

93

level two parameters Timeliness, Execution, and Collateral Damage.38 Timeliness is a
score that indicates how quickly the strike could be executed from its initiation. Execution
measures whether the attack would accomplish the larger military purpose. Collateral
Damage measures the number of unintended casualties associated with the strike,
particularly important for the WMD scenarios where there is a substantial chance of
releasing toxic chemicals, biological materials, or even radioactive material. The reason
for the weighted sum aggregation rule is that different scenarios place different emphases
on these parameters. Recall that Scenarios three and four, the Terrorist Site scenarios,
call for more timeliness since the terrorist meeting may not last very long. Scenarios five
and six, the Weapons of Mass Destruction strikes, have less stringent requirements for
timeliness as presumably the WMD site is not fleeting.
Moving to the right, we see that the summary-level score for Overall Risk is simply (1min(Mission C Risk x; x=1-3)); the sign reversal works to transform summary-level risk
into the same color-coded scheme as effectiveness, where a low score of risk
corresponds to an unacceptable result.
Continuing down and to the left in the diagram above, we see that the Level 2
variable Execution is an aggregate measure of two Level 3 parameters, Reach Target
and Find and Kill. Reach Target represents the likelihood of the target being within range
of the weapon and the weapon system’s ability to penetrate air defenses, if any. Find and
Kill measures the weapon system’s ability to destroy the target, particularly challenging
for Scenarios 5 and 6, the two WMD scenarios. Find Target, a lower-level parameter, is
especially difficult for the mobile missiles scenario. Since the PGS weapon must perform
both of the critical tasks Reach Target and Find and Kill, the aggregation methodology
chosen was to multiply the scores for each, representing the logical “and” combining rule
for probabilities.
Moving to the right, the figure shows that the variable Mission C Risk x (x=1-3) is an
aggregate of two risks--the nominal and the hard case for each of three scenario

38

Capital letters are used to denote variable names.

94

classes.39 This variable Net C Risk is itself an aggregation of four types of lower-level
risks (although Net C Risk and the four lower-level risks are all implemented in Level 3 of
the model). The first of these lower-level risks is Political-Strategic Risk During
Development. This dimension includes the chances that the program will remain funded
by Congress. It also includes the likelihood that the U.S. will have the cooperation of
allies if an option includes forward basing or staging for SOF operations. Continuing to
the right, Technical and Programmatic Risk measures the likelihood of technical failure
to achieve the assumed capability. Some options have relatively low technical risk, as
the technology and operating procedures are relatively mature; in other cases, it may
not be clear that technical challenges don’t defy the laws of physics and engineering.
For the options involving sensors, achieving adequate automated target recognition
involves considerable technical and programmatic risk, especially in areas with complex
terrain or ground clutter. For options further out in the future, such as advanced bomber,
there is the question of whether the industrial base will be able to accomplish what is
needed.
Employment Risk refers to the availability of the capability at the time it is needed, i.e.
whether the resources might be tied up elsewhere such as those required to penetrate air
defenses. Employment Risk also includes the perceived risk of nuclear misinterpretation
(higher in the SLBM options40) and the possibility that adversary’s surface-to-air missiles
used for air space defense have capabilities more advanced than expected (e.g. more
resistant to electronic countermeasures). It also includes the risk of the adversary getting
warnings of U.S. operations by infiltration or penetrating U.S. military networks. Other
Risks include the possibility that the consequences of the attack will be other than
planned—a strike intended to deter or coerce might be misinterpreted as the leading
edge of a more comprehensive attack, or allies reacting badly. This risk dimension
includes the possibility that the strike will firm up an adversary’s resolve rather than
influence him to act in ways the U.S. would prefer.

39

The nomenclature “C Risk” indicates that risk is measured on an inverse scale: a higher number is good.

40

As discussed in the NRC study, the actual risk appears to be quite low, assuming that reasonable actions are taken.

95

Compared with the effectiveness dimensions, many of the risk measures are
matters of perspective. In contrast with a testable parameter such as the likelihood
reaching the target, risk measures are generally more subjective. In the case of
ambiguity, Congress may not fund the Conventional Trident Missile modification out of
concerns that it might be misinterpreted as a nuclear strike by allies, or may prompt a
nuclear response by countries such as China or Russia. Here we have several layers of
perspectives: the analyst and decision-makers’ view, along with Congress’ view of
China or Russia’s perspective.
The third generic dimension, cost, is based on simple estimates of cost relative to the
baseline option in the summary scorecard but not in the model. If cost estimates included
a higher level of uncertainty, they could be modeled as uncertain variables (using any
number or type of lower-level parameters), but the options chosen are viewed to be
feasibly affordable, and the estimates treated as certain variables.
As the figure shows, the top level measure Overall Effectiveness is an aggregate
measure of lower level scores. This aggregation introduces a perspective parameter
important when multiresolution modeling is used: the aggregation rule itself. One could
simply choose to take an average of the effectiveness scores for each scenario, but that
would imply something about the decision makers’ perspective; that they valued each of
the scenarios the same. Alternatively, one could take a weighted sum of the effectiveness
in each scenario, but that would imply that the relative value of effectiveness for each
scenario could be both known a priori, or could be agreed-upon by the decision makers.
The aggregation beliefs are another area where the risk dimension appears to be
more a matter of perspective than the return dimension. The return dimension includes
parameters for which a logical “and” methodology is obvious, but it is not as clear how
to combine disparate types of risks. For instance aggregating Net C Risk into Mission C
Risk x consists of taking the nominal scenario and the more challenging scenario (or
“hard” case) from each of the three scenario classes. Again, the choice of aggregation
method—averaging--is a matter of belief about how risk should be treated. As we will
see, the MPSDM approach is to assign a logical variable to plausible aggregation
96

methods and treat this logical variable as an uncertain one, to be varied in the
computational experiment.
The return dimension is not without its perspective parameters, however. Note from
the figure that Overall Effectiveness is represented as a weighted sum of the
effectiveness scores from the different scenarios. The approach taken in MPSDM is to
treat the relative values of these scenarios as sets of uncertain parameters. This allows
the analyst to adjust the weights and explore how the decision makers’ relative values
affect option superiority.
There are two concepts important in multiresolution modeling. The first is the choice
of aggregation rules. The second is the choice of scoring methodology from the various
sub measures up to a measure score. The technique used by Davis and Dreyer (2009) is
used in MPSDM to normalize all top-level variables to a scale of zero to one. This
technique also includes the possibility of nonlinear threshold scoring, as described by the
figure below.

Figure 4.2 - Scoring Methodology to Compute
Nonlinear Thresholds
The reason for nonlinear scoring is that sometimes there exists a threshold of “good
enough” in capability; adding more of an input does not necessarily add more
effectiveness. An obvious example is that above a certain level of Kill Target, Execution
Score does not improve.
97

Referring to the figure above, the composite (or higher-level) score in this method is
computed in the math model by the following equation
if
if
If
Where
the score for the measure i, the option j, sub measure k
the values of the sub measure for measure I, investment option j, sub measure k
the threshold values for option j, sub measure k
the goal values for option j, sub measure k
the threshold score for option j, sub measure k
the goal score for option j, sub measure k
Thus, each sub measure is scored according to whether it is below the threshold,
above the goal, or in between. This formulation also accounts for the case where the
score decreases with increasing values, with the equations modified accordingly.
As with aggregation parameters, nonlinear threshold parameters are treated as
perspective parameters in MPSDM, modeled as uncertain variables, and allowed to vary
in the computational experiment.
Note that this model is meant to illustrate the principles and methodology of MPSM.
As such, is uses simplified representations of factors contributing to CPGS capability
procurement strategy.
MPSDM step #2: Simplify the problem
As Figure 3.1 illustrated, the second step in the MPSDM methodology is to simplify
the problem using EA to find the forces driving relative option superiority. The problem
can be further simplified by eliminating any dominated options and criteria that don’t
differentiate the options.
Exploratory analysis
Recall the steps of exploratory analysis defined earlier in Figure 3.2, repeated below.
98

Figure 4.3 - Steps in Exploratory Analysis
(Figure Adapted From Bankes 1993)
Each of these steps for the CPGS example will be discussed in the following
sections.
Exploratory analysis step 1: Design the computational experiment
EA starts with designing a “computational experiment.” As in a traditional
experiment, input assumptions are varied and resulting outcomes are evaluated. For the
CPGS illustrative case, the input parameters represent a set of uncertain assumptions,
and the resulting measures—return and risk measures—are outcomes associated with
each combination of inputs. The concept in exploratory analysis is that if the assumptions
vary within their plausible ranges, then the resulting dependent variables represent a suite
of plausible outcomes.
The choice of inputs (or independent variables) for the computational experiment
was based on multiple criteria:
• Varying multiple dimensions of parameter space. Traditional sensitivity
analysis varies one parameter at a time, around some baseline set of
assumptions. Exploratory analysis, on the other hand, varies multiple
independent variables simultaneously.
• Exploring effects of nonlinearity
• Including representative values, beliefs, and expectations from Table 3.1
• Demonstrating a methodology that explores parameter space systematically
• Demonstrating the management of the curse of dimensionality where
practical
99

Thus, the computational experiment began by choosing independent variables: All
Level 2 parameters within the model, along with the aggregation parameters used to
compute Level 1 Overall Effectiveness from Level 2 Effectiveness for each scenario; and
the aggregation rule used in computing Level 2 Mission C Risk x from Level 3 Net C risk.
In the figure below, the arrows indicate which parameters were selected as independent
variables for the computational experiment.

Figure 4.4 - Model Used in CPGS Example with
Arrows Indicating Independent Variables Chosen
for the Computational Experiment
The table below shows this information, arranged by the type of assumption (value,
belief, or expectation) made for each parameter.

100

Table 4.3 - Independent Variables Chosen for PGS
Illustration
The first column of the table above gives a description of the uncertain assumption.
Davis, Shaver, and Beck (2008) treated the question of whether assets were forward
deployed or not as two separate options.41 The approach used here is to treat that
indicator variable as an uncertain parameter which affects timeliness. If assets are
deployed close to the position of the strike, the parameter Timeliness (defined as the flight
time from launch to the target in hours) is higher.42 Another way timeliness is addressed
in this example is by the weight given to that measure in the aggregation to Effectiveness
for each scenario; some scenarios place more emphasis on the need for timeliness. For

41 There are more than one ways to look at the forward-basing question. The first is that it is a separate option, with

associated costs. The other way to look at forward basing is as a more random occurrence: at the time of the strike,
the U.S. may or may not have forces deployed near the strike. The latter interpretation was chosen for the initial
analysis. If forward basing had proven to be a critical factor, the analysis could have been iterated to pull it out as a
separate option, take action to increase its probability, and evaluate it against other remaining options.
42

Note that the parameter Timeliness is another reversed measure: a higher number is bad.

101

instance, terrorists may be meeting only for a short time and the mobile missiles may be
vulnerable briefly.
Continuing to the right in the table, we note that the assumptions do not always
relate to all options and scenarios. In the case of forward deployment, this pertains to the
aircraft-based options and not to those employing SLBMs. The column labeled “ From
Baseline” indicates how much each parameter was varied in the computational
experiment relative to the baseline case. For the Forward Deployed assumption for
Options 1,2, and 6 which employ aircraft, the table below shows the variation of the
Timeliness model parameter (in hours to reach target) for each value of the logical
variable Forward Deployed and each scenario (S1n is Scenario 1 nominal case, S1h is
Scenario 1 hard case, etc.)

Table 4.4 - Value of Timeliness as a Function of
Logical Variable Forward Deployed and Scenario
(Only used for Options 1,2, and 6 which employ
aircraft)
As Table 4.3 shows, Execution, Collateral Damage, and Net Mission Risk are varied
by plus or minus x percent, with x being programmable in the computational experiment.
Two values of x were used: 20% and 40%. By comparing the results for these two
excursions, we can see the effects, if any, of nonlinearities such as nonlinear scoring
thresholds and aggregation rules.
Continuing down the rows in Table 4.3, the Risk Aggregation Rule from Level 3 to
Level 2 was varied between two beliefs of how aggregation should be modeled: As the
average of the nominal and hard case for each scenario; and taking the worst case. The
102

next assumption, the aggregation weights used in computing Overall Effectiveness
represents different values that the decision makers place on the scenarios. For these
weights, sets of parameters were chosen as indicated in the table below.

Table 4.5 - Sets of Aggregation Weight Focuses in
the Computational Experiment
Here, a set of values is called a “focus.” Here, focus represents a clustered set of
decision-makers’ values, as in “I value this scenario highly and that scenario less.” This is
what Davis Shaver and Beck (2008) called a type of perspective and can be thought of as
follows: for Focus 1, the decision maker might believe that the scenarios are equally valid
to use for choosing an option. A different decision maker might view the nominal case for
each scenario as more valid, since, for instance, the hard case may not be achievable in
the time frame being considered. This is represented as Focus 2. Another decision maker
may believe that achieving the capability to be effective in the hard case would be an
excellent deterrent and therefore should shape the strategy (Focus 3). Focus 3 would
also represent the values of a decision maker who believes that the harder case is either
more realistic or that the easier case is simply wishful thinking. Still another perspective is
that Scenario 1 is not credible, either because it represents too much of a challenge or
because the US would not use CPGS capability against mobile missiles and risk
retaliation. This is represented by Focus 4. Other focuses are possible, but not
represented in this illustrative example. For instance, a decision maker might believe that
the third scenario is not credible, in which case it would receive zero weight.

103

The last column of Table 4.3 which identifies whether each assumption reflects a
value, belief, or expectation, deserves a bit more explanation. As described earlier, many
values, beliefs, and expectations can be represented as parameters in a mathematical
model. For instance assumption 1, whether the assets are forward deployed or not,
represents a belief about the likelihood of sustaining this forward-basing capability, or
having forces available at the time. One could argue that this is also an expectation about
the future, but beliefs are viewed as more complex models about how the world works (or
in this case, will work) than expectations. Forward basing is in reality a complex function
of many factors such as cost, political support within the US and its allies, the location of
the strike, and so on.
Similarly, how well a strike is in reality executed is a very complex function of many
variables, some of which may be relatively simple matters of physics (navigation system
drift), but others not so simple. For instance, the amount of ground clutter or deceptive
tactics used by the adversary to hide mobile missiles is unknown, and can affect the
likelihood of finding the target in complex ways. As will be demonstrated later, the
approach taken in MPSDM is to represent higher-level parameters as a simple range of
variables, use exploratory analysis to see which ones affect relative option superiority,
and then drill down in more detail in the model on these parameters that matter. Thus, we
can start out with a simple parametric variation to represent a range of complex beliefs.
The design for this experiment was such that all combinations of cases were run.
The table below shows the number of levels evaluated for each independent variable.

104

Table 4.6 - Number of Levels Used for each
Independent Variable in the Computational
Experiment
From the table above, we see that in order to cover every combination of
parameters for every level, it was necessary to run 25 * 4 = 128 runs in the computational
experiment.
Although only 128 runs were required for this illustrative case, it is not uncommon in
exploratory analysis to construct tens of thousands of combinations of independent
variables. It may be necessary to construct a macro to populate the table of independent
variables as model dimensionality increases.
Next, we turn to a discussion of dependent variables. For multiresolution models, it
is not entirely obvious which variables are dependent. For instance, is a Level 2 variable a
dependent variable of an aggregation from Level 3 variables, or an independent variable
of an aggregation to Level 1 variables? The answer is that it depends on the stage of
exploratory analysis one is currently considering. For this first stage of EA, where the
independent variables are predominantly in Level 2, the Level 1 variables are defined as
the dependent variables for the computational experiment. Referring to Figure 4.1, these
are: Overall Effectiveness and Overall Risk, and Effectiveness for each scenario. Cost will
105

be included as options are compared. As will be described in more detail later, Relative
Option Superiority in returns or risk is the eventual figure of merit.
Exploratory analysis step 2: Run a suite of plausible outcomes
Recall from Figure 4.3 that the second step in EA is to generate a suite of plausible
outcomes for the range of independent variables chosen. For the step, the existing PAT
model for CPGS required modification. The reason for this is that PAT was designed so
that the user specifies some inputs (e.g. choice of aggregation and scoring functions) by
selecting from a menu rather than giving a parameter value as required for use with a
data table. In addition, to recompute level 2 and 3 worksheets, a “Recompute Level 2 (3)
Data Sheet” button must be selected. These menu and recomputing functions were
programmed to be executed with Macros. These macros were replaced by explicit
equations in Microsoft Excel, hard-wired in for the CPGS example.43 For instance,
parameters were set in the tables of independent variables to define the aggregation and
scoring methodology based on IF statements in Microsoft Excel. Duplicate worksheets
were created for Level 3, Level2, and Summary level variables which updated the
worksheets automatically and incorporated the hard-wired menu functions, and the
results checked against the PAT model.
The figure below shows a result of the summary-level calculations done for the
CPGS example.

43 An approach that was not attempted, but which may be useful, is to combine the Microsoft Excel data table function

programs in Visual Basic.

106

with batch

Option #
1) Base
Case

Mobile
Terrorist
WMD
Missiles
Site
Facilities
(2020) Terrorist
(2020)
(2020) Overall
Mobile
WMD
Missiles Reactive
Site Fleeting Facilities
Hard
Risk
(2020)
Threat
(2020)
Target
(2020)
Case (2020)

2) Penaids

0.02
0.02

0.02
0.02

0.61
0.77

0.49
0.57

0.11
0.49

0.18
0.46

0.00
0.50

3) SLBM +
Penaids

0.02

0.02

0.97

0.89

0.49

0.46

0.50

4) SLBM +
Penaids +
SOF
Vehicle

0.02

0.02

0.97

0.89

0.87

0.46

0.50

5) SLBM +
Penaids +
Sensors

0.22

0.02

0.97

0.89

0.49

0.46

0.50

6) Adv.
Bomber +
Sensors +
SOF
Vehicle

1.00

0.02

0.77

0.57

1.00

0.53

0.50

Figure 4.3 - Summary Scorecard

107

This compares with Davis, Shaver, and Beck’s (2008) Figure S.5, with two
exceptions: First, the color scheme is very slightly different. One of the features in Excel
for Office 2007 is the ability to automatically generate scorecard colors without the need
for a macro.44 This feature can aid in model transparency and standardization from
analyst to analyst of scorecard colors. The second difference between the scorecard
above and Davis, Shaver, and Beck’s (2008) Figure S.5 pertains to the scores for Options
1, 2, and 6 (the ones that use a bomber) for the Terrorist Site Fleeting Target scenario.
Specifically, the scorecard above gives a more positive score (yellow vs. red). This is
because of the way the variable Timeliness is aggregated with the variables Execution
and Collateral Damage.
Timeliness for this scenario is treated as a more challenging requirement than for
the other scenarios because of the time-stressing nature of the scenario: the terrorists are
assumed to only be meeting for a limited amount of time. The stricter Timeliness
requirement is operationalized in the model in two ways: first, by giving Timeliness more
weight in the aggregation; and second, by scoring it more severely than in the other
scenarios. The scoring algorithm is illustrated below.

Figure 4.5 - Timeliness Scoring Illustration

44 A macro is still needed if one wishes to change the scoring thresholds associated with each color, or to insert a letter

representing the color (e.g. R for red) for color-blind individuals or black and white copying.

108

For all the scenarios, the Timeliness Score varies between 0 and 1 as shown above,
but the Threshold and Goal Values (in hours) are considerably shorter for the Terrorist
Site Fleeting Target scenario as shown in the table below.
Scenario

Threshold Value

Goal Value

Mobile Missiles

16

72

Mobile Missiles Reactive Threat

16

72

Terrorist Site

6

18

Terrorist Site Fleeting Target

0.5

3

WMD Facilities

48

100

WMD Facilities Hard Case

48

100

Table 4.7 - Timeliness Scoring Values for Different
Scenarios
As can be seen from the table above, if the time to reach the target exceeds the goal
value of 3 hours for the Terrorist Site Fleeting Target scenario, the Timeliness score
drops to zero. Other scenarios have less stringent goal values, up to 100 hours because
the target is not fleeting.
In addition to the stricter Timeliness Weight and Scoring parameters for the Terrorist
Site Fleeting Target scenario, Davis, Shaver, and Beck included a third operationalization
of the more stringent timeliness requirement. They assumed separate requirements for
timeliness, execution, and minimizing collateral damage (a nonlinear aggregation).
Further, they were fairly conservative in estimating the execution time for manned aircraft,
even if forward deployed, unless assumed to be on high alert. As a result, manned
aircraft failed for the fleeting-target scenario.
Although the model used to illustrate MPSDM included the first two treatments of the
stricter Timeliness requirement for the Terrorist Site Fleeting Target scenario (a higher
weight for Timeliness and lower goal and threshold values in the scoring algorithm), the
third treatment (the nonlinear summary-level aggregation) was not included in the model
for two reasons. The first is that the NRC report found that the one hour goal “was not
109

considered as a strict criterion, and some options that would not quite meet the DOD goal
were considered in the analysis.” In addition, Woolf (2008) included options that would not
meet the one-hour goal and posed operational modes to mitigate the longer travel time of
manned aircraft (p. 20):
How likely is it that the United States would face a sudden, unanticipated
conflict, with no time to build up its forces in the region and with the
requirement to strike some targets within hours of the start of the conflict?
Would a delay of several hours or even days undermine the value of
attacking these targets at the start of a conflict? Could other weapons systems
provide the United States with the ability to “loiter” near the theater of
operations, allowing a prompt attack during the conflict if hidden or concealed
targets are revealed? A comparison of the likelihood of those scenarios that
may provide the most stressing environments with the likelihood of less
stressful scenarios may lead to the conclusion that other weapons systems
can respond to many of these requirements in most circumstances.
Although the NRC study (and Davis-Shaver-Beck) were understandably not
sanguine about the ability to achieve short timelines without unusually good strategic
warning, it seemed reasonable in this dissertation to soften somewhat the “requirements”
for promptness—if only to make comparing options a bit more challenging.
The second reason is that the model used in this research, although retaining many
of the salient features of the more detailed model used in Davis, Shaver, and Beck, was
simplified in order to more clearly illustrate the MPSM principles and methodology.
Once the independent and dependent variables have been defined, the number and
combination of independent variables determined, and nominal analytical results checked
out, it was a relatively simple programming task to compute the suite of plausible
outcomes using Microsoft Excel’s Data Table function.
The suite of plausible inputs and outcomes is a matrix where each row represents a
“run” or a different combination of inputs. Each column represents either the input
assumption or the outcome score. Since there were 128 possible combinations of inputs
110

chosen in the experimental design, there are 128 rows in the matrix. There were six input
assumption as described by Table 4.3, and 48 outcomes: one measure of effectiveness
for each of six scenarios along with overall risk for each option (7x6=42 measures); plus
Overall Effectiveness for each option (6 measures). The addition of a run number
identifier brings the total number of columns to 55 (6 + 42+6+1=55). The table below
shows the format of the e128 X 55 matrix of independent and dependent variables.

Table 4.8 - Excerpt from the Results of the
Computational Experiment
The first column indicates the Run number, followed by a set of independent
variables (Forward Deployed up through Overall Effectiveness Aggregation Weights
(Focus)). The dependent variables (Effectiveness for each Option for each Scenario; Risk
for each Option; and Overall Effectiveness for each Option) were computed for each set
of independent variables.
Exploratory analysis step 3: Explore the results graphically
Now that our matrix of independent variables and dependent variables has been
generated, the work of making sense of it all begins. One type of graphic that appears to
be particularly useful is a box-and-whisker plot (or box plot) as shown in the figure below.

111

Figure 4.6 - Overall Effectiveness for the CPGS
Illustration. + 20% Parameter Variation
This plot shows the statistical results for the 128 runs of the computational
experiment. Overall effectiveness for each option is shown as a box, where the bottom
and the top edges of the box indicate the 25th and 75th percentile results, respectively.
The difference between the 25th and 75th percentile results is defined as the interquartile
112

range. The heavier horizontal line indicates the median result. The short horizontal bars
(the whiskers) represent the value corresponding with 1.5 times the Interquartile Range,
with outliers (data lying outside the whiskers) indicated by hollow circles. Options 1-6 are
described and listed in order of increased cost.
As discussed earlier, it is not possible to deduce true statistical results for these
outcomes because no effort was made to accurately represent the distribution of input
parameters, nor are they necessarily independent. Recall that Overall Effectiveness is an
aggregate measure of the weighted sum of scenario performance. Some scenarios may
lead to low effectiveness, some to high effectiveness. It is difficult to see this bi-modal (or
multimodal) result from this aggregated measure. A drill down to the scenario level may
give more insight into the options’ performance. The figure below shows six box-andwhisker plots: One for each option’s Overall Effectiveness by scenario.

113

Figure 4.7 - Overall Effectiveness for Each Option
by Scenario in the PGS Illustration: + 20%
Parameter Variation
114

The figure below shows the same Overall Effectiveness results, except with a
separate plot for each scenario.

Figure 4.8 - Overall Effectiveness for
Each Scenario by Option in the PGS
Illustration: + 20% Parameter Variation
115

Recall that the figure of merit is Relative Option Superiority, and we are not drawing
conclusions about absolute effectiveness. The aim is to identify which options should be
retained for further analysis. From the figure above, we can see that:
• Scenario 1n (Mobile missiles case) is performed best by Options 5 and 6, but it
remains to be seen whether Option 6 is worth the extra cost.
• Scenario 1h (Mobile missiles hard case) is not performed well by any option,
showing no difference from the worst performing option to the best performing
option.
• Scenario 2n (Terrorist site case) performs reasonably well by all options, but
shows little difference from the worst performing option to the best performing
option. Although one cannot interpret the statistical results literally because all
cases are not equally likely, the top whisker is almost identical from one option to
the next, the 75th percentiles are within 0.1 and the median varies by less than 0.2
units of Overall Effectiveness.45
• Scenario 2h (Terrorist site fleeting target) shows some variation between Options.
Options 3-5 perform well, compared with Options 1,2, and 6.
• Scenario 3n (WMD facilities) shows a large variation between Options. Options 4
and 6 perform better than Options 2, 3, and 5, which perform better than Option 1.
• Scenario 3h (WMD facilities hard case) is performed moderately well by all but the
first Option.
Thus, scenarios 1n, 2h and 3n show some difference in performance between
options, and are identified as “option differentiators” since they help us choose between
options. The other scenarios, 1h, 2n, and 3h show essentially no difference from the
worst performing option to the best performing option, and therefore do not help us
differentiate the options. We will focus on the option differentiator scenarios, eliminating
the others for this iteration of the EA process.

45

Overall Effectiveness is normalized from 0 (not effective) to 1 (fully effective).

116

Just as scenarios which are not option differentiators can be eliminated from
consideration, options that always perform worse than others—those that are dominated-can be eliminated. Recall that Relative Option Superiority for Overall Effectiveness for
option I over option j is defined as.
ROE,I,j = Overall Effectivenessi (i=1-6) – Overall Effectiveness j (i=1-6)
For each of the 128 runs, ROE,I,j was computed for each pair of options. It was determined
that Options 1-3 are dominated in Overall Effectiveness by Options 4 and 5; the
difference in Overall Effectiveness was positive for all 128 runs. Option 6 was not
dominated in effectiveness. Before we eliminate Options 1-3 from further consideration,
let’s take a look at Overall Risk.

117

Figure 4.9 - Overall Risk for Each Option
(+ 20% Parameter Variation)
From the figure above, we can see that Option 1 has a higher Overall Risk than the
other options (for two reasons: SOF are required for this option in order to identify the
precise target, and also because the manned aircraft’s ingress/egress is risky) and that
Option 6 has some cases of lower risk than the others (it includes a stealthy SOF vehicle
118

and an advanced bomber with increased stealth). Options 3-5 include an SLBM which
carries with it the perceived risk of misinterpretation. This will be discussed in more detail
later. For now, nothing in the Overall Risk results indicates that Options 1-3, which are
dominated in Effectiveness, should not be eliminated from consideration.
Recall that options are numbered in terms of increasing relative cost, and that
Options 4 through 6 are higher cost than Options 1 through 3. Is this a reason to retain
Options 1 through 3? It is a judgment call whether cost is a significant driver and options
that otherwise perform poorly should be retained because they are less costly. In this
example, two considerations went into the judgment to drop Options 1 through 3, which
are dominated in return, and not worse in risk. First, it was assumed that all options are
feasibly affordable and that the wide range of return and risk would more influence the
choice of options than cost. Secondly, cost of the remaining options is included in the
discussion aids used to elicit decision makers’ value of cost relative to risk and return.
Thus, scenario S1h, S2n, and S3h can be eliminated from further consideration for
this set of options because they are not option differentiators, and Options 1-3 can be
eliminated because they are dominated by Options 4,5, or 6. The figure below shows the
Scenario Effectiveness for the remaining options and criteria.

119

Figure 4.10 - Effectiveness for Each NonDominated Option for Each Differentiating Scenario
120

Of course it will not always be the case that options and criteria can be eliminated.
For instance, some criteria may differentiate some of the options. It is possible that, once
the preliminary scenarios are developed, one or more option may be created to deal with
the particular challenges or opportunities suggested by some of the scenarios. Similarly,
options won’t always be dominated in every case that is run in the computational
experiment; some cases may emphasize a relative strength of an option compared to the
others, some may point out a relative weakness. The approach advocated here is to look
for simplifications. If the number of options and criteria can be reduced, so much the
better. If they can’t, the remaining methodology remains the same.
Recall that the relative value for each scenario was defined as a set of four
“focuses”, each representing a set of scenario weights corresponding to a particular
perspective. Since some of those scenarios have been eliminated, it makes sense to go
back and revisit these focuses for the three existing scenarios. The table below shows the
new formulation of sets of aggregation weights for each focus.

Table 4.9 - Reformulation of Aggregation Weight
Sets for Each Focus of the Differentiating Scenarios
From the table above, the first focus represents the perspective that the remaining
scenarios are equally valuable in choosing an option. The next three rows include a
variable X, which corresponds to the relative preference for one scenario over the other
two. When X=0.67, Focus 2 puts all the weight on Scenario S1n and none on the other
two scenarios. This corresponds to a strong belief that Scenario S1n be the most
121

valuable scenario to consider when choosing options. Focus 3 puts all the value on
Scenario S2h, and Focus 4 puts all the emphasis on Scenario S3n. Thus, by varying X
between 0 and 0.67, the relative preference of one scenario over another can be
explored.
The figure below shows Overall Effectiveness for the extreme values of X.

Figure 4.11 - Overall Effectiveness for Each NonDominated Option For Different Values of Focus
Variable X (+ 20% Parameter Variation)
Because decision makers may have strong preferences for one scenario vs.
another, the value X=0.667 was chosen for further consideration. The effect of choosing
this over X=0 can be seen from the figure above; the range of Overall Effectiveness was
increased for each option, and Option 4’s median result increased somewhat.
Exploratory analysis step 4: Mine the data to determine driving forces
The previous section described graphical exploration of the data. Often, the analyst
can gain useful insights about the system from bridging the gap from data table to data
mining with graphical exploration. In addition, high-level decision makers may find graphs
and plots more intuitively satisfying and explainable than data mining results. The next
section describes the method to perform statistical data mining in order to determine the
122

factors that drive one option to be superior to another, or drive an option to have low
effectiveness. Let us begin by determining the factors that predict when Option 4 will be
superior to Option 5.
Recall that PRIM defines parameter space using the dimensions of the independent
variables, and tries to identify regions of multidimensional parameter space of
predominantly “good” outcomes. MPSDM defines Relative Option Superiority for measure
Y of Option i over j as the difference
Ryij = Yi(i=1-6)-Y j(i=1-6, ij) where Y is an outcome of interest and i,j are options
For this exploration, we wish to find factors that drive Option 4’s superiority to Option
5 in Overall Effectiveness. Thus, in the equation above, i is set to Option 4 and j is set to
Option 5 and Y is Overall Effectiveness. A positive value for Relative Option Superiority
(Ry45) indicates that for that particular run, Option 4 is superior to Option 5 in Overall
Effectiveness. “Good” cases for this exploration are defined as cases where R is positive,
“bad” where R is negative. Thus, the PRIM algorithm searches for areas in
multidimensional parameter space where Option 4’s Overall Effectiveness is superior to
that of Option 5.
The results of running the PRIM algorithm showed that the predominant factor
driving Option 4’s relative superiority to Option 5 was when the variable Focus was equal
to 4. Referring to Table 4.8, above, this means that Option 4 is Superior to Option 5 when
decision makers value Scenario S3n more than the other two differentiating scenarios.
Recalling Figure 4.7, an excerpt of which is shown below, this PRIM result is consistent
with the graphical observations: Option 4 is superior to Option 5 when decision makers
value scenario S3n highly.

123

Figure 4.12 - Graphical Result Supporting PRIM
Conclusion on Relative Option Superiority
Next we turn to finding the forces that drive Option 4 to perform poorly. As we
will see later, identifying these factors may be useful if an option is picked for further
consideration, because there may be a strategy to address its vulnerabilities. What is
meant by vulnerability? Although a number of measures could be used, the idea is to
explore the “worst performing” cases using some threshold. The threshold that separated
“good” cases from “bad” cases in PRIM was defined here for all options as the 25th
percentile Overall Effectiveness.46 PRIM found that the factors driving Option 4’s poor
performance were:
• Focus = 2 (emphasis on Scenario S1n) which is consistent with the low
effectiveness score for S1n from the left side of the figure above
• Execution being low in Scenario S1n.

46

th

Note again that the 25 percentile cases do not represent actual probabilities since no effort was made to model the
distributions of input parameters, and they are not all independent. Another alternative would be to define the
th
threshold as an absolute level, or the lowest 10 percentile cases, This lower relative threshold was also used for
some of the options, and no difference was found in the driving factors.

124

This last finding is consistent with the graphical results in the figure above but
additional insights require more analysis: what drives Execution for Scenario S1n to be
low?
Recall from Figure 4.1 that Execution itself is an aggregate measure. It is the
product of variables Reach Target and Find and Kill Target. There are two paths for
exploring deeper from Execution:
1. Run the exploratory analysis procedure, using Execution as the dependent
variable and lower-level variables as the independent variables
2. Drill down in the multiresolution model to see what drives Option 4’s Execution
in Scenario S1n.
The first path has three attractive features: it effectively increases the dimensional
capabilities of PRIM. Instead of starting the exploratory analysis with all possible lowerlevel variables, taking this step-wise approach—exploring one level at a time and then
exploring from the driving forces found at each level—affords a methodical “walk” through
multidimensional parameter space, using fewer PRIM variables. Secondly, this lowerlevel exploration may be necessary for extraordinarily large models where a drill down in
the multiresolution model is not as simple. Third, PRIM would be most useful when
answering more discriminating questions, such as “at what value of this driving force, or
with what combinations of values for multiple driving forces would relative option
superiority switch signs?
The second path, drilling down in the model, was chosen for this demonstration
because it was quicker, and demonstrates another value of the multiresolution modeling
technique: real-time drill-downs to gain quick insight into lower-level factors that drive
results of interest. A quick inspection of the results of the computational experiment
showed that the variable Find Target drove Option 4’s Execution in Scenario S1n. For this
Mobile Missiles scenario, sensors are required to find the target.

125

Thus far Option 4 has been explored in terms of its superiority to Option 5, and also
in terms of its poor performance. Next, the PRIM procedure is repeated, comparing each
nondominated option pair. The table below shows the results of these explorations:

126

Option 4 Superior

To Option 4:
• SLBM
• Penaids
• SOF Vehicle

-

To Option 5:
• SLBM
• Penaids
• Sensors

Scenario S3n (striking
weapons of mass
destruction) valued
most strongly

To Option 6:
• Adv. Bomber
• Sensors
• SOF Vehicle

Scenario S2h (Striking
Terrorist Site-Fleeting
Target) valued most
strongly

Option 5 Superior

Option 6 Superior

• Scenario S1n
(striking mobile
missiles) valued
most strongly

• Scenario S1n
(striking mobile
missiles) valued
most strongly
• Scenario S1n
Execution is low
(need Sensors)

-

Scenario S2h
(Striking Terrorist
Site-Fleeting Target)
valued most strongly

Scenario S3n
(striking weapons of
mass destruction)
valued most strongly

-

Table 4.10 - Summary of Relative Option
Superiority: + 20% Parameter Variation
The off-diagonal terms show conditions where one option is superior to another.
Many of the cells are somewhat obvious from the box plots, but a drill down helps give
insight into what lower-level factors are driving the results at the scenario level. As before,
there are two drill-down approaches: One using PRIM and the one used for this
illustrative model: Inspecting the results of the MRM. Some of the drill down results are
worthy of discussion. Option 5 incorporates on-board sensors, which reduces the
maximum weight of the warhead that can be used, compared with Option 4. WMDs in this
scenario are assumed to be more challenging to destroy, because they may be
somewhat hardened or buried. This also explains why Option 4 is superior to Option 5
when this scenario is valued most strongly. Similarly, Option 6 is superior to Option 5
when scenario S3n (destroying a WMD site) is valued most strongly. This is because
127

Option 6, which utilizes an advanced bomber, has the highest payload weight capability
of all options, increasing the likelihood of destroying a WMD.
Continuing to the bottom row of the table above, Options 4 and 5 are superior to
Option 6 when Scenario S2h is most emphasized. This is because the SLBM of Option 4
is timelier than the advanced bomber of Option 6, and this scenario stresses timeliness.
Next we explore what drives an option’s vulnerabilities—the factors that are
associated with particularly low effectiveness. The table below shows the results of this
analysis.

128

Option’s
Vulnerability
Option 4:
• SLBM
• Penaids
• SOF Vehicle
Option 5:
• SLBM
• Penaids
• Sensors
Option 6:
• Adv. Bomber
• Sensors
• SOF Vehicle

Option 4’s effectiveness is particularly low when
• Scenario S1n (striking mobile missiles) valued
most strongly
• Scenario S1n Execution is low (need Sensors)
Option 5’s Effectiveness is particularly low when:
• Execution in Scenario S3n is low (larger warhead
needed)
• Collateral Damage in Scenario S3n high

Option 6’s Effectiveness is particularly low when all
scenarios are valued the same

Table 4.11 - Summary of Option Vulnerability: +
20% Parameter Variation
Option 4’s vulnerabilities are evident when Scenario S1n is valued most strongly by
the decision makers. This option has particularly poor performance for this scenario
because it does not include advanced sensors to find the target. Option 5 has particularly
low effectiveness when execution is low and collateral damage in scenario S3n (striking
Weapons of Mass Destruction) is high. Option 6’s effectiveness is particularly low when
all scenarios are valued the same: this is because Option 6 performs one scenario (S1n)
better than the other two options, and one scenario (S2h) worse than the other two
options.
These tabular results give a complete picture of relative option superiority and
conditions of poor option performance, but another representation of the results might be
more useful. The figure below shows the box-and-whisker plot with highlights from the
tabular results, along with annotation describing the factors that drive an option to be
more or less effective than others for a given scenario.
129

Figure 4.13 - Annotated Box Plot. + 20% Parameter
Variation
130

MPSDM proposes that the annotated box-and-whisker plot be used as a discussion
aid with decision makers. Scorecards, which are often used, have their advantages:
• They are more familiar to many decision makers, particularly in business and
defense applications
• They are less abstract and may be more cognitively effective for a diverse
audience
• They are more complete, giving results for all options and criteria
• Scorecards, especially as created by the PAT model, allow instantaneous
drill-downs to lower-level factors that may be affecting higher-level results.
However, the annotated box-and-whisker plot has some advantages over
scorecards:
• They show the results of full parameter space exploration
• They indicate the range and some distributional data
• They give an indication of the “corners” of parameter space for further
analysis of the feasibility of particular cases. Often the vulnerabilities are
areas the adversary will seek to exploit
• A box plot simplifies the problem, showing differentiating scenarios’ relative
effectiveness for nondominated options along with cost
The most complete way to represent the analyst’s understanding of the system may
to use both a scorecard and an annotated box-and-whisker plot. The scorecard can be
used to give a more complete “big picture” and aid real-time drill down exploration. The
box-and-whisker plots provide some explicit analytical results that might otherwise have
to be done in the decision maker’s head, and provide an analytic distillation of complex
understandings.

131

The next step is to evaluate the effects of nonlinear parameter space. Nonlinearity
comes into the model, for instance, when nonlinear aggregation rules and scoring
thresholds are used, or when elements are modeled as nonlinear functions of other
parameters. Recall from Table 4.3 that some of the parameters (Execution, Collateral
Damage, and Net Mission Risk) were varied + 20% in this last exploration. Next,
variations of + 40% are explored, and the results compared. The figure below repeats the
previous figure, and adds the plots of + 40% parameter variation for comparison.

132

Figure 4.14 - Comparison of + 20% and + 40%
Parameter Variation on Overall Option
Effectiveness
133

The figure above shows that the spread of results, as expected, is larger for the
+ 40% variation than the + 20% variation. For the most part, the results are unchanged.
The exception is for Scenario S1n: Options 5’s median is very slightly higher for the +
40% variation, and Option 6’s median is somewhat lower. This may be due to a “floor
effect” for option 5, where Effectiveness is often quite low, and a “ceiling effect” for Option
6 where Effectiveness is sometimes quite high. Note that the relative option superiority
for the + 20% and + 40% variation are fundamentally the same. The important result is
that nonlinear effects are not significant for our chosen figure of merit, relative option
superiority.
So far, the first two steps of the MPSDM methodology have been completed: The
problem has been framed as a set of initial options and criteria, with perspective
parameters evaluated explicitly along with more objective factors; and the problem has
been simplified by eliminating dominated options and non-differentiating criteria and
performing exploratory analysis to find the factors driving relative option superiority.
MPSDM methodological step #3: Derive the strategy
Recall from Figure 3.1 that the third step in the MPSDM methodology is to derive the
strategy by using the driving forces’ time frame and controllability to determine type of
strategy to employ, and then modifying the options and criteria, iterating as required.
Let us imagine that decision makers used the annotated box plot of Figure 4.13 as
an aid to discuss the relative value of the options, including their relative cost. Let us
further assume that they chose Option 5 as a relatively cost-effective choice for further
consideration. It is the timeliest option, with somewhat more capability in Scenario S1n
than Option 4. Although it does not perform Scenario S3n as well as Option 6, it is less
than half the relative cost. Although the next step in the MPSDM process could be
performed using all three options, the methodology is illustrated by proceeding with
Option 5 as the most cost-effective choice.

134

Recall from the middle row of Table 4.9 that the factors driving Option 5’s relative
option inferiority were low Warhead Weight and high Collateral Damage in Scenario S3n
(Destroying WMDs). Can we improve these factors, thereby improving Option 5?
Warhead Weight is somewhat controllable in the long term, as is Collateral Damage
The figure below shows the MPSDM controllability/time frame heuristic, with the factor
driving Option 5’s relative inferiority to Option 4 in Return (warhead weight and collateral
damage) placed in the “controllable” quadrant in the long term.

Figure 4.15 - Time Frame/Controllability Heuristic
with Driving Force in Most Appropriate Quadrant
Thus, from the upper right hand quadrant of the figure above, Option 5’s
Effectiveness could be improved in the long term by shaping actions to affect 1) the
likelihood of destroying the WMD site and 2) causing unacceptable collateral damage.
Item 1 can be accomplished by removing the third stage of the Conventional Trident
Missile used in Option 5, and replacing it with a new payload. This allows the SLBM to
135

carry a biconic re-entry vehicle with a payload that more accurately aims a heavier
warhead to strike at a given angle. This modification has several advantages of the CTM
third stage:
1. the heavier payload increases the likelihood of “killing” the target
2. the biconic re-entry vehicle enables the warhead to hit the target at a normal
angle, increasing the likelihood of “killing” the target
3. the improved aim increases the likelihood of finding the target
4. the steerable re-entry vehicle has more range than other re-entry vehicles.
5. this increased payload weight capability could also be used to carry an
unmanned aerial vehicle (UAV) that could be developed for longer-term use.
The UAV would be very helpful in Scenario 1 since it could carry sensors to
locate the mobile missiles
In addition to increasing warhead weight, this modification would also improve the
other driving force, Collateral Damage. Items 2 and 3, above, would also reduce collateral
damage.
Noteworthy is the fact that this option was created by the NRC as the so-called
CTM-2. Their expert opinion converged to the same solution as the MPSDM approach.
In addition to these shaping actions, Figure 4.15 recommends that resources be
applied to developing early warning of the effect of the adversary developing WMD
capabilities. Early warning in general is beneficial to enable a wider variety of responses,
but in the case of WMD, detailed intelligence about facility characteristics and
vulnerabilities is especially valuable to reduce actual collateral damage. Enrolling allies
early in the need to get this intelligence, or to destroy the WMD facilities early may reduce
the effect of collateral damage, especially if the facilities can be destroyed before toxic
materials are produced.
A final note: This “controllifying” activity, or figuring out if any aspect of the driving
forces can be brought under the control of the decision makers is not to be
underestimated. Often, when a factor seems completely outside the decision makers’
136

control, influences from other domains can be brought to bear. An agreement with a third
party, a game-changing breakthrough, or even an unforeseen circumstance my bring the
factor into indirect control. Sometimes the group, especially when stakeholders are
included, has resources far beyond what any individual decision maker may recognize.
What about Option 5’s risk? Recall from Figure 4.9 That Option 5’s Overall Risk is
driven by the ambiguity issues of a conventional warhead being launched from the same
submarine as a nuclear warhead. Although ambiguity is the most often-raised concern
about CTM options, and Congress has expressed reservations about funding CTM for
this reason47, the NRC (2008) committee and Woolf (2008) offer several observations on
the ambiguity issue. First, that any CPGS option could carry nuclear weapons, making
the launch platform criterion less of an option differentiator than previously considered.
Second, the risk could be mitigated by a number of methods:
• Notifying other countries, in particular China and Russia, prior to launch
• Enacting transparency arrangements to inform other countries about the CPGS
system, its operation, and its doctrine for use
• Sharing early warning data at a joint facility
• Inspection of U.S. facilities
• A continuous visual monitoring system to ensure that conventional warheads
have not been replaced by nuclear ones
The NRC committee made the following conclusion
The risk of a CPGS attack being misinterpreted and leading to a nuclear attack
on the United States could be mitigated and managed through readily available
mechanisms. The benefits of possessing a limited CPGS capability, such as that
provided by CTM, outweigh the risks associated with nuclear ambiguity.
Now that the driving forces have been found and Time Frame/Controllability
heuristic has been used to identify strategies to modify Option 5, the criteria themselves
47

NRC (2008) Appendix B presents a letter from Senators Daniel K. Inouye and Ted Stevens, Chairman and Ranking
Members of the Senate Committee on Appropriations, Subcommittee on Defense. The letter states that “there was
widespread, but not universal, agreement [in the Senate] that the Congress should not proceed with the conventional
Trident program [and that] critical to the opposition was a belief that the Trident option proposed the most difficult
challenge of ambiguity.” The NRC disagreed with Congress’ decision to not support testing of conventional Trident
missiles in 2008.

137

can be evaluated in light of the insights gained so far. In reviewing the results of
exploratory analysis and seeing a simpler view of a complex problem, decision makers
may wish to modify the initial criteria: Is ambiguity as much of an option differentiator as
originally thought? From the discussion of the relative value of different scenarios, are the
values of the decision makers converging?
As indicated in Figure 3.1, the last step in the MPSDM methodology is to modify the
options and criteria and iterate the process. Using the modifications to Option 5 discussed
above, and any updates to the criteria that the decision makers have come to understand,
a new set of options and criteria can be used as the starting point for another round of
exploratory analysis. A new suite of plausible outcomes can be generated, a new set of
driving forces can be identified, and the options modified according to the insights gained
from both the analysis and from the discussion of decision makers’ perspectives elicited
in each iteration. This iterative process can continue as long as resources are available,
or until decision makers find shaping actions and hedges to address the driving forces
associated with the option chosen, or they reach consensus.
Reports from the NRC (2008) indicates that the committee started with highly
diverse views amongst themselves.48 This group of scientists, engineers, retired flag
officers, policy analysts, political scientists, and retired senior officials was sought by NRC
organizers for their expertise in the different fields. Some members were very sensitive to
foreign relations issues, including arms control. Some were more technology-focused.
There were debates about all significant issues, often with disagreements. Members
pointedly did not purport to reach agreement, for example, on the relative importance of
the scenarios or the desirability of more far-reaching deployments.
Nevertheless, the committee came to consensus about the final recommendations
and the relative superiority of the option they created as a result of the insights gained
during their discussion. At the end of the day, the committee had many
recommendations, but they focused on facts, analysis, and on what should be done.

48 Unpublished communication with Paul Davis, NRC Committee member.

138

