# Wainfan (2010) - Multi-perspective Strategic Decision Making: Complete Chapter 1

## 論文基本情報

**タイトル**: Multi-perspective Strategic Decision Making: Principles, Methods, and Tools  
**著者**: Lynne Wainfan  
**発行年**: 2010年3月  
**種別**: 博士論文（公共政策分析）  
**所属**: Pardee RAND Graduate School  
**指導委員会**: Paul Davis (Chair), David Groves, Richard Hillestad  
**総ページ数**: 170ページ  

---


# Chapter 1 - Introduction

## Significance of the research

In the 21st century, organizations governing every type of institution are experiencing unprecedented demands to consider alternative viewpoints from outside stakeholders, the decision makers themselves, and from new types of adversaries. One factor that contributes to this trend is the information age. Widespread access and rapid dissemination of information brings a high level of scrutiny from public stakeholders to government, business, and civil organizations. Marten and Samuels (2009) report that vulnerable colleges and universities experience "unprecedented external demands for accountability and quality assurance by the public, donors, accreditors, legislative bodies, and the U.S. Department of Education." Decision makers, becoming accountable to a wider group of stakeholders, external to the group must increasingly take these diverse perspectives into account when devising strategy.

In the educational sector, Eherenberg (2004) reports that wealthier institutions of higher education are seeing a dramatic shift in the makeup of their Boards of Trustees. In his book, Governing Academia, Who's in Charge at the Modern University? Eherenberg explores the effect of Educational Boards of Trustees becoming more heterogeneous, as they admit the alumni "insiders' voice." Goodstein, Gautan, and Boeker (1994) found that board diversity may be a significant constraint on strategic change.

U.S. Defense policy makers must adjust to a wider scope of considerations as well. Adversaries now include diffuse, non-governmental entities as well as nation states. These new adversaries are fundamentally different than nation states in terms of capabilities, tactics, motivations, strengths, and vulnerabilities. In addition, adversaries will search for and exploit combinations of vulnerable assumptions--combinations that may be hard to predict as systems become more complex. Defense policy must maintain the capability to deal with traditional adversary nations, while adding the capability to protect against non-government opponents (Hough 2008).



In addition to a fundamentally broader set of adversaries to consider, defense strategists must, as always, consider large number of factors that contribute to creating and maintaining alliances with other countries. Domestically, defense policymakers must continue to take into account the perspective of Congress, consider the likelihood of continued funding levels, and predict the political stability of programs in the midst of increased transparency and accountability from the public.

Another factor affecting the heterogeneity of governing institutions is regulatory. In response to perceived financial misdeeds, the Sarbanes-Oxley Act was passed by Congress in 2002. This, along with other, state-specific legislation requires governors of for-profit institutions, and to some extent non-profit institutions, to include more "outsiders" on their Boards of Directors.

U.S. government, for-profit, and non-profit institutions are not the only ones feeling the pressure driving them to consider more diverse perspectives. According to a recent RAND Pardee Center workshop report, regional and international institutions, facing pressure from economic, environmental, and activist forces, "may need substantial modification to contribute towards a stable, free, and just world in the 21st century."

How do high-level decision makers proceed with the difficult challenge of creating strategy which addresses these diverse perspectives? Classical management theory prescribes methodology for the decision-making group to agree on objectives, often from a shared understanding of the organization's vision and mission (Hitt, Ireland, and Hoskisson 2009). When groups are homogenous, consensus on objectives is relatively likely. As perspectives within the decision-making group diverge, or when decision makers must consider a wide range of stakeholder, analyst, and adversary viewpoints, consensus on objectives grows less likely. If objectives cannot be agreed upon, then it is improbable that the group will agree on strategies to accomplish those objectives.

There is clear evidence of so-called dissonance when values conflict (Heifitz 1994). Although governing groups rarely break out into fistfights as the Continental Congress

