Chapter 1- Introduction
## Significance of the research
In the 21st century, organizations governing every type of institution are experiencing
unprecedented demands to consider alternative viewpoints from outside stakeholders,
the decision makers themselves, and from new types of adversaries. One factor that
contributes to this trend is the information age. Widespread access and rapid
dissemination of information brings a high level of scrutiny from public stakeholders to
government, business, and civil organizations. Marten and Samuels (2009) report that
vulnerable colleges and universities experience “unprecedented external demands for
accountability and quality assurance by the public, donors, accreditors, legislative bodies,
and the U.S. Department of Education.” Decision makers, becoming accountable to a
wider group of stakeholders, external to the group must increasingly take these diverse
perspectives into account when devising strategy.
In the educational sector, Eherenberg (2004) reports that wealthier institutions of
higher education are seeing a dramatic shift in the makeup of their Boards of Trustees. In
his book, Governing Academia, Who’s in Charge at the Modern University? Eherenberg
explores the effect of Educational Boards of Trustees becoming more heterogeneous, as
they admit the alumni “insiders’ voice.” Goodstein, Gautan, and Boeker (1994) found that
board diversity may be a significant constraint on strategic change.
U.S. Defense policy makers must adjust to a wider scope of considerations as well.
Adversaries now include diffuse, non-governmental entities as well as nation states.
These new adversaries are fundamentally different than nation states in terms of
capabilities, tactics, motivations, strengths, and vulnerabilities. In addition, adversaries will
search for and exploit combinations of vulnerable assumptions--combinations that may be
hard to predict as systems become more complex. Defense policy must maintain the
capability to deal with traditional adversary nations, while adding the capability to protect
against non-government opponents (Hough 2008).

In addition to a fundamentally broader set of adversaries to consider, defense
strategists must, as always, consider large number of factors that contribute to creating
and maintaining alliances with other countries. Domestically, defense policymakers must
continue to take into account the perspective of Congress, consider the likelihood of
continued funding levels, and predict the political stability of programs in the midst of
increased transparency and accountability from the public.
Another factor affecting the heterogeneity of governing institutions is regulatory. In
response to perceived financial misdeeds, the Sarbanes-Oxley Act was passed by
Congress in 2002. This, along with other, state-specific legislation requires governors of
for-profit institutions, and to some extent non-profit institutions, to include more “outsiders”
on their Boards of Directors.
U.S. government, for-profit, and non-profit institutions are not the only ones feeling
the pressure driving them to consider more diverse perspectives. According to a recent
RAND Pardee Center workshop report, regional and international institutions, facing
pressure from economic, environmental, and activist forces, “may need substantial
modification to contribute towards a stable, free, and just world in the 21st century.”1
How do high-level decision makers proceed with the difficult challenge of creating
strategy which addresses these diverse perspectives? Classical management theory
prescribes methodology for the decision-making group to agree on objectives, often from
a shared understanding of the organization’s vision and mission (Hitt, Ireland, and
Hoskisson 2009). When groups are homogenous, consensus on objectives is relatively
likely. As perspectives within the decision-making group diverge, or when decision
makers must consider a wide range of stakeholder, analyst, and adversary viewpoints,
consensus on objectives grows less likely. If objectives cannot be agreed upon, then it is
improbable that the group will agree on strategies to accomplish those objectives.
There is clear evidence of so-called dissonance when values conflict (Heifitz 1994).
Although governing groups rarely break out into fistfights as the Continental Congress

1

Pardee Center Workshop on Due Diligence for Humanity’s Long-Term Future, January 13, 2008, RAND,
Santa Monica, Ca.

2

reportedly did during revolutionary times, consensus can become more difficult to achieve
when a broader group of perspectives must be considered.
What is Multi-perspective Strategic Decision Making?
Strategic decision making theory is often described in the context of strategic
management research, with roots extending back to Chandler’s (1962) Strategy and
Structure and Ansoff’s (1965) Corporate Strategy (Hoskisson et al.1999). As early as the
mid-1980s, strategic decision making was defined by different researchers in different
ways. Chaffe (1985) cites several studies to support her claim that “virtually everyone
writing on strategy agrees that no consensus on its definition exists. Mador (2000) lists
several definitions of strategic decisions used in the literature:
• “[a decision which is] important, in terms of the actions taken, the resources
committed, or the precedents set” (Mintzberg, Raisinghani and Theoret 1976);
• “decisions that determine the overall direction of the firm’ (Quinn 1980);
• “[those which] 1) involve strategic positioning; 2) have high stakes; 3) involve
many of the firm’s functions; and 4) [can] be considered representative of the
process by which major decisions are made at the firm.”
Eisenhardt and Zbaracki (1992) define strategic decisions as “those infrequent
decisions made by the top leaders of an organization that critically affect organizational
health and survival.” Mador (2000) summarizes these various definitions: “By implication,
strategic decisions are complex, and involve a high degree of uncertainty.” Although the
nature of all these definitions has a somewhat different slant, Dean and Sharfman (1996)
conclude that in their research, managers had no trouble identifying strategic decisions.
Strategic decision making, for the purposes of this research, is the process of
making long-term decisions that shape the course of an organization. Such decision
making is often done by groups of high-level decision makers. Examples of strategic
decision makers include Boards of Governors/Trustees/Directors, multi-national or
regional groups, and Defense policymakers, among others.
Strategic decision making is distinct from operational or tactical decision making in
several ways. First, decision makers must typically consider time frames of months to
3

years, not days to weeks. Uncertainty is deeper, not only because of the longer
timeframes, but because the capabilities of adversaries (e.g. competitors, enemies) are
not often known in the near term, or are not easily predictable. Also, the strategic decision
can affect resources in the millions or billions, instead of hundreds or thousands, as well
as affecting the general approach the organization takes to deal with challenges.
Multi-perspective strategic decision making (MPSDM) is defined in this research as
the process of making long-term decisions that affect the course of an organization,
taking into account diverse perspectives—values, beliefs, and expectations. These
perspective can differ between individuals in the decision-making group, analysts,
stakeholders, and analysts. This research describes an MPSDM approach: principles, a
methodology, and a set of tools designed to help groups agree on strategic actions when
decision makers either have amongst themselves, or must consider, perspectives other
than their own. A novel heuristic is proposed which suggests strategy type based on the
time frame and amount of control decision makers have over the factors driving relative
superiority of options. Using these heuristic, strategic options can be modified and the
analysis can be iterated. This dissertation then illustrates the approach with a simplified
defense acquisition example.
Audience for this research
This research is envisioned to be most useful to consultants and staff to strategic
decision makers, and students who will become strategic decision makers, consultants or
staff. The approach is designed to be applicable to a wide variety of types of institutions,
and it is demonstrated in the dissertation using a simplified version of a real-world
defense procurement problem, accessible to a broad audience.
What is meant by perspectives?
Davis et al. (2008) define a perspective as “a way of looking at the problem when
assessing the ‘balance’ within a portfolio of investments” (p. xxxviii), and describe
different types of considerations in high-level strategic assessment. For instance, they
describe the U.S. Pacific Command perspective as being relatively more concerned
4

about the long term, the “strategic” view, the Pacific region, and big-power balances than
the U.S. Special Operations Command. In this framework, a perspective is associated
with an organization and includes many assumptions.
MPSDM defines perspectives at the level of individual assumptions, as opposed to a
set, and an individual’s assumptions, as opposed to a group’s.2 MPSDM defines
perspectives as:
• Values - what individuals think is important,
• Beliefs – mental models of how the world works, and
• Expectations - individuals’ view about how the future will unfold.
Values, or what individuals think is important, are often difficult to define. The
challenge here is to devise a way of characterizing many types of values (or criteria) in an
analytic framework. One early practitioner of what is now known as Multicriteria Decision
Making (MCDM) theory was Benjamin Franklin, who composed lists of “pros” and “cons”
to ideas, crossing off considerations of equal importance before evaluating the remaining
considerations. (Figueira, Greco, and Ehrgott 2005). Keeney and Raffia defined MultiAttribute Utility Theory (MAUT) in a 1976 publication that is a standard reference in
decision science tests. More recently, a number of methods have been created to
evaluate options against multiple criteria (see Zopounidis and Doumpos (2002) for a
review). Many of these methods apply “weights” to the different criteria before computing
an aggregate score and ranking the alternatives. Other methods use more complex
aggregation methodology. The criteria themselves are considered by MPSDM to
represent one type of value, with the aggregation weights and methodology representing
relative preference between criteria, another type of value.
Often, analysts and strategists try to anticipate what a stakeholder group might value
before developing strategy. This is difficult without the stakeholders being involved in the

2

MPSDM allows for assumptions to be grouped together into sets but does not assume such grouping. If reliable
information about correlated values, beliefs, and expectations can be made, the analysis can vary all the relevant
assumptions together. This method serves to reduce the number of combinations of assumptions and simplify the
exploratory analysis (conceptually and computationally). However, it is not always possible to predict such groupings
before the analysis (even within an organization, individuals may differ in their perspectives), and some assumptions
within the groupings may not affect the outcomes of interest to the same extent as the others.

5

creation of strategy, because sometimes the stakeholders themselves may not know the
relative priority of their values before seeing an assessment of the options. For instance,
how would an individual “trade” one criterion for another if some predetermined goal
cannot be met with any feasible alternative?
If values are difficult to define, characterize, or know ahead of strategy development,
the challenge is to explicitly include them in the process of creating strategy. Often highlevel decision makers find that they are either unable or unwilling to explicitly define or
express their values. Some considerations that are important to high-level decision
makers are unspeakable, for a variety of reasons. For instance, keeping certain sensitive
information (organization-based or personal) from leaking out may make it difficult to
explicitly include some types of values in the creation of strategy. Other “unspeakable
criteria” may include considerations that may be viewed as parochial, those that are not
fully thought out, or controversial views3.
One approach sometimes used to address values is to define membership in
various groups and then look for and characterize common values within the group.
Pfeffer (1973) defined board diversity as representation from different occupational and
professional groups. This distinction is used by others studying board diversity (Baysinger
and Butler 1985; Kosnik 1990; Powell 1991; Thompson 1967). Their research shows that
generally, as constituencies that board members represent grow more diverse, “the
greater the potential for conflict and factions to develop based on divergent definitions of
organizational goals and policies” (Goodstein, Gautam, and Boeker 1994). Kosnik (1987)
and Singh and Harianto (1989) found that the proportion of “outsiders” to “insiders” on the
boards that they studied affected organizational compensation. One could imagine
different definitions of diversity: Liberal vs. conservative; generational (i.e. age); race;
country of origin; socioeconomic status, etc. For strategy development with different
stakeholders, another dimension of values might be related to the type of institution the
individual represents—family owned, hierarchical, not-for-profit, etc. and that institutions’

3

The considerable range of such ‘unspeakable criteria’ came out in discussions with Paul K. Davis.

6

organizational values. To date, the effects of these types of diversity have not been
documented.
The second element of perspective, beliefs, pertains to an individual’s view of how
the world works, or the relationship between factors. Beliefs could be thought of as if/then
relationships, for instance “if our organization pushes this lever then the system will
respond this way.” MPSDM distinguishes “analytical” beliefs from other types of beliefs.
Analytical techniques, for example, include the “best” way to aggregate variables into a
higher-order summary. For instance, criterion weights are often used in MCDM to
compute an overall score for each option, but algorithms other than weighted sum may
seem more appropriate to the analyst. Contrast this analytical belief with a decisionmaker’s belief that if the organization attempts a military strike, the enemy will respond.
The likelihood of an enemy’s response depends on many beliefs: the effectiveness of that
response, the counter-response, world opinion, etc. Thus, analytical beliefs are of a
different nature than other types of beliefs, many of which depend on other types of
beliefs.
Beliefs, or views of how a system works, may be even less clear to decision makers
than values. Beliefs define a decision makers understanding of relationships based on
objective information and inference or deduction. What is meant by beliefs in this
research includes not just beliefs about how factors are related, but uncertainty in today’s
state of the world. Specifically, current capabilities, particularly an adversary’s, are critical
to the success of strategies in the for-profit and defense areas. If an adversary’s
capabilities are guarded as private information, the decision makers’ beliefs about them
may vary widely. Some information is known, some is not. Decision makers must rely on
a combination of objective information and inferences, and deductions. These inferences
and deductions produced by different individuals with access to the same objective
information may vary widely. Sometimes these beliefs are testable, often they are not. To
add another layer of uncertainty on top of already uncertain beliefs, the decision makers’
beliefs about an adversary’s actions depend on beliefs about the adversary’s beliefs.
Additional areas where beliefs may differ from individual to individual occur between
analysts and analysts, or between analysts and decision makers. Analysts often
7

communicate with a variety of math models, but high-level decision makers have their
own mental models of how a system will likely respond to one or more assumptions.4
The third element in the definition of perspectives is individual’s expectations.
Webster’s equates expectation with anticipation, which is defined as “the act of looking
forward.” Thus, there is an implication that expectations pertain to a time in the future.
MPSDM considers expectations to be decision makers’, stakeholders’, analysts’, and
adversaries’ views about how the future is likely to unfold. Expectations are one of three
types of perspective, but they also include how other types of perspectives—beliefs and
values—may change in the future.
Treating perspectives as uncertainties
What types of factors can be considered uncertain? Although many researchers
associate uncertainty with incomplete knowledge of the environment or with changes
occurring with time (Downey and Slocum 1975), MPSDM treats all types perspective
(values, beliefs, and expectations) as uncertain in the analysis for five reasons: First,
many of them are uncertain, most notably expectations of the future. Second,
perspectives represent differences between individuals. In some cases, these differences
may be unknown at the time of the analysis. For instance, decision makers themselves
may not know they have values different from those of other decision makers. In addition,
the adversary’s perspectives may be held as private information. Third, analysts may
differ in their belief of the “best” way to model aspects of the system. Fourth, since
expectations of the future are uncertain, and changes in values and beliefs may change
in the future, values and beliefs are also uncertain.
The fifth reasons perspectives are treated as uncertainties in MPSDM is that some
analytical treatments of uncertainty are useful for dealing with perspectives. The term

4 The terms “assumption” and “independent variable” are used interchangeably here, and meant to imply a temporary

assertion about an uncertain variable or model. This is a broader definition than, for instance, Dewar et al. (2001)
define an assumption as “an assertion about some characteristic of the future that underlies the current operation or
plans or an organization.” Dewar ties assumptions to expectations of the future, but MPSDM allows for current values
and beliefs to be assumed as well.

8

“deep uncertainty,” originally attributed to Arrow (2001)5, has also been used in research
to apply to conditions where uncertainty is ambiguous or vague and/or the relative value
of outcomes cannot be clearly established (Bankes, 2003). Lempert, Popper and Bankes
(2003) broaden the concept of deep uncertainty even further:
[Deep uncertainty is] where analysts do not know, or the parties to a decision
cannot agree on, (1) the appropriate conceptual models that describe the
relationships among the key driving forces that will shape the long-term future,
[what MPSDM calls beliefs] (2) the probability distributions used to represent
uncertainty about key variables and parameters in the mathematical
representations of these conceptual models, [a combination of some types of
beliefs and expectations in MPSDM], and/or (3) how to value the desirability of
alternative outcomes [a type of value] (p. xii).
One of the lines of research that this dissertation draws heavily from is Robust
Decision Making (RDM). RDM is an analytic method for developing robust policies—
those that perform well over a large range of uncertain futures. The goal of RDM is not to
aim for optimal outcomes, but for robustness (in the sense that outcomes that remain
good across a wide range of uncertainties). RDM has been applied to a variety of social
policy issues such as: Climate change (Groves, Lempert, Barry, Wainfan 2008; Groves,
2007; Lempert et al. 2004; Lempert and Schlesinger 2000; Lempert et al.1996; Lempert
et al. 2000); global sustainability (Lempert et al. 2003); educational investment (Park
and Lempert 1998) and science and technology investment (Lempert and Bonomo
1998).
As will be described in more detail later, RDM puts forth a method of exploring
uncertain parameter space using graphical and data-mining techniques that is
applicable to MPSDM. However, RDM has a somewhat different emphasis than MPSDM.
Whereas RDM aims to define strategies that perform reasonably well over a broad range

5

Lempert, Popper, and Bankes (2003) cite a 2001 presentation by Arrow regarding climate change policy.

9

of plausible futures, MPSDM focuses on how to define strategies that can be agreed
upon by group of decision makers who may never agree on values, beliefs, and
expectations. MPSDM’s emphasis on decision makers’, stakeholders’, analysts’, and
adversaries’ perspectives helps groups accommodate minority views and converge
iteratively towards consensus on strategic actions.
Goals of this research
This research proposes and demonstrates methodologies, principles, and a set of
tools to help strategic decision makers agree on actions despite diverse perspectives
amidst deep uncertainty. It extends and demonstrates the concept of exploratory analysis
(EA) to simultaneously consider uncertainty about objective factors and so-called
perspective parameters: those associated with the different values, beliefs, and
expectations including the analytical belief about the best way to aggregate and score
parameters in a mathematical model. 6 It offers an extension of multiresolution modeling
techniques and frameworks to help analysts and decision makers methodically navigate
and gain insights about plausible outcomes in broad parameter space. It proposes
graphical techniques to share insights among the decision-making group about a wide
range of plausible futures. Statistical data-mining techniques then focus the group’s
discussion on factors that matter to the choice of options, along with the conditions under
which they do, and to refine the group’s understanding of different perspectives. MPSDM
proposes ways of simplifying the problem so that decision makers can develop a shared
understanding of the forces driving the choice of strategy. Finally, it includes a process to
modify the options, consider minority views, and iterate the methodology to improve the
likelihood of consensus on strategic actions.

6

The distinction between objective factors and perspective factors (values, beliefs, and expectations about the future)
may not be as firm as has been indicated. Many factors that might be considered objective are in fact subjectively
estimated (especially expectations) or subjectively assigned some nominal value. Strictly speaking, objective factors are
ones that can be verified as fact, i.e. an event happened, a weapon destroyed the target, etc. What is meant here is to
recognize the differences with which individuals may estimate factors and account for these differences in perspectives.

10

