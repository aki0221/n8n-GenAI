# Chapter 2 - Challenges of Multi-perspective Strategic Decision Making, How Others Have Approached These Challenges, and the Principles of MPSDM

Decision makers face several challenges when devising strategy, even when their fellow decision makers are relatively like themselves. As values, beliefs, and expectations of other decision makers, stakeholders, and adversaries are taken into account, some of these challenges are made even more difficult. This chapter addresses the major challenges encountered in coming to consensus on strategy amidst diverse perspectives:

- framing the problem
- addressing perspectives in the analysis
- dealing with the curse of dimensionality
- creating strategy from the analytical results

Much as broader perspectives can bring a richer set of strategic possibilities and tools to a decision-making process, research from a wide variety of disciplines offers a selection of approaches to these challenges. The next sections of this chapter describe each of the major challenges of MPSDM, along with approaches that others have used to address them. The MPSDM approach to each challenge is summarized, and relevant principles are proposed.

The chapter then concludes with a summary of the types of literatures explored for this research, along with key concepts taken from each.

## Challenge # 1: Framing the strategic problem for analysts and decision makers

### What is framing?

The literature offers a range of definitions for "framing" as it relates to decision making. Entman (1993) defines framing fairly broadly:

> To frame is to select some aspects of a perceived reality and make them more salient in a communicating text, in such a way as to promote a particular problem definition, causal interpretation, moral evaluation, and/or treatment recommendation for the item described (p. 52).

A widely-cited description of framing was introduced by Khaneman and Tversky (1984) as selecting and highlighting some features of reality while omitting others. Nutt (1998) evaluated 350 strategic decisions to evaluate the process of framing a strategic issue "by influencing the directions that are set to guide the search for alternatives." Nutt found that stakeholders (typically activists in his sample) were the most common framers, at least initially. "Decision making was initiated by claims from stakeholders that pointed out salient concerns and difficulties and prompted directions to be set that guided a search for ways to respond."

In policy analysis, framing a problem means figuring out how analysts and decision makers could think about salient aspects of a problem before seeking alternative solutions. It also includes determining the structure that represents the problem amidst multiple criteria and uncertainty.

### Why is framing a challenge for MPSDM?

Individual stakeholders may consider one aspect of a system to be most salient but when decision-making groups or stakeholders consider different perspectives, it may be difficult to "get on the same page." Defense planners might think of the problem in terms of meeting future military objectives, but Congress must determine funding priorities, and allies must consider political feasibility. As groups consider more perspectives in their decision making process, it becomes hard to agree on common frameworks.


As expectations about the long-term future diverge among strategic decision-making groups, it is easy to understand how reasonable individuals could differ in how they think about a problem.

In addition to differences in ways that decision makers think about a problem, several studies have identified different decision making styles. Alternative judgment and decision-style taxonomies exist, but Hammond et al. (1997) describe empirical studies that show decision modes range from rational to intuitive. Hitt and Tyler (1991) provide a useful summary that includes intuitive or quick judgments (sometimes called naturalistic decision making); rational-normative, external control, and strategic choice models.

Khatri and Ng (2000) compare the relative prevalence of an intuitive strategic decision making style with the rational-analytical style in business decisions. In their interviews of senior managers of computer, banking, and utility organizations, they found that intuitive processes are used often in organizational decision making. Interestingly, intuitive processes were positively correlated with organizational environment in an unstable environment, negatively related in a stable environment.

Sometimes the presence of a group affects the criteria that individuals use for decisions. Janis' famous (1982) study of seven major governmental decisions identified the concept of Groupthink, where the need to be included in the decision-making group can outweigh the rational expected outcome of the group's decision.

Eisenhardt and Zbaracki (1992) review the strategic decision making literature, identifying the dominant paradigms and reviewing empirical support for each. They conclude "that decision makers are boundedly rational, that power wins battles of choice, and that chance matters. It is also clear that a synthesis of bounded rationality and political perspectives provides a compelling description of strategic decision making."

Davis, Kulick, and Egner (2005) point out that there are advantages and disadvantages to different decision-making styles. They identify approaches to synthesize decision processes with some virtues of both rational-analytic and naturalistic styles, pointing out ways that a good staff could work with an intuitive decision maker by finding critical assumptions, building in contingencies, etc.

In what has been called the "standard reference and textbook for many years to come"(Brewer, 2009) on risk assessment, the National Research Council Committee (NRC) on Improving Risk Analysis Approaches Used by the U.S. EPA (2009) concluded that environmental problems are socially constructed and therefore depend on human values, which are mediated by diverse perceptions. Four chapters are devoted to human, institutional, and "irrational" components of risk assessment. The committee cites a two-decade effort to deal with nuclear power plant waste at Yucca Mountain, Nevada and conclude that the issue is not as simple as rational calculation of leaking radiation from storage canisters. Instead, the issue is more about fears and lack of trust among the general population. They urge decision makers to confront and manage the perceptions of those affected rather than the rational expectations and technical assessments.

Another cognitive process that individuals use relates to simplifying complexity. As problems include more variables and relationships between the variables, decision makers frequently make use shortcuts, or heuristics to reduce a problem down to what they conceive as the bare essence of a problem. (Simon and Newell 1958; Kahneman, Tversky, and Slovic 1982; Gigerenzer, Todd, and the ABC Research Group 1999). These simplifications often have a basis in human judgment, experience, or intuition. In an interesting example of a heuristic, Rabin and Weizsacker (2009) demonstrate what they call "narrow bracketing," where individuals make decisions by focusing on one choice at a time rather than considering the full set of choices available.

### Approach taken by MPSDM to address the challenge of framing the problem

The MPSDM approach recognizes that framing is inherently subjective and that different stakeholders will naturally frame problems differently based on their perspectives, values, and objectives. Rather than trying to force consensus on a single frame, MPSDM explicitly acknowledges multiple frames and treats them as part of the uncertainty that must be addressed in the analysis.

The approach involves several key elements:

1. **Explicit identification of different frames**: Rather than assuming a single correct way to frame the problem, MPSDM systematically identifies the different ways that various stakeholders frame the strategic problem.

2. **Treatment of frames as uncertainties**: Different problem frames are treated as sources of uncertainty, similar to how traditional decision analysis treats uncertainty about future events or parameter values.

3. **Robust strategy identification**: The goal is to identify strategies that perform reasonably well across different problem frames, rather than strategies that are optimal for a single frame.

4. **Structured problem characterization**: MPSDM provides a structured approach to characterizing the strategic problem that explicitly accounts for different perspectives on objectives, constraints, and evaluation criteria.

## Challenge # 2: Addressing perspectives in the analysis

### Approach taken by MPSDM to address perspectives in the analysis

Traditional decision analysis typically assumes that decision makers can agree on objectives, criteria, and probability assessments. However, when multiple perspectives are involved, these assumptions often break down. Different stakeholders may have fundamentally different objectives, may weight the same objectives differently, or may have different beliefs about the likelihood of various outcomes.

The MPSDM approach addresses this challenge through several mechanisms:

1. **Explicit representation of perspective-dependent elements**: Rather than trying to force agreement on a single set of objectives or criteria, MPSDM explicitly represents how these elements vary across perspectives.

2. **Uncertainty analysis across perspectives**: The analysis examines how conclusions change as different perspective-dependent assumptions are varied.

3. **Robust strategy identification**: The focus shifts from finding optimal strategies for a single perspective to finding strategies that are robust across multiple perspectives.

4. **Structured stakeholder engagement**: MPSDM provides structured methods for eliciting and incorporating different stakeholder perspectives into the analysis.

## Challenge #3: Dealing with the dimensionality of addressing uncertainties and perspectives

### What is the curse of dimensionality?

The curse of dimensionality refers to the exponential growth in computational complexity as the number of variables or dimensions in a problem increases. In the context of multi-perspective strategic decision making, this manifests in several ways:

1. **Multiple perspectives multiply uncertainties**: Each additional perspective potentially introduces new sources of uncertainty about objectives, criteria, assumptions, and parameter values.

2. **Combinatorial explosion**: The number of possible combinations of assumptions across perspectives grows exponentially with the number of perspectives and the number of uncertain elements within each perspective.

3. **Analysis paralysis**: As the dimensionality of the problem increases, traditional analytical approaches may become computationally intractable or may produce results that are too complex to interpret and act upon.

### How does MPSDM address the curse of dimensionality?

MPSDM addresses the curse of dimensionality through several strategies:

1. **Hierarchical decomposition**: Complex problems are broken down into more manageable sub-problems that can be analyzed separately and then integrated.

2. **Scenario-based analysis**: Rather than trying to analyze all possible combinations of assumptions, MPSDM focuses on a manageable set of representative scenarios that capture the key sources of uncertainty and disagreement.

3. **Sensitivity analysis**: The approach systematically examines which uncertainties and perspective differences have the greatest impact on strategic conclusions.

4. **Robust decision making techniques**: MPSDM employs techniques from robust decision making that are specifically designed to handle high-dimensional uncertainty spaces.

5. **Iterative refinement**: The analysis process is iterative, allowing analysts to focus computational resources on the most important sources of uncertainty and disagreement.

## Challenge #4: Creating strategy from the analysis

The final challenge in multi-perspective strategic decision making is translating analytical results into actionable strategy. This is particularly difficult when the analysis reveals that different perspectives lead to different strategic recommendations.

Traditional decision analysis typically identifies a single "optimal" strategy based on expected value calculations or similar criteria. However, when multiple perspectives are involved, there may be no single strategy that is optimal from all perspectives. Instead, the analysis may reveal:

1. **Trade-offs between perspectives**: Strategies that perform well from one perspective may perform poorly from another.

2. **Robust strategies**: Strategies that perform reasonably well across multiple perspectives, even if they are not optimal from any single perspective.

3. **Contingent strategies**: Strategies that adapt based on which perspective proves to be most accurate or relevant.

4. **Portfolio approaches**: Combinations of strategies that hedge against uncertainty about which perspective is most appropriate.

The MPSDM approach to creating strategy from multi-perspective analysis involves:

1. **Explicit presentation of trade-offs**: Rather than hiding disagreements, the approach explicitly presents the trade-offs between different perspectives.

2. **Robust strategy identification**: The analysis focuses on identifying strategies that are robust across perspectives rather than optimal for any single perspective.

3. **Adaptive strategy design**: Where possible, strategies are designed to be adaptive, allowing for course corrections as more information becomes available about which perspectives are most accurate.

4. **Stakeholder engagement in strategy selection**: The final strategy selection process explicitly engages stakeholders in considering the trade-offs and making informed choices about how to balance different perspectives.

## Types of literatures explored in deriving the MPSDM approach

The development of the MPSDM approach drew upon research from multiple disciplines and literatures:

1. **Decision Analysis and Operations Research**: Traditional decision analysis provides the foundational mathematical and conceptual framework, including techniques for handling uncertainty and multiple criteria.

2. **Behavioral Decision Research**: Research on cognitive biases, heuristics, and the psychology of decision making informs the understanding of how individuals and groups actually make decisions under uncertainty.

3. **Strategic Management**: Literature on strategic planning and strategic decision making in organizations provides insights into the practical challenges of strategy formulation in complex environments.

4. **Policy Analysis**: Research on policy analysis and public decision making offers approaches for handling multiple stakeholders and conflicting objectives in government settings.

5. **Risk Analysis**: The risk analysis literature provides methods for handling deep uncertainty and for communicating uncertainty to decision makers.

6. **Game Theory and Conflict Analysis**: These fields offer insights into strategic interaction and decision making in adversarial environments.

7. **Systems Analysis**: Systems thinking and systems analysis provide frameworks for understanding complex problems with multiple interacting components.

8. **Organizational Behavior**: Research on group decision making, organizational politics, and stakeholder management informs the understanding of how decisions are actually made in organizational contexts.

Each of these literatures contributed key concepts and techniques that were synthesized into the integrated MPSDM approach described in this research.

