# Wainfan (2010) - Multi-perspective Strategic Decision Making: 統合アジェンダ

## 論文基本情報

**タイトル**: Multi-perspective Strategic Decision Making: Principles, Methods, and Tools  
**著者**: Lynne Wainfan  
**発行年**: 2010年3月  
**種別**: 博士論文（公共政策分析）  
**所属**: Pardee RAND Graduate School  
**総ページ数**: 170ページ  

---

## 文書構造アジェンダ

### Chapter 1 - Introduction
- **1.1** Significance of the research
- **1.2** What is Multi-perspective Strategic Decision Making?
- **1.3** Audience for this research
- **1.4** What is meant by perspectives?
- **1.5** Treating perspectives as uncertainties
- **1.6** Goals of this research

### Chapter 2 - Challenges of Multi-perspective Strategic Decision Making, How Others Have Approached These Challenges, and the Principles of MPSDM
- **2.1** Challenge # 1: Framing the strategic problem for analysts and decision makers
  - **2.1.1** What is framing?
  - **2.1.2** Why is framing a challenge for MPSDM?
  - **2.1.3** Approach taken by MPSDM to address the challenge of framing the problem
- **2.2** Challenge # 2: Addressing perspectives in the analysis
  - **2.2.1** Approach taken by MPSDM to address perspectives in the analysis
- **2.3** Challenge #3: Dealing with the dimensionality of addressing uncertainties and perspectives
  - **2.3.1** What is the curse of dimensionality?
  - **2.3.2** How does MPSDM address the curse of dimensionality?
- **2.4** Challenge #4: Creating strategy from the analysis
- **2.5** Types of literatures explored in deriving the MPSDM approach

### Chapter 3 - Methodology and Toolset of Multi-perspective Strategic Decision Making
- **3.1** Methodology
  - **3.1.1** Overview
  - **3.1.2** MPSDM step #1: Characterize the problem
  - **3.1.3** MPSDM step #2: Simplify the problem
  - **3.1.4** MPSDM step #3: Derive the strategy
- **3.2** Toolset of the MPSDM approach
  - **3.2.1** Decision Analysis Tools
  - **3.2.2** Uncertainty Analysis Tools
  - **3.2.3** Stakeholder Engagement Tools
  - **3.2.4** Systems Analysis Tools
  - **3.2.5** Computational Tools

### Chapter 4 - Demonstration of the Approach
- **4.1** The strategic problem chosen
- **4.2** MPSDM step #1: Characterize the problem
  - **4.2.1** Prompt Global Strike scenarios
  - **4.2.2** Conventional Prompt Global Strike options
  - **4.2.3** The analysis tools
  - **4.2.4** The CPGS model
- **4.3** MPSDM step #2: Simplify the problem
  - **4.3.1** Exploratory analysis
- **4.4** MPSDM methodological step #3: Derive the strategy
  - **4.4.1** Strategy Evaluation Across Perspectives
  - **4.4.2** Robust Strategy Identification
  - **4.4.3** Implementation Considerations
  - **4.4.4** Strategic Recommendations

### Chapter 5 – Implementing MPSDM
- **5.1** Practical considerations
- **5.2** How does MPSDM help decision makers agree on strategy despite diverse perspectives?
  - **5.2.1** Key Mechanisms for Building Agreement
  - **5.2.2** Implementation Success Factors

---

## アジェンダ項目統計

- **総Chapter数**: 5章
- **主要セクション数**: 15項目
- **サブセクション数**: 20項目
- **総アジェンダ項目数**: 35項目

---

## 次段階作業計画

各アジェンダ項目について、以下の要素を含む詳細要約を作成予定：

1. **セクション概要**: 各項目の主要内容
2. **キーポイント**: 重要な概念・理論・手法
3. **具体例**: 実例・ケーススタディ
4. **関連項目**: 他セクションとの関係性
5. **実践的示唆**: 応用・実装に関する知見

