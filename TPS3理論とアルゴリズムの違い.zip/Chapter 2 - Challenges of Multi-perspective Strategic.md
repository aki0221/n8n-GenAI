Chapter 2 - Challenges of Multi-perspective Strategic
Decision Making, How Others Have Approached These
Challenges, and the Principles of MPSDM
Decision makers face several challenges when devising strategy, even when their
fellow decision makers are relatively like themselves. As values, beliefs, and expectations
of other decision makers, stakeholders, and adversaries are taken into account, some of
these challenges are made even more difficult. This chapter addresses the major
challenges encountered in coming to consensus on strategy amidst diverse perspectives:
• framing the problem
• addressing perspectives in the analysis
• dealing with the curse of dimensionality
• creating strategy from the analytical results
Much as broader perspectives can bring a richer set of strategic possibilities and
tools to a decision-making process, research from a wide variety of disciplines offers a
selection of approaches to these challenges. The next sections of this chapter describe
each of the major challenges of MPSDM, along with approaches that others have used to
address them. The MPSDM approach to each challenge is summarized, and relevant
principles are proposed.
The chapter then concludes with a summary of the types of literatures explored for
this research, along with key concepts taken from each.
Challenge # 1: Framing the strategic problem for analysts and decision makers

11

What is framing?
The literature offers a range of definitions for “framing” as it relates to decision
making. Entman (1993) defines framing fairly broadly:
To frame is to select some aspects of a perceived reality and make them more
salient in a communicating text, in such a way as to promote a particular problem
definition, causal interpretation, moral evaluation, and/or treatment
recommendation for the item described (p. 52).
A widely-cited description of framing was introduced by Khaneman and Tversky
(1984) as selecting and highlighting some features of reality while omitting others. Nutt
(1998) evaluated 350 strategic decisions to evaluate the process of framing a strategic
issue “by influencing the directions that are set to guide the search for alternatives.” Nutt
found that stakeholders (typically activists in his sample) were the most common
framers, at least initially. “Decision making was initiated by claims from stakeholders that
pointed out salient concerns and difficulties and prompted directions to be set that guided
a search for ways to respond.”
In policy analysis, framing a problem means figuring out how analysts and decision
makers could think about salient aspects of a problem before seeking alternative
solutions. It also includes determining the structure that represents the problem amidst
multiple criteria and uncertainty.
Why is framing a challenge for MPSDM?
Individual stakeholders may consider one aspect of a system to be most salient but
when decision-making groups or stakeholders consider different perspectives, it may be
difficult to “get on the same page.” Defense planners might think of the problem in terms
of meeting future military objectives, but Congress must determine funding priorities, and
allies must consider political feasibility. As groups consider more perspectives in their
decision making process, it becomes hard to agree on common frameworks. As
expectations about the long-term future diverge among strategic decision-making groups,
it is easy to understand how reasonable individuals could differ in how they think about a
problem.
12

In addition to differences in ways that decision makers think about a problem,
several studies have identified different decision making styles. Alternative judgment and
decision-style taxonomies exist, but Hammond et al. (1997) describe empirical studies
that show decision modes range from rational to intuitive. Hitt and Tyler (1991) provide a
useful summary that includes intuitive or quick judgments (sometimes called naturalistic
decision making); rational-normative, external control, and strategic choice models.
Khatri and Ng (2000) compare the relative prevalence of an intuitive strategic
decision making style with the rational-analytical style in business decisions. In their
interviews of senior managers of computer, banking, and utility organizations, they found
that intuitive processes are used often in organizational decision making. Interestingly,
intuitive processes were positively correlated with organizational environment in an
unstable environment, negatively related in a stable environment.
Sometimes the presence of a group affects the criteria that individuals use for
decisions. Janis’ famous (1982) study of seven major governmental decisions identified
the concept of Groupthink, where the need to be included in the decision-making group
can outweigh the rational expected outcome of the group’s decision.
Eisenhardt and Zbaracki (1992) review the strategic decision making literature,
identifying the dominant paradigms and reviewing empirical support for each. They
conclude “that decision makers are boundedly rational, that power wins battles of choice,
and that chance matters. It is also clear that a synthesis of bounded rationality and
political perspectives provides a compelling description of strategic decision making.”
Davis, Kulick, and Egner (2005) point out that there are advantages and
disadvantages to different decision-making styles. They identify approaches to synthesize
decision processes with some virtues of both rational-analytic and naturalistic styles,
pointing out ways that a good staff could work with an intuitive decision maker by finding
critical assumptions, building in contingencies, etc.
In what has been called the “standard reference and textbook for many years to
come”(Brewer, 2009) on risk assessment, the National Research Council Committee
(NRC) on Improving Risk Analysis Approaches Used by the U.S. EPA (2009) concluded
that environmental problems are socially constructed and therefore depend on human
13

values, which are mediated by diverse perceptions. Four chapters are devoted to human,
institutional, and “irrational” components of risk assessment. The committee cites a twodecade effort to deal with nuclear power plant waste at Yucca Mountain, Nevada and
conclude that the issue is not as simple as rational calculation of leaking radiation from
storage canisters. Instead, the issue is more about fears and lack of trust among the
general population. They urge decision makers to confront and manage the perceptions
of those affected rather than the rational expectations and technical assessments.
Another cognitive process that individuals use relates to simplifying complexity. As
problems include more variables and relationships between the variables, decision
makers frequently make use shortcuts, or heuristics to reduce a problem down to what
they conceive as the bare essence of a problem. (Simon and Newell 1958; Kahneman,
Tversky, and Slovic 1982; Gigerenzer, Todd, and the ABC Research Group 1999). These
simplifications often have a basis in human judgment, experience, or intuition. In an
interesting example of a heuristic, Rabin and Weizsacker (2009) demonstrate what they
call “narrow bracketing.” That is, decision makers sometimes evaluate subsets of choices
in isolation, resulting in decisions whose outcome is dominated by other possible choices.
They also find that the percentage of people exhibiting the suboptimal choices exhibited
in narrow bracketing is higher when the stakes are high, implying a higher chance of
narrow bracketing for strategic decision making compared with operational or tactical
decision making.
In summary, the research shows that individuals often have different ways of
thinking about problems, sometimes analytical, sometimes not. As problems involve more
variables and the associated relationships between the variables, individuals and groups
may rely on simplified cognitive models of the system being evaluated. 7
Thus, one underlying principle of MPSDM is as follows:
Principle #1: Perspectives (values, beliefs, and expectations) are as important to
strategic problems as more objective criteria.
7

Davis and Hillestad introduced alternative “views or perspectives” in early work on strategic portfolio analysis; see, e.g.,
Hillestad and Davis (1998), p. xv.

14

Approach taken by MPSDM to address the challenge of framing the problem
This section will describe the four aspects proposed by MPSDM to frame the
problem: The multicriteria scorecard; the use of return, risk, and cost as generic criteria;
characterization of performance with box-and-whisker plots; and characterization of timescale and factor controllability.
Aspect #1: The multicriteria scorecard
MPSDM proposes an analytic framework which takes into account more subjective,
or “soft” factors associated with perspectives. Strategic problems, by their nature, are
complex and deeply uncertain and therefore analytic exploration of the options is called
for in order to have adequate conceptual scope while also usefully simplifying and frame
the problem for decision makers. As will be described later, MPSDM proposes several
ways to simplify the strategic problem which are based on an analytic framework, while
taking into account diverse perspectives.
The multicriteria scorecard methodology is quite common in the multi-criteria
decision making literature. Originally applied to U.S. Department of Transportation policy
in 1971 (Chesler and Goeller 1973), and to environmental policy (Goeller et al. 1977).8 A
multicriteria scorecard shows a score for each option for each criterion. Sometimes
quantitative results are shown in a scorecard, with each option represented as a row and
each criterion in a column. Often a simpler color code is used in the scorecard decision
aid. The colors typically represent results of quantitative analysis, i.e. some numeric
score rates a “green” vs. a “yellow” score. Davis has done extensive research in framing
a problem for decision makers with scorecard methodologies (Davis 2002; Davis and
Hillestad 2002; Davis 2008; Davis, Johnson, Long and Gompert 2008). A sample
scorecard from a defense procurement example (Davis, 2008) is shown in the figure
below.

8 Different kinds of scorecards are commonly used for enterprise management to perform business evaluation (Kaplan

and Norton 1996).

15

Measures of option goodness: effectiveness
(color) by scenario class and overall risk

The Options

Figure 2.1 - Scorecard Result. Order of
goodness (least to best) is Red, Orange,
Yellow, Light Green, and Green
In the scorecard presentation above, the first column lists the options being
considered to achieve capability for a Prompt Global Strike. The subsequent columns
indicate the score for each option against each criterion. In the figure above,
effectiveness in each of six scenarios is shown9, as is the overall risk for each option.
Scores are color-coded, with the worst score interval indicated by a red rating, followed
by orange, yellow, light green, and green. The color codes are also indicated in the
upper right hand corner of each cell of the scorecard by their initial. This initial helps
color-blind individuals and those reviewing a black and white copy of the scorecard to
interpret the results. Scorecards allow quantitative comparison of multiple options
against multiple criteria.
9

The term scenarios in this research refers to a specification of a potential mission and the conditions of that mission

16

Aspect # 2: Return, risk, and cost as generic criteria
The scorecard framework described in Figure 2.1, above, implies that there are a set
of top-level measures that can be identified for decision makers and analysts. Note from
the figure that Davis et al. (2008) have identified a type of return (performance in a
number of scenarios) and risk as two generic,10 top-level option evaluation criteria. Return
(operationalized in the figure as measures of effectiveness), risk, and sometimes cost are
used often in Davis’ research (Davis & Dreyer 2009; Davis et al. (2008); Davis, Shaver,
and Beck (2008); Dreyer and Davis (2005)).
This return/risk framework also has a strong basis in the financial management
literature. Researchers and practitioners in this domain have long had to deal with
simplifying an uncertain and complex problem and expressing findings in terms that are
accessible to decision makers with different levels of knowledge or interest. These
simplifying considerations have been incorporated in much of Davis’ portfolio analysis
work (Davis & Dreyer 2009; Davis et al. (2008); Davis, Shaver, and Beck (2008); Dreyer
and Davis (2005)).
In his seminal work on Portfolio Theory, Markowitz (1952) distilled risk and return as
two useful dimensions to consider in investment decisions. Subsequently, other financialworld portfolio theories have been developed: Modern Portfolio Theory (Elton and Gruber
1991; Elton et al. 2006); Post-Modern Portfolio Theory (Swisher and Kasten 2005) and
Focused Portfolio Theory (Hagstrom 1999). All of these branches of portfolio theory
feature a small set of summary-level indicators to guide investment decisions.
MPSDM proposes using the two-dimensional risk/return framework long used in
Davis’ research and financial literatures along with the cost of each option as three
generic, summary-level criteria. For this research, it is assumed that the options are all
feasibly affordable, but that the preference for an option may be affected by its relative
cost.

10 The term generic here is meant to imply “common.” These generic dimensions are envisioned to be useful for a variety

of MPSDM applications. As will be discussed later, the subdimensions, or lower-level measures that aggregate up to
the top-level dimensions are assumed to be application-specific.

17

Another benefit of using the return, risk, and cost framing (along with drilling down to
lower-level dimensions as described later) is that extensive research has been
performed, and will be conducted on ways that people compare these three fundamental
variables. The use of these three summary measures may allow the MPSDM approach to
benefit from some of the useful insights coming from this important research.
There are some challenges to using return/risk/cost framing, however. The practical
usefulness of this simplified framing of returns, risk, and cost depends on many factors:
the decision makers’ interest in details, the “spread” of the top-level scores once
uncertainty is taken into account, and the insights that can be shared about what drives
the return, risk, and cost, among other factors. Aggregate measures may be “too
aggregated,” offering little or no insight into the lower-level factors that affect choice of
strategic options. As will be shown in Chapter 4, the top-level scores may be useful for
describing the forest of option performance, but not as helpful in understanding why
options perform as they do. In addition, although MPSDM prescribes three generic toplevel dimensions (return, risk, cost) as financial theory recommends, the strategic problem
is often more complicated than the financial one. First, return and risk are not typically
measured in monetary terms, especially as the number of subdimensions increases. It is
not always obvious how to combine, or aggregate measures that are in fundamentally
different units. In addition, decision makers may have special responsibilities that are not
easily compared or traded.
Another challenge of this framework shows up in the risk dimension. Financial risk is
often measured in terms of variance of price, a very simple measure compared with the
multi-dimensional concept of risk that decision-makers with diverse perspectives would
need to consider. In this research, risk is defined as a measure of concern that an
option’s actual performance might be less than indicated by the expected return. It
reflects consideration of both likelihood and consequence of worse-than-expected
performance. For MPSDM problems, there often does not exist historical data to provide
an empirical basis for calculations of risk that are often commonly used in financial
assessments.
18

MPSDM proposes these top-level factors not as a replacement for more detailed
characterization of the system, but for two purposes: first, as a structural foundation for
the scorecard criteria; and second, as a way for the analyst and possibly the decision
makers to get a forest-level view of the system before exploring the trees.
Let us turn next to defining what is meant here by returns. Strategic decision making
by its nature typically allocates resources in the present in order to prepare for the future.
In financial management, returns can be defined and evaluated in monetary terms. In
strategic decision making, the returns are typically of a different nature, for example
market share, employee good will, effectiveness in different scenarios, perception of
those who provide funding, etc.
The challenge then is to frame the sub elements11 of return in a way that will cover
the values or criteria that are important to decision makers. Since these values are often
non-monetary, the subdimensions of return must be crafted to fit the problem at hand.
What lower-level factors go into the top-level measure of return? Although the
methodology, principles, and toolset of MPSDM are not restricted to the use of scenario
performance in return dimensions, scenario methodology is quite common in corporate
planning (Shoemaker 1992). The scenario framework is used in the MPSDM example
illustrated later.12
The use of scenarios in order to bring concreteness and clarity about uncertainty to
decision makers has a long history in research. Herman Kahn pioneered the use of
scenarios in the 1950s at RAND to aid U.S. military planning (DeWeerd 1967). Kahn
combined detailed analysis with imagination to produce “future-now” narratives, reports
written as though the author were in the future (Chermack, Lynham, and Ruona 2001).
Kahn and Wiener introduced scenario planning to the business community in 1967 (Kahn
and Wiener 1967). More recently, Davis’ multiscenario analysis (Davis 1988; 1994)
approach has been applied to defense-related planning and the RDM line of research has

11

Sub elements can be thought of as underlying dimensions

12 In some literatures, scenarios are known as “worlds” or “states of the world.” Much of the scenario literature focuses on

“gaps” between what is expected to exist in the future and what will be needed to meet the demands of a particular
scenario, as in “will we have the capability to succeed if this scenario occurs?”

19

devised methods to discover “policy relevant” scenarios: Sets of assumptions that make a
difference to an outcome of interest (see Groves 2005 for more history of RDM).
Outside the research world, scenario planning is quite common in practice. A major
survey showed that over 50% of Fortune 500 companies used scenarios in their planning
as early as 1982 (Schoemaker 1992). Scenarios are a useful for a number of reasons.
Before scenario development, it was common to model the system with uncertainties
embedded the model, sometimes in probabilistic terms. Scenarios present a number of
“models of the future” to decision makers, each representing possible resolutions for
some of the uncertainties with probabilistic claims. This decomposition of uncertainty into
distinct states helps individuals to cope with complexity (Schoemaker 1992). In addition,
scenarios provide a device for bringing concreteness to a problem. What psychologists
call the availability heuristic—the ease with which one can bring to mind exemplars of an
event—helps people pay attention to circumstances they can recall from memory or
easily imagine (Tversky and Kahneman 1973; Bettman 1979). Scenarios are one way to
help decision makers imagine the future more easily.
Along with return, risk, and cost, a useful fourth dimension might be upside potential,
in a way that might be a symmetric analog to risk. Davis, Kulick, and Egner (2005) argue
that ignoring upside potential can lead to seriously flawed decision making because it
biases the group towards risk reduction without considering opportunities. The
methodology presented in this research does not preclude evaluation of upside potential
as a separate criterion, and in fact allows for any top-level measures of return. In fact, by
identifying cases of extremely favorable results graphically in the annotated box-andwhisker plots13 and exploring the conditions under which they occur with data-mining
techniques with exploratory analysis (both of which will be detailed later), upside potential
can be explicitly assessed in the MPSDM approach.
There are several ways to characterize risk into its lower-level dimensions. In the
financial world, risk is often associated with volatility (Markowitz 1952). In the defense
procurement example presented later, overall risk might be composed of several lower13 i.e. outliers or areas of extremely high return or areas of extremely low risk or cost. Similarly, the opposite return and risk edge of the

box-and-whisker plots are important because it is precisely these vulnerabilities that adversaries will seek out and exploit.

20

level measures: There may be a risk of funding not being continued for an unpopular
weapon system; collateral damage in wartime may be higher for one option compared
with another; or another option may be risky due to the potential use of the capability to
be misinterpreted in a crisis as a nuclear attack (National Research Council, 2008),
among other considerations.
Cost can also have lower-level dimensions, which would be important if there are
significant uncertainties in some aspects of the system’s cost estimates. Cost dimensions
could be, for example, fixed and variable; time-related (near/long term, by year, etc.);
proportion of costs allocated to different bill payers, including allies; and the “pots of
money” associated with funding, among other dimensions. Another factor to consider is
any cost constraint: what are the budgetary limitations? Constraints can be explicitly
included in the analytical model, or explored to see the conditions under which constraints
are exceeded. Depending on the problem at hand, lower-level cost dimensions can be
defined to address these factors, as well as areas where the cost estimates contain more
or less uncertainty.
Although the illustrative example of MPSDM given in Chapter 4 treats cost factors as
relatively more certain than other factors within return and risk dimensions, real policy
issues often have highly uncertain cost factors. Consider the current national health care
debate: although decision makers agree on the goal to improve the quality of health care
in the United States, much of the debate has been about cost factors. For instance, highly
uncertain factors include the total cost, how the costs are allocated to different bill payers,
whether the costs will be near term, long term, or spread out in time, whether the total
cost will increase compared with the current policies, etc.
Even in defense acquisition policy, where historical data can provide a basis to
derive cost estimates, policy makers must consider sub-dimensions within the cost
dimension: near-term vs. long term; cost sharing with allies; which programs to cut in
order to afford new ones; cost inflation or risk; life cycle costs; operating vs. support costs,
etc.
The concept in MPSDM is to define a number of return, risk, can cost
subdimensions that are relevant to the strategic issue at hand. Depending on the types of
21

uncertainties or the factors that are most salient to the decision makers or stakeholders, a
number of subdimensions can be defined and assessed for each option. Identifying and
communicating the subdimensions of return, risk, and costs can help decision makers
understand the scope of what was considered, can help analysts to identify specifically
how one option differs from another in return, risk, and cost, and can focus discussion on
more finite aspects of return risk, and cost, compared with a top-level measure of each.
Thus, the initial analytical framework used for MPSDM is a scorecard of measures
and submeasures of returns, risk, and cost for each feasible, action-based option, with
the objective to avoid the necessity of agreeing on values, beliefs, and expectations while
evaluating each option against the others.
The risk/return/cost scorecard framework offers several advantages over other
methods to summarize analytical results and elicit discussion of relative option
performance.
1. It presents a summary of all options against all criteria simultaneously,
allowing decision makers to identify each option’s area of good and poor
performance.
2. This visualization has been used in a variety of domains for decades, and is
familiar to decision makers.
3. The scorecard shows explicitly which options and criteria were evaluated,
allowing the decision makers to understand the scope of the strategic
analysis.
4. The scorecard methodology provides a top-level structure that can be used
for the more detailed strategic analysis. Each criterion can be divided into
lower-level criteria that are evaluated for each option. Thus, the scorecard
visualization tool provides a framework that can be used in what is called a
multiresolution model. This model structure will be discussed in more detail
later.
5. The scorecard methodology, as implemented by Davis et al. (2008) allows for
real time “drill downs” on individual criteria. These drilldowns can help
decision makers understand the lower-level factors in a multiresolution model
22

that drive the higher-level aggregate score. Not only can this drill down serve
to share insights, but it may elicit a discussion of the likelihood or
characterization of those driving factors.
There are several challenges to using a scorecard methodology with MPSDM,
however.
1. Good scorecard technique, particularly selection of the evaluation criteria to aid
decision making, requires a mix of art and science. A scorecard can easily
become too “busy” with multiple criteria and options, making it difficult to gain any
insight from the scoring presented. The scorecard can be simplified if a few
aggregate or summary-level scores per criterion can be presented for each option,
but showing measures that are too highly aggregated can obfuscate insight.
2. If decision makers within the group vary in their perspectives, then they may also
vary differently in their knowledge of, or interest in, technical details. One person
may have deep knowledge of the problem, and need to understand and validate
the detailed technical assumptions and parameters in an evaluation. Another
individual may have only a top-level awareness or interest in the technical aspects
of the problem.14
3. There may be no simple set of criteria that the group members all agree are
important.
4. Even after analysts have resolved matters of fact, decision makers may disagree on
the value of an absolute score that merits a specific (red, yellow, green) rating. For
instance, one criterion might be viewed as “unacceptable,” or given a red score by
an individual with one set of beliefs, or a “yellow” by another with a different set of
beliefs. Current economic policies, for example, are expected by some to be
successful and others to be counterproductive.

14 As perspectives become more diverse, wider differences can be expected in the interest in understanding the details

of an analytical model. Davis has had good results with the technique of real time “zooms” to lower-level results in a
hierarchical model that explain the top-level scores.

23

5. The analyst must decide and communicate what the score for each option and
criteria represents. One way to do this is to show one or more edges of the
distribution, for instance the best or worst case results (or both, using two colors or
two columns for each criterion). Another alternative is to show the central
tendency, such as the mean of the measure being evaluated. This central
tendency may blur some important combinations of assumptions that might give
plausible, extreme results. Often these are the exact combinations of variables
that adversaries will seek to exploit. Sometimes the central tendency can be
annotated to give more information.
Aspect #3: Characterization of the performance with box-and-whisker plots
Of the scorecard challenges above, items 1-3 will be addressed subsequently. Item
4 (decision makers may disagree on the value of an absolute score that merits a specific-red, yellow, green—rating) and Item 5 (the analyst’s decision on what the score
represents, a central tendency or some other measure) can be addressed in some cases
by another framing aspect proposed by MPSDM, the annotated box-and-whisker plot.
An example of an annotated box plot is shown below.

24

Figure 2.2 - Example of an Annotated Box-andWhisker Plot
Starting at the top of each option’s graph, the option is described in words. The Y
axis shows each option’s return or risk scores (although this score could be for any
subdimension, let’s assume for the moment that it is an Overall Return score) for each
option. Lower-level criteria that went into the Y-axis score (Overall Return score) are
described in words along the X-axis. (Here, lower-level criteria might be effectiveness in
scenarios 3, 7, and 8). Factors contributing to each option’s relative performance are
described in comments within the plot. Cost for each retained option is listed on the Xaxis. 15

15

As described earlier, the three generic dimensions recommended for the decision-makers’ consideration are return,
risk, and cost. What is illustrated in this diagram, and in the illustrative example later, is that cost is treated as a simple
variable. That is, it is represented on charts but cost uncertainty per se is not explored as an uncertain variable, and
elements of cost are not modeled in detail. MPSDM allows for different kinds of cost to be treated as an uncertain
variable, and modeled using multiple resolutions. The examples shown for uncertain returns and risk demonstrate the
procedure that would be used. The “retained” options and criteria, as described later, are the options that are not
dominated by others, and the criteria which differentiate the options.

25

The boxes and lines on the graph represent statistical results from running a large
number of “cases”, where assumptions are allowed to vary together. The upper edge of
the box represents the 75th percentile score, the lower edge of the box is the 25th
percentile score, with the difference between these scores being defined as the
interquartile range. The bottom horizontal bar outside the box (the lower whisker) is 1.5
times the interquartile range below the 75th percentile. The top horizontal bar outside the
box (the upper whisker) is 1.5 times the Interquartile range above the 25th percentile. The
heavy horizontal bar inside each box represents the median score. Outliers, if they exist,
are defined as points outside the whiskers and shown as hollow circles.
It is important to note that it is not possible to deduce true statistical results for these
outcomes because no effort is made to accurately represent the distribution of uncertain
assumptions, nor are assumptions necessarily independent from each other. However, as
will be seen in the illustrative example, box-and-whisker plots can be used to gain firstlevel insight into factors that drive one option to perform relatively better or worse than
others.
Aspect #4: Characterization of time-scale and factor controllability
Thus far three aspects of an MPSDM framework have been described: a
multicriteria scorecard framework; top-level criteria of return, risk, and cost as a useful
way to think analytically about the problem; and an annotated box-and-whisker plot to
characterize performance in order to distill results down for decision makers and to focus
discussion on factors that drive option choice. A fourth framework aspect that MPSDM
introduces is a heuristic that uses the analytical results to identify the best type of strategy
to be used. MPSDM postulates that time frame and controllability (the amount of control
the decision makers have) of the factors driving option choice are the two generic,
summary-level measures that are useful in determining the best type of strategy to
pursue. This will be discussed further in the next chapter.
Of course this heuristic assumes that the factors driving option choice can be
identified. As problems become more complex, either because of the high number of
perspectives, or the large numbers of uncertain factors and relationships, it is not always
26

obvious which factors drive the outcomes of interest to decision makers. This challenge is
best met with exploratory analysis (EA), which will be described in more detail later.
Challenge # 2: Addressing perspectives in the analysis
Recall from the previous chapter that perspectives have been defined in this
research as values, beliefs, and expectations. We are still faced with the problem of
evaluating the options against soft, or non-quantifiable risk/return/cost criteria. This is
typically handled in the multi-criteria decision making literature by leaving fundamentally
different types of criteria separate, coming up with a precise score for each criterion for
each option and letting the decision makers discuss which criteria are of higher value.
The problem with this approach is that in a multi-perspective decision-making
environment, this discussion may not lead to consensus. Individual decision makers may
focus on one column of the scorecard (or the score that separates a red rating from a
yellow) and never come to agreement on which is more important.
Approach taken by MPSDM to address perspectives in the analysis
The MPSDM approach was designed specifically to address the challenge of
evaluating options against soft, or perspective-based criteria. As will be described next in
more detail, many types of perspectives can be represented parametrically in an analytic
model.16 These “perspective parameters” can be explored in parallel with more objective
parameters to find the factors that affect the choice of options.
Incorporating values into the analysis
As defined earlier, values are what individuals consider important; what they value.
A good example of an approach to include values in the analysis comes from the socalled balanced scorecard methodology used in business. Kaplan and Norton (1996)
define four generic dimensions, or values to measure companies: The financial dimension
(how owners view the company); the customer relationship dimension; the business
16 Davis and Hillestad introduced alternative “views or perspectives” in early work on strategic portfolio analysis; see,

e.g., Hillestad and Davis (1998), p. xv.

27

process dimension; and the learning and innovation dimension. Scenario approaches
propose performance in a number of scenarios, or sets of assumptions, as criteria. Here,
decision makers must decide the relative value of the different scenarios: How likely are
they? Is one a better measure of how well the organization will do in the future? Are there
important criteria that the scenario set ignores? What if two or more criteria conflict? What
if one criterion is so challenging that it would cost an inordinate amount of money to meet
it? All of these questions relate to the decision makers’ sets of values, and are not easily
answered, especially before the performance of the system is well understood.
Using the scorecard framework, one type of value is operationalized in MPSDM as
the choice of criteria, or column definitions against which each option will be evaluated.
Sometimes decision makers can agree on a set of criteria, but sometimes they can’t
agree upon important criteria, or relative importance. Sometimes the decision makers
themselves don’t know ahead of the analysis, which criterion is paramount. Perhaps the
validity of a criterion “depends” on other factors which the decision makers can’t
characterize before the analysis. These factors could include the cost, the relative tradeoffs between meeting one criterion vs. another, what the adversary will do in response to
the strategy being developed, etc. Although many of these factors can be refined with an
iterative approach, and by re-visiting strategy in light of new evidence, some types of
values can be modeled analytically. The choice of initial criteria is clearly an attempt at
finding a common set of values for the decision makers to use initially.
Similarly, the relative importance of each of the criteria is a relative value that can be
represented analytically. Weighted sum or more complex logic to aggregate overall
return, risk, and cost can be analyzed and explored to determine which parameters (i.e.
weights or logical variables associated with each aggregation method), if any, drive the
choice of options.
By discussing the results of the analytical exploration, it is sometimes possible to
elicit decision makers’ values. For instance, if one option has slightly more return but
significantly more risk than another, the decision makers may face the risk/return tradeoff
at that point. The MPSDM methodology proposes starting with a broad criteria set initially,
one that covers the range of factors the decision makers’ view as important. The
28

methodology explicitly analyzes different values, winnows them down to include the set
that differentiates the options, focuses discussion on the values that affect relative option
superiority, and includes an iterative approach to refine the analysis of the options if new
values are elicited in the face of plausible return, risk, and cost.
Incorporating beliefs into the analysis
Beliefs, or views about how the system works, define relationships between factors.
Examples include a set of if/then relationships, correlations, and more complex
associations and models. One type of belief is the likely actions of an adversary in
response to a strategic option being picked. These actions are influenced by a variety of
factors: An adversary’s perceptions of the action; their capabilities; their expectations of
future actions by the decision makers’ organization and its associates; the adversary’s
perception of others’ perceptions, and so on. Beliefs can be based on history, conjecture,
intuition, or logic and thus can differ significantly within the decision making group. When
an adversary holds private information, the beliefs about their responses within the
decision making group may differ significantly from what actually occurs.
Beliefs are operationalized analytically in two ways in MPSDM. The first is by
different mathematical models or algorithms representing relationships between factors.
Often analysts have incomplete information when formulating these models and must
insert their own beliefs into the process. The second way beliefs are represented in
MPSDM is by the choice of plausible range and distribution of the uncertain variables for
exploratory analysis. For example, the analyst may believe that a product being
introduced has a performance within a given range, or that the risk of misinterpretation of
intentions by an adversary could be quite high. Often models can be refined (for
instance, to include additional related factors) or tested to more accurately specify
performance.
MPSDM proposes two tools for incorporating beliefs explicitly into the strategic
problem analysis. The first is the multiresolution model (MRM), which will be described in
detail later. In an MRM, a model element’s resolution can be refined as exploratory
analysis finds that some factors affect the choice of options more than others. The second
29

is through the use of logical “belief variables” as uncertain variables. During the numerous
runs of a computational experiment, the belief variables are assigned different logical
values.17 For instance, if three different models of an adversary’s response are plausible,
a logical variable can be assigned to take on the values 1, 2, or 3. Depending on the
value of that variable in a particular run of the computational experiment, the algorithm
can pick the associated model to use.
A related belief can be considered more analytical: How two or more lower-level
measures should be aggregated and scored “upwards” in the multiresolution model. As
described earlier, aggregation and scoring algorithms are sometimes obvious (as in the
case of probabilities) and sometimes they are a matter of beliefs. Aggregation beliefs in
MPSDM are handled as just described, with logical variables that define the different
plausible aggregation and scoring methods. Note that aggregation methods define how
two or more variables should be combined into a higher-level result; scoring methods
define the result according to the result’s scale and take into consideration nonlinear
scoring thresholds.
The final type of belief that MPSDM defines relates to the scoring thresholds in the
colored scorecard of Figure 2.1. It is sometimes a matter of perspective, for example,
which score should rate and unacceptable (or a red) rating for a particular option and
criterion. As before, these thresholds can sometimes be bypassed by using annotated
box-and-whisker plots or can be treated as uncertain parameters, varied in different runs
of the computational experiment, and explored analytically to identify the factors that
affect option superiority.
Incorporating expectations into the analysis
Recall from the previous chapter that expectations are defined in this research to be
associated with how factors may change in the future. Strategic decision making
considers time frames that are longer than operational or tactical decision making. As
uncertainty grows, sensitivity analysis around some presumed baseline projection
17 In this dissertation, the term “run” is the same as the term “cases” and refers to a set of independent variables

associated with a run of the computational experiment used in exploratory analysis.

30

becomes less applicable for three reasons: First, large ranges of plausible values of
factors necessitate identifying plausible combinations of uncertain parameters that
produce extreme results. Second, nonlinear effects may be introduced. Third, timechanging factors in MPSDM include not only objective ones, but also values and beliefs.
As will be described in the next section, some types of values and beliefs are best
represented analytically as different structural models, for which sensitivity analysis is not
applicable.
Parameterizing perspectives
The table below presents some examples of how many types of values, beliefs, and
expectations can be represented by model parameters.

31

Table 2.1 - Types of Perspectives and How they
Can Be Parameterized in a Model
Type of Perspective (Value,
Belief, or Expectation)
Value 1: What is important to
consider in evaluating returns, risk,
or cost?
Value 2: How one criterion is
valued over another
Belief 1: How some part of the
system works

Belief 2: Capabilities and risks,
either of the decision makers’
organization or of an adversary’s
Belief 3: How two model elements
should “best” combine to create a
higher-level assessment
Belief 4: What is an “unacceptable”
or “good enough” result of some
element in the model?
Expectations: how a factor is likely
to change in the future

How it could be
parameterized in the model
Choice of return, risk, or cost
subdimensions18
Aggregation algorithms and
parameters used to roll up
subdimensions of return, risk, or
cost into higher-level measures
Logical variables associated
with different structure elements
of the model. MPSDM allows a
number of different models to
be explored simultaneously
Plausible range or distribution of
input parameters (or
assumptions) used in
exploratory analysis
Choice of aggregation rules and
parameters
Scoring algorithms and
thresholds
Plausible range or distribution of
input parameters (or
assumptions) used in
computational experiment

Although returns and risk have been identified as generic summary-level
dimensions, what are the lower-level subdimensions of each? For the balanced scorecard
example, what comprises financial performance? Which time frame should be
considered? As Value 1 in the table above indicates, the choice of subdimensions reflects
the lower-level criteria the decision makers value.

18

Cost could be considered along with return and risk, but here it is assumed that it is less uncertain.

32

As indicated in the discussion of multicriteria scorecards, much research has been
done in evaluating performance against multiple scenarios, so scenarios might be a good
choice depending on the problem at hand. Clearly the domain and the views of the
stakeholder in a specific problem must be chosen to consider as broad a set as possible,
at least initially. The approach taken in MPSDM is to initially include many subdimensions
of returns as feasible and then identify and winnow down the criteria to the
subdimensions that matter to the outcomes of interest.
Value 2, how one criterion is valued over another, is conceptually more difficult. As is
often seen in the multi-criteria decision making literature, the concept of assigning weights
to each subdimension of risk or return is useful. An extension of multi-criteria decision
making theory that is offered here is to assume those weights are uncertain variables for
the computational experiment. Another extension of multi-criteria decision making theory
is the assumption that other aggregation rules besides a weighted sum are possible when
rolling up any lower-level measures into higher-level results. The following types of
aggregation rules can be easily incorporated into any hierarchical model (Hillestad and
Davis 1998):
• Weighted Sum
• Multiplying (as in logical “and” considerations)
• Logical “or” considerations
• Taking the highest value
• Taking the lowest value
• Nonlinear thresholds
The weighted sum approach is well known, but there are situations where other
aggregation rules might be called for. A multiplying rule would be used if two elements
were both necessary in order to achieve a higher-level effect. For instance, if in order to

33

field a new weapon, two technological capabilities must be operational at the same time,
a failure of either one would mean that the system would not be available when needed.
Logical “or” combinations are a bit more difficult to consider conceptually. They may
occur, for instance, if a weapon could be carried on either one of two or more platforms.
Either platform A is available or platform B is available, and the appropriate aggregation
methodology for that situation would be to use an “or” aggregation rule that selects the
“best” platform. This is another area where multiresolution modeling pays off. Trying to
aggregate two factors that are related by an “or” condition by, for instance, averaging
them, obfuscates the true behavior of the system. Consider the distribution of a variable
that was a result of an averaging aggregation rule vs. an “or” rule. The “or” rule might
produce a bimodal distribution, corresponding to the outcomes associated with the
variables being aggregated, whereas an averaging rule would more likely produce a
unimodal distribution. Explicitly allowing this “or” condition gives a more accurate and
useful model.
It may be appropriate to take the highest value or lowest value of two lower-level
measures when risk is being evaluated. For example, this approach might be used by a
decision maker to combine development risk with risk of stable funding. The combination
method, as described in the table above, is a matter of perspective. If one is particularly
risk-sensitive, it might make sense to take the worse of the two (or more) sub elements of
risk as the aggregate measure. Other individuals may believe that an average is close
enough, or even better, especially if there are many underlying measures to consider.
A more complex concept of rolling up lower-level measures into higher-level ones is
a nonlinear threshold scoring method. The figure below illustrates this.

34

Figure 2.3 - Nonlinear Threshold Scoring
Postulate that a higher-level score in the multiresolution model was related a lowerlevel parameter, but in a nonlinear fashion such as a floor or ceiling effect. For example,
in a technology development, some level of performance might be considered “good
enough” to meet a higher-level requirement. Any performance increase above that
threshold level would be of little or no benefit. Any number of nonlinear functions could
be represented mathematically in the model, but a simple example is shown in the figure
above. Here, only four nonlinear threshold parameters need be specified: the threshold
and goal values of the lower-level parameter, and the scores associated with those
threshold and goal values in the resulting higher-level result. Since “good enough” may be
a matter of perspective (as might be the associated score), these parameters can be
represented in the model as uncertain variables and explored to find conditions where
they affect outcomes.
Similarly, recall that a scorecard has different colors associated with the various
levels of returns or risk. The value of the parameter associated with a “red” rating is a
matter of perspective. This is yet another example of a perspective parameter that is
easily treated as an uncertain parameter in exploratory analysis.
For cases like this, where the scoring and aggregation methodology itself is a matter
of perspective, MPSDM takes the approach of considering many plausible scoring and
aggregation rules, assigning them each a logical value, and running the computational
35

experiment on the full range of plausible scoring and aggregation rules. Exploratory
analysis can then discover which rules “matter”, or affect the outcomes of interest.
Referring back to Table 3.1, this same method also applies to Belief 1: how some
part of the system works. For different beliefs, or views of how the system works,
alternate models of lower-level elements can be created. Each model can then be
assigned a logical value. For some of the runs in the exploratory analysis, model A will be
used and other runs will use model B and so forth.
The final rows in the table above pertain to beliefs and expectations about the future
that are uncertain. The approach here is similar to the previous discussion: The ranges
(or distributions, if they can be derived) are treated as uncertain variables, assigned
different values for different runs in the computational experiment, and assessed using
exploratory analysis to see which parameters matter and under what circumstances (i.e.
for what ranges of parameters) they affect the choice of options.
The uncertain variables, or assumption parameters in the model, can be
continuous, discrete, or logical. Logical variables can, for instance, define which sets of
parameters or which algorithm should be used for a particular run of the computational
experiment. Thus parametric as well as structural variation can be explored. As
mentioned before, these parameters include objective factors (e.g. those defined by the
laws of physics) and more subjective, or perspective-related factors such as the relative
value of one criterion over another, beliefs about the relationships between elements of
the system, or expectations about the future.
This approach builds from the next principle used in MPSDM research:
Principle #3: Many types of perspectives can be parameterized and evaluated in
parallel with more objective factors.
How is MPSDM’s analytical treatment of perspectives related to other treatments?
MPSDM drew heavily from two lines of research in its approach to perspectives.
Davis et al. (2008) consider logical groupings of subjective factors as one type of
perspective. For instance an “optimistic assessment” could include favorable values of
36

sets of uncertain parameters. As will be detailed later, MPSDM does not preclude this
logical grouping, but also includes the capability to assess individual measures of
perspectives, in order to determine which ones affect the choice of options.
RDM (Lempert et al. 2003) defines an XLRM framework that can be mapped to
many of MPSDM’s types of values, beliefs, and expectations. Exogenous factors, those
outside the decision-makers’ control, are most closely related to MPSDM’s concept of
expectations about the future, although not all expectations are exogenous. Levers that
decision makers can push are called options in MPSDM. Relationships, or ways that the
future evolves over time in response to the decision makers’ levers, correspond to a type
of beliefs in MPSDM. Measures, or performance standards that are used to rank the
desirability of various options, corresponds to a type value in MPSDM.
MPSDM builds on these previous works, but treats perspectives somewhat more
systematically in two ways. First, it proposes two types of uncertain variables: objective
parameters that are typically associated with the future or adversaries’ capabilities, and
“perspective parameters,” those subjective factors used to represent the values, beliefs,
and expectations of the decision makers, analysts, stakeholders, and adversaries. In
some sense, all uncertain values could be considered to be a matter of perspective.
Those that pertain to an uncertain future could represent expectations. Those that
represent, for instance, adversary’s current capabilities could be considered beliefs. The
intention here is to differentiate between objective parameters, which relate to, for
instance, laws of physics, and perspective parameters, which represent the more
subjective judgments, deductions, and inferences.
Secondly, the MPDM methodology treats different perspective as uncertain
variables, and initially intermingles these two types of outcome drivers. Once the
parameter space is explored in a computational experiment, the factors that most drive
the choice of option are disentangled into lower levels of the model as necessary to gain
insights about the system. These factors are then presented in a simplified form (the
annotated box-and-whisker plot) that aims to share insights and to aid discussion of the
factors that affect choice of option.
37

Challenge #3: Dealing with the dimensionality of addressing uncertainties and
perspectives
What is the curse of dimensionality?
As discussed in the previous section, many criteria may be important to strategic
decision makers. As multiple options are compared against multiple criteria, the number
of parameters can grow quite large. With additional uncertain input parameters (both
objective and subjective) in a long, strategic timeframe, the number of parameters can
easily swamp capabilities of analysts and decision makers to make sense of them.
Hillestad19 identifies the “curse of dimensionality” as being problematic for defense
acquisition problems.
The advent of desktop computing brings new computational capability for this type of
problem, but in order to build shared understanding of a problem to multi-perspective
decision makers, the problem must be simplified to a level where a decision-making
group can discuss a manageable number of criteria, options, and uncertain factors in
order to reach a conclusion.
Sometimes an analyst can find a useful simplification, or way of boiling a problem
down to the important elements. However, as perspectives vary along with other
parameters, the curse of dimensionality makes it difficult for the analyst to “get their arms
around” a problem. In order to simplify results in a meaningful way, the analyst may have
difficulty presenting results that do not inherently contain biases produced by their
attempts to simplify results of analyses.
How does MPSDM address the curse of dimensionality?
MPSDM proposes a number of ways to address the curse of dimensionality by
structuring the analytical model and simplifying the problem usefully without losing
thoroughness or the essence of a problem. These approaches include the use of a
multiresolution model, along with a number of useful simplifications.

19

personal correspondence.

38

The use of a multiresolution model
Recall scorecard challenges 1 and 2, which speak to the need to balance the
oversimplification of aggregate return/risk/cost measures with the thoroughness and
precision of including multiple detailed submeasures. This is where a technique that Davis
calls multiresolution modeling is particularly helpful. (Davis and Bigelow 1998; Davis and
Bigelow 2003; Davis and Hillestad 2002). An MRM provides a systematic way of
structuring the analysis that assists both the analysts and the decision makers.
Resolution refers to the level at which something is described. Multiresolution
modeling, as defined by Davis and Bigelow (1998) is “building a single model, a family of
models, or both to describe the same phenomena at different levels of resolution, a family
of elements which multiple levels of abstraction.” Abstraction here is meant to imply a
simplification without losing the essence of the phenomenon being modeled. The figure
below illustrates the concept.

Figure 2.4 - Example of a Multiresolution Model
Starting at the top of the figure, the high-level measures return, risk, and cost can be
broken down into lower-level subdimension measures. Measures can have as many
levels of detail as required to give the needed insight into the critical dimensions of the
problem at hand. For instance, as discussed earlier, dimensions of return might be
performance in any problem-specific criteria such as effectiveness in a number of

39

scenarios, performance against fundamentally different types of considerations, etc.
Return and cost measures can be further broken down as required.
Thus, with MRM, one can reason about different input assumptions and outcomes at
different levels of detail. MRM produces one or more relatively high-level measures, (for
example, Return/Risk/Cost20) but the illustrative problem presented later evaluates Return
as Overall Effectiveness for six subdimensions (scenarios), which is a large number of
criteria. Aggregated measures of return, risk, or cost provide an opportunity to winnow
down the dimensions of the problem.
Davis and Bigelow’s (1998) research on multiresolution models has identified them
as a useful tool for several reasons:
• Humans reason at different levels of detail, a point particularly true for the
application here where decision makers may have different knowledge of, or
interest in seeing, the details of the system being evaluated.
• Knowledge comes at different levels of resolution, and different laws operate at
different laws of detail.
• A detailed model may ignore some relationships that operate at the higher-level,
such as strategy and adaptive behavior.
• A higher-level model is typically quicker and less expensive to generate.
• More detailed (lower-level) models require much data, which is often unavailable
or unreliable.
The first consideration also applies well to strategy domains where decision makers
naturally think hierarchically. Corporate and nonprofit decision makers are well used to
breaking a system down into lower-level organizations, subcontractors, etc. Defense

20

The names of model parameters are capitalized in this dissertation.

40

policy makers are strongly rooted in system engineering tradition, where a complex
system is often decomposed in a hierarchical structure.21
Beyond the analytical advantages, Davis has demonstrated the power of sharing
multiresolution analysis with groups of high-level decision makers in defense-related
applications. (see for example Davis, Shaver, and Beck 2008; Davis, Johnson, Long and
Gompert 2008; Dreyer and Davis 2005). High-level decision makers typically do not have
an abundance of time to gain familiarity with detailed analytical models. If a model is
represented in multiple levels, it allows for real-time “drill downs” to lower levels with other
analysts and decision makers. This ability to quickly zoom to lower levels of the model
allows the model builder to show underlying assumptions and share insights about why
aggregate variables behave as they do.
Another advantage of multiresolution models, which is particularly important for
decision makers of varying knowledge about the problem, is that individuals can easily
see the higher-level aspects of the assessment. If a model is not understood, then the
decision maker has to either simply trust the analysts, or employ his own staff to validate
the model. Even if decision makers are unfamiliar with some of the technical details of the
problem, presenting the model in various levels of abstraction allows them to grasp the
essence of the analysis.
A final advantage of multiresolution models comes from a method defined for
MPSDM where the analyst explores uncertain parameter space in a stepwise manner.
Instead of evaluating all independent variables (i.e. assumptions) at once, the user can
“step down” the multiresolution model one layer at a time, finding the most influential
variable to explore before refining that part of the model and exploring at a lower level.
Thus, a multiresolution model can help the analyst navigate a large, complex model in a
logical, piecewise way.
21

Bracken, Birkler, and Slomovik (1996) describe a principle, “structure should match strategy” that considers an
organizational structure derived from strategy. A natural structure for a multiresolution model might be to reflect
organizational hierarchy, i.e. subcontractors’ products and services at a lower level than prime contractors, etc. Some
practitioners of methods to structure so-called “wicked” problems start with organizational entities as discrete elements
(Horn and Weber 2007). A notable counter-example is the Department of Defense, where capabilities-based planning
was adopted as a strategy. Organizing in terms thereof has been disruptive because was inconsistent with funding
paths and required an extra layer.

41

Thus, another principle of MPSDM is as follows:
Principle #4: A multiresolution model is useful for strategic decision making analysis
when perspectives vary.
The main challenge of multiresolution models lies in the aggregation techniques
used to form the higher-level summary measures. Sometimes the proper technique is
obvious. For instance, if two lower-level factors represent probabilities of two necessary
components, such as a wing and a tail of an airplane being available, then the logical
aggregation rule is to multiply the two probabilities.
Other times, however, it is not obvious how lower-level variables should be
combined. In particular, computing overall risk from two fundamentally different types of
risk is a challenge. This may be a matter of the decision makers’ beliefs about how to
evaluate risk.
The value of a multiresolution model for exploratory analysis has not been widely
understood. Davis, Shaver, and Beck (2008) call for advancing the science of exploratory
analysis to portfolio-framed (i.e. multiresolution scorecard) problems: “Significant research
will be needed to extend the current theory and methods and to make them practically
available to the Department of Defense” (p. xxx). MPSDM addresses this need.
Useful simplification #1: Using Relative Option Superiority as a figure of merit
Recall scorecard challenge # 3, that there may be no simple set of criteria that the
group members all agree are important. This challenge can be addressed by focusing on
the figure of merit Relative Option Superiority in order to gain and share insight into the
underlying conditions that affect choice. Relative Option Superiority for one option over
another is defined for each dimension or subdimension as the difference in scores for
each pair of options.

42

where

Since a return/risk/cost framework has been proposed, relative option superiority
includes the differences in some return, risk, or cost measure for each pair of options.
If criteria can be quantified numerically and an absolute prediction of an outcome
can be made precisely, then it is a simple matter to compute the performance of one
option over another. In most cases, however there are criteria for which absolute scores
can be neither computed nor agreed upon. Even more difficult is the challenge of
agreeing on the absolute threshold for a “red” vs. a “yellow” score on a scorecard, or the
threshold of acceptability for a given measure. Discussing Relative Option Superiority
may bypass certain disagreements, i.e. model specifics. Although individuals may
disagree about the specifics, they may be more likely to agree that one option is relatively
superior in some measure than another.
Another advantage of using Relative Option Superiority as a figure of merit is that it
may be easier for the group to agree on relative return or risk of one option over another.
Such consensus, even if grudging, can bypass disagreement about details of the analysis
which may or may not affect the choice of options.
In addition, focusing on the figure of merit Relative Option Superiority enables some
comparisons to be made without detailed analysis. For instance, there may be an option
that has a potentially disastrous outcome for some combinations of assumptions, making
it an inherently riskier option than others. A quick look at relative option superiority may
rule this option out without need for any additional, more detailed modeling.
Another advantage of this Relative Option Superiority in return/risk/cost framing is
that it focuses the evaluation. Specifically, the scope of the multi-dimensional parameter
space for several assumptions and multiple options can grow to the point where it quickly
becomes overwhelming to analytical capabilities and decision makers’ ability to form
insights, especially when perspectives vary. The important factors can be obscured by
43

being buried in a large amount of relatively unimportant information to strategic choice (for
instance, areas where all options perform relatively the same). Focusing on areas that are
important—in this case, the conditions under which one option performs relatively well or
relatively poorly in return, risk, or cost compared to another option, can simplify the
evaluation. This simplification may help guide decision makers to shared understanding.
Although the general methods described in this dissertation are applicable to other
figures of merit (for instance regret), MPSDM focuses on Relative Option Superiority for a
number of reasons:
• The concept of relative superiority is easily understood by decision makers who
may have little knowledge about the technical details of the problem. In addition, it
may help them explain the group’s choice to stakeholders with even less
knowledge about alternative perspectives.
• The process allows exploration of the relative upside and downside of the options.
Identifying factors that drive an option being highly preferred in return, for instance,
can lead to strategies to affect those factors. This brings forward the possibility of
“upside potential” or “game-changing option” without inventing an additional
criterion.
• As will be seen in the next chapter, concentrating on relative superiority focuses
exploratory analysis. Rather than setting an arbitrary threshold for separating
options’ performance into “good” vs. “bad,” and using exploratory analysis to find
the factors associated with the bad areas of multi-dimensional parameter space,
MPSDM sets specific thresholds for explorations: the levels of risk or return where
one option performs better than another.
Thus, MPSDM proposes the following principle:
Principle #2: Relative Option Superiority is a useful discriminating figure of merit.

44

Useful simplification #2: Starting with a finite set of feasible options
This research assumes as a starting point that a relatively small initial set of feasible
options (or alternative actions to take) has been identified for evaluation. Keeney (1992)
prescribes a group beginning decision making by focusing on values, but notes that
“decisionmaking usually focuses on the choice among alternatives.” The premise of
MPSDM is that decision makers may never agree on values, beliefs, or expectations.
Therefore, MPSDM methodology starts with a relatively small set of feasible options, and
includes a process to iterate the analysis and group discussion once values and other
factors that drive the choice of options are understood.
Useful simplification #3: Using exploratory analysis to navigate uncertainty and
determine forces driving Relative Option Superiority
Once the options have been identified, the analytical evaluation of those options
against multiple criteria can begin. As discussed earlier, various strands of research begin
with this options/criteria framework: MAUT, MCDM, among others. Nguyen (2003)
defines some categories of methods used in the research to compare options against
criteria:
• Value/utility Methods
• Scoring
• Ranking and outranking methods (Roy 1993; Barns et al. 1986)
All these methods appear to have the same first step: identifying a priori which
outcomes or criteria might be of interest to decision makers.
Many of these methods assign weights to the different outcome criteria, either to
compute an aggregate measure of value for each option, or to aid the option ranking
calculation. Clearly criteria and weights can be directly related to what MPSDM defines
as the values dimension of perspectives. For example, consider a group that identifies
several criteria. If they all agree on the relative importance of these criteria, the task of
ranking the strategic options is relatively straightforward.
45

Recently, it has been recognized that the weights for each criterion may not be
known before the analysis, or may differ between decision makers. A variety of
questioning techniques have been developed to quantify the weights that represent each
criterion’s importance to the decision makers before the assessment of the options (see
Nguyen 2003 for a review). Of course this method applies only if decision makers can
quantify their relative values before seeing the results of the option assessment.
Sometimes individuals can’t characterize their values ahead of the analysis; their relative
preference for one criterion over another “depends” on factors that aren’t accessible to
the decision makers ahead of the analysis. For instance, there may be a “show stopper”
condition or a level below which an option is ruled unattractive, despite its good
performance against other criteria.
It is also recognized that such weighted-sum characterizations of a problem may not
faithfully represent how real decision makers decide. One example is where an option
that receives a particularly high score against one criterion may be deemed a “game
changer”, despite its relatively low performance score against other criteria. MPSDM
allows for nonlinear scoring techniques such as this.
A primary goal of any effective decision-making tool is to focus the decision-makers’
attention onto factors that have a significant effect on the final outcome produced by the
decision, while ensuring that the parameter space has been covered thoroughly.
Although differing perspectives can make it difficult for decision makers to focus their
discussions on strategic actions rather than the validity of the perspectives themselves,
some types of perceptions may not affect the decision much at all. For instance, the
analytical belief of which lower-level model is “best” may not, in the end, make a
difference in Relative Option Superiority. The MPSDM methodology provides a way of
simplifying the problem, focusing the discussion on parameters that significantly affect
outcome.
One of the simplifying approaches proposed by MPSDM is to use exploratory
analysis (EA) techniques to mine out the parameters--perspective or more objective
ones--that make a difference to Relative Option Superiority. EA is analysis that examines
projected behavior of the system across the “assumptions space” or “scenario space.”
46

That is, the assumptions (inputs) that drive the model are varied—simultaneously, not
merely one by one—so that the analyst can identify combinations of assumptions that
lead to good, bad, and ambiguous results. Exploratory analysis was originally associated
with scenario space analysis (Davis and Winnefeld 1983; Davis 1994) and is a
generalization and renaming of “multiscenario analysis” (Davis 1988). EA is closely
related to what was originally called exploratory modeling (Bankes 1993) and applied in
RDM (Lempert et al. 2003).
Although EA will be described in detail in the next chapter, at the top level, it can be
thought of as the opposite of conventional analysis. In traditional modeling techniques,
the analyst designs and builds a model, specifies the inputs, or assumptions, and the
model produces the associated outcome. EA, on the other hand, involves designing and
constructing a computational experiment where assumptions are varied simultaneously
as sets of independent variables, with the outcomes of interest making up the dependent
variables. A large number of assumption sets or “cases” are analyzed, with the computer
producing a multidimensional database consisting of assumptions and outcomes for each
case. Starting with this database, graphical and data-mining techniques are then used to
work backwards, trying to determine the driving forces—the assumptions and
combinations of assumptions that affect the choice of options.
Applying EA to MPSDM problems presents a few challenges. Currently, for national
security applications, the practice is to identify perspectives as sets of alternate, selfconsistent sets of assumptions (Davis et al.2008a). These sets could consist of, for
instance, optimistic assessments of groups of unknown variables. For example an
adversary’s capability, risk measures, or likelihood of stable funding from Congress could
be assigned to take on a range more favorable than a pessimistic assessment. The
scores from these groups of assumptions are then rolled up into what becomes, in effect,
a new criterion or column in a scorecard, e.g., the optimistic assessment. The idea is to
identify a type of perspective made up of several related measures. The resulting
optimistic assessment can then be compared against an analogous pessimistic
assessment. To compute an overall assessment, two practices are used currently: the
first is to leave the optimistic and pessimistic assessments separate for the decision
47

maker; the second method is to compute an aggregate assessment using a weighted
average of the different assessments (Davis et al. 2008a)
MPSDM proposes two extensions to EA as it is used in national security
applications. It permits the analyst to:
• methodically “step” through the exploration, navigating downward through the MRM,
exploring further as the driving forces at each level are identified
• identify categories of perspective parameters: values, beliefs, and expectations.
Beliefs include analytical beliefs about the “best” way to model, score, and
aggregate parameters in a multiresolution model.
• treat perspectives as individual parameters. Although the experimental design is
made simpler if one can collect sets of perspective parameters, it is sometimes
hard to tell ahead of the analysis how decision makers’ and analysts’ values,
beliefs, and expectations tie together. Sets of perspectives can be assembled after
the EA, as RDM does, to define the perspectives that matter—those affecting the
choice of options.
• describe preliminary exploratory analysis using inspection and graphical methods
to gain insight from the suite of runs.
• use data mining techniques employed in the RDM research to determine the
“important” perspective and objective factors (i.e. those that affect the outcomes of
interest).
• identify categories of perspective parameters: values, beliefs, and expectations.
Beliefs include analytical beliefs about the “best” way to model, score, and
aggregate parameters in a multiresolution model.
The first extension, above, is a stepwise exploration of parameter space, moving
“down” the MRM with each subsequent exploration. This stepwise approach examines
fewer assumptions at a time, in series rather than in parallel, and offers a few advantages
over a single, complex model structure:
48

• It allows the analyst to “maintain their bearings” during the exploration, keeping the
model as simple as possible for as long as possible. Often, explaining a
multiresolution model to decision makers in a logical, system-engineering structure
will help them gain confidence in the model. If decision makers are used to a
hierarchical way of thinking, for instance in national security or competitive fields,
they may be particularly receptive to this type of structure;
• Using a multiresolution model development method which starts with a simplified
model and letting the EA guide the model refinement may save time and money;
and
• It may extend the dimensional capabilities of analytical algorithms. Two tools—the
one used to generate the results of the computational experiment, and the EA
data-mining algorithm—have computational limitations which can be extended by
evaluating fewer assumptions at a time.
• It permits a disaggregation
In the social policy stream of research, RDM practitioners have made advances in
using and comparing algorithms to find clusters of independent variables that affect the
outcomes of interest. MPSDM uses this approach to EA, but also contributes to the
Exploratory Modeling approach used in RDM applications in multiple ways.
First, MPSDM defines a multiresolution modeling structure that may appeal to
decision makers with little or no knowledge of the technical details of the problem. RDM is
currently being tested with actual high-level decision makers. The author worked on one
experiment where RDM was compared with other methodologies to evaluate the impact
of climate change on California Water planning. Although RDM performed well against
other methods, it was viewed as too complex for some participants. Only a minority of
participants felt strongly that RDM was easy to understand, and that it was easy to
explain to stakeholders. The six useful simplifications described in this chapter, plus the
use of multiresolution modeling techniques are aimed at providing thorough yet simplified
representations of the strategic decision to high-level decision makers.
49

In addition, a novel contribution of this research is to define perspective parameters,
including those associated with aggregation rules, as uncertain variables, to be explored
at the same time as more objective factors. Unlike other analytical techniques, where
perspectives are considered after the analysis is complete, here they are analytically
represented in the model and explored simultaneously with more objective factors to find
which ones matter to the outcomes of interest, and under which conditions they matter.
Other useful simplifications
Thus far, MPSDM proposes three ways that problems can be usefully simplified:
Using Relative Option Superiority as a figure of merit; starting with a relatively small set of
feasible options; and using EA to find forces driving Relative Option Superiority. Three
other useful simplifications are proposed by MPSDM:
1. Using a process that includes a mix of aggregating (to represent top-level results) and
disentangling (to parse out the key factors driving the top-level results) in order to
navigate the uncertain parameter space and share insights gained along the way.
2. Identifying options that are dominated, or inferior in important criteria to others. These
options can be eliminated from consideration.
3. Identifying criteria which differentiate options. That is, criteria for which one or more
options are relatively superior to others. If all options perform relatively the same for a
particular criterion, then that criterion is of little use in helping decision makers
choose between strategic options. That criterion can be eliminated in that iteration of
the MPSDM methodology.
The first method of aggregating and disentangling in a step-wise exploration of an
MRM will be described in more detail in the next chapter.
The second method, looking for dominated options to eliminate, may not always
yield results. An option may be inferior to others for some sets of uncertain parameters for
a measure, say return, but not in all of them. Or it may be inferior to another option in
return, but not in risk. MPSDM proposes starting with the baseline option as the “current
plan,” so that other options can be evaluated relative to the “do nothing differently”
50

strategy. With this choice of baseline, the failure to reach a decision on strategy results in
the baseline strategy being adopted, and decision makers will have a clear indication of
its relative strengths and weaknesses. Since presumably other options improve in at least
one aspect of the strategic problem, it is somewhat likely that the baseline option will be
dominated, in return or risk or both.
The third method, above, starts with a broad set of criteria and then evaluates each
option’s performance against each criterion. If all options perform relatively well or poorly
for a criterion, that measure can be eliminated since it doesn’t affect the choice of
options—it is not an option differentiator. Later, after options are modified and the
MPSDM method is iterated, that criterion may need to be re-included for consideration.
Thus, MPSDM offers seven ways to address the curse of dimensionality: the use of
MRM with a return/risk/cost framework; the choice of Relative Option Superiority as a
figure of merit; starting with a relatively small initial set of feasible options; extending EA
methodologies to discover forces (including perspectives and MRM aggregation
techniques) driving the system; an aggregation/disentangling process to efficiently
navigate uncertain parameter space; eliminating dominated options; and eliminating
criteria that don’t differentiate options.
Challenge #4: Creating strategy from the analysis
One possible method to derive strategy is for the decision makers to discuss the
annotated whisker plots and all agree that an option is clearly superior to the others. This
happy circumstance is more likely to occur if uncertainty is relatively small, decision
makers’ perspectives are closely aligned, and an option’s score on a scorecard is so
much better in all criteria that it dominates the others. This situation is relatively rare, and
it is clear that a workable decision-making methodology cannot be predicated on its
regular occurrence.
Other methods can be used by a group to create strategy. RDM regularly evaluates
each option (or policy lever) to find the vulnerabilities—conditions under which an option
performs poorly (Groves et al. 2008). The decision makers then discuss or vote on the
likelihood of the factors driving the vulnerabilities turning out in a way that favors one
51

option over another. Savage’s (1950) work on minimizing the maximum regret is related
to this concept of choosing options by considering the downside potential, or risk. RDM
uses a related but not identical measure in its definition of regret to find strategies that
work “reasonably well” over a large number of plausible futures. This approach has clear
appeal, especially when the worst case is unacceptable as in the potential for disastrous
global climate change, national security-related vulnerabilities, or for corporations that
have the potential to fail. As will be described in the next chapter, MPSDM adopts the
RDM approach of identifying vulnerabilities for options of interest as one factor guiding
the iteration of options.22
Still another method to create strategy is to look for ones that are flexible, adaptive,
and robust (Davis 2002, Davis, Kulick, and Egner 2005). The FAR philosophy prescribes
strategies that—within economic constraints—generate capabilities that are flexible
enough for multiple missions and uses; adaptive enough to deal with diverse
circumstances; and robust enough to withstand shock and recover.
Although it is necessary to assess a number of options relative to outcomes of
interest, strategy does not necessarily consist solely of decision makers choosing an
option. Instead, decision makers can use insights gained from the above methodology to
create paths forward. These paths forward can take into account the different beliefs and
expectations, once the key ones that affect the outcomes of interest are mined out.
One of the goals of MPSDM is to usefully simplify complexity, as described in the
previous section. Continuing this theme, a simple heuristic is proposed which uses
driving forces’ time frame and controllability (the level to which decision makers can
affect a factor) to determine the type of strategy that should be considered to affect
option superiority. The figure below shows this heuristic.

22 Although the use of Regret as a figure of merit is not precluded in MPSDM’s methodology, Relative Option Superiority

is currently defined as a simple difference in some measure of return, risk, or cost between two options.

52

Figure 2.5 - Heuristic to Derive Strategy Type
Based on Time Frame/Controllability of Driving
Forces
The upper right hand corner pertains to driving forces that are longer-term and still
somewhat controllable. An example of this might be a technology to overcome a
capability that the adversary may or may not be developing. A good strategy in this
quadrant would be two-pronged: develop early warning capabilities to give the
organization more time (hence more alternatives) to address the capabilities gap; and
invest in shaping actions.
Shaping strategies change the likelihood or effect of a driving force. They can come
in two forms: efforts to shape the environment in desirable ways (what Davis (1989) calls
“environmental shaping strategies” (Bracken (1990) applies business principles to the
national-security concept); and actions to change the decision-makers’ organization in
desirable ways, what MPSDM calls “internal shaping strategies.” Since driving forces in
53

this quadrant are by definition longer term, there may be sufficient time to affect such
shaping actions. An example of a driving force in the business domain for this quadrant
would be market presence. A competitor may be planning a market entry into a new
country. Here, the two-pronged strategy would be to develop early warning of that
possibility (are they running focus groups? Moving distribution centers closer to that
country, etc?); and a shaping action to affect the likelihood or effect of the action external
to the decision-makers’ organization: acquire a company in that region, put plans in place
for a pre-emptive entry, etc. An example of an internal shaping strategy in the defense
world would be to create a training program to prepare for the possibility that military
forces will need to be deployed for a new type of mission.
MPSDM’s concept of an early warning is related to Dewar et al.’s (1993) concept of
a signpost. They define a signpost as “an event or threshold that clearly indicates the
changing vulnerability of an assumption.” The term “early warning” in MPSDM is meant to
imply an indication that the mix of strategic actions that was planned may have to change.
This could be due to a change in expectations, i.e. the future is not unfolding in the way
expected, or the change in effects, i.e. a new belief has emerged.
Regardless of the differences in exact meaning, Dewar’s advice for signposts
applies to early warning mechanisms as well: They should be unambiguous and genuine,
especially when adversaries may use deception practices. Dewar recommends use of
multiple indicators, and that the sensing be implemented by the same organization that
does the planning. He also describes the use of a sequence of indicators that is activated
once one signpost appears.
Continuing on to the lower right hand quadrant of the figure above, we find driving
forces that are longer term but predominantly outside the decision-makers’ ability to
control. An example from business might be the emergence of a new competitor into the
marketplace. In the defense world, a driving force in this lower right hand quadrant might
be the political instability of a potential adversary country. The emphasis in this lower half
of the figure is in formulating responses to uncontrollable factors. For this case, the best
strategy is again two-pronged: The first prong is to develop early warning capabilities
54

designed to detect the change. The second prong of the suggested strategy type involves
those responses themselves, which should be adaptive.
What is meant here by adaptiveness? The word “adaptive” as it pertains to strategy
has been used by many authors, with slightly different shades of meaning. Hofer (1973)
was perhaps the first to characterize an adaptive model of organizational strategy,
characterizing it as
concerned with the development of a viable match between the opportunities and
risks present in the external environment and the organization’s capabilities and
resources for exploiting these opportunities.
More recently, Davis (2008) defines an adaptive strategy as “one able to be effective
in a wide range of operational circumstances.” (See also Davis 1993; Davis, Gompert and
Kugler 1996; Davis 2002). Lempert et al.’s (2003) methodology for quantitative, long-term
policy research defines adaptivity as “identifying, assessing, and choosing among nearterm actions that shape options available to future generations.”
Common to these definitions of adaptive strategy is the concept that some factor in
the environment (i.e. outside the decision makers’ control) may change in the future, in
ways that may not be predictable now, and an adaptive strategy is a plan to respond in a
way that accounts for that change.
Clearly there is some overlap between these three definitions of adaptiveness. The
intention here is to take advantage of the time frame/controllability framework and
separate shaping actions, which are by definition controllable by the decision makers’
organization, from adaptive responses to forces beyond the decision makers’ control.
MPSDM defines an adaptive strategy as a plan that prepares for the possibility that some
factor in the environment (i.e. outside the decision makers’ control) may change in the
future in ways that may not be predictable now. Adaptive strategies can include hedges
and contingency plans along with the associated early warning sign.
A contingency plan is a set of executable responses to some warning sign that may
be sensed in the future. It may or may not involve a near-term investment, and may or
may not necessitate replanning at the time the sign is received. An example of a
contingency plan for the business example might be to acquire competitive intelligence
55

and devise a way to market the decision makers’ product as superior to the new entrant,
should the competitor enter the marketplace. For the defense example, a contingency
plan might be to increase the number of reserve resources to prepare for additional
threats, should they emerge.
The concept of a hedge appears to have somewhat different connotations,
depending on the domain in which the term is used. In financial literature, a hedge is an
investment intended to protect oneself from the risk of an unfavorable shift in the price of
a security.23 Davis (1989) and Bracken (1990) define a hedging strategy as one that
“copes with external contingencies arising from other environments (insofar as shaping
strategies cannot cope with them).” Dewar et al. (1993) define hedging actions as actions
“taken to better prepare an organization for the failure of one of its important
assumptions.”24 In all three definitions, the concept of hedging presupposes one type of
investment now based on an assumed expectation of the future, but a hedge is an
additional near-term investment “just in case” that expectation proves false.25
A hedge, as the term is used here, differs from a contingency plan in that it requires
a near-term investment, and does not involve replanning as do some types of
contingency plans. A contingency plan assumes that some signal in the future will prompt
a shift in the set of actions the organization takes. Both are in response to a driving force
in the environment, outside the decision-makers’ control, and both are more common in
longer-term planning.
A hedge in the business example might be to invest in developing new products for
a different market to diversify the company’s offerings in case a competitor develops a
23

Longo (2009) identifies two sources for the original hedging strategy: Alfred W. Smith is generally recognized as
creating the first hedge fund, but Warren Buffet reported that Benjaman Graham operated the first hedge fund in
1926.

24

Dewar et al.(2003) say that hedging actions are distinctly different from shaping actions, in that hedging actions, which
prepare for the world of violated assumptions, and require an act of replanning. MPSDM’s concept of a hedge does
not require replanning, because it includes the possibility of preplanned shifts in actions in the future that would be
activated by a signal. Davis, Kulick, and Egner (2005) refer to branches, or contingency plans in response to
monitored changes, as distinct from hedges that allow appropriate responses to problems that arise for which there
are nonexistent or inadequate plans.

25

Hedges are typically associated with uncertain expectations about the future, and MPSDM’s heuristic uses hedges for
longer-term driving variables. An extension of MPSDM would consider hedges for uncertain values and beliefs as
well.

56

game-changing capability. A hedge in the defense example might be to form a coalition of
countries and agree on a unified response “just in case” an aggression occurs. Note that
some adaptive response plans, if known to the adversary, might in themselves act as a
deterrent.
In differentiating the two types of long-term strategies (those on the right hand side
of the heuristic: shaping actions vs. adaptiveness) two considerations are useful to
remember: First, that these are responses to driving forces that are either within, or
outside of the decision makers’ control. (The strategic actions themselves are completely
within the decision makers’ control); and second, that shaping actions assume the
decision makers can affect the likelihood or effect of some factor and adaptiveness is a
response to some change in the environment, outside the decision makers’ control.
MPSDM proposes two ways in which hedges can be incorporated into the decisionmaking methodology. The first is to use the EA process to identify those assumptions
which most affect option superiority and define a type of hedge. This is the process
described so far.
The other way hedges could be incorporated into the MPSDM process is by taking
into account the different expectations about the future that individual decision makers
may hold. Consider two investment strategies: “all in” investment strategy designed to
address one future state of the world; or a diversified portfolio of investments including
hedges that could reduce the total risk exposure. The first strategy presupposes that
decision makers could agree on one future state of the world. As perspectives vary, the
likelihood of this agreement diminishes. One method sometimes used to reach
consensus on expectations is by voting on the likelihood of alternate futures. Although the
voting process may seem impartial, it contains some problems: do all votes count the
same? What if one decision maker has little confidence in their expectations? Is there
someone in the group whose special expertise that is diluted by the voting process?
Arrow’s impossibility theorem (Arrow 1951) demonstrates that with three or more options
to choose from, no voting system can produce a community-wide ranking from the ranked
preferences of individuals while also meeting three criteria: unrestricted domain; nonimposition; and non-dictatorship.
57

One variant of a hedging strategy is a so-called mixed strategy; pick some of Option
A, some of Option B, etc. An example from the defense or business world might be to
invest in one phase of Option A, such as the development phase, and to proceed with
Option B until it is well into production. The building-block approach used by Davis to
define components of a system could also be applied in the time domain by breaking
options into smaller, milestone-based phases. Of course a mixed strategy could include
dimensions other than phases: it could include number of units produced, a fixed
investment amount in each option, etc.
The diversified investment approach can mitigates consensus issues. It addresses
minority perspectives by explicitly considering, and planning for futures that may be
unlikely but high consequence. The remaining issue, however, is how much of the
portfolio to invest in each of these alternative expectations of the future. Here is where the
value of the early warnings comes into play. Early warning of, for instance, an adversary
taking unexpected action allows time to shift the investment to counter that action.
Other approaches to strategic decision making identify early-on the levers that the
decision makers can push; MPSDM proposes waiting until the driving forces are
understood. This has two potential advantages: It may save time by avoiding discussion
of actions that don’t affect outcomes of interest; and it may expand the option set. By
focusing in on one or two driving factors, groups may come up with creative ways to affect
things that they might not have considered in the broader context.
This “controllifying” activity is not to be underestimated. Often, when a factor seems
completely outside the decision makers’ control, influences from other domains can be
brought to bear. An agreement with a third party, a game-changing breakthrough, or even
an unforeseen circumstance may bring the factor into indirect control. Sometimes the
group (especially when stakeholders are included) has resources far beyond what any
individual decision maker may recognize.
Continuing clockwise to the lower left hand quadrant of the figure above, we find
uncontrollable driving forces in the near term. This is perhaps the most challenging
quadrant of all, because there is insufficient time to invest in shaping or adaptive
strategies. An example from the business world might be the brewing political instability of
58

a country in which the company does business. In the defense world, a driving force in
this quadrant might be an upcoming meeting of a terrorist leader in a known location.
Here, the idea is to develop a set of pre-planned executable responses in case the driving
force turns out unfavorably. Rather than sit and wait, a set of trip wires can be developed,
with associated actions so that decision making, should the future unfold as indicated,
can be quick. A trip wire is different from an early warning in that it is intended to be a
clear signal that a change has occurred, from which pre-planned actions can be taken
quickly. For our business example, this might mean developing set of clear indicators
associated with different levels of responses up to and including plans to evacuate
employees from the country. For the defense example, a response in this quadrant would
be to invest in unambiguous intelligence and develop doctrine for making decisions such
as striking an adversary during a brief moment of their vulnerability.
Continuing to the upper left hand quadrant of the figure above, we find driving forces
that are near-term and controllable. Examples of this in the business world might be the
probability for winning a proposal for the first product in a new product line. A defense
example might be availability of resources for a new trouble spot brewing. Since these are
near-term, there is not sufficient time to develop adaptive strategies. Similarly, there is no
need to put signposts in place, although it may be useful to verify underlying assumptions.
The type of strategy recommended for this quadrant is to focus investments (perhaps by
using resources previously used for hedges) or shift resources. For instance, in the
business example, a strategy here might be to apply more resources to the proposal. In
the defense example, one strategy might be to develop doctrine regarding location of
bases or deployed forces.
Note that even though strategic decision making has been defined as the process of
making long-term decisions involving large amounts of resources, a brief discussion
about time frame is in order. Strategic decision making, by definition, considers long-term
outcomes, but it is useful to consider whether each driving force is predominantly nearterm or long-term for the following reasons:

59

• Although strategic decision making looks further into the future than operational or
tactical decision making, resources must be split between investments with nearterm and longer-term results. Strategic decisions are intended to have long-term
effects, but the decision itself will lead to actions beginning in the short term.
• This heuristic may also be useful for shorter-term decision making as well, by
focusing the group’s discussion on what factors can be brought under the control
of the decision making group.
• Some driving forces may appear to be not under the group’s control in the long
term, but there may be actions that can be taken to drive them towards
controllability. For instance, a potential ally’s desire to cooperate might seem
uncontrollable in the near-term, but tactics might be created to incentivize them to
change their participation.26 Doing so would increase the number of ways to deal
with the driving force. Such shaping actions are long-term in nature, but must be
initiated in the near term in order to have maximum effects.
• Some factors that affect long-term outcomes can be affected in the near term. In the
example described earlier, shifting resources to cover a proposal can affect the
likelihood of winning the longer-term program.
Next, in a process that will be described in more detail later, options which are
relatively superior to others can be modified to improve their returns, risk, or cost using
the type of strategy suggested in the time frame/controllability heuristic. The MPSDM
process is then repeated, iterating options and/or criteria (that may have been revealed or
refined during the process) as resources allow or one option becomes clearly superior.
26 Here we have another example of a distinction between the XLRM framing used in RDM and the approach taken here.

Recall that the X refers to Exogenous variables, and that decision makers start by identifying exogenous factors
before the analysis. MPSDM has a different view of exogeneity. While it is clearly critical for decision makers to
understand their span of control, there are times when creative strategies can be derived to increase a factor’s
controllability. Similarly, a decision maker may sometimes have indirect controllability, that may only come out after a
few driving forces are determined. For instance, there may be tools in the decision makers’ toolkit that can be used to
influence an adversary, even when an adversary’s actions seem, at first blush, to be exogenous to the decision
makers.

60

The preceding discussion illustrates another underlying principle of MPSDM.
Principle #5: Time frame and controllability of driving forces are two critical factors
that drive the choice of type of strategy to employ.

61

Types of literatures explored in deriving the MPSDM approach
A variety of disciplines contributed to the literature review for the MPSDM approach.
The figure below shows the disciplines that contributed methods, principles, frameworks,
or tools in this research.

Figure 2.6 - Literatures Contributing to MPSDM
62

From policy analysis literature comes the methodology of identifying options,
facilitating discussion of those considerations for which high-level decision makers’
experience and judgment are most useful, and selecting an action-based option (e.g.
“invest in that set of capabilities”). Some of the data mining applications and tools used in
Exploratory Analysis come from policy domains. As discussed earlier, the MPSDM
approach builds on Davis’ line of research, the RDM methodology, as well as Dewar’s
work in policy analysis.
Economics and decision science seek to describe ways in which people choose.
Much work has been done on the different models describing human choice. The initial
framework chosen here, the scorecard methodology used frequently in multi-attribute
decision theory, allows decision makers to view the performance of a few options to
discussion. The so-called balanced scorecard methodology (Kaplan and Norton 1996)
has been used in a variety of organizations over the years.
Financial theory often works to simplify complex financial measures into a few
simple metrics, such as expected risk and return, as well as to create two-dimensional
representation of complex market behavior for decision makers. As described earlier,
portfolio theory and its variants seek to simplify and reduce total risk exposure through
diversification, a type of hedge.
Psychology researchers recognize that people are not always rational actors—that
decisions are sometimes made not on the basis of increasing expected return, but rather
on rules of thumb, biases, and heuristics used (sometimes without being explicit about
the basis of the decision). Psychology literature also discusses the amount of complexity
that people can usefully absorb, and encourages useful simplification of a problem. The
author has been involved with psychological experiments aiming to help us understand
how people prefer to characterize uncertainty, as well as some additional experiments
involving high-level decision makers. One of the most interesting findings is that the
problem must be simplified usefully, in order for the decision maker to not only
understand it, but to communicate it to his or her superiors or stakeholders. Finally, the
recent brain research involving imagery of different parts of the brain during decision
63

making looks quite promising to help us understand biological factors that influence
choice (Camerer 2008).
System thinking tells us how to structure a problem in order to simplify it. The
multiresolution model, which will be discussed in detail later, is one such useful
structuring approach. Lower-level measures are aggregated up to higher-level
measures, with data analysis and scoring algorithms used to put multiple dimensions of
goodness for multiple options on a single scorecard. This method almost literally gets
everyone on the same page, discussing action-based options rather than the underlying
values, beliefs, and expectations upon which individuals may never agree. In addition,
the multiresolution model permits real-time “drill downs” to lower-level parameters which
greatly helps build credibility of the presenter and allows high-level decision makers to do
real time “what if” analysis. Systems thinking also emphasizes the relations between
elements (e.g. beliefs and aggregation methods) that can be parameterized, analyzed
and understood.
All of these disciplines were explored for their usefulness in MPSDM, and the
bibliography can be considered a sampling of the works consulted.

64

