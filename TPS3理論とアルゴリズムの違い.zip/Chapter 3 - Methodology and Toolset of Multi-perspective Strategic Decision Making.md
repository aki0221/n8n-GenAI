# Chapter 3 - Methodology and Toolset of Multi-perspective Strategic Decision Making

## Methodology

### Overview

Classical management thinking prescribes group discussions about objectives, followed by development of corresponding strategies and plans (Hitt, Ireland, and Hoskisson 2009). This traditional approach includes on an underlying assumption that the risk, returns, and cost of options being considered can be predicted with a relatively high level of confidence, and that uncertain variables can be identified and characterized.

MPSDM seeks to be more realistic about uncertainty, and about the existence and importance of differing perspectives. It develops strategies and plans focused on actions (options) while accommodating diverse and sometimes uncertain perspectives. The figure below illustrates the MPSDM methodology.

**Figure 3.1 - MPSDM Methodology**

MPSDM calls for:
1. **Characterizing the problem** for analysts and decision makers using a return/risk/cost framework and an initial set of criteria in a multiresolution model; choosing a feasible, action-oriented initial set of strategic options; and evaluating perspective parameters explicitly
2. **Simplifying the problem** using a multi-pronged approach
3. Using the driving forces' controllability and time frame to determine type of strategy which best addresses the choice of options, and modifying options and criteria as required

Once insights about the problem are gained and shared, the problem is iterated, repeating the analysis on the revised set of criteria and options based on initial experience. At any phase of this methodology, decision makers can be consulted for their perspectives, but experience shows that high-level decision makers want a combination of credible results and discussion at a level where their expertise and judgment can be most useful.

At the top level, the MPSDM methodology looks similar to other three-phase strategic decision making process models (Schwenk 1995), although the phases are sometimes described using different words. MPSDM, more specifically than other approaches, focuses on decision makers', stakeholders', and adversaries' different perspectives. This different focus is more evident in the detailed description of the methodology.

### MPSDM step #1: Characterize the problem

The management and policy analysis literature proposes several ways to frame problems but, as discussed earlier, in order to derive strategy, MPSDM starts with return/risk/cost framework and an initial set of criteria, against which options will be evaluated. There are many ways to identify an initial set of criteria, for example by defining some capability desired in the future and assessing the current capability. Closing the capabilities gap could be one criterion. Other criteria could the highest considerations held important by different constituencies. Typically constraints are identified at this early stage of characterizing the problem.

Although the MPSDM methodology can use any type of returns or risk measures, performance in scenarios is a good starting criterion for assessing different strategic options, for reasons described earlier.

The first step involves several key activities:

1. **Problem Definition**: Clearly articulating the strategic problem from multiple perspectives, recognizing that different stakeholders may frame the problem differently.

2. **Stakeholder Identification**: Identifying all relevant stakeholders, including decision makers, analysts, affected parties, and potential adversaries.

3. **Perspective Elicitation**: Systematically gathering information about how different stakeholders view the problem, including their objectives, constraints, and evaluation criteria.

4. **Option Generation**: Developing an initial set of strategic options that are feasible and action-oriented.

5. **Criteria Development**: Establishing evaluation criteria that reflect the diverse perspectives and objectives of different stakeholders.

6. **Uncertainty Identification**: Identifying key sources of uncertainty, including both traditional uncertainties (about future events) and perspective-related uncertainties (about objectives and values).

### MPSDM step #2: Simplify the problem

The second step of MPSDM focuses on making the problem more tractable for analysis while preserving the essential elements that drive strategic choice. This involves several approaches:

1. **Dimensional Reduction**: Identifying the most critical uncertainties and perspectives that drive strategic conclusions, and focusing analytical resources on these key elements.

2. **Scenario Development**: Creating a manageable set of scenarios that capture the key sources of uncertainty and disagreement among stakeholders.

3. **Hierarchical Decomposition**: Breaking complex problems down into more manageable sub-problems that can be analyzed separately and then integrated.

4. **Sensitivity Analysis**: Determining which assumptions and parameter values have the greatest impact on strategic conclusions.

5. **Robust Strategy Screening**: Using preliminary analysis to identify strategies that are clearly dominated or clearly superior across multiple perspectives.

The simplification process is iterative and involves close collaboration between analysts and decision makers to ensure that important elements are not inadvertently eliminated from the analysis.

### MPSDM step #3: Derive the strategy

The final step involves translating the analytical results into actionable strategy. This is often the most challenging step because the analysis may reveal fundamental trade-offs between different perspectives or may identify multiple strategies that are roughly equivalent in terms of their robustness across perspectives.

Key activities in this step include:

1. **Strategy Evaluation**: Systematically evaluating how different strategies perform across the range of perspectives and scenarios identified in the earlier steps.

2. **Trade-off Analysis**: Explicitly identifying and presenting the trade-offs between different strategic options, particularly how strategies that favor one perspective may disadvantage others.

3. **Robust Strategy Identification**: Identifying strategies that perform reasonably well across multiple perspectives, even if they are not optimal from any single perspective.

4. **Adaptive Strategy Design**: Where appropriate, designing strategies that can adapt based on new information about which perspectives prove to be most accurate or relevant.

5. **Implementation Planning**: Developing detailed implementation plans that account for the multi-perspective nature of the strategic environment.

6. **Monitoring and Evaluation**: Establishing systems for monitoring strategy implementation and evaluating performance across multiple perspectives.

## Toolset of the MPSDM approach

The MPSDM approach employs a variety of analytical tools and techniques, drawn from multiple disciplines:

### Decision Analysis Tools
- Multi-attribute utility analysis for handling multiple, conflicting objectives
- Influence diagrams for representing complex decision problems
- Sensitivity analysis for identifying critical assumptions
- Value of information analysis for prioritizing data collection efforts

### Uncertainty Analysis Tools
- Monte Carlo simulation for propagating uncertainty through complex models
- Scenario analysis for exploring alternative futures
- Robust decision making techniques for handling deep uncertainty
- Real options analysis for valuing flexibility and adaptability

### Stakeholder Engagement Tools
- Structured elicitation techniques for gathering stakeholder perspectives
- Facilitated workshops for building shared understanding
- Delphi techniques for achieving consensus on technical judgments
- Conflict resolution methods for addressing fundamental disagreements

### Systems Analysis Tools
- Systems thinking approaches for understanding complex interactions
- Causal mapping for representing stakeholder mental models
- Cross-impact analysis for exploring scenario interactions
- Morphological analysis for systematic option generation

### Computational Tools
- Optimization algorithms for identifying efficient strategies
- Machine learning techniques for pattern recognition in complex data
- Visualization tools for communicating complex analytical results
- Decision support systems for interactive strategy exploration

The specific combination of tools used in any particular application depends on the nature of the strategic problem, the number and diversity of stakeholders involved, the time and resources available for analysis, and the preferences of decision makers for different types of analytical approaches.

The key principle underlying the MPSDM toolset is flexibility - the approach should be adaptable to different types of strategic problems and different organizational contexts, while maintaining its core focus on explicitly addressing multiple perspectives in strategic decision making.

