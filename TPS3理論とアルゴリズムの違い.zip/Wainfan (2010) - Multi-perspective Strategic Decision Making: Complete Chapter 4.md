# Wainfan (2010) - Multi-perspective Strategic Decision Making: Complete Chapter 4

## Chapter 4 - Demonstration of the Approach

### シナリオクラス2: 都市環境での作戦

For this second class of scenarios, we have two different types of challenges, both of which are a matter of perspective:

• Since the setting is urban, what is considered "acceptable" collateral damage risk?
• How firm are the requirements for one-hour response time?

This second scenario class has a historical basis. Various strikes have been aimed at killing al-Qaeda leaders during brief times of vulnerability, including a 1998 strike on an Al Qaeda training camp reportedly narrowly missing Osama bin Laden. The firmness of the requirements for a one-hour response time is not only a matter of decision makers' expectations, but also adversaries' perspectives on U.S. capabilities at the time.

### シナリオクラス3: 大量破壊兵器施設への攻撃

The third scenario class is an attack on facilities for weapons of mass destruction (WMD) such as a nuclear-weapon facility or one involving biological or chemical weapons. A strike may need the assistance of on-the-ground intelligence agents or Special Operations Forces (SOF). Here the following questions must be addressed:

• What type of air defenses might be encountered?
• Will the facility be above ground and well located, or below ground and not precisely known?
• Will U.S. resources be deployed near the facility?

This third class of scenarios stresses the ability to penetrate air defenses and locate the target accurately, since its position may not be known precisely. It also risks the leak of toxic materials and/or damage to international perceptions.

