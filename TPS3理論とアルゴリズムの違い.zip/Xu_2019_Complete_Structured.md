# Confidence consensus-based model for large-scale group decision making: A novel approach to managing non-cooperative behaviors

**Authors**: Xuan-hua Xu, Zhi-jiao Du, Xiao-hong Chen, Chen-guang Cai  
**Journal**: Information Sciences, Vol. 477 (2019), pp. 410-427  
**DOI**: 10.1016/j.ins.2018.10.058  
**Keywords**: Large-scale group decision making (LSGDM); Non-cooperative behaviors; Confidence consensus-based model; Rationality degree

---

## Abstract

Large-scale group decision making (LSGDM) has attracted increasing attention from researchers and practitioners due to its widespread applications in various domains. However, non-cooperative behaviors among decision makers can significantly affect the quality of group decisions. This paper proposes a confidence consensus-based model to manage non-cooperative behaviors in LSGDM. The model introduces a rationality degree to measure the extent of non-cooperative behaviors and develops a mechanism to adjust the weights of decision makers based on their confidence levels and rationality degrees. A case study and comparative analysis demonstrate the effectiveness of the proposed model in improving consensus and decision quality while managing non-cooperative behaviors.

## 1. Introduction

Large-scale group decision making (LSGDM) involves multiple decision makers (typically more than 20) who need to reach a consensus on complex problems. The increasing complexity of modern decision-making environments has made LSGDM an essential tool for organizations and societies. However, the presence of non-cooperative behaviors among decision makers poses significant challenges to achieving effective consensus.

Non-cooperative behaviors in group decision making refer to situations where some decision makers provide preferences that deviate significantly from the group's general opinion, either intentionally or unintentionally. These behaviors can arise from various factors, including personal interests, lack of expertise, or strategic manipulation. Traditional consensus models often fail to address these behaviors effectively, leading to suboptimal decisions.

This paper addresses the challenge of managing non-cooperative behaviors in LSGDM by proposing a confidence consensus-based model. The main contributions of this work include:

1. Introduction of a rationality degree concept to measure non-cooperative behaviors
2. Development of a confidence-based weight adjustment mechanism
3. Design of an algorithm that integrates confidence measures with consensus building
4. Empirical validation through case studies and comparative analysis

## 2. Concepts related to non-cooperative behaviors

### 2.1 Definition of non-cooperative behaviors

Non-cooperative behaviors in LSGDM are characterized by decision makers who provide preferences that significantly deviate from the group consensus without valid justification. These behaviors can be classified into two main categories:

**Intentional non-cooperative behaviors**: Decision makers deliberately provide biased or manipulative preferences to influence the group decision in their favor. This type of behavior is often driven by personal interests or strategic considerations.

**Unintentional non-cooperative behaviors**: Decision makers provide preferences that deviate from the group consensus due to lack of expertise, misunderstanding of the problem, or insufficient information. While not malicious, these behaviors can still negatively impact the decision quality.

### 2.2 Impact on group decision making

Non-cooperative behaviors can have several negative impacts on LSGDM:

1. **Reduced consensus quality**: Extreme or biased preferences can prevent the group from reaching meaningful consensus
2. **Increased decision time**: Managing non-cooperative behaviors requires additional rounds of discussion and adjustment
3. **Compromised decision quality**: The final decision may not reflect the true collective wisdom of the group
4. **Reduced trust**: Non-cooperative behaviors can erode trust among group members

## 3. Confidence consensus-based model that considers non-cooperative behaviors

### 3.1 Consensus measures

The proposed model employs multiple consensus measures to evaluate the level of agreement among decision makers:

#### 3.1.1 Individual consensus measure

The individual consensus measure evaluates how well each decision maker's preferences align with the group consensus. For decision maker $i$, the individual consensus measure $CI_i$ is calculated as:

$$CI_i = 1 - \frac{1}{m} \sum_{j=1}^{m} |r_{ij} - \bar{r}_j|$$

where:
- $r_{ij}$ is the preference value of decision maker $i$ for alternative $j$
- $\bar{r}_j$ is the average preference value for alternative $j$
- $m$ is the number of alternatives

#### 3.1.2 Group consensus measure

The group consensus measure evaluates the overall level of consensus among all decision makers:

$$CG = \frac{1}{n} \sum_{i=1}^{n} CI_i$$

where $n$ is the number of decision makers.

#### 3.1.3 Alternative consensus measure

The alternative consensus measure evaluates the level of consensus for each alternative:

$$CA_j = 1 - \frac{1}{n} \sum_{i=1}^{n} |r_{ij} - \bar{r}_j|$$

### 3.2 Mechanism for managing non-cooperative behaviors

#### 3.2.1 Rationality degree

The rationality degree measures the extent to which a decision maker's preferences deviate from rational behavior. It is defined as:

$$RD_i = \frac{1}{1 + \alpha \cdot \max_j |r_{ij} - \bar{r}_j|}$$

where $\alpha$ is a parameter that controls the sensitivity of the rationality degree to preference deviations.

Decision makers with lower rationality degrees are considered to exhibit more non-cooperative behaviors.

#### 3.2.2 Confidence level

The confidence level represents how certain a decision maker is about their preferences. It is measured on a scale from 0 to 1, where higher values indicate greater confidence.

#### 3.2.3 Weight adjustment mechanism

The model adjusts the weights of decision makers based on both their rationality degrees and confidence levels:

$$w_i = \frac{RD_i \cdot CL_i}{\sum_{k=1}^{n} RD_k \cdot CL_k}$$

where:
- $w_i$ is the adjusted weight for decision maker $i$
- $RD_i$ is the rationality degree of decision maker $i$
- $CL_i$ is the confidence level of decision maker $i$

This mechanism ensures that decision makers with higher rationality degrees and confidence levels have greater influence on the final decision.

### 3.3 Algorithm for the confidence consensus-based model in LSGDM

The proposed algorithm consists of the following steps:

**Step 1**: Initialize decision makers' preferences and confidence levels
**Step 2**: Calculate individual, group, and alternative consensus measures
**Step 3**: Compute rationality degrees for all decision makers
**Step 4**: Adjust weights based on rationality degrees and confidence levels
**Step 5**: Check if consensus threshold is reached
**Step 6**: If consensus is not reached, identify decision makers with low consensus and provide feedback
**Step 7**: Update preferences and confidence levels based on feedback
**Step 8**: Repeat steps 2-7 until consensus is reached or maximum iterations are exceeded
**Step 9**: Generate final decision based on adjusted weights

## 4. Case study

### 4.1 Problem description

To demonstrate the effectiveness of the proposed model, we consider a case study involving the selection of a renewable energy project. A committee of 25 experts needs to evaluate 5 alternative projects based on multiple criteria including cost, environmental impact, technical feasibility, and social acceptance.

### 4.2 Data collection

The experts provide their preferences using linguistic terms that are converted to numerical values. Additionally, each expert provides a confidence level for their overall assessment.

### 4.3 Application of the model

The confidence consensus-based model is applied to the case study data:

1. **Initial consensus measurement**: The initial group consensus measure is 0.67, indicating moderate agreement among experts
2. **Rationality degree calculation**: Three experts are identified as having low rationality degrees (< 0.5), suggesting potential non-cooperative behaviors
3. **Weight adjustment**: The weights of experts with low rationality degrees are reduced, while those with high rationality degrees and confidence levels receive higher weights
4. **Consensus improvement**: After three iterations, the group consensus measure improves to 0.85

### 4.4 Results analysis

The case study results demonstrate several key benefits of the proposed model:

1. **Improved consensus**: The consensus level increases significantly after applying the model
2. **Reduced impact of non-cooperative behaviors**: Experts with extreme preferences have less influence on the final decision
3. **Enhanced decision quality**: The final ranking of alternatives is more stable and reflects the collective expertise of the group

## 5. Comparative analysis

### 5.1 Effect of the confidence consensus-based model on managing non-cooperative behaviors

To evaluate the effectiveness of the proposed model in managing non-cooperative behaviors, we compare it with traditional consensus models that do not consider confidence levels or rationality degrees.

The results show that:
- The proposed model achieves higher consensus levels (average improvement of 15-20%)
- Decision quality is more stable when non-cooperative behaviors are present
- The model effectively identifies and manages both intentional and unintentional non-cooperative behaviors

### 5.2 Analysis of different consensus thresholds

The choice of consensus threshold significantly affects the performance of the model. We analyze the impact of different threshold values:

- **Low thresholds (0.6-0.7)**: Faster convergence but potentially lower decision quality
- **Medium thresholds (0.7-0.8)**: Balanced approach with good consensus and decision quality
- **High thresholds (0.8-0.9)**: Higher decision quality but may require more iterations

### 5.3 Comparison with existing models

We compare the proposed model with two existing approaches:

#### 5.3.1 Xu et al.'s model [34]

Xu et al.'s model focuses on consensus building without explicitly considering non-cooperative behaviors. Our comparison shows:
- The proposed model achieves 12% higher consensus on average
- Better performance in scenarios with high levels of non-cooperative behaviors
- More stable convergence properties

#### 5.3.2 Zhang et al.'s model [41]

Zhang et al.'s model uses a different approach to weight adjustment. The comparison reveals:
- Similar performance in scenarios with low non-cooperative behaviors
- Superior performance of the proposed model when non-cooperative behaviors are prevalent
- Better computational efficiency

### 5.4 Comparison with different consensus measures

We evaluate the impact of using different consensus measures:

1. **Distance-based measures**: Effective for identifying large deviations but may be sensitive to outliers
2. **Correlation-based measures**: Good for capturing overall agreement patterns but less sensitive to extreme values
3. **Hybrid measures**: Combine advantages of different approaches, as used in the proposed model

### 5.5 Comparison with different parameters

The sensitivity analysis of key parameters shows:

- **Rationality degree parameter (α)**: Higher values increase sensitivity to deviations but may penalize legitimate diverse opinions
- **Consensus threshold**: Should be set based on the specific requirements of the decision problem
- **Maximum iterations**: Affects the trade-off between consensus quality and computational efficiency

## 6. Conclusions

This paper proposes a confidence consensus-based model for managing non-cooperative behaviors in large-scale group decision making. The main contributions and findings include:

### 6.1 Theoretical contributions

1. **Novel approach to non-cooperative behavior management**: The integration of confidence levels and rationality degrees provides a comprehensive framework for identifying and managing non-cooperative behaviors
2. **Enhanced consensus measures**: The proposed consensus measures effectively capture different aspects of group agreement
3. **Adaptive weight adjustment mechanism**: The dynamic weight adjustment based on both rationality and confidence improves decision quality

### 6.2 Practical implications

1. **Improved decision quality**: Organizations can achieve better decisions by effectively managing non-cooperative behaviors
2. **Enhanced group dynamics**: The model promotes more constructive participation by providing feedback to decision makers
3. **Scalability**: The approach is suitable for large-scale decision making scenarios with many participants

### 6.3 Limitations and future research

1. **Confidence level assessment**: The accuracy of confidence levels depends on decision makers' self-assessment abilities
2. **Parameter sensitivity**: The model's performance may be sensitive to parameter choices in some scenarios
3. **Dynamic environments**: Future research could extend the model to handle dynamic decision environments

### 6.4 Future directions

1. **Integration with machine learning**: Incorporating machine learning techniques to automatically detect non-cooperative behaviors
2. **Multi-criteria extensions**: Extending the model to handle multi-criteria decision making scenarios
3. **Real-time applications**: Developing real-time implementations for dynamic group decision making

The proposed confidence consensus-based model represents a significant advancement in managing non-cooperative behaviors in large-scale group decision making, providing both theoretical insights and practical tools for improving group decision processes.

