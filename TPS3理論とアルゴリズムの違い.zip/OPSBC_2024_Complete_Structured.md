# OPSBC: A method to sort Pareto-optimal sets of solutions in multi-objective problems (2024)

## Abstract

In recent decades, the significance of multi-objective problems has grown substantially. One of the most popular methods for solving these problems involves the construction of Pareto sets. Pareto sets are exponentially sized relative to the input size of the problem, and so the need to reduce, or at least order, them arises. This work proposes the order of Pareto solutions by Borda count, an approach that makes use of ranking methods to establish preferences among the optimal solutions. To evaluate the proposed approach, a comparative study is conducted, evaluating its performance in comparison to other widely used and well-established methods within this domain. Finally, a case study with real-world data is used to show how the methodology works.

## 1. Introduction

Multi-Objective Problems (MOPs) have become increasingly relevant in recent decades. These are decision problems characterized by having multiple, often conflicting, criteria and/or objectives. The term criteria in this context is used to refer to different attributes any decision may have (cost, risk, etc.), and the objectives are the functions used to aggregate those criteria.

Following Ehrgott (2005) and Gunantara (2018), a general MOP can be written as:

min F(x) = (f₁(x), ..., fₘ(x))
subject to: x ∈ U

where m is the number of objective functions/criteria, U is the feasible region and fᵢ is ith objective function.

MOPs are found in a variety of fields, such as engineering, finance, and agriculture. When an optimization problem has just one objective function, the course of action is relatively straightforward. The problem typically falls into one of three categories: infeasible, unbounded, or having a unique solution. Algorithms exist to identify and solve the problem if possible. However, the situation is not as assured in MOPs. It is usually impossible to optimize all different objective functions simultaneously.

Due to this, the concept of Pareto set or Pareto-optimal set arises. The Pareto set contains all solutions such that there is no one that clearly outperforms the others. That is, x* ∈ U belongs to the Pareto set if it does not exist another solution y ∈ U satisfying the following two conditions: (1) fᵢ(y) ≤ fᵢ(x*) ∀i = 1, ..., m and (2) fⱼ(y) < fⱼ(x*) for at least one j = 1, ..., m.

The image of the Pareto set in the objective space is called the Pareto front. The inherent difficulty that appears once the Pareto set is found, is how to choose the best alternative among all of them. In addition, the Pareto size may be too large and the Decision Maker (DM) may find it impractical. For example, it has been proven that, in bi-criteria shortest path problems, the size of the Pareto set grows exponentially with the number of vertices of the graph.

The key in this situation is that, for a DM, it is mostly impossible to have an overall view of all the available solutions to make a sensible decision, and providing a subset of optimal solutions is more convenient. However, the process of generating a reduced Pareto set, also known as pruned Pareto set is far from trivial, and there are several approaches to face it.

### 1.1 Problem Motivation

One intuitive idea is to use an aggregation function, such as a weighted sum, to reduce the optimal set to just one final solution. Once the weights are determined by a DM, the Pareto solutions are evaluated on the aggregation and the optimal one is selected. However, it is more common to see in the literature that the aggregation of the objectives is performed at the beginning to transform the multi-objective problem into a single-objective one.

### 1.2 Research Contribution

This work proposes a novel approach called OPSBC (Order of Pareto Solutions by Borda Count) that uses ranking methods to establish preferences among optimal solutions. The method addresses the challenge of ordering large Pareto sets in a systematic and theoretically grounded manner.

## 2. Pruning Methods Background

The literature on Pareto set reduction can be broadly categorized into several approaches, each with its own advantages and limitations.

### 2.1 Classical Pruning Approaches

Traditional pruning methods focus on reducing the size of Pareto sets while maintaining representativeness of the solution space. These methods typically employ geometric or statistical criteria to select a subset of solutions.

### 2.2 Preference-Based Methods

Preference-based approaches incorporate decision maker preferences either a priori or interactively during the solution process. These methods aim to focus the search on regions of the Pareto front that are most relevant to the decision maker.

### 2.3 Clustering-Based Techniques

Clustering approaches group similar solutions together and select representatives from each cluster. This ensures diversity in the final solution set while reducing computational burden.

## 3. The Borda Count's Background

The Borda count is a single-winner election method in which voters rank candidates in order of preference. The Borda count determines the outcome of an election by giving each candidate a certain number of points corresponding to the position in which he or she is ranked by each voter.

### 3.1 Mathematical Foundation

In its simplest form, under the Borda count, a candidate receives n-1 points for each first-place vote, n-2 points for each second-place vote, and so on, where n is the number of candidates. The candidate with the most points wins.

### 3.2 Properties and Characteristics

The Borda count satisfies several desirable properties including:
- Condorcet efficiency in many cases
- Resistance to strategic voting
- Computational simplicity
- Intuitive interpretation

### 3.3 Applications in Decision Making

The Borda count has been successfully applied in various decision-making contexts beyond elections, including multi-criteria decision analysis and ranking problems.

## 4. The OPSBC Method

### 4.1 Example of the OPSBC Method

To illustrate the OPSBC methodology, we present a detailed example showing how Pareto solutions are ranked using the Borda count principle. The example demonstrates the step-by-step application of the method to a multi-objective optimization problem.

### 4.2 WOPSBC: Introducing Subjectivity

The Weighted OPSBC (WOPSBC) variant introduces subjective preferences by allowing different weights to be assigned to different criteria. This extension makes the method more flexible and applicable to real-world scenarios where decision makers have varying preferences.

#### 4.2.1 Weight Assignment Strategies

Several strategies for weight assignment are discussed:
- Equal weighting for unbiased ranking
- Expert-based weighting incorporating domain knowledge
- Data-driven weighting based on historical preferences
- Interactive weighting allowing real-time preference adjustment

#### 4.2.2 Sensitivity Analysis

The method includes sensitivity analysis to understand how changes in weights affect the final ranking. This helps decision makers understand the robustness of their choices.

### 4.3 Algorithmic Implementation

The OPSBC algorithm consists of the following main steps:

1. **Pareto Set Generation**: Generate the complete Pareto-optimal set
2. **Criterion Ranking**: Rank solutions according to each individual criterion
3. **Borda Score Calculation**: Calculate Borda scores for each solution
4. **Final Ranking**: Order solutions based on total Borda scores
5. **Subset Selection**: Select top-k solutions or apply threshold-based selection

### 4.4 Computational Complexity

The computational complexity of OPSBC is analyzed in terms of:
- Time complexity: O(n²m) where n is the number of solutions and m is the number of objectives
- Space complexity: O(nm) for storing rankings and scores
- Scalability considerations for large Pareto sets

## 5. Comparative Study

### 5.1 Time Comparison

A comprehensive time comparison is conducted between OPSBC and other established methods in the literature. The comparison includes:
- Execution time for different problem sizes
- Scalability analysis
- Memory usage patterns
- Convergence characteristics

### 5.2 Quality Metrics

Several quality metrics are used to evaluate the performance of different methods:
- **Hypervolume**: Measures the volume of objective space dominated by the solution set
- **Spacing**: Evaluates the distribution of solutions in the objective space
- **Spread**: Measures the extent of the solution set
- **Coverage**: Assesses how well the method covers the Pareto front

### 5.3 Statistical Analysis

Statistical tests are performed to determine the significance of performance differences between methods. The analysis includes:
- Wilcoxon signed-rank tests
- Friedman tests for multiple comparisons
- Effect size calculations
- Confidence interval analysis

### 5.4 Benchmark Problems

The comparative study uses a variety of benchmark problems including:
- Standard test functions (ZDT, DTLZ series)
- Real-world engineering problems
- Financial portfolio optimization
- Resource allocation problems

## 6. Case Study with Real-World Data

### 6.1 Problem Description

A detailed case study is presented using real-world data from a specific application domain. The case study demonstrates the practical applicability of the OPSBC method and its advantages over traditional approaches.

### 6.2 Data Preprocessing

The preprocessing steps required to prepare real-world data for the OPSBC method are described, including:
- Data cleaning and normalization
- Handling missing values
- Outlier detection and treatment
- Feature selection and transformation

### 6.3 Results and Interpretation

The results of applying OPSBC to the real-world case study are presented and interpreted. The analysis includes:
- Comparison with domain expert rankings
- Sensitivity analysis of the results
- Practical implications for decision makers
- Validation of the method's effectiveness

### 6.4 Lessons Learned

Key insights and lessons learned from the case study are discussed, including:
- Practical considerations for implementation
- Limitations and potential improvements
- Generalizability to other domains
- Recommendations for practitioners

## 7. Conclusions and Future Work

### 7.1 Summary of Contributions

The main contributions of this work are summarized:
- Introduction of the OPSBC method for Pareto set ordering
- Theoretical analysis of the method's properties
- Comprehensive experimental evaluation
- Demonstration of practical applicability

### 7.2 Limitations and Challenges

Several limitations and challenges are acknowledged:
- Computational scalability for very large Pareto sets
- Sensitivity to weight selection in WOPSBC
- Dependence on the quality of the initial Pareto set
- Need for domain expertise in weight assignment

### 7.3 Future Research Directions

Several directions for future research are identified:
- Extension to dynamic multi-objective problems
- Integration with interactive optimization methods
- Development of automatic weight learning techniques
- Application to emerging domains such as machine learning and AI

### 7.4 Practical Implications

The practical implications of the OPSBC method for decision makers and practitioners are discussed, including:
- Improved decision support capabilities
- Reduced cognitive burden on decision makers
- Enhanced transparency in the decision process
- Better utilization of computational resources

## References

[References would be listed here in the actual paper]

