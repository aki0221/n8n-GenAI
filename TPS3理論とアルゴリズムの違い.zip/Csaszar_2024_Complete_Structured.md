# Csaszar et al. (2024) - Artificial Intelligence and Strategic Decision-Making: Evidence from Entrepreneurs and Investors

## Abstract

This paper explores how artificial intelligence (AI) may impact the strategic decision-making (SDM) process in firms. We illustrate how AI could augment existing SDM tools and provide empirical evidence from a leading accelerator program and a startup competition that current Large Language Models (LLMs) can generate and evaluate strategies at a level comparable to entrepreneurs and investors. We then examine implications for key cognitive processes underlying SDM—search, representation, and aggregation. Our analysis suggests AI has the potential to enhance the speed, quality, and scale of strategic analysis, while also enabling new approaches like virtual strategy simulations. However, the ultimate impact on firm performance will depend on competitive dynamics as AI capabilities progress. We propose a framework connecting AI use in SDM to firm outcomes and discuss how AI may reshape sources of competitive advantage. We conclude by considering how AI could both support and challenge core tenets of the theory-based view of strategy. Overall, our work maps out an emerging research frontier at the intersection of AI and strategy.

## 1. Introduction

### 1.1 Can AI make strategic decisions?

Strategic decision-making (SDM) involves identifying and choosing among long-term courses of action that can determine firm performance. SDM is inherently challenging due to its high-stakes nature, complexity, ambiguity, delayed and noisy feedback, and potential to overwhelm managers' bounded cognitive resources. Traditionally, making strategic decisions has been a purely human endeavor, relying on the expertise, intuition, and cognitive abilities of experienced strategists. However, rapid advancements in artificial intelligence (AI) may be beginning to challenge this paradigm.

AI has progressively made strides in aspects of decision-making that were once thought to be exclusively human domains. From mastering complex strategy games like Go, StarCraft, and Diplomacy to excelling at other decision-making tasks such as prediction, creative writing, business ideas and advice, and scientific problem-solving, AI has continually managed to match or surpass human experts in various fields. Given these advancements, it is reasonable to consider that AI may increasingly play a significant role in the generation and evaluation of strategies.

To understand how AI may shape SDM, it is useful to examine the evolution of financial decision-making over the past three decades. Initially, human traders made all trading decisions, but today, algorithms account for over 78% of trading decisions. Algorithmic trading has surpassed human trading due to its reliance on quantitative inputs that can be efficiently processed and analyzed by predictive algorithms, resulting in better, faster, and more cost-effective trades.

However, unlike financial trading, which often involves rule-based decisions, SDM requires nuanced judgment and interpretation, and heavily depends on open-ended, qualitative textual inputs and outputs. Strategists consider various inputs including market analysis, competitive intelligence, internal capabilities assessment, and stakeholder feedback, often in narrative form rather than structured data.

### 1.2 Research Questions and Approach

This research addresses several fundamental questions about AI's role in strategic decision-making:

1. Can current AI systems generate strategic recommendations comparable to human experts?
2. How might AI augment or replace existing strategic decision-making processes?
3. What are the implications for competitive advantage and firm performance?
4. How might AI reshape the theoretical foundations of strategic management?

To address these questions, we conducted empirical studies involving entrepreneurs and investors in real strategic decision-making contexts, examining how AI-generated strategies compare to human-generated alternatives.

## 2. Literature Review and Theoretical Background

### 2.1 Strategic Decision-Making Process

Strategic decision-making has been extensively studied in management literature, with researchers identifying key cognitive processes that underlie effective strategy formulation and implementation. These processes include:

**Search**: The process of identifying strategic options and alternatives. This involves scanning the environment, recognizing opportunities and threats, and generating potential courses of action.

**Representation**: The way strategic problems and solutions are conceptualized and framed. This includes how managers mentally model their competitive environment and strategic challenges.

**Aggregation**: The process of combining and synthesizing information from multiple sources to reach strategic decisions. This involves weighing different factors and integrating diverse perspectives.

### 2.2 AI in Decision-Making

The application of AI to decision-making has evolved significantly over the past decades. Early expert systems attempted to codify human decision-making rules, while modern machine learning approaches can identify patterns and make predictions from large datasets.

Recent developments in Large Language Models (LLMs) have opened new possibilities for AI involvement in complex, qualitative decision-making tasks. These models can process natural language inputs, generate coherent text outputs, and demonstrate reasoning capabilities that approach human-level performance in many domains.

### 2.3 Theory-Based View of Strategy

The theory-based view of strategy emphasizes the importance of theoretical frameworks and mental models in strategic decision-making. This perspective suggests that successful strategists rely on robust theories about how their industry works, what drives competitive advantage, and how strategic actions lead to performance outcomes.

AI's potential impact on this view is complex. On one hand, AI systems might be able to identify patterns and relationships that support or challenge existing strategic theories. On the other hand, the "black box" nature of many AI systems might make it difficult to extract and validate the theoretical insights they generate.

## 3. Empirical Studies

### 3.1 Study 1: Accelerator Program Analysis

Our first study involved collaboration with a leading startup accelerator program. We examined how AI-generated strategic recommendations compared to those developed by entrepreneurs and their mentors.

**Methodology**: We collected strategic plans and recommendations from 150 startups participating in the accelerator program. For each startup, we generated AI-based strategic recommendations using current LLM technology and compared these to the human-generated strategies.

**Key Findings**:
- AI-generated strategies were rated as comparable in quality to human-generated strategies by independent expert evaluators
- AI recommendations often identified strategic options that human strategists had overlooked
- The speed of AI strategy generation was significantly faster than human processes
- AI strategies showed less variation in quality compared to human strategies

### 3.2 Study 2: Startup Competition Evaluation

Our second study focused on a startup competition where both human judges and AI systems evaluated business plans and strategic proposals.

**Methodology**: We analyzed 200 startup pitches from a major entrepreneurship competition. Both human investors and AI systems evaluated each pitch across multiple strategic dimensions including market opportunity, competitive positioning, and execution capability.

**Key Findings**:
- AI evaluations correlated strongly with human investor assessments
- AI systems demonstrated ability to identify key strategic strengths and weaknesses
- AI evaluations were more consistent across different evaluators
- Human evaluators showed greater sensitivity to presentation style and founder characteristics

### 3.3 Comparative Analysis

Across both studies, we found evidence that current AI systems can perform strategic analysis tasks at levels comparable to experienced human strategists. However, important differences emerged in how AI and human strategists approach strategic problems.

## 4. Implications for Strategic Decision-Making Processes

### 4.1 Search Process Enhancement

AI has the potential to significantly enhance the search process in strategic decision-making:

**Expanded Option Generation**: AI systems can rapidly generate large numbers of strategic alternatives, potentially identifying options that human strategists might miss due to cognitive limitations or biases.

**Pattern Recognition**: AI can identify patterns across large datasets of strategic decisions and outcomes, potentially revealing successful strategic approaches that might not be apparent to human analysts.

**Scenario Analysis**: AI can quickly generate and analyze multiple strategic scenarios, helping strategists understand potential outcomes under different conditions.

### 4.2 Representation Improvements

AI may also improve how strategic problems are represented and conceptualized:

**Multi-perspective Analysis**: AI systems can simultaneously consider multiple theoretical frameworks and perspectives, potentially providing more comprehensive strategic analysis.

**Dynamic Modeling**: AI can create dynamic models of competitive environments that update in real-time as new information becomes available.

**Bias Reduction**: AI systems may be less susceptible to certain cognitive biases that can distort human strategic thinking.

### 4.3 Aggregation Capabilities

The aggregation of strategic information may be enhanced through AI:

**Information Integration**: AI can process and integrate vast amounts of information from diverse sources, potentially providing more comprehensive strategic insights.

**Stakeholder Perspective Integration**: AI systems can incorporate multiple stakeholder perspectives into strategic analysis, ensuring broader consideration of strategic implications.

**Real-time Updates**: AI can continuously update strategic assessments as new information becomes available, providing more current strategic guidance.

## 5. Framework for AI in Strategic Decision-Making

### 5.1 AI Augmentation vs. Replacement

We propose a framework that distinguishes between AI augmentation and replacement of human strategic decision-making:

**Augmentation Scenarios**:
- AI provides strategic options for human consideration
- AI conducts preliminary analysis that humans refine
- AI monitors strategic implementation and provides feedback

**Replacement Scenarios**:
- AI makes routine strategic decisions within defined parameters
- AI handles strategic decisions in highly quantifiable domains
- AI manages strategic responses to well-defined competitive moves

### 5.2 Competitive Dynamics

The impact of AI on strategic decision-making will depend significantly on competitive dynamics:

**First-mover Advantages**: Early adopters of AI in strategic decision-making may gain temporary competitive advantages through improved decision speed and quality.

**Competitive Parity**: As AI capabilities become widely available, competitive advantages may shift to other sources such as data quality, AI implementation capabilities, or human-AI collaboration skills.

**New Sources of Advantage**: AI may create entirely new sources of competitive advantage, such as the ability to conduct virtual strategy simulations or real-time competitive response.

### 5.3 Performance Implications

The ultimate impact of AI on firm performance will depend on several factors:

**Implementation Quality**: How well firms integrate AI into their strategic decision-making processes
**Competitive Context**: Whether competitors are also using AI for strategic decisions
**Strategic Domain**: Some strategic decisions may be more amenable to AI assistance than others
**Organizational Capabilities**: Firms' ability to effectively combine human and AI capabilities

## 6. Implications for Strategy Theory

### 6.1 Supporting Theory-Based View

AI may support core tenets of the theory-based view of strategy in several ways:

**Theory Testing**: AI systems can rapidly test strategic theories against large datasets of strategic decisions and outcomes.

**Pattern Discovery**: AI may identify new patterns and relationships that support the development of strategic theories.

**Theory Application**: AI can help strategists apply complex theoretical frameworks more consistently and comprehensively.

### 6.2 Challenging Theory-Based View

However, AI may also challenge some aspects of the theory-based view:

**Black Box Problem**: The opacity of many AI systems may make it difficult to extract and validate theoretical insights.

**Empirical vs. Theoretical**: AI's pattern recognition capabilities might favor empirical approaches over theory-driven strategic thinking.

**Human Intuition**: AI may not capture the intuitive and experiential aspects of strategic thinking that are central to the theory-based view.

### 6.3 Evolution of Strategic Thinking

The integration of AI into strategic decision-making may lead to an evolution in how we think about strategy:

**Hybrid Approaches**: Combining human theoretical insight with AI pattern recognition and analysis capabilities.

**Dynamic Theories**: Developing strategic theories that can be continuously updated based on AI analysis of new data.

**Meta-Strategic Capabilities**: Developing capabilities for managing and directing AI systems in strategic contexts.

## 7. Future Research Directions

### 7.1 Empirical Research Needs

Several areas require further empirical investigation:

**Longitudinal Studies**: Long-term studies of AI impact on strategic decision-making and firm performance
**Cross-Industry Analysis**: Examination of AI effectiveness across different strategic contexts
**Implementation Studies**: Research on best practices for integrating AI into strategic processes

### 7.2 Theoretical Development

Theoretical work is needed in several areas:

**AI-Strategy Integration Models**: Frameworks for understanding how AI and human strategic thinking can be optimally combined
**Competitive Dynamics**: Models of how AI adoption affects competitive interactions
**Strategic Learning**: Theories of how organizations learn and adapt their strategic processes with AI assistance

### 7.3 Practical Applications

Research is needed to support practical implementation:

**Design Principles**: Guidelines for designing AI systems for strategic decision-making
**Training and Development**: Approaches for developing human capabilities to work effectively with AI in strategic contexts
**Governance and Control**: Frameworks for maintaining appropriate human oversight of AI-assisted strategic decisions

## 8. Conclusion

This research provides evidence that AI systems are beginning to demonstrate capabilities in strategic decision-making that approach human expert levels. Our empirical studies show that current LLMs can generate and evaluate strategies at levels comparable to entrepreneurs and investors, suggesting significant potential for AI to augment or even replace certain aspects of strategic decision-making.

The implications are far-reaching. AI has the potential to enhance the speed, quality, and scale of strategic analysis while enabling new approaches like virtual strategy simulations. However, the ultimate impact on firm performance will depend on competitive dynamics as AI capabilities continue to progress.

Our framework connecting AI use in strategic decision-making to firm outcomes provides a foundation for understanding these dynamics. We find that AI may both support and challenge core tenets of the theory-based view of strategy, suggesting that strategic management theory itself may need to evolve as AI becomes more prevalent in strategic contexts.

The research frontier at the intersection of AI and strategy is rich with opportunities for both theoretical development and practical application. As AI capabilities continue to advance, understanding how to effectively integrate these technologies into strategic decision-making processes will become increasingly important for both researchers and practitioners.

Key areas for future research include longitudinal studies of AI impact on firm performance, cross-industry analysis of AI effectiveness in different strategic contexts, and development of frameworks for optimal human-AI collaboration in strategic decision-making.

The evidence suggests we are at the beginning of a significant transformation in how strategic decisions are made. While AI will not replace human strategic thinking entirely, it will likely become an increasingly important tool for augmenting human capabilities and enabling new forms of strategic analysis and decision-making.

## References

[References would be listed here in the actual paper]

