# Wainfan (2010) - Multi-perspective Strategic Decision Making: Complete Agenda Headers

## Chapter 1 - Introduction
  ### Significance of the research
  ### What is Multi-perspective Strategic Decision Making?
  ### Audience for this research
  ### What is meant by perspectives?



## Chapter 2 - Challenges of Multi-perspective Strategic Decision Making, How Others Have Approached These Challenges, and the Principles of MPSDM
  ### Why is framing a challenge for MPSDM?
  ### The Options
  ### The Criteria
  ### The Scenarios
  ### The Perspectives
  ### Approach taken by MPSDM to address perspectives in the analysis
  ### Incorporating values into the analysis
  ### Incorporating beliefs into the analysis


## Chapter 3 - Methodology and Toolset of Multi-perspective Strategic Decision Making
  ### Overview
  ### Methodology
  ### Other simplifications
  ### Toolset of the MPSDM approach


## Chapter 4 - Demonstration of the Approach
  ### The strategic problem chosen
  ### What is the value of achieving CPGS capability beyond what is currently available?
  ### Illustrative Example
  ### Conventional Prompt Global Strike options


## Chapter 5 - Implementing MPSDM
  ### Practical considerations

