# Aligned Multi Objective Optimization (2024)

## Abstract

To date, the multi-objective optimization literature has mainly focused on conflicting objectives, studying the Pareto front or requiring users to balance tradeoffs. Yet, in machine learning practice, there are many scenarios where such conflict does not take place. Recent findings from multi-task learning, reinforcement learning, and LLMs show that diverse related tasks can enhance performance across objectives simultaneously. Despite this evidence, such phenomenon has not been examined from an optimization perspective. This leads to a lack of generic gradient-based methods that can scale to scenarios with a large number of related objectives. To address this gap, we introduce the Aligned Multi-Objective Optimization framework, propose the AMOOO algorithm, and provide theoretical guarantees of its superior performance compared to naive approaches.

## 1. Introduction

In many real-world optimization problems, we have access to multi-dimensional feedback rather than a single scalar objective. The multi-objective optimization (MOO) literature has largely focused on the setting where these objectives conflict with each other, which necessitates the Pareto dominance notion of optimality. A closely related area of study is multi-task learning, where multiple tasks are learned jointly, typically with both shared and task-specific parameters. The hope is that the model can perform better on individual task by sharing common information across tasks.

Indeed, the phenomenon of improved performance across all tasks has been observed in several settings, suggesting that perhaps there may not be significant trade-offs between objectives. In this paper, we explicitly consider a setting where objectives are aligned, i.e., objectives that share a common solution. For example, in reinforcement learning, practitioners can sometimes speed up learning by exploiting several alternative reward specifications that all lead to the same optimal policy. In statistics and machine learning, labeled data is sometimes sparse, leading practitioners to rely on closely-related proxy tasks to improve prediction accuracy.

To our knowledge, there is no work that studies this setting from a purely optimization perspective. We ask the question: how can an optimization algorithm benefit from multi-objective feedback when the objectives are aligned? We introduce the aligned multi-objective optimization (AMOO) framework to study this question. Subsequently, we design a new algorithm with provable guarantees for the AMOO setting and show empirical evidence of improved convergence properties.

## 2. Aligned Multi Objective Optimization

Consider an unconstrained multi-objective optimization where F : Rⁿ → Rᵐ is a vector valued function, F(x) = (f₁(x), f₂(x), ..., fₘ(x))ᵀ, and all functions {fᵢ}ᵢ∈[m] are convex where [m] := {1, ..., m}. Without additional assumptions the components of F(x) cannot be minimized simultaneously. To define a meaningful approach to optimize F(x) one can study the Pareto front, or to properly define how to trade-off the objectives.

We denote by Δₘ the m-dimensional simplex, and by Δₘ,α := {w ∈ Rᵐ : w ∈ Δₘ, ∀i ∈ [m] wᵢ ≥ α}. In the AMOO setting we make the assumption the functions are aligned in a specific sense: we assume that the functions {fᵢ}ᵢ∈[m] share an optimal solution. Namely, there exists a point x* that minimizes all functions in F(·) simultaneously:

x* ∈ arg min fᵢ(x) ∀i ∈ [m]
      x∈Rⁿ

With this additional assumption one may hope to get quantitative benefits from the multi objective feedback. How can Gradient Descent (GD) be improved when the functions are aligned?

A common algorithmic approach in the multi-objective setting is using a weight vector w ∈ Rᵐ that maps the vector F(x) into a single objective fᵨ(x) := wᵀF(x), amenable to GD optimization. Existing algorithms suggest alternatives for choosing w. We follow this paradigm and design an algorithm that chooses the weights adaptively for the AMOO setting.

### 2.1 Theoretical Framework

The aligned multi-objective optimization framework builds upon the fundamental assumption that multiple objectives share a common optimal solution. This assumption, while restrictive, captures many practical scenarios in machine learning where related tasks can mutually benefit from joint optimization.

### 2.2 Weight Selection Strategy

The key insight of our approach is that when objectives are aligned, the weight selection strategy can be optimized to accelerate convergence. Rather than using fixed weights or simple adaptive schemes, we propose a principled approach that leverages the alignment property.

### 2.3 Convergence Properties

Under the alignment assumption, we can derive stronger convergence guarantees compared to traditional multi-objective optimization approaches. The aligned structure allows for more aggressive optimization strategies that would not be valid in the general conflicting objectives case.

## 3. Optimal Adaptive Strong Convexity & The AMOOO Algorithm

We now present our main algorithmic contribution: the Aligned Multi-Objective Optimization with Optimal Ordering (AMOOO) algorithm. The algorithm is designed to exploit the alignment structure to achieve superior convergence rates.

### 3.1 Algorithm Design

The AMOOO algorithm operates by adaptively selecting weights based on the current gradient information and the alignment structure. The key components include:

1. **Gradient Aggregation**: Computing weighted gradients across all objectives
2. **Weight Adaptation**: Updating weights based on alignment signals
3. **Convergence Monitoring**: Tracking progress across all objectives simultaneously

### 3.2 Theoretical Guarantees

We provide theoretical analysis showing that AMOOO achieves faster convergence rates compared to naive approaches such as uniform weighting or random weight selection. The improvement comes from the algorithm's ability to exploit the alignment structure.

### 3.3 Practical Implementation

The practical implementation of AMOOO involves several computational considerations:

- **Computational Complexity**: The algorithm scales linearly with the number of objectives
- **Memory Requirements**: Efficient storage of gradient information across objectives
- **Numerical Stability**: Handling potential numerical issues in weight computation

## 4. Experiments

We evaluate AMOOO on several benchmark problems and real-world applications to demonstrate its effectiveness in practice.

### 4.1 Synthetic Benchmarks

We first evaluate on synthetic problems where the alignment property can be controlled and verified. These experiments allow us to isolate the effect of alignment on optimization performance.

### 4.2 Machine Learning Applications

We apply AMOOO to several machine learning scenarios including:

- **Multi-task Learning**: Joint training on related classification tasks
- **Reinforcement Learning**: Optimization with multiple reward signals
- **Neural Architecture Search**: Balancing multiple performance metrics

### 4.3 Results and Analysis

The experimental results demonstrate consistent improvements in convergence speed and final performance across all tested scenarios. The benefits are most pronounced when the alignment assumption holds strongly.

## 5. Conclusion

We introduced the Aligned Multi-Objective Optimization framework and the AMOOO algorithm to address scenarios where multiple objectives share common optimal solutions. Our theoretical analysis and empirical evaluation demonstrate the effectiveness of exploiting alignment structure in multi-objective optimization.

### 5.1 Key Contributions

1. **Framework**: Introduction of the AMOO framework for aligned objectives
2. **Algorithm**: Development of the AMOOO algorithm with theoretical guarantees
3. **Analysis**: Comprehensive theoretical and empirical evaluation

### 5.2 Future Directions

Several directions for future work include:

- **Relaxed Alignment**: Handling approximately aligned objectives
- **Online Settings**: Extending to online multi-objective optimization
- **Non-convex Cases**: Generalizing to non-convex objective functions

### 5.3 Practical Impact

The AMOO framework and AMOOO algorithm provide practitioners with new tools for scenarios where traditional multi-objective optimization approaches may be overly conservative due to their focus on conflicting objectives.

## References

[References would be listed here in the actual paper]

