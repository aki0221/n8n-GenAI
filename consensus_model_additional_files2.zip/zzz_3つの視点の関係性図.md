# 3つの視点の関係性図

## 3つの視点の関係性概念図 (Mermaid)

```mermaid
%%{init: {'theme': 'base', 'themeVariables': { 'primaryColor': '#f0f0f0', 'primaryTextColor': '#323232', 'primaryBorderColor': '#888888', 'lineColor': '#555555', 'secondaryColor': '#e0e0e0', 'tertiaryColor': '#f9f9f9'}}}%%

flowchart TD
    classDef market fill:#FFD700,stroke:#B8860B,color:#8B4513,stroke-width:2px
    classDef tech fill:#87CEFA,stroke:#4682B4,color:#191970,stroke-width:2px
    classDef business fill:#98FB98,stroke:#2E8B57,color:#006400,stroke-width:2px
    classDef consensus fill:#F5F5F5,stroke:#A9A9A9,color:#696969,stroke-width:2px,stroke-dasharray: 5 5
    
    %% タイトルと説明
    title["<b>3つの視点の関係性</b><br/>テクノロジー・マーケット・ビジネスの相互作用"]
    
    %% 3つの視点（三角形の頂点に配置）
    Market["マーケット視点<br/><b>先行性</b><br/>需要・受容性・トレンド"]:::market
    Tech["テクノロジー視点<br/><b>基盤性</b><br/>実現可能性・成熟度"]:::tech
    Business["ビジネス視点<br/><b>実効性</b><br/>収益性・戦略適合性"]:::business
    
    %% 中心のコンセンサス
    Consensus["コンセンサス<br/>(3視点の均衡点)"]:::consensus
    
    %% 視点間の相互作用（双方向矢印）
    Market -- "要求・ニーズ" --> Tech
    Tech -- "提供・実現" --> Market
    
    Market -- "機会・制約" --> Business
    Business -- "投資・戦略" --> Market
    
    Tech -- "可能性・制約" --> Business
    Business -- "方向性・資源" --> Tech
    
    %% コンセンサスへの接続
    Market --> Consensus
    Tech --> Consensus
    Business --> Consensus
    
    %% 視点の特性説明
    MarketNote["<b>マーケット視点の先行性</b><br/>・市場ニーズが出発点<br/>・顧客価値の源泉<br/>・採用の決定要因"]
    TechNote["<b>テクノロジー視点の基盤性</b><br/>・実現可能性の基盤<br/>・技術的制約の源<br/>・革新の原動力"]
    BusinessNote["<b>ビジネス視点の実効性</b><br/>・持続可能性の判断<br/>・資源配分の決定<br/>・戦略整合性の確保"]
    
    %% 説明の配置
    MarketNote -.-> Market
    TechNote -.-> Tech
    BusinessNote -.-> Business
    
    %% 理想的なコンセンサス状態の説明
    ConsensusNote["<b>理想的なコンセンサス状態</b><br/>・3つの視点が均衡<br/>・相互の制約を満たす<br/>・持続可能な価値創出"]
    ConsensusNote -.-> Consensus
```

## 図の説明

この図は、コンセンサスモデルにおける3つの視点（テクノロジー、マーケット、ビジネス）の関係性を視覚的に表現したものです。

### 各視点の特性と役割

1. **マーケット視点（黄色）- 先行性**:
   - 市場のニーズや受容性が出発点となります
   - 顧客価値の源泉であり、最終的な採用の決定要因です
   - 他の視点に対して「要求・ニーズ」を提示し、「機会・制約」を示します

2. **テクノロジー視点（青色）- 基盤性**:
   - 技術的な実現可能性の基盤を提供します
   - 革新の原動力であると同時に、技術的制約の源でもあります
   - マーケットに対して「提供・実現」し、ビジネスに「可能性・制約」を示します

3. **ビジネス視点（緑色）- 実効性**:
   - 持続可能性の判断と資源配分の決定を担います
   - 戦略整合性を確保し、長期的な価値創出を可能にします
   - 他の視点に対して「投資・戦略」と「方向性・資源」を提供します

### 視点間の相互作用

各視点は独立して存在するのではなく、常に相互に影響し合っています：

- **マーケット ⇔ テクノロジー**: マーケットはニーズを提示し、テクノロジーはそれを実現します
- **マーケット ⇔ ビジネス**: マーケットは機会と制約を示し、ビジネスは投資と戦略で応えます
- **テクノロジー ⇔ ビジネス**: テクノロジーは可能性と制約を示し、ビジネスは方向性と資源を提供します

### コンセンサスの形成

図の中心にある「コンセンサス」は、3つの視点が均衡した理想的な状態を表しています。この状態では：

- 3つの視点からの評価が整合している
- 各視点の制約条件を相互に満たしている
- 持続可能な価値創出が可能になっている

コンセンサスモデルの目的は、この均衡点を見つけ出し、多角的な視点から裏付けられた意思決定を支援することにあります。
