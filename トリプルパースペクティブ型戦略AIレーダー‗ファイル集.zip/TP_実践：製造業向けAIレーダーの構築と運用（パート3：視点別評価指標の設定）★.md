# 実践：製造業向けAIレーダーの構築と運用（パート3：視点別評価指標の設定）

## 視点別評価指標の基本フレームワーク

トリプルパースペクティブ型戦略AIレーダーを製造業に適用するためには、テクノロジー、マーケット、ビジネスの3つの視点それぞれに適切な評価指標を設定する必要があります。本セクションでは、製造業向けAIレーダーの視点別評価指標とその設定方法について解説します。

### 評価指標設計の基本原則

効果的な評価指標を設計するためには、以下の基本原則を考慮する必要があります：

1. **測定可能性**: 定量的に測定できる指標を優先する
2. **関連性**: 各視点の本質的な側面を捉える指標を選択する
3. **予測力**: 将来の変化や機会を予測するのに役立つ指標を含める
4. **実用性**: データ収集と分析が現実的に可能な指標を選択する
5. **バランス**: 短期的・長期的視点、内部・外部要因のバランスを取る

### 指標階層の構築

各視点の評価指標は、以下の階層構造で整理することが効果的です：

1. **主要指標（Key Indicators）**: 各視点の中核的な評価要素を表す少数の指標
2. **補助指標（Supporting Indicators）**: 主要指標を補完し、より詳細な分析を可能にする指標
3. **早期警戒指標（Early Warning Indicators）**: 変化の兆候を早期に捉えるための先行指標

## テクノロジー視点の評価指標

テクノロジー視点では、製造業における技術的な競争力、イノベーション能力、技術トレンドへの適応度などを評価します。

### 主要指標

1. **技術成熟度指標（Technology Maturity Index）**
   - 定義: 主要技術の成熟度レベル（TRL: Technology Readiness Level）の加重平均
   - 計算方法: Σ(技術i の TRL × 技術i の重要度) / Σ(技術i の重要度)
   - データソース: 研究開発データベース、技術評価レポート
   - 更新頻度: 四半期ごと

2. **技術革新指標（Innovation Index）**
   - 定義: 特許出願数、研究開発投資効率、新技術導入率などの複合指標
   - 計算方法: 0.4 × 正規化(特許出願数) + 0.3 × 正規化(R&D投資効率) + 0.3 × 正規化(新技術導入率)
   - データソース: 特許データベース、R&D予算・成果データ、技術導入記録
   - 更新頻度: 半年ごと

3. **技術競争力指標（Technical Competitiveness Index）**
   - 定義: 競合他社と比較した技術的優位性の評価
   - 計算方法: 主要技術分野ごとの相対的位置づけの加重平均
   - データソース: 競合分析レポート、技術ベンチマーク、市場調査
   - 更新頻度: 年次

### 補助指標

1. **技術多様性指標（Technology Diversity Index）**
   - 定義: 技術ポートフォリオの多様性と分散度
   - 計算方法: 1 - Σ(技術分野iの比率)²（ハーフィンダール指数の逆数）
   - 意義: 技術的リスクの分散と新たな組み合わせの可能性を評価

2. **技術寿命指標（Technology Lifecycle Index）**
   - 定義: 主要技術の予想残存寿命の加重平均
   - 計算方法: Σ(技術iの予想残存年数 × 技術iの重要度) / Σ(技術iの重要度)
   - 意義: 技術の陳腐化リスクと更新必要性を評価

3. **技術適応性指標（Technology Adaptability Index）**
   - 定義: 新技術への適応速度と柔軟性
   - 計算方法: 新技術の評価から導入までの平均期間の逆数
   - 意義: 技術変化への対応能力を評価

### 早期警戒指標

1. **破壊的技術出現指標（Disruptive Technology Emergence Index）**
   - 定義: 業界に影響を与える可能性のある破壊的技術の出現頻度と重要度
   - 計算方法: Σ(破壊的技術iの出現シグナル強度 × 潜在的影響度)
   - 意義: 技術的ディスラプションの早期発見

2. **技術トレンド乖離指標（Technology Trend Divergence Index）**
   - 定義: 自社の技術開発方向と業界トレンドとの乖離度
   - 計算方法: 自社技術投資分野と業界トレンドのコサイン類似度の逆数
   - 意義: 業界トレンドからの逸脱リスクを評価

3. **技術人材ギャップ指標（Technical Talent Gap Index）**
   - 定義: 必要な技術スキルと現有人材スキルのギャップ
   - 計算方法: Σ(技術分野iの重要度 × スキルギャップ率i)
   - 意義: 人材面での技術的制約を早期に特定

## マーケット視点の評価指標

マーケット視点では、製造業における市場機会、顧客ニーズ、競争環境などを評価します。

### 主要指標

1. **市場成長指標（Market Growth Index）**
   - 定義: 主要市場セグメントの成長率の加重平均
   - 計算方法: Σ(市場セグメントiの成長率 × セグメントiの戦略的重要度) / Σ(セグメントiの戦略的重要度)
   - データソース: 市場調査レポート、販売データ、業界統計
   - 更新頻度: 四半期ごと

2. **顧客価値指標（Customer Value Index）**
   - 定義: 顧客満足度、顧客維持率、顧客生涯価値などの複合指標
   - 計算方法: 0.3 × 正規化(顧客満足度) + 0.3 × 正規化(顧客維持率) + 0.4 × 正規化(顧客生涯価値)
   - データソース: 顧客調査、CRMデータ、販売データ
   - 更新頻度: 四半期ごと

3. **市場シェア動向指標（Market Share Momentum Index）**
   - 定義: 市場シェアの変化率と方向性
   - 計算方法: (現在の市場シェア - 12ヶ月前の市場シェア) / 12ヶ月前の市場シェア
   - データソース: 市場シェアデータ、販売データ、業界レポート
   - 更新頻度: 四半期ごと

### 補助指標

1. **製品差別化指標（Product Differentiation Index）**
   - 定義: 競合製品と比較した差別化の度合い
   - 計算方法: 主要製品属性における差別化スコアの加重平均
   - 意義: 競争優位性と価格プレミアム維持能力を評価

2. **市場浸透指標（Market Penetration Index）**
   - 定義: 潜在市場に対する実際の市場浸透率
   - 計算方法: 実際の顧客数 / 潜在的な顧客総数
   - 意義: 市場開拓の余地と成長機会を評価

3. **顧客セグメント多様性指標（Customer Segment Diversity Index）**
   - 定義: 顧客ベースの多様性と分散度
   - 計算方法: 1 - Σ(顧客セグメントiの比率)²（ハーフィンダール指数の逆数）
   - 意義: 特定セグメントへの依存リスクを評価

### 早期警戒指標

1. **顧客行動変化指標（Customer Behavior Change Index）**
   - 定義: 顧客の購買行動、使用パターン、嗜好の変化率
   - 計算方法: 主要顧客行動メトリクスの変化率の加重平均
   - 意義: 顧客ニーズの変化を早期に検出

2. **競合動向指標（Competitor Activity Index）**
   - 定義: 競合他社の戦略的行動の頻度と重要度
   - 計算方法: Σ(競合行動iの頻度 × 影響度)
   - 意義: 競争環境の変化を早期に検出

3. **市場飽和度指標（Market Saturation Index）**
   - 定義: 市場の飽和度と成長限界への接近度
   - 計算方法: 現在の市場規模 / 推定最大市場規模
   - 意義: 市場成長の限界と新市場開拓の必要性を評価

## ビジネス視点の評価指標

ビジネス視点では、製造業における収益性、効率性、持続可能性などを評価します。

### 主要指標

1. **収益性指標（Profitability Index）**
   - 定義: 売上高利益率、投資収益率、資本収益率などの複合指標
   - 計算方法: 0.4 × 正規化(売上高利益率) + 0.3 × 正規化(ROI) + 0.3 × 正規化(ROCE)
   - データソース: 財務諸表、会計システム、投資分析
   - 更新頻度: 月次

2. **運用効率指標（Operational Efficiency Index）**
   - 定義: 生産効率、資源利用効率、サイクルタイムなどの複合指標
   - 計算方法: 0.4 × 正規化(OEE) + 0.3 × 正規化(資源利用効率) + 0.3 × 正規化(サイクルタイム効率)
   - データソース: 生産データ、MESシステム、運用レポート
   - 更新頻度: 週次または月次

3. **ビジネスモデル強靭性指標（Business Model Resilience Index）**
   - 定義: 収益源の多様性、固定費比率、キャッシュフロー安定性などの複合指標
   - 計算方法: 0.3 × 正規化(収益源多様性) + 0.3 × 正規化(固定費比率の逆数) + 0.4 × 正規化(キャッシュフロー安定性)
   - データソース: 財務データ、事業計画、リスク評価
   - 更新頻度: 四半期ごと

### 補助指標

1. **サプライチェーン強靭性指標（Supply Chain Resilience Index）**
   - 定義: サプライチェーンの冗長性、柔軟性、可視性の複合評価
   - 計算方法: 0.3 × 正規化(サプライヤー多様性) + 0.4 × 正規化(供給切替能力) + 0.3 × 正規化(サプライチェーン可視性)
   - 意義: サプライチェーンリスクへの耐性を評価

2. **コスト構造最適化指標（Cost Structure Optimization Index）**
   - 定義: コスト構造の最適性と競争力
   - 計算方法: 1 - (自社コスト構造 / 業界ベストプラクティスコスト構造)
   - 意義: コスト面での競争優位性を評価

3. **資産活用効率指標（Asset Utilization Efficiency Index）**
   - 定義: 有形・無形資産の活用効率
   - 計算方法: 売上高 / 総資産
   - 意義: 資産の効率的活用度を評価

### 早期警戒指標

1. **コスト圧力指標（Cost Pressure Index）**
   - 定義: 原材料価格、人件費、エネルギーコストなどの上昇圧力
   - 計算方法: 主要コスト要素の変化率の加重平均
   - 意義: コスト上昇リスクを早期に検出

2. **規制変化指標（Regulatory Change Index）**
   - 定義: 業界規制の変化頻度と影響度
   - 計算方法: Σ(規制変更iの発生確率 × 影響度)
   - 意義: 規制環境の変化によるリスクと機会を評価

3. **人材流動性指標（Talent Fluidity Index）**
   - 定義: 主要人材の離職率と採用難易度
   - 計算方法: 0.5 × 正規化(主要人材離職率) + 0.5 × 正規化(主要ポジション充足時間)
   - 意義: 人材リスクを早期に検出

## n8nによる視点別評価指標の実装

トリプルパースペクティブ型戦略AIレーダーの視点別評価指標をn8nで実装するためのワークフローの例を以下に示します。

### 指標計算の基本ワークフロー

以下は、テクノロジー視点の主要指標である「技術成熟度指標」を計算するための基本的なn8nワークフローです：

```javascript
// n8nワークフロー例：技術成熟度指標の計算

// トリガーノード：月次スケジュール
{
  "nodes": [
    {
      "parameters": {
        "rule": {
          "interval": [
            {
              "field": "months",
              "daysInterval": 0,
              "monthsInterval": 1
            }
          ]
        }
      },
      "name": "Monthly Schedule",
      "type": "n8n-nodes-base.scheduleTrigger",
      "position": [250, 300]
    },
    
    // 技術データ取得ノード
    {
      "parameters": {
        "operation": "select",
        "schema": "radar_data",
        "table": "technology_assessment",
        "columns": "technology_id, technology_name, trl_level, importance_score",
        "additionalFields": {
          "where": "assessment_date >= date_trunc('month', current_date - interval '1 month') AND assessment_date < date_trunc('month', current_date)"
        }
      },
      "name": "Get Technology Data",
      "type": "n8n-nodes-base.postgres",
      "position": [450, 300]
    },
    
    // 指標計算ノード
    {
      "parameters": {
        "jsCode": "// 技術成熟度指標の計算\nconst technologies = $input.item.json;\n\n// 必要なデータの抽出\nlet totalWeightedTRL = 0;\nlet totalImportance = 0;\n\n// 各技術のTRLと重要度を掛け合わせて合計\ntechnologies.forEach(tech => {\n  const trl = parseFloat(tech.trl_level);\n  const importance = parseFloat(tech.importance_score);\n  \n  totalWeightedTRL += trl * importance;\n  totalImportance += importance;\n});\n\n// 技術成熟度指標の計算\nconst technologyMaturityIndex = totalImportance > 0 ? \n  (totalWeightedTRL / totalImportance).toFixed(2) : 0;\n\n// 結果の返却\nreturn {\n  json: {\n    indicator_name: 'Technology Maturity Index',\n    indicator_value: parseFloat(technologyMaturityIndex),\n    calculation_date: new Date().toISOString(),\n    data_period: 'Last Month',\n    raw_data_count: technologies.length\n  }\n};"
      },
      "name": "Calculate Technology Maturity Index",
      "type": "n8n-nodes-base.function",
      "position": [650, 300]
    },
    
    // 結果保存ノード
    {
      "parameters": {
        "operation": "insert",
        "schema": "radar_data",
        "table": "perspective_indicators",
        "columns": "perspective, indicator_name, indicator_value, calculation_date, data_period, raw_data_count",
        "additionalFields": {
          "values": {
            "perspective": "technology"
          }
        }
      },
      "name": "Save Indicator Result",
      "type": "n8n-nodes-base.postgres",
      "position": [850, 300]
    }
  ],
  "connections": {
    "Monthly Schedule": {
      "main": [
        [
          {
            "node": "Get Technology Data",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Get Technology Data": {
      "main": [
        [
          {
            "node": "Calculate Technology Maturity Index",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Calculate Technology Maturity Index": {
      "main": [
        [
          {
            "node": "Save Indicator Result",
            "type": "main",
            "index": 0
          }
        ]
      ]
    }
  }
}
```

### 複合指標計算ワークフロー

複数の指標を組み合わせた複合指標（例：マーケット視点の「顧客価値指標」）を計算するためのワークフローは以下のようになります：

```javascript
// n8nワークフロー例：顧客価値指標の計算

// トリガーノード：四半期スケジュール
{
  "nodes": [
    {
      "parameters": {
        "rule": {
          "interval": [
            {
              "field": "months",
              "daysInterval": 0,
              "monthsInterval": 3
            }
          ]
        }
      },
      "name": "Quarterly Schedule",
      "type": "n8n-nodes-base.scheduleTrigger",
      "position": [250, 300]
    },
    
    // 顧客満足度データ取得ノード
    {
      "parameters": {
        "operation": "select",
        "schema": "radar_data",
        "table": "customer_satisfaction",
        "columns": "AVG(satisfaction_score) as avg_satisfaction",
        "additionalFields": {
          "where": "survey_date >= date_trunc('quarter', current_date - interval '3 month') AND survey_date < date_trunc('quarter', current_date)"
        }
      },
      "name": "Get Customer Satisfaction",
      "type": "n8n-nodes-base.postgres",
      "position": [450, 200]
    },
    
    // 顧客維持率データ取得ノード
    {
      "parameters": {
        "operation": "select",
        "schema": "radar_data",
        "table": "customer_retention",
        "columns": "retention_rate",
        "additionalFields": {
          "where": "calculation_date = (SELECT MAX(calculation_date) FROM customer_retention WHERE calculation_date < current_date)"
        }
      },
      "name": "Get Customer Retention",
      "type": "n8n-nodes-base.postgres",
      "position": [450, 300]
    },
    
    // 顧客生涯価値データ取得ノード
    {
      "parameters": {
        "operation": "select",
        "schema": "radar_data",
        "table": "customer_lifetime_value",
        "columns": "AVG(clv) as avg_clv",
        "additionalFields": {
          "where": "calculation_date >= date_trunc('quarter', current_date - interval '3 month') AND calculation_date < date_trunc('quarter', current_date)"
        }
      },
      "name": "Get Customer Lifetime Value",
      "type": "n8n-nodes-base.postgres",
      "position": [450, 400]
    },
    
    // データ結合ノード
    {
      "parameters": {
        "jsCode": "// 3つのデータソースからのデータを結合\nconst satisfaction = $node['Get Customer Satisfaction'].json;\nconst retention = $node['Get Customer Retention'].json;\nconst clv = $node['Get Customer Lifetime Value'].json;\n\n// 結合データの返却\nreturn {\n  json: {\n    avg_satisfaction: parseFloat(satisfaction.avg_satisfaction || 0),\n    retention_rate: parseFloat(retention.retention_rate || 0),\n    avg_clv: parseFloat(clv.avg_clv || 0)\n  }\n};"
      },
      "name": "Merge Data",
      "type": "n8n-nodes-base.function",
      "position": [650, 300]
    },
    
    // 正規化ノード
    {
      "parameters": {
        "jsCode": "// 各指標の正規化\nconst data = $input.item.json;\n\n// 基準値（業界平均や目標値など）\nconst benchmarks = {\n  satisfaction: { min: 0, max: 5, target: 4.5 },\n  retention: { min: 0, max: 100, target: 90 },\n  clv: { min: 0, max: 10000, target: 8000 }\n};\n\n// Min-Max正規化関数\nfunction normalize(value, min, max) {\n  if (max === min) return 0.5;\n  return (value - min) / (max - min);\n}\n\n// 各指標の正規化\nconst normalizedSatisfaction = normalize(\n  data.avg_satisfaction,\n  benchmarks.satisfaction.min,\n  benchmarks.satisfaction.max\n);\n\nconst normalizedRetention = normalize(\n  data.retention_rate,\n  benchmarks.retention.min,\n  benchmarks.retention.max\n);\n\nconst normalizedCLV = normalize(\n  data.avg_clv,\n  benchmarks.clv.min,\n  benchmarks.clv.max\n);\n\n// 結果の返却\nreturn {\n  json: {\n    raw_data: data,\n    normalized: {\n      satisfaction: normalizedSatisfaction,\n      retention: normalizedRetention,\n      clv: normalizedCLV\n    }\n  }\n};"
      },
      "name": "Normalize Indicators",
      "type": "n8n-nodes-base.function",
      "position": [850, 300]
    },
    
    // 複合指標計算ノード
    {
      "parameters": {
        "jsCode": "// 顧客価値指標の計算\nconst data = $input.item.json;\nconst normalized = data.normalized;\n\n// 重み付け\nconst weights = {\n  satisfaction: 0.3,\n  retention: 0.3,\n  clv: 0.4\n};\n\n// 加重平均の計算\nconst customerValueIndex = (\n  weights.satisfaction * normalized.satisfaction +\n  weights.retention * normalized.retention +\n  weights.clv * normalized.clv\n).toFixed(2);\n\n// 結果の返却\nreturn {\n  json: {\n    indicator_name: 'Customer Value Index',\n    indicator_value: parseFloat(customerValueIndex),\n    calculation_date: new Date().toISOString(),\n    data_period: 'Last Quarter',\n    component_values: {\n      satisfaction: normalized.satisfaction,\n      retention: normalized.retention,\n      clv: normalized.clv\n    },\n    raw_data: data.raw_data\n  }\n};"
      },
      "name": "Calculate Customer Value Index",
      "type": "n8n-nodes-base.function",
      "position": [1050, 300]
    },
    
    // 結果保存ノード
    {
      "parameters": {
        "operation": "insert",
        "schema": "radar_data",
        "table": "perspective_indicators",
        "columns": "perspective, indicator_name, indicator_value, calculation_date, data_period, component_values",
        "additionalFields": {
          "values": {
            "perspective": "market"
          }
        }
      },
      "name": "Save Indicator Result",
      "type": "n8n-nodes-base.postgres",
      "position": [1250, 300]
    }
  ],
  "connections": {
    "Quarterly Schedule": {
      "main": [
        [
          {
            "node": "Get Customer Satisfaction",
            "type": "main",
            "index": 0
          },
          {
            "node": "Get Customer Retention",
            "type": "main",
            "index": 0
          },
          {
            "node": "Get Customer Lifetime Value",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Get Customer Satisfaction": {
      "main": [
        [
          {
            "node": "Merge Data",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Get Customer Retention": {
      "main": [
        [
          {
            "node": "Merge Data",
            "type": "main",
            "index": 1
          }
        ]
      ]
    },
    "Get Customer Lifetime Value": {
      "main": [
        [
          {
            "node": "Merge Data",
            "type": "main",
            "index": 2
          }
        ]
      ]
    },
    "Merge Data": {
      "main": [
        [
          {
            "node": "Normalize Indicators",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Normalize Indicators": {
      "main": [
        [
          {
            "node": "Calculate Customer Value Index",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Calculate Customer Value Index": {
      "main": [
        [
          {
            "node": "Save Indicator Result",
            "type": "main",
            "index": 0
          }
        ]
      ]
    }
  }
}
```

### 早期警戒指標監視ワークフロー

早期警戒指標（例：ビジネス視点の「コスト圧力指標」）を監視し、閾値を超えた場合にアラートを発するワークフローの例です：

```javascript
// n8nワークフロー例：コスト圧力指標の監視

// トリガーノード：週次スケジュール
{
  "nodes": [
    {
      "parameters": {
        "rule": {
          "interval": [
            {
              "field": "days",
              "hoursInterval": 0,
              "daysInterval": 7
            }
          ]
        }
      },
      "name": "Weekly Schedule",
      "type": "n8n-nodes-base.scheduleTrigger",
      "position": [250, 300]
    },
    
    // コストデータ取得ノード
    {
      "parameters": {
        "operation": "select",
        "schema": "radar_data",
        "table": "cost_factors",
        "columns": "factor_name, current_value, previous_value, weight",
        "additionalFields": {
          "where": "update_date = (SELECT MAX(update_date) FROM cost_factors)"
        }
      },
      "name": "Get Cost Factors",
      "type": "n8n-nodes-base.postgres",
      "position": [450, 300]
    },
    
    // コスト圧力指標計算ノード
    {
      "parameters": {
        "jsCode": "// コスト圧力指標の計算\nconst costFactors = $input.item.json;\n\nlet totalWeightedChange = 0;\nlet totalWeight = 0;\n\n// 各コスト要素の変化率を計算\ncostFactors.forEach(factor => {\n  const current = parseFloat(factor.current_value);\n  const previous = parseFloat(factor.previous_value);\n  const weight = parseFloat(factor.weight);\n  \n  // 変化率の計算（パーセンテージ）\n  const changeRate = previous > 0 ? \n    ((current - previous) / previous) * 100 : 0;\n  \n  totalWeightedChange += changeRate * weight;\n  totalWeight += weight;\n});\n\n// コスト圧力指標の計算\nconst costPressureIndex = totalWeight > 0 ? \n  (totalWeightedChange / totalWeight).toFixed(2) : 0;\n\n// 結果の返却\nreturn {\n  json: {\n    indicator_name: 'Cost Pressure Index',\n    indicator_value: parseFloat(costPressureIndex),\n    calculation_date: new Date().toISOString(),\n    alert_threshold: 5.0, // 5%以上の上昇で警告\n    is_alert: parseFloat(costPressureIndex) >= 5.0,\n    factor_count: costFactors.length\n  }\n};"
      },
      "name": "Calculate Cost Pressure Index",
      "type": "n8n-nodes-base.function",
      "position": [650, 300]
    },
    
    // 結果保存ノード
    {
      "parameters": {
        "operation": "insert",
        "schema": "radar_data",
        "table": "early_warning_indicators",
        "columns": "perspective, indicator_name, indicator_value, calculation_date, is_alert, alert_threshold",
        "additionalFields": {
          "values": {
            "perspective": "business"
          }
        }
      },
      "name": "Save Indicator Result",
      "type": "n8n-nodes-base.postgres",
      "position": [850, 300]
    },
    
    // アラート条件ノード
    {
      "parameters": {
        "conditions": {
          "boolean": [
            {
              "value1": "={{$json.is_alert}}",
              "value2": true
            }
          ]
        }
      },
      "name": "Is Alert?",
      "type": "n8n-nodes-base.if",
      "position": [1050, 300]
    },
    
    // アラート通知ノード
    {
      "parameters": {
        "to": "finance-team@example.com",
        "subject": "=Cost Pressure Alert: {{$json.indicator_value}}% Increase Detected",
        "text": "=Cost Pressure Index has exceeded the alert threshold.\n\nCurrent Value: {{$json.indicator_value}}%\nThreshold: {{$json.alert_threshold}}%\nCalculation Date: {{$json.calculation_date}}\n\nPlease review the cost factors and take appropriate action.",
        "options": {
          "priority": "high"
        }
      },
      "name": "Send Alert Email",
      "type": "n8n-nodes-base.emailSend",
      "position": [1250, 250]
    }
  ],
  "connections": {
    "Weekly Schedule": {
      "main": [
        [
          {
            "node": "Get Cost Factors",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Get Cost Factors": {
      "main": [
        [
          {
            "node": "Calculate Cost Pressure Index",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Calculate Cost Pressure Index": {
      "main": [
        [
          {
            "node": "Save Indicator Result",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Save Indicator Result": {
      "main": [
        [
          {
            "node": "Is Alert?",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Is Alert?": {
      "main": [
        [
          {
            "node": "Send Alert Email",
            "type": "main",
            "index": 0
          }
        ],
        []
      ]
    }
  }
}
```

## 視点別評価指標のカスタマイズポイント

製造業向けAIレーダーの視点別評価指標は、企業の特性や目的に応じてカスタマイズする必要があります。以下に主要なカスタマイズポイントを示します。

### 1. 業種別のカスタマイズ

1. **自動車製造業**
   - テクノロジー視点: 電動化対応度、自動運転技術成熟度、軽量化技術指標
   - マーケット視点: 環境規制対応指標、グローバル市場浸透率、アフターマーケット収益指標
   - ビジネス視点: モジュール化効率指標、プラットフォーム共通化指標、リコールリスク指標

2. **電子機器製造業**
   - テクノロジー視点: 半導体集積度指標、エネルギー効率指標、ミニチュア化指標
   - マーケット視点: 製品ライフサイクル短縮指標、消費者技術採用率、互換性指標
   - ビジネス視点: 知的財産収益化指標、部品調達リスク指標、製品多様性指標

3. **食品・飲料製造業**
   - テクノロジー視点: 保存技術指標、包装革新指標、生産自動化指標
   - マーケット視点: 消費者健康志向指標、地域嗜好適応度、季節変動指標
   - ビジネス視点: 原材料価格変動指標、賞味期限最適化指標、食品安全指標

### 2. 企業規模別のカスタマイズ

1. **大企業向け**
   - 複数地域・事業部間の比較指標
   - グローバルサプライチェーン複雑性指標
   - 規模の経済活用度指標
   - 組織変革速度指標

2. **中小企業向け**
   - ニッチ市場支配力指標
   - リソース効率最大化指標
   - 柔軟性・適応性指標
   - 特化技術優位性指標

### 3. 戦略目標別のカスタマイズ

1. **コスト競争力重視**
   - 原価低減トレンド指標
   - 自動化投資効果指標
   - 規模の経済達成度指標
   - 固定費最適化指標

2. **差別化戦略重視**
   - 製品独自性指標
   - プレミアム価格維持指標
   - ブランド強度指標
   - イノベーション先行指標

3. **集中戦略重視**
   - ニッチ市場シェア指標
   - 顧客ロイヤルティ深度指標
   - 特化技術優位性指標
   - 参入障壁強度指標

## 視点別評価指標の統合と活用

3つの視点（テクノロジー、マーケット、ビジネス）の評価指標を統合し、戦略的意思決定に活用するためのアプローチを以下に示します。

### 1. 視点間の関連性分析

各視点の指標間の相関関係や因果関係を分析することで、より深い洞察を得ることができます。例えば：

- 技術成熟度指標（テクノロジー視点）と市場成長指標（マーケット視点）の関連性
- 製品差別化指標（マーケット視点）と収益性指標（ビジネス視点）の関連性
- 技術革新指標（テクノロジー視点）と運用効率指標（ビジネス視点）の関連性

### 2. 統合ダッシュボードの構築

3つの視点の主要指標を統合したダッシュボードを構築することで、全体像を把握しやすくなります：

- レーダーチャートによる3視点の主要指標の可視化
- 時系列トレンドによる変化の把握
- 閾値超過アラートの統合表示
- ドリルダウン機能による詳細分析

### 3. 戦略的意思決定への活用

統合された評価指標を以下のような戦略的意思決定に活用できます：

- 研究開発投資の優先順位付け
- 市場参入・撤退の判断
- 製品ポートフォリオの最適化
- M&A機会の評価
- リスク管理と対策の策定

## まとめ

製造業向けトリプルパースペクティブ型戦略AIレーダーの効果的な実装には、テクノロジー、マーケット、ビジネスの3つの視点それぞれに適切な評価指標を設定することが不可欠です。本セクションでは、各視点の主要指標、補助指標、早期警戒指標の設計と実装方法を示しました。

これらの指標は、n8nワークフローを活用して自動的に計算・監視することができ、企業の特性や目的に応じてカスタマイズすることが可能です。3つの視点の評価指標を統合し、相互関連性を分析することで、より包括的な戦略的洞察を得ることができます。

次のセクションでは、これらの評価指標を活用したカスタマイズポイントと運用ベストプラクティスについて詳細に解説します。
