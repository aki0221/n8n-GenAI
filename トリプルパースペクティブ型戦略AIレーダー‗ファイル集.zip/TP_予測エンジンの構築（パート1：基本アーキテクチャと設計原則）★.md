# 予測エンジンの構築（パート1：基本アーキテクチャと設計原則）

## 予測エンジンの役割と重要性

トリプルパースペクティブ型戦略AIレーダーにおける予測エンジンは、過去および現在のデータに基づいて将来の状態を予測し、意思決定者に先見的な洞察を提供する重要なコンポーネントです。本セクションでは、予測エンジンの基本アーキテクチャと設計原則について詳細に解説します。

### 予測エンジンの主要目的

1. **将来トレンドの予測**
   - 各視点（テクノロジー、マーケット、ビジネス）における将来の発展方向を予測
   - 重要指標の時間的推移を予測
   - 変化点の事前検出と予測

2. **代替シナリオの生成と評価**
   - 複数の将来シナリオの自動生成
   - 各シナリオの発生確率の推定
   - シナリオ間の相互関係の分析

3. **リスクと機会の特定**
   - 潜在的リスクの早期警告
   - 新たな機会の発見
   - 不確実性の定量化と可視化

4. **意思決定支援**
   - 予測に基づく推奨アクションの提案
   - 意思決定の結果シミュレーション
   - 最適なタイミングの提案

## 予測エンジンの基本アーキテクチャ

予測エンジンは、以下の主要コンポーネントで構成されます。

### 全体アーキテクチャ

```
+----------------------------------+
|         データ前処理層            |
|  +----------------------------+  |
|  |    データクリーニング       |  |
|  +----------------------------+  |
|  |    特徴量エンジニアリング   |  |
|  +----------------------------+  |
|  |    時系列変換              |  |
|  +----------------------------+  |
+----------------------------------+
              ↓↑
+----------------------------------+
|          モデル層                |
|  +----------------------------+  |
|  |    統計的予測モデル         |  |
|  +----------------------------+  |
|  |    機械学習モデル          |  |
|  +----------------------------+  |
|  |    ディープラーニングモデル |  |
|  +----------------------------+  |
|  |    アンサンブルモデル       |  |
|  +----------------------------+  |
+----------------------------------+
              ↓↑
+----------------------------------+
|         シナリオ生成層           |
|  +----------------------------+  |
|  |    モンテカルロシミュレーション|  |
|  +----------------------------+  |
|  |    シナリオ構築エンジン     |  |
|  +----------------------------+  |
|  |    確率的モデリング        |  |
|  +----------------------------+  |
+----------------------------------+
              ↓↑
+----------------------------------+
|         評価・最適化層           |
|  +----------------------------+  |
|  |    予測精度評価            |  |
|  +----------------------------+  |
|  |    モデル選択・最適化      |  |
|  +----------------------------+  |
|  |    不確実性定量化          |  |
|  +----------------------------+  |
+----------------------------------+
              ↓↑
+----------------------------------+
|         インターフェース層        |
|  +----------------------------+  |
|  |    API・インテグレーション  |  |
|  +----------------------------+  |
|  |    可視化コンポーネント     |  |
|  +----------------------------+  |
|  |    アラート・通知システム   |  |
|  +----------------------------+  |
+----------------------------------+
```

### コンポーネント詳細

1. **データ前処理層**
   - **データクリーニング**: 欠損値処理、外れ値検出、重複排除
   - **特徴量エンジニアリング**: 特徴量抽出、変換、選択
   - **時系列変換**: 季節性分解、トレンド抽出、リサンプリング

2. **モデル層**
   - **統計的予測モデル**: ARIMA、指数平滑法、状態空間モデル
   - **機械学習モデル**: ランダムフォレスト、勾配ブースティング、SVR
   - **ディープラーニングモデル**: LSTM、GRU、Transformer
   - **アンサンブルモデル**: スタッキング、バギング、ブースティング

3. **シナリオ生成層**
   - **モンテカルロシミュレーション**: 確率的シミュレーション
   - **シナリオ構築エンジン**: ルールベース・データ駆動型シナリオ生成
   - **確率的モデリング**: ベイジアンネットワーク、マルコフモデル

4. **評価・最適化層**
   - **予測精度評価**: RMSE、MAE、MAPE、交差検証
   - **モデル選択・最適化**: ハイパーパラメータ調整、特徴量選択
   - **不確実性定量化**: 予測区間、確率分布、信頼度スコア

5. **インターフェース層**
   - **API・インテグレーション**: RESTful API、Webhook
   - **可視化コンポーネント**: チャート、ダッシュボード
   - **アラート・通知システム**: 閾値ベースアラート、異常検知

## 予測エンジンの設計原則

トリプルパースペクティブ型戦略AIレーダーにおける予測エンジンの設計には、以下の原則を適用します。

### 1. モジュール性と拡張性

予測エンジンは、独立したモジュールとして設計し、新しいモデルやアルゴリズムの追加が容易になるようにします。

```javascript
// n8n workflow: Prediction Engine Module Registration
// Function node for registering prediction modules
[
  {
    "id": "registerPredictionModule",
    "type": "n8n-nodes-base.function",
    "parameters": {
      "functionCode": `
        // Input: Module metadata
        const moduleMetadata = $input.item.json.module_metadata || {};
        
        // Validate module metadata
        if (!moduleMetadata.id || !moduleMetadata.name || !moduleMetadata.type) {
          throw new Error('Invalid module metadata: id, name, and type are required');
        }
        
        // Register module in the registry
        const registryEntry = {
          id: moduleMetadata.id,
          name: moduleMetadata.name,
          type: moduleMetadata.type,
          description: moduleMetadata.description || '',
          version: moduleMetadata.version || '1.0.0',
          parameters: moduleMetadata.parameters || {},
          input_schema: moduleMetadata.input_schema || {},
          output_schema: moduleMetadata.output_schema || {},
          dependencies: moduleMetadata.dependencies || [],
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        };
        
        // In a real implementation, this would be stored in a database
        // For demonstration, we'll just return the registry entry
        
        return {
          json: {
            success: true,
            message: \`Module \${moduleMetadata.name} registered successfully\`,
            registry_entry: registryEntry
          }
        };
      `
    }
  }
]
```

### 2. 多モデルアプローチ

単一のモデルに依存せず、複数の予測モデルを組み合わせることで、予測の堅牢性と精度を向上させます。

```javascript
// n8n workflow: Multi-Model Prediction Ensemble
// Function node for ensemble prediction
[
  {
    "id": "ensemblePrediction",
    "type": "n8n-nodes-base.function",
    "parameters": {
      "functionCode": `
        // Input: Predictions from multiple models
        const modelPredictions = $input.item.json.model_predictions || [];
        const ensembleMethod = $input.item.json.ensemble_method || 'weighted_average';
        const weights = $input.item.json.weights || {};
        
        // Validate input
        if (modelPredictions.length === 0) {
          throw new Error('No model predictions provided');
        }
        
        // Perform ensemble prediction based on the specified method
        let ensemblePrediction;
        
        switch (ensembleMethod) {
          case 'simple_average':
            ensemblePrediction = performSimpleAverage(modelPredictions);
            break;
          case 'weighted_average':
            ensemblePrediction = performWeightedAverage(modelPredictions, weights);
            break;
          case 'stacking':
            ensemblePrediction = performStacking(modelPredictions, weights);
            break;
          case 'voting':
            ensemblePrediction = performVoting(modelPredictions);
            break;
          default:
            throw new Error(\`Unsupported ensemble method: \${ensembleMethod}\`);
        }
        
        return {
          json: {
            ensemble_method: ensembleMethod,
            model_predictions: modelPredictions,
            ensemble_prediction: ensemblePrediction
          }
        };
        
        // Helper function: Perform simple average
        function performSimpleAverage(predictions) {
          // Calculate average prediction for each time point
          const timePoints = getUniqueTimePoints(predictions);
          const result = {};
          
          timePoints.forEach(timePoint => {
            const values = predictions
              .filter(p => p.predictions[timePoint] !== undefined)
              .map(p => p.predictions[timePoint]);
            
            if (values.length > 0) {
              result[timePoint] = values.reduce((sum, val) => sum + val, 0) / values.length;
            }
          });
          
          return result;
        }
        
        // Helper function: Perform weighted average
        function performWeightedAverage(predictions, weights) {
          // Calculate weighted average prediction for each time point
          const timePoints = getUniqueTimePoints(predictions);
          const result = {};
          
          timePoints.forEach(timePoint => {
            let weightedSum = 0;
            let totalWeight = 0;
            
            predictions.forEach(p => {
              if (p.predictions[timePoint] !== undefined) {
                const modelId = p.model_id;
                const weight = weights[modelId] || 1;
                
                weightedSum += p.predictions[timePoint] * weight;
                totalWeight += weight;
              }
            });
            
            if (totalWeight > 0) {
              result[timePoint] = weightedSum / totalWeight;
            }
          });
          
          return result;
        }
        
        // Helper function: Perform stacking
        function performStacking(predictions, weights) {
          // In a real implementation, this would use a meta-model
          // For demonstration, we'll use a weighted average with confidence-based weights
          
          const timePoints = getUniqueTimePoints(predictions);
          const result = {};
          
          timePoints.forEach(timePoint => {
            let weightedSum = 0;
            let totalWeight = 0;
            
            predictions.forEach(p => {
              if (p.predictions[timePoint] !== undefined) {
                const modelId = p.model_id;
                const baseWeight = weights[modelId] || 1;
                const confidence = p.confidence ? p.confidence[timePoint] || 0.5 : 0.5;
                
                // Adjust weight based on confidence
                const adjustedWeight = baseWeight * confidence;
                
                weightedSum += p.predictions[timePoint] * adjustedWeight;
                totalWeight += adjustedWeight;
              }
            });
            
            if (totalWeight > 0) {
              result[timePoint] = weightedSum / totalWeight;
            }
          });
          
          return result;
        }
        
        // Helper function: Perform voting
        function performVoting(predictions) {
          // For categorical predictions, use majority voting
          // For numerical predictions, use binning and voting
          
          // For demonstration, we'll assume numerical predictions and use binning
          const timePoints = getUniqueTimePoints(predictions);
          const result = {};
          
          timePoints.forEach(timePoint => {
            const values = predictions
              .filter(p => p.predictions[timePoint] !== undefined)
              .map(p => p.predictions[timePoint]);
            
            if (values.length > 0) {
              // For simplicity, we'll use the median
              result[timePoint] = calculateMedian(values);
            }
          });
          
          return result;
        }
        
        // Helper function: Get unique time points
        function getUniqueTimePoints(predictions) {
          const timePointsSet = new Set();
          
          predictions.forEach(p => {
            Object.keys(p.predictions).forEach(timePoint => {
              timePointsSet.add(timePoint);
            });
          });
          
          return Array.from(timePointsSet).sort();
        }
        
        // Helper function: Calculate median
        function calculateMedian(values) {
          const sortedValues = [...values].sort((a, b) => a - b);
          const mid = Math.floor(sortedValues.length / 2);
          
          return sortedValues.length % 2 === 0
            ? (sortedValues[mid - 1] + sortedValues[mid]) / 2
            : sortedValues[mid];
        }
      `
    }
  }
]
```

### 3. 適応性と自己学習

予測エンジンは、新しいデータが利用可能になるたびに自動的に学習し、予測モデルを更新する能力を持ちます。

```javascript
// n8n workflow: Adaptive Model Training
// Function node for adaptive model training
[
  {
    "id": "adaptiveModelTraining",
    "type": "n8n-nodes-base.function",
    "parameters": {
      "functionCode": `
        // Input: New data and current model state
        const newData = $input.item.json.new_data || [];
        const currentModelState = $input.item.json.current_model_state || {};
        const modelConfig = $input.item.json.model_config || {};
        
        // Validate input
        if (newData.length === 0) {
          throw new Error('No new data provided for training');
        }
        
        // Determine if retraining is needed
        const shouldRetrain = determineIfRetrainingNeeded(newData, currentModelState, modelConfig);
        
        if (shouldRetrain) {
          // In a real implementation, this would trigger the model retraining process
          // For demonstration, we'll simulate the retraining process
          
          const updatedModelState = simulateModelRetraining(newData, currentModelState, modelConfig);
          
          return {
            json: {
              retraining_performed: true,
              previous_model_state: currentModelState,
              updated_model_state: updatedModelState,
              retraining_metrics: {
                data_points_used: newData.length,
                training_time: Math.random() * 100, // Simulated training time
                improvement: Math.random() * 0.2 // Simulated improvement
              }
            }
          };
        } else {
          return {
            json: {
              retraining_performed: false,
              current_model_state: currentModelState,
              reason: 'Retraining criteria not met'
            }
          };
        }
        
        // Helper function: Determine if retraining is needed
        function determineIfRetrainingNeeded(newData, currentModelState, modelConfig) {
          // Criteria for retraining:
          // 1. Minimum number of new data points
          // 2. Time since last training
          // 3. Performance degradation
          // 4. Concept drift detection
          
          const minNewDataPoints = modelConfig.min_new_data_points || 100;
          const maxTimeSinceTraining = modelConfig.max_time_since_training || 7 * 24 * 60 * 60 * 1000; // 7 days in ms
          const performanceThreshold = modelConfig.performance_threshold || 0.1;
          
          // Check minimum number of new data points
          if (newData.length < minNewDataPoints) {
            return false;
          }
          
          // Check time since last training
          const lastTrainingTime = new Date(currentModelState.last_training_time || 0).getTime();
          const currentTime = new Date().getTime();
          
          if (currentTime - lastTrainingTime < maxTimeSinceTraining) {
            // Check performance degradation or concept drift
            const recentPerformance = calculateRecentPerformance(newData, currentModelState);
            const baselinePerformance = currentModelState.performance_metrics?.error || 1.0;
            
            return recentPerformance > baselinePerformance * (1 + performanceThreshold);
          }
          
          // If enough time has passed since last training, retrain anyway
          return true;
        }
        
        // Helper function: Calculate recent performance
        function calculateRecentPerformance(newData, currentModelState) {
          // In a real implementation, this would calculate the model's performance on new data
          // For demonstration, we'll simulate performance calculation
          
          // Simulate error calculation (lower is better)
          let totalError = 0;
          
          newData.forEach(dataPoint => {
            // Simulate prediction error
            const actualValue = dataPoint.actual_value || 0;
            const predictedValue = simulatePrediction(dataPoint, currentModelState);
            const error = Math.abs(actualValue - predictedValue) / Math.max(0.1, Math.abs(actualValue));
            
            totalError += error;
          });
          
          return totalError / newData.length;
        }
        
        // Helper function: Simulate prediction
        function simulatePrediction(dataPoint, modelState) {
          // In a real implementation, this would use the model to make a prediction
          // For demonstration, we'll simulate a prediction
          
          // Simulate a prediction with some noise
          const actualValue = dataPoint.actual_value || 0;
          const noise = (Math.random() - 0.5) * 0.2 * Math.abs(actualValue);
          
          return actualValue + noise;
        }
        
        // Helper function: Simulate model retraining
        function simulateModelRetraining(newData, currentModelState, modelConfig) {
          // In a real implementation, this would retrain the model
          // For demonstration, we'll simulate model retraining
          
          // Create updated model state
          const updatedModelState = {
            ...currentModelState,
            last_training_time: new Date().toISOString(),
            data_points_count: (currentModelState.data_points_count || 0) + newData.length,
            version: (currentModelState.version || 0) + 1,
            performance_metrics: {
              error: Math.max(0.1, (currentModelState.performance_metrics?.error || 0.5) * (0.8 + Math.random() * 0.4)),
              accuracy: Math.min(0.99, (currentModelState.performance_metrics?.accuracy || 0.5) * (1 + Math.random() * 0.1))
            }
          };
          
          return updatedModelState;
        }
      `
    }
  }
]
```

### 4. 不確実性の明示的な表現

予測結果には、常に不確実性の度合いを明示的に含め、意思決定者がリスクを適切に評価できるようにします。

```javascript
// n8n workflow: Uncertainty Quantification
// Function node for quantifying prediction uncertainty
[
  {
    "id": "quantifyUncertainty",
    "type": "n8n-nodes-base.function",
    "parameters": {
      "functionCode": `
        // Input: Prediction data
        const predictions = $input.item.json.predictions || {};
        const modelMetadata = $input.item.json.model_metadata || {};
        const confidenceLevel = $input.item.json.confidence_level || 0.95;
        
        // Validate input
        if (Object.keys(predictions).length === 0) {
          throw new Error('No predictions provided');
        }
        
        // Quantify uncertainty for each prediction
        const result = {};
        
        Object.entries(predictions).forEach(([timePoint, value]) => {
          // Calculate prediction interval
          const interval = calculatePredictionInterval(value, timePoint, modelMetadata, confidenceLevel);
          
          // Calculate confidence score
          const confidenceScore = calculateConfidenceScore(value, timePoint, modelMetadata);
          
          // Calculate probability distribution
          const distribution = calculateProbabilityDistribution(value, timePoint, modelMetadata);
          
          result[timePoint] = {
            predicted_value: value,
            prediction_interval: interval,
            confidence_score: confidenceScore,
            probability_distribution: distribution
          };
        });
        
        return {
          json: {
            predictions_with_uncertainty: result,
            confidence_level: confidenceLevel,
            model_id: modelMetadata.model_id || 'unknown'
          }
        };
        
        // Helper function: Calculate prediction interval
        function calculatePredictionInterval(value, timePoint, modelMetadata, confidenceLevel) {
          // In a real implementation, this would use model-specific methods
          // For demonstration, we'll simulate prediction intervals
          
          // Get model error or use default
          const modelError = modelMetadata.average_error || 0.2;
          
          // Adjust error based on time horizon (further in future = more uncertainty)
          const timeHorizonFactor = calculateTimeHorizonFactor(timePoint);
          const adjustedError = modelError * timeHorizonFactor;
          
          // Calculate z-score for the given confidence level
          // For 95% confidence, z ≈ 1.96
          const z = confidenceLevel === 0.9 ? 1.645 :
                   confidenceLevel === 0.95 ? 1.96 :
                   confidenceLevel === 0.99 ? 2.576 : 1.96;
          
          // Calculate interval width
          const intervalWidth = z * adjustedError * Math.abs(value);
          
          return {
            lower_bound: value - intervalWidth,
            upper_bound: value + intervalWidth,
            width: intervalWidth * 2
          };
        }
        
        // Helper function: Calculate confidence score
        function calculateConfidenceScore(value, timePoint, modelMetadata) {
          // In a real implementation, this would use model-specific methods
          // For demonstration, we'll simulate confidence scores
          
          // Base confidence from model metadata
          const baseConfidence = modelMetadata.base_confidence || 0.8;
          
          // Adjust confidence based on time horizon
          const timeHorizonFactor = calculateTimeHorizonFactor(timePoint);
          
          // Adjust confidence based on data quality
          const dataQualityFactor = modelMetadata.data_quality_factor || 0.9;
          
          // Calculate final confidence score
          const confidenceScore = baseConfidence * Math.pow(timeHorizonFactor, -0.5) * dataQualityFactor;
          
          // Ensure confidence is between 0 and 1
          return Math.max(0, Math.min(1, confidenceScore));
        }
        
        // Helper function: Calculate probability distribution
        function calculateProbabilityDistribution(value, timePoint, modelMetadata) {
          // In a real implementation, this would generate a proper distribution
          // For demonstration, we'll simulate a normal distribution
          
          // Get model error or use default
          const modelError = modelMetadata.average_error || 0.2;
          
          // Adjust error based on time horizon
          const timeHorizonFactor = calculateTimeHorizonFactor(timePoint);
          const adjustedError = modelError * timeHorizonFactor;
          
          // Standard deviation for normal distribution
          const stdDev = adjustedError * Math.abs(value);
          
          // Generate points for the distribution curve
          const distributionPoints = [];
          const numPoints = 21; // Odd number to include the mean
          const range = 3; // +/- 3 standard deviations
          
          for (let i = 0; i < numPoints; i++) {
            const z = -range + (2 * range * i) / (numPoints - 1);
            const x = value + z * stdDev;
            const y = Math.exp(-0.5 * z * z) / (stdDev * Math.sqrt(2 * Math.PI));
            
            distributionPoints.push({ x, y });
          }
          
          return {
            distribution_type: 'normal',
            mean: value,
            standard_deviation: stdDev,
            points: distributionPoints
          };
        }
        
        // Helper function: Calculate time horizon factor
        function calculateTimeHorizonFactor(timePoint) {
          // Parse time point to determine how far in the future it is
          // Format: '2023-06-01' or '2023-Q2' or '2023'
          
          // For demonstration, we'll use a simple approach
          // Assume timePoint is in format 'YYYY-MM-DD' or similar
          
          // Current date
          const now = new Date();
          
          // Try to parse the time point
          let targetDate;
          
          if (timePoint.match(/^\d{4}-\d{2}-\d{2}$/)) {
            // YYYY-MM-DD format
            targetDate = new Date(timePoint);
          } else if (timePoint.match(/^\d{4}-Q[1-4]$/)) {
            // YYYY-Q# format
            const year = parseInt(timePoint.substring(0, 4));
            const quarter = parseInt(timePoint.substring(6, 7));
            const month = (quarter - 1) * 3;
            targetDate = new Date(year, month, 15);
          } else if (timePoint.match(/^\d{4}$/)) {
            // YYYY format
            const year = parseInt(timePoint);
            targetDate = new Date(year, 6, 1); // Middle of the year
          } else {
            // Default: assume it's 1 month in the future
            targetDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
          }
          
          // Calculate months difference
          const monthsDiff = (targetDate.getFullYear() - now.getFullYear()) * 12 +
                            (targetDate.getMonth() - now.getMonth());
          
          // Factor increases with time horizon
          // 1 month: factor = 1
          // 12 months: factor ≈ 2
          // 36 months: factor ≈ 3.5
          return Math.max(1, Math.sqrt(1 + monthsDiff / 6));
        }
      `
    }
  }
]
```

### 5. 視点間の相互作用の考慮

テクノロジー、マーケット、ビジネスの各視点間の相互作用を明示的にモデル化し、予測に反映させます。

```javascript
// n8n workflow: Cross-Perspective Interaction Modeling
// Function node for modeling interactions between perspectives
[
  {
    "id": "modelCrossPerspectiveInteractions",
    "type": "n8n-nodes-base.function",
    "parameters": {
      "functionCode": `
        // Input: Perspective-specific predictions and interaction matrix
        const perspectivePredictions = $input.item.json.perspective_predictions || {};
        const interactionMatrix = $input.item.json.interaction_matrix || {};
        const timePoints = $input.item.json.time_points || [];
        
        // Validate input
        if (Object.keys(perspectivePredictions).length === 0) {
          throw new Error('No perspective predictions provided');
        }
        
        if (timePoints.length === 0) {
          throw new Error('No time points provided');
        }
        
        // Ensure we have predictions for all perspectives
        const perspectives = ['technology', 'market', 'business'];
        perspectives.forEach(perspective => {
          if (!perspectivePredictions[perspective]) {
            throw new Error(\`Missing predictions for \${perspective} perspective\`);
          }
        });
        
        // Initialize adjusted predictions with original values
        const adjustedPredictions = {};
        perspectives.forEach(perspective => {
          adjustedPredictions[perspective] = { ...perspectivePredictions[perspective] };
        });
        
        // Apply cross-perspective interactions
        const maxIterations = 5; // Limit iterations to prevent infinite loops
        let hasConverged = false;
        let iteration = 0;
        
        while (!hasConverged && iteration < maxIterations) {
          const previousAdjustedPredictions = JSON.parse(JSON.stringify(adjustedPredictions));
          
          // For each time point
          timePoints.forEach(timePoint => {
            // For each target perspective
            perspectives.forEach(targetPerspective => {
              // Calculate adjustment from other perspectives
              let adjustment = 0;
              
              // For each source perspective
              perspectives.forEach(sourcePerspective => {
                if (sourcePerspective !== targetPerspective) {
                  // Get interaction strength
                  const interactionStrength = interactionMatrix[sourcePerspective]?.[targetPerspective] || 0;
                  
                  if (interactionStrength !== 0) {
                    // Get source perspective value
                    const sourceValue = perspectivePredictions[sourcePerspective][timePoint] || 0;
                    
                    // Calculate contribution to adjustment
                    adjustment += interactionStrength * sourceValue;
                  }
                }
              });
              
              // Apply adjustment
              const originalValue = perspectivePredictions[targetPerspective][timePoint] || 0;
              const adjustedValue = originalValue + adjustment;
              
              // Update adjusted prediction
              adjustedPredictions[targetPerspective][timePoint] = adjustedValue;
            });
          });
          
          // Check convergence
          hasConverged = checkConvergence(previousAdjustedPredictions, adjustedPredictions, 0.001);
          iteration++;
        }
        
        return {
          json: {
            original_predictions: perspectivePredictions,
            adjusted_predictions: adjustedPredictions,
            interaction_matrix: interactionMatrix,
            iterations: iteration,
            converged: hasConverged
          }
        };
        
        // Helper function: Check convergence
        function checkConvergence(previous, current, threshold) {
          // Calculate maximum difference
          let maxDiff = 0;
          
          Object.keys(current).forEach(perspective => {
            Object.keys(current[perspective]).forEach(timePoint => {
              const prevValue = previous[perspective][timePoint] || 0;
              const currValue = current[perspective][timePoint] || 0;
              const diff = Math.abs(currValue - prevValue);
              
              maxDiff = Math.max(maxDiff, diff);
            });
          });
          
          return maxDiff < threshold;
        }
      `
    }
  }
]
```

### 6. 透明性と説明可能性

予測結果だけでなく、その根拠や信頼性も明示的に提供し、意思決定者が予測の背景を理解できるようにします。

```javascript
// n8n workflow: Prediction Explainability
// Function node for generating prediction explanations
[
  {
    "id": "generatePredictionExplanations",
    "type": "n8n-nodes-base.function",
    "parameters": {
      "functionCode": `
        // Input: Prediction data and model information
        const prediction = $input.item.json.prediction || {};
        const modelInfo = $input.item.json.model_info || {};
        const featureImportance = $input.item.json.feature_importance || {};
        const historicalContext = $input.item.json.historical_context || {};
        
        // Validate input
        if (Object.keys(prediction).length === 0) {
          throw new Error('No prediction data provided');
        }
        
        // Generate explanations for the prediction
        const explanations = {
          summary: generateSummaryExplanation(prediction, modelInfo),
          key_factors: generateKeyFactorsExplanation(prediction, featureImportance),
          historical_context: generateHistoricalContextExplanation(prediction, historicalContext),
          uncertainty: generateUncertaintyExplanation(prediction),
          methodology: generateMethodologyExplanation(modelInfo)
        };
        
        return {
          json: {
            prediction,
            explanations
          }
        };
        
        // Helper function: Generate summary explanation
        function generateSummaryExplanation(prediction, modelInfo) {
          // Create a summary explanation of the prediction
          
          const predictedValue = prediction.value || 0;
          const timePoint = prediction.time_point || 'unknown';
          const confidenceScore = prediction.confidence_score || 0;
          const modelName = modelInfo.name || 'unknown model';
          
          let trend = 'stable';
          if (prediction.previous_value) {
            const change = predictedValue - prediction.previous_value;
            const percentChange = change / Math.abs(prediction.previous_value) * 100;
            
            if (percentChange > 5) trend = 'increasing';
            else if (percentChange < -5) trend = 'decreasing';
          }
          
          const trendText = trend === 'increasing' ? '上昇' : 
                           trend === 'decreasing' ? '下降' : '安定';
          
          return {
            text: \`\${timePoint}時点での予測値は\${formatValue(predictedValue)}で、前回と比較して\${trendText}傾向にあります。この予測の確信度は\${Math.round(confidenceScore * 100)}%です。この予測は\${modelName}を使用して生成されました。\`,
            trend,
            confidence_level: confidenceScore > 0.8 ? 'high' : 
                             confidenceScore > 0.5 ? 'medium' : 'low'
          };
        }
        
        // Helper function: Generate key factors explanation
        function generateKeyFactorsExplanation(prediction, featureImportance) {
          // Explain the key factors influencing the prediction
          
          // Sort features by importance
          const sortedFeatures = Object.entries(featureImportance)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5); // Top 5 features
          
          const keyFactors = sortedFeatures.map(([feature, importance]) => ({
            feature,
            importance,
            direction: Math.random() > 0.5 ? 'positive' : 'negative', // In a real implementation, this would be determined from the model
            description: generateFeatureDescription(feature, importance)
          }));
          
          return {
            text: \`この予測に最も影響を与えている要因は\${keyFactors[0].feature}（影響度: \${Math.round(keyFactors[0].importance * 100)}%）です。その他の重要な要因には\${keyFactors.slice(1).map(f => f.feature).join('、')}があります。\`,
            key_factors: keyFactors
          };
        }
        
        // Helper function: Generate historical context explanation
        function generateHistoricalContextExplanation(prediction, historicalContext) {
          // Provide historical context for the prediction
          
          const predictedValue = prediction.value || 0;
          const historicalAverage = historicalContext.average || 0;
          const historicalMax = historicalContext.max || 0;
          const historicalMin = historicalContext.min || 0;
          
          let comparison = 'average';
          if (predictedValue > historicalMax * 0.9) comparison = 'high';
          else if (predictedValue < historicalMin * 1.1) comparison = 'low';
          
          const comparisonText = comparison === 'high' ? '過去の最高値に近い' : 
                                comparison === 'low' ? '過去の最低値に近い' : '過去の平均的な値に近い';
          
          return {
            text: \`この予測値（\${formatValue(predictedValue)}）は\${comparisonText}値です。過去の平均は\${formatValue(historicalAverage)}、最高値は\${formatValue(historicalMax)}、最低値は\${formatValue(historicalMin)}でした。\`,
            comparison,
            historical_data: {
              average: historicalAverage,
              max: historicalMax,
              min: historicalMin
            }
          };
        }
        
        // Helper function: Generate uncertainty explanation
        function generateUncertaintyExplanation(prediction) {
          // Explain the uncertainty in the prediction
          
          const interval = prediction.prediction_interval || {};
          const lowerBound = interval.lower_bound || 0;
          const upperBound = interval.upper_bound || 0;
          const confidenceLevel = prediction.confidence_level || 0.95;
          
          const range = upperBound - lowerBound;
          const midPoint = (upperBound + lowerBound) / 2;
          const relativeRange = range / Math.abs(midPoint);
          
          let uncertaintyLevel = 'medium';
          if (relativeRange > 0.5) uncertaintyLevel = 'high';
          else if (relativeRange < 0.2) uncertaintyLevel = 'low';
          
          const uncertaintyText = uncertaintyLevel === 'high' ? '高い' : 
                                 uncertaintyLevel === 'low' ? '低い' : '中程度の';
          
          return {
            text: \`この予測には\${uncertaintyText}不確実性があります。\${Math.round(confidenceLevel * 100)}%の確率で、実際の値は\${formatValue(lowerBound)}から\${formatValue(upperBound)}の範囲内になると予測されます。\`,
            uncertainty_level: uncertaintyLevel,
            relative_range: relativeRange
          };
        }
        
        // Helper function: Generate methodology explanation
        function generateMethodologyExplanation(modelInfo) {
          // Explain the methodology used for the prediction
          
          const modelType = modelInfo.type || 'unknown';
          const modelDescription = getModelDescription(modelType);
          const dataPoints = modelInfo.training_data_points || 'unknown';
          const lastTraining = modelInfo.last_training_date || 'unknown';
          
          return {
            text: \`この予測は\${modelDescription}を使用して生成されました。モデルは\${dataPoints}のデータポイントで訓練され、最後のトレーニングは\${lastTraining}に行われました。\`,
            model_type: modelType,
            training_info: {
              data_points: dataPoints,
              last_training: lastTraining
            }
          };
        }
        
        // Helper function: Format value
        function formatValue(value) {
          // Format value for display
          if (typeof value !== 'number') return value;
          
          // Round to 2 decimal places
          return Math.round(value * 100) / 100;
        }
        
        // Helper function: Generate feature description
        function generateFeatureDescription(feature, importance) {
          // In a real implementation, this would provide a meaningful description
          // For demonstration, we'll use placeholder descriptions
          
          const descriptions = {
            'market_growth': '市場成長率の変化',
            'technology_adoption': '技術採用率の変化',
            'competitor_activity': '競合他社の活動',
            'regulatory_changes': '規制環境の変化',
            'consumer_sentiment': '消費者センチメントの変化',
            'innovation_rate': 'イノベーション率の変化',
            'economic_indicators': '経済指標の変化',
            'supply_chain_factors': 'サプライチェーン要因',
            'pricing_trends': '価格動向の変化',
            'product_lifecycle': '製品ライフサイクルの段階'
          };
          
          return descriptions[feature] || \`\${feature}の変化\`;
        }
        
        // Helper function: Get model description
        function getModelDescription(modelType) {
          // Provide a description for the model type
          
          const descriptions = {
            'arima': '時系列分析モデル（ARIMA）',
            'prophet': '時系列予測モデル（Prophet）',
            'random_forest': 'ランダムフォレスト機械学習モデル',
            'gradient_boosting': '勾配ブースティング機械学習モデル',
            'lstm': 'ディープラーニング長短期記憶（LSTM）モデル',
            'transformer': 'Transformerニューラルネットワークモデル',
            'ensemble': '複数モデルのアンサンブル'
          };
          
          return descriptions[modelType] || modelType;
        }
      `
    }
  }
]
```

## n8nによる予測エンジンの基本実装

n8nを活用して、予測エンジンの基本的なワークフローを実装します。

### 予測エンジン初期化ワークフロー

```javascript
// n8n workflow: Prediction Engine Initialization
// This workflow initializes the prediction engine
[
  {
    "id": "start",
    "type": "n8n-nodes-base.start",
    "position": [100, 300]
  },
  {
    "id": "initializePredictionEngine",
    "type": "n8n-nodes-base.function",
    "position": [300, 300],
    "parameters": {
      "functionCode": `
        // Initialize prediction engine configuration
        const predictionEngineConfig = {
          version: '1.0.0',
          created_at: new Date().toISOString(),
          perspectives: ['technology', 'market', 'business'],
          time_horizons: ['3_months', '6_months', '1_year', '2_years'],
          default_models: {
            technology: 'ensemble',
            market: 'ensemble',
            business: 'ensemble'
          },
          ensemble_config: {
            method: 'weighted_average',
            models: {
              arima: { weight: 0.2 },
              prophet: { weight: 0.3 },
              lstm: { weight: 0.3 },
              gradient_boosting: { weight: 0.2 }
            }
          },
          uncertainty_config: {
            confidence_levels: [0.8, 0.9, 0.95],
            default_confidence_level: 0.9
          },
          interaction_matrix: {
            technology: {
              market: 0.3,
              business: 0.2
            },
            market: {
              technology: 0.1,
              business: 0.4
            },
            business: {
              technology: 0.2,
              market: 0.3
            }
          },
          update_frequency: '1_day',
          storage_config: {
            predictions_retention: '1_year',
            models_retention: '2_years'
          }
        };
        
        return {
          json: {
            success: true,
            message: 'Prediction engine initialized successfully',
            config: predictionEngineConfig
          }
        };
      `
    }
  },
  {
    "id": "registerModels",
    "type": "n8n-nodes-base.function",
    "position": [500, 300],
    "parameters": {
      "functionCode": `
        // Register prediction models
        const models = [
          {
            id: 'arima',
            name: 'ARIMA Model',
            type: 'statistical',
            description: 'AutoRegressive Integrated Moving Average model for time series forecasting',
            parameters: {
              p: 2,
              d: 1,
              q: 2
            }
          },
          {
            id: 'prophet',
            name: 'Prophet Model',
            type: 'statistical',
            description: 'Facebook Prophet model for time series forecasting with seasonality',
            parameters: {
              seasonality_mode: 'multiplicative',
              changepoint_prior_scale: 0.05
            }
          },
          {
            id: 'gradient_boosting',
            name: 'Gradient Boosting Model',
            type: 'machine_learning',
            description: 'Gradient Boosting Regression model for time series forecasting',
            parameters: {
              n_estimators: 100,
              learning_rate: 0.1,
              max_depth: 3
            }
          },
          {
            id: 'lstm',
            name: 'LSTM Model',
            type: 'deep_learning',
            description: 'Long Short-Term Memory neural network for time series forecasting',
            parameters: {
              units: 50,
              dropout: 0.2,
              recurrent_dropout: 0.2
            }
          },
          {
            id: 'ensemble',
            name: 'Ensemble Model',
            type: 'ensemble',
            description: 'Ensemble of multiple models for improved forecasting accuracy',
            parameters: {
              method: 'weighted_average',
              models: ['arima', 'prophet', 'gradient_boosting', 'lstm']
            }
          }
        ];
        
        // In a real implementation, this would register models in a database
        // For demonstration, we'll just return the registered models
        
        return {
          json: {
            success: true,
            message: \`\${models.length} models registered successfully\`,
            registered_models: models
          }
        };
      `
    }
  },
  {
    "id": "createDataPipelines",
    "type": "n8n-nodes-base.function",
    "position": [700, 300],
    "parameters": {
      "functionCode": `
        // Create data pipelines for prediction engine
        const dataPipelines = [
          {
            id: 'technology_data_pipeline',
            name: 'Technology Data Pipeline',
            perspective: 'technology',
            data_sources: [
              { id: 'tech_news', type: 'rss', url: 'https://example.com/tech_news.rss' },
              { id: 'patent_database', type: 'api', url: 'https://example.com/api/patents' },
              { id: 'research_papers', type: 'api', url: 'https://example.com/api/research' }
            ],
            preprocessing_steps: [
              { type: 'clean_text', params: { remove_html: true, lowercase: true } },
              { type: 'extract_entities', params: { entity_types: ['technology', 'company', 'person'] } },
              { type: 'sentiment_analysis', params: { model: 'default' } }
            ],
            feature_engineering: [
              { type: 'trend_extraction', params: { window_size: 30 } },
              { type: 'topic_modeling', params: { num_topics: 10 } },
              { type: 'temporal_aggregation', params: { frequency: 'weekly' } }
            ]
          },
          {
            id: 'market_data_pipeline',
            name: 'Market Data Pipeline',
            perspective: 'market',
            data_sources: [
              { id: 'market_news', type: 'rss', url: 'https://example.com/market_news.rss' },
              { id: 'social_media', type: 'api', url: 'https://example.com/api/social' },
              { id: 'market_research', type: 'api', url: 'https://example.com/api/market_research' }
            ],
            preprocessing_steps: [
              { type: 'clean_text', params: { remove_html: true, lowercase: true } },
              { type: 'extract_entities', params: { entity_types: ['company', 'product', 'market'] } },
              { type: 'sentiment_analysis', params: { model: 'default' } }
            ],
            feature_engineering: [
              { type: 'trend_extraction', params: { window_size: 30 } },
              { type: 'market_segmentation', params: { num_segments: 5 } },
              { type: 'temporal_aggregation', params: { frequency: 'weekly' } }
            ]
          },
          {
            id: 'business_data_pipeline',
            name: 'Business Data Pipeline',
            perspective: 'business',
            data_sources: [
              { id: 'financial_news', type: 'rss', url: 'https://example.com/financial_news.rss' },
              { id: 'company_reports', type: 'api', url: 'https://example.com/api/company_reports' },
              { id: 'economic_indicators', type: 'api', url: 'https://example.com/api/economic' }
            ],
            preprocessing_steps: [
              { type: 'clean_text', params: { remove_html: true, lowercase: true } },
              { type: 'extract_entities', params: { entity_types: ['company', 'financial', 'regulation'] } },
              { type: 'sentiment_analysis', params: { model: 'default' } }
            ],
            feature_engineering: [
              { type: 'trend_extraction', params: { window_size: 30 } },
              { type: 'financial_ratio_analysis', params: { ratios: ['roi', 'profit_margin', 'growth_rate'] } },
              { type: 'temporal_aggregation', params: { frequency: 'weekly' } }
            ]
          }
        ];
        
        // In a real implementation, this would create data pipelines in the system
        // For demonstration, we'll just return the created pipelines
        
        return {
          json: {
            success: true,
            message: \`\${dataPipelines.length} data pipelines created successfully\`,
            created_pipelines: dataPipelines
          }
        };
      `
    }
  },
  {
    "id": "setupScheduledPredictions",
    "type": "n8n-nodes-base.function",
    "position": [900, 300],
    "parameters": {
      "functionCode": `
        // Setup scheduled predictions
        const scheduledPredictions = [
          {
            id: 'daily_predictions',
            name: 'Daily Predictions',
            schedule: 'daily',
            time: '00:00:00',
            perspectives: ['technology', 'market', 'business'],
            time_horizons: ['3_months', '6_months', '1_year'],
            topics: 'all',
            notification: {
              enabled: true,
              channels: ['email', 'dashboard'],
              threshold: 'significant_change'
            }
          },
          {
            id: 'weekly_predictions',
            name: 'Weekly Detailed Predictions',
            schedule: 'weekly',
            day: 'monday',
            time: '00:00:00',
            perspectives: ['technology', 'market', 'business'],
            time_horizons: ['3_months', '6_months', '1_year', '2_years'],
            topics: 'all',
            include_scenarios: true,
            notification: {
              enabled: true,
              channels: ['email', 'dashboard', 'report'],
              threshold: 'all'
            }
          },
          {
            id: 'monthly_strategic_predictions',
            name: 'Monthly Strategic Predictions',
            schedule: 'monthly',
            day: 1,
            time: '00:00:00',
            perspectives: ['technology', 'market', 'business'],
            time_horizons: ['1_year', '2_years'],
            topics: 'strategic',
            include_scenarios: true,
            include_recommendations: true,
            notification: {
              enabled: true,
              channels: ['email', 'dashboard', 'report', 'presentation'],
              threshold: 'all'
            }
          }
        ];
        
        // In a real implementation, this would schedule predictions in the system
        // For demonstration, we'll just return the scheduled predictions
        
        return {
          json: {
            success: true,
            message: \`\${scheduledPredictions.length} prediction schedules created successfully\`,
            scheduled_predictions: scheduledPredictions
          }
        };
      `
    }
  },
  {
    "id": "finalizePredictionEngineSetup",
    "type": "n8n-nodes-base.function",
    "position": [1100, 300],
    "parameters": {
      "functionCode": `
        // Finalize prediction engine setup
        const items = $input.all();
        
        const setupSummary = {
          engine_config: items[0].json.config,
          registered_models: items[1].json.registered_models,
          data_pipelines: items[2].json.created_pipelines,
          scheduled_predictions: items[3].json.scheduled_predictions,
          setup_completed_at: new Date().toISOString(),
          status: 'ready'
        };
        
        return {
          json: {
            success: true,
            message: 'Prediction engine setup completed successfully',
            setup_summary: setupSummary
          }
        };
      `
    }
  }
]
```

## まとめ

本セクションでは、トリプルパースペクティブ型戦略AIレーダーにおける予測エンジンの基本アーキテクチャと設計原則について詳細に解説しました。予測エンジンの役割と重要性、基本アーキテクチャ、設計原則、n8nによる基本実装など、多岐にわたる側面を網羅しました。

特に、モジュール性と拡張性、多モデルアプローチ、適応性と自己学習、不確実性の明示的な表現、視点間の相互作用の考慮、透明性と説明可能性といった設計原則は、トリプルパースペクティブ型戦略AIレーダーの予測機能を効果的に実装するための基盤となります。

次のパートでは、予測モデルの詳細な実装方法と、具体的なユースケースについて解説します。
