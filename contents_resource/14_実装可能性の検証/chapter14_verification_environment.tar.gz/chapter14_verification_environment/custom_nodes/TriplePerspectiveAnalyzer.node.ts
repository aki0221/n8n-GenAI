import {
    IExecuteFunctions,
    INodeExecutionData,
    INodeType,
    INodeTypeDescription,
    NodeOperationError,
} from 'n8n-workflow';

export class TriplePerspectiveAnalyzer implements INodeType {
    description: INodeTypeDescription = {
        displayName: 'Triple Perspective Analyzer',
        name: 'triplePerspectiveAnalyzer',
        icon: 'fa:chart-line',
        group: ['transform'],
        version: 1,
        description: '3視点統合分析を実行するカスタムノード',
        defaults: {
            name: 'Triple Perspective Analyzer',
        },
        inputs: ['main'],
        outputs: ['main'],
        properties: [
            {
                displayName: '分析対象データ',
                name: 'analysisData',
                type: 'json',
                default: '{}',
                description: '分析対象となるデータをJSON形式で入力',
                required: true,
            },
            {
                displayName: '技術視点重み',
                name: 'technicalWeight',
                type: 'number',
                default: 0.33,
                description: '技術視点の重み付け（0-1）',
                typeOptions: {
                    minValue: 0,
                    maxValue: 1,
                    numberStepSize: 0.01,
                },
            },
            {
                displayName: '市場視点重み',
                name: 'marketWeight',
                type: 'number',
                default: 0.33,
                description: '市場視点の重み付け（0-1）',
                typeOptions: {
                    minValue: 0,
                    maxValue: 1,
                    numberStepSize: 0.01,
                },
            },
            {
                displayName: 'ビジネス視点重み',
                name: 'businessWeight',
                type: 'number',
                default: 0.34,
                description: 'ビジネス視点の重み付け（0-1）',
                typeOptions: {
                    minValue: 0,
                    maxValue: 1,
                    numberStepSize: 0.01,
                },
            },
        ],
    };

    async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
        const items = this.getInputData();
        const returnData: INodeExecutionData[] = [];

        for (let i = 0; i < items.length; i++) {
            try {
                const analysisData = this.getNodeParameter('analysisData', i) as object;
                const technicalWeight = this.getNodeParameter('technicalWeight', i) as number;
                const marketWeight = this.getNodeParameter('marketWeight', i) as number;
                const businessWeight = this.getNodeParameter('businessWeight', i) as number;

                // 重み付けの合計が1になるように正規化
                const totalWeight = technicalWeight + marketWeight + businessWeight;
                const normalizedWeights = {
                    technical: technicalWeight / totalWeight,
                    market: marketWeight / totalWeight,
                    business: businessWeight / totalWeight,
                };

                // 3視点分析の実行
                const analysisResult = await this.performTriplePerspectiveAnalysis(
                    analysisData,
                    normalizedWeights
                );

                returnData.push({
                    json: {
                        originalData: analysisData,
                        weights: normalizedWeights,
                        analysisResult,
                        timestamp: new Date().toISOString(),
                    },
                });
            } catch (error) {
                if (this.continueOnFail()) {
                    returnData.push({
                        json: {
                            error: error.message,
                        },
                    });
                    continue;
                }
                throw new NodeOperationError(this.getNode(), error);
            }
        }

        return [returnData];
    }

    private async performTriplePerspectiveAnalysis(
        data: any,
        weights: { technical: number; market: number; business: number }
    ): Promise<any> {
        // 技術視点分析
        const technicalAnalysis = this.analyzeTechnicalPerspective(data);
        
        // 市場視点分析
        const marketAnalysis = this.analyzeMarketPerspective(data);
        
        // ビジネス視点分析
        const businessAnalysis = this.analyzeBusinessPerspective(data);

        // 統合スコア計算
        const integratedScore = 
            technicalAnalysis.score * weights.technical +
            marketAnalysis.score * weights.market +
            businessAnalysis.score * weights.business;

        // 静止点検出（簡易版）
        const equilibriumPoint = this.detectEquilibriumPoint(
            technicalAnalysis,
            marketAnalysis,
            businessAnalysis
        );

        return {
            perspectives: {
                technical: technicalAnalysis,
                market: marketAnalysis,
                business: businessAnalysis,
            },
            integratedScore,
            equilibriumPoint,
            recommendation: this.generateRecommendation(integratedScore, equilibriumPoint),
        };
    }

    private analyzeTechnicalPerspective(data: any): any {
        // 技術視点の分析ロジック（簡易版）
        const technicalFactors = [
            'feasibility',
            'complexity',
            'scalability',
            'maintainability',
        ];

        let score = 0;
        let factorCount = 0;

        technicalFactors.forEach(factor => {
            if (data[factor] !== undefined) {
                score += Number(data[factor]) || 0;
                factorCount++;
            }
        });

        const averageScore = factorCount > 0 ? score / factorCount : 0;

        return {
            score: Math.min(Math.max(averageScore, 0), 1), // 0-1の範囲に正規化
            factors: technicalFactors,
            details: {
                evaluatedFactors: factorCount,
                rawScore: score,
            },
        };
    }

    private analyzeMarketPerspective(data: any): any {
        // 市場視点の分析ロジック（簡易版）
        const marketFactors = [
            'marketSize',
            'competition',
            'demand',
            'trends',
        ];

        let score = 0;
        let factorCount = 0;

        marketFactors.forEach(factor => {
            if (data[factor] !== undefined) {
                score += Number(data[factor]) || 0;
                factorCount++;
            }
        });

        const averageScore = factorCount > 0 ? score / factorCount : 0;

        return {
            score: Math.min(Math.max(averageScore, 0), 1), // 0-1の範囲に正規化
            factors: marketFactors,
            details: {
                evaluatedFactors: factorCount,
                rawScore: score,
            },
        };
    }

    private analyzeBusinessPerspective(data: any): any {
        // ビジネス視点の分析ロジック（簡易版）
        const businessFactors = [
            'profitability',
            'riskLevel',
            'resourceRequirement',
            'strategicAlignment',
        ];

        let score = 0;
        let factorCount = 0;

        businessFactors.forEach(factor => {
            if (data[factor] !== undefined) {
                score += Number(data[factor]) || 0;
                factorCount++;
            }
        });

        const averageScore = factorCount > 0 ? score / factorCount : 0;

        return {
            score: Math.min(Math.max(averageScore, 0), 1), // 0-1の範囲に正規化
            factors: businessFactors,
            details: {
                evaluatedFactors: factorCount,
                rawScore: score,
            },
        };
    }

    private detectEquilibriumPoint(
        technical: any,
        market: any,
        business: any
    ): any {
        // 静止点検出の簡易実装
        const scores = [technical.score, market.score, business.score];
        const variance = this.calculateVariance(scores);
        const mean = scores.reduce((sum, score) => sum + score, 0) / scores.length;

        return {
            isEquilibrium: variance < 0.1, // 分散が0.1未満の場合を静止点とみなす
            variance,
            mean,
            stability: 1 - variance, // 安定性指標
        };
    }

    private calculateVariance(scores: number[]): number {
        const mean = scores.reduce((sum, score) => sum + score, 0) / scores.length;
        const squaredDifferences = scores.map(score => Math.pow(score - mean, 2));
        return squaredDifferences.reduce((sum, diff) => sum + diff, 0) / scores.length;
    }

    private generateRecommendation(integratedScore: number, equilibriumPoint: any): string {
        if (equilibriumPoint.isEquilibrium && integratedScore > 0.7) {
            return '高い統合スコアと安定した静止点を検出。実行を強く推奨します。';
        } else if (integratedScore > 0.6) {
            return '良好な統合スコア。条件を満たせば実行を推奨します。';
        } else if (integratedScore > 0.4) {
            return '中程度の統合スコア。リスクと利益を慎重に検討してください。';
        } else {
            return '低い統合スコア。実行前に戦略の見直しを推奨します。';
        }
    }
}

