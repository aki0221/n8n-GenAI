#!/bin/bash

# 第14章実証検証環境セットアップスクリプト
# 作成支援: Manus AI

echo "=== 第14章 n8n実証検証環境セットアップ開始 ==="

# 現在のディレクトリを確認
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "セットアップディレクトリ: $SCRIPT_DIR"

# 必要なディレクトリの作成
echo "必要なディレクトリを作成中..."
mkdir -p mock_api_config
mkdir -p logs

# Mock APIの設定ファイル作成
echo "Mock API設定ファイルを作成中..."
cat > mock_api_config/mockserver.properties << EOF
mockserver.logLevel=INFO
mockserver.disableSystemOut=false
EOF

# Mock APIの初期設定JSON作成
cat > mock_api_config/expectations.json << EOF
[
  {
    "httpRequest": {
      "method": "GET",
      "path": "/api/technical-data"
    },
    "httpResponse": {
      "statusCode": 200,
      "headers": {
        "Content-Type": ["application/json"]
      },
      "body": {
        "feasibility": 0.8,
        "complexity": 0.6,
        "scalability": 0.9,
        "maintainability": 0.7,
        "timestamp": "2024-01-01T00:00:00Z"
      }
    }
  },
  {
    "httpRequest": {
      "method": "GET",
      "path": "/api/market-data"
    },
    "httpResponse": {
      "statusCode": 200,
      "headers": {
        "Content-Type": ["application/json"]
      },
      "body": {
        "marketSize": 0.8,
        "competition": 0.5,
        "demand": 0.9,
        "trends": 0.8,
        "timestamp": "2024-01-01T00:00:00Z"
      }
    }
  },
  {
    "httpRequest": {
      "method": "GET",
      "path": "/api/business-data"
    },
    "httpResponse": {
      "statusCode": 200,
      "headers": {
        "Content-Type": ["application/json"]
      },
      "body": {
        "profitability": 0.7,
        "riskLevel": 0.4,
        "resourceRequirement": 0.6,
        "strategicAlignment": 0.9,
        "timestamp": "2024-01-01T00:00:00Z"
      }
    }
  }
]
EOF

# Docker Composeでサービス起動
echo "Docker Composeでサービスを起動中..."
docker-compose down --remove-orphans
docker-compose up -d

# サービス起動待機
echo "サービス起動を待機中..."
sleep 30

# サービス状態確認
echo "サービス状態を確認中..."
docker-compose ps

# n8nの起動確認
echo "n8nの起動を確認中..."
for i in {1..10}; do
    if curl -s http://localhost:5678 > /dev/null; then
        echo "n8nが正常に起動しました"
        break
    else
        echo "n8n起動待機中... ($i/10)"
        sleep 10
    fi
done

# Mock APIの起動確認
echo "Mock APIの起動を確認中..."
if curl -s http://localhost:1080/api/technical-data > /dev/null; then
    echo "Mock APIが正常に起動しました"
else
    echo "Mock APIの起動に問題があります"
fi

# 実証検証環境の情報表示
echo ""
echo "=== 実証検証環境セットアップ完了 ==="
echo "n8n Web UI: http://localhost:5678"
echo "  ユーザー名: admin"
echo "  パスワード: verification123"
echo ""
echo "PostgreSQL: localhost:5432"
echo "  データベース: n8n"
echo "  ユーザー名: n8n"
echo "  パスワード: n8n_password"
echo ""
echo "Redis: localhost:6379"
echo ""
echo "Mock API: http://localhost:1080"
echo "  技術データ: http://localhost:1080/api/technical-data"
echo "  市場データ: http://localhost:1080/api/market-data"
echo "  ビジネスデータ: http://localhost:1080/api/business-data"
echo ""
echo "カスタムノード: ./custom_nodes/"
echo "テストワークフロー: ./test_workflows/"
echo ""
echo "=== 次のステップ ==="
echo "1. n8n Web UIにアクセス"
echo "2. カスタムノードのインストール（手動）"
echo "3. テストワークフローのインポート"
echo "4. 3視点統合分析の動作確認"
echo ""

