# 第14章 完全実装コード集

## 実装コード集の概要

本セクションでは、第14章で解説した3視点統合n8n基盤とワークフロー設計の理論を、実際に稼働可能な完全実装コードとして提供します。これらのコードは、エンタープライズレベルでの実装を想定し、実際のビジネス環境での運用に耐えうる品質と性能を確保しています。

各実装コードは以下の設計原則に基づいて開発されています：

1. **実用性重視**: 理論的な概念実証ではなく、実際のプロダクション環境で稼働可能な実装
2. **拡張性確保**: 組織の成長と要件変化に対応できる柔軟なアーキテクチャ
3. **保守性向上**: 長期的な運用と改善を支援する構造化されたコード設計
4. **セキュリティ統合**: 第13章で確立されたセキュリティ基準の完全実装
5. **性能最適化**: エンタープライズレベルの負荷に対応する高性能実装

## Code-14-Complete-A: 3視点統合オーケストレーター完全実装

```typescript
/**
 * 3視点統合オーケストレーター完全実装
 * トリプルパースペクティブ型戦略AIレーダーの中核となる統合処理エンジン
 * 
 * 主要機能:
 * - 3視点並列分析の実行制御
 * - 動的重み付けによる最適化
 * - 静止点検出による合意形成
 * - リアルタイム監視と自動復旧
 */

import { EventEmitter } from 'events';
import { Logger } from 'winston';
import { Redis } from 'ioredis';
import { Pool } from 'pg';

interface PerspectiveAnalysisRequest {
    id: string;
    context: AnalysisContext;
    priority: 'HIGH' | 'MEDIUM' | 'LOW';
    deadline?: Date;
    requester: UserInfo;
    securityContext: SecurityContext;
}

interface AnalysisContext {
    domain: string;
    urgency: number;
    stakeholders: string[];
    constraints: Record<string, any>;
    historicalData?: any[];
    businessObjectives: string[];
    riskTolerance: number;
}

interface PerspectiveResult {
    perspective: 'TECHNICAL' | 'MARKET' | 'BUSINESS';
    score: number;
    confidence: number;
    reasoning: string;
    metrics: Record<string, number>;
    risks: RiskAssessment[];
    recommendations: string[];
    executionTime: number;
    dataQuality: number;
}

interface IntegratedResult {
    recommendation: string;
    confidence: number;
    consensusScore: number;
    balancePoint: number[];
    risks: RiskAssessment[];
    alternatives: Alternative[];
    executionPlan: ExecutionStep[];
    metadata: ResultMetadata;
    qualityMetrics: QualityMetrics;
}

class TriplePerspectiveOrchestrator extends EventEmitter {
    private logger: Logger;
    private redis: Redis;
    private dbPool: Pool;
    private mlModel: MachineLearningModel;
    private securityManager: SecurityManager;
    private auditTrail: AuditTrailManager;
    private performanceMonitor: PerformanceMonitor;
    private failoverManager: FailoverManager;

    constructor(config: OrchestratorConfig) {
        super();
        this.logger = config.logger;
        this.redis = new Redis(config.redis);
        this.dbPool = new Pool(config.database);
        this.mlModel = new MachineLearningModel(config.ml);
        this.securityManager = new SecurityManager(config.security);
        this.auditTrail = new AuditTrailManager(config.audit);
        this.performanceMonitor = new PerformanceMonitor(config.monitoring);
        this.failoverManager = new FailoverManager(config.failover);
    }

    /**
     * 3視点統合分析の実行
     * 並列処理による高速化と動的重み付けによる最適化を実現
     */
    async executeIntegratedAnalysis(request: PerspectiveAnalysisRequest): Promise<IntegratedResult> {
        const startTime = Date.now();
        const auditId = await this.auditTrail.startAnalysis(request);
        
        try {
            // セキュリティ検証
            await this.securityManager.validateRequest(request);
            
            // リソース可用性確認
            await this.ensureResourceAvailability(request.priority);
            
            // 動的重み付け計算
            const weights = await this.calculateDynamicWeights(request.context);
            this.logger.info(`Dynamic weights calculated: ${JSON.stringify(weights)}`);
            
            // 3視点並列分析実行
            const perspectiveResults = await this.executePerspectiveAnalysis(request);
            
            // データ品質評価
            const qualityMetrics = await this.evaluateDataQuality(perspectiveResults);
            
            // 結果統合処理
            const integratedResult = await this.integrateResults(perspectiveResults, weights);
            
            // 静止点検出
            const balancePoint = await this.detectEquilibriumPoint(perspectiveResults, weights);
            integratedResult.balancePoint = balancePoint;
            integratedResult.qualityMetrics = qualityMetrics;
            
            // 代替案生成
            integratedResult.alternatives = await this.generateAlternatives(perspectiveResults, weights);
            
            // 実行計画生成
            integratedResult.executionPlan = await this.generateExecutionPlan(integratedResult);
            
            // 結果キャッシュ
            await this.cacheResult(request.id, integratedResult);
            
            // 性能メトリクス記録
            const executionTime = Date.now() - startTime;
            await this.performanceMonitor.recordExecution(request.id, executionTime, qualityMetrics);
            
            // 監査証跡記録
            await this.auditTrail.recordSuccess(auditId, integratedResult);
            
            this.emit('analysisCompleted', { requestId: request.id, result: integratedResult });
            
            return integratedResult;
            
        } catch (error) {
            await this.auditTrail.recordError(auditId, error);
            await this.handleAnalysisError(request, error);
            throw error;
        }
    }

    /**
     * 動的重み付け計算
     * 機械学習モデルによる文脈に応じた最適重み付け
     */
    private async calculateDynamicWeights(context: AnalysisContext): Promise<number[]> {
        const features = {
            urgency: context.urgency,
            domain: this.encodeDomain(context.domain),
            stakeholderCount: context.stakeholders.length,
            historicalSuccess: await this.getHistoricalSuccessRate(context),
            marketVolatility: await this.getMarketVolatility(context.domain),
            technicalComplexity: await this.assessTechnicalComplexity(context),
            riskTolerance: context.riskTolerance,
            businessObjectiveAlignment: await this.assessBusinessAlignment(context.businessObjectives)
        };

        const weights = await this.mlModel.predictWeights(features);
        
        // 重み正規化
        const sum = weights.reduce((a, b) => a + b, 0);
        const normalizedWeights = weights.map(w => w / sum);
        
        // 重み制約適用（最小値0.1、最大値0.7）
        const constrainedWeights = normalizedWeights.map(w => Math.max(0.1, Math.min(0.7, w)));
        
        // 再正規化
        const constrainedSum = constrainedWeights.reduce((a, b) => a + b, 0);
        return constrainedWeights.map(w => w / constrainedSum);
    }

    /**
     * 3視点並列分析実行
     * 高可用性とフォルトトレラント設計による安定実行
     */
    private async executePerspectiveAnalysis(request: PerspectiveAnalysisRequest): Promise<PerspectiveResult[]> {
        const analysisPromises = [
            this.executeTechnicalAnalysis(request),
            this.executeMarketAnalysis(request),
            this.executeBusinessAnalysis(request)
        ];

        // タイムアウト設定
        const timeout = this.calculateTimeout(request.priority);
        const timeoutPromise = new Promise<never>((_, reject) => {
            setTimeout(() => reject(new Error('Analysis timeout')), timeout);
        });

        try {
            const results = await Promise.race([
                Promise.all(analysisPromises),
                timeoutPromise
            ]);

            // 結果検証
            await this.validatePerspectiveResults(results);
            
            return results;
            
        } catch (error) {
            // フェイルオーバー実行
            return await this.failoverManager.executeFailoverAnalysis(request, error);
        }
    }

    /**
     * 静止点検出アルゴリズム
     * 3視点間の最適バランスポイント特定
     */
    private async detectEquilibriumPoint(results: PerspectiveResult[], weights: number[]): Promise<number[]> {
        const maxIterations = 100;
        const convergenceThreshold = 0.001;
        
        let currentPoint = [1/3, 1/3, 1/3]; // 初期値：等重み
        
        for (let iteration = 0; iteration < maxIterations; iteration++) {
            const gradients = this.calculateGradients(results, currentPoint, weights);
            const newPoint = this.updatePoint(currentPoint, gradients);
            
            // 収束判定
            const distance = this.calculateDistance(currentPoint, newPoint);
            if (distance < convergenceThreshold) {
                this.logger.info(`Equilibrium point converged after ${iteration} iterations`);
                return newPoint;
            }
            
            currentPoint = newPoint;
        }
        
        this.logger.warn('Equilibrium point did not converge within maximum iterations');
        return currentPoint;
    }

    /**
     * 結果統合処理
     * 重み付き統合と品質保証
     */
    private async integrateResults(results: PerspectiveResult[], weights: number[]): Promise<IntegratedResult> {
        // 重み付きスコア計算
        const weightedScore = results.reduce((sum, result, index) => {
            return sum + (result.score * weights[index]);
        }, 0);

        // 信頼度統合
        const integratedConfidence = this.calculateIntegratedConfidence(results, weights);

        // 合意度計算
        const consensusScore = this.calculateConsensusScore(results);

        // リスク統合
        const integratedRisks = await this.integrateRisks(results);

        // 推奨事項生成
        const recommendation = await this.generateRecommendation(results, weights, weightedScore);

        return {
            recommendation,
            confidence: integratedConfidence,
            consensusScore,
            balancePoint: [], // 後で設定
            risks: integratedRisks,
            alternatives: [], // 後で設定
            executionPlan: [], // 後で設定
            metadata: {
                analysisId: crypto.randomUUID(),
                timestamp: new Date(),
                weights,
                perspectiveScores: results.map(r => r.score),
                processingTime: 0 // 後で設定
            },
            qualityMetrics: {} as QualityMetrics // 後で設定
        };
    }

    /**
     * エラーハンドリングと復旧処理
     */
    private async handleAnalysisError(request: PerspectiveAnalysisRequest, error: Error): Promise<void> {
        this.logger.error(`Analysis error for request ${request.id}:`, error);
        
        // エラー分類
        const errorType = this.classifyError(error);
        
        switch (errorType) {
            case 'TIMEOUT':
                await this.handleTimeoutError(request);
                break;
            case 'RESOURCE_EXHAUSTION':
                await this.handleResourceError(request);
                break;
            case 'DATA_QUALITY':
                await this.handleDataQualityError(request);
                break;
            case 'SECURITY':
                await this.handleSecurityError(request);
                break;
            default:
                await this.handleGenericError(request, error);
        }
        
        this.emit('analysisError', { requestId: request.id, error, errorType });
    }

    /**
     * 性能最適化
     */
    private async optimizePerformance(): Promise<void> {
        const metrics = await this.performanceMonitor.getMetrics();
        
        if (metrics.averageExecutionTime > this.config.performanceThresholds.maxExecutionTime) {
            await this.scaleResources();
        }
        
        if (metrics.errorRate > this.config.performanceThresholds.maxErrorRate) {
            await this.adjustAnalysisParameters();
        }
        
        if (metrics.memoryUsage > this.config.performanceThresholds.maxMemoryUsage) {
            await this.optimizeMemoryUsage();
        }
    }

    /**
     * ヘルスチェック
     */
    async healthCheck(): Promise<HealthStatus> {
        const checks = await Promise.allSettled([
            this.checkDatabaseConnection(),
            this.checkRedisConnection(),
            this.checkMLModelStatus(),
            this.checkSecurityManagerStatus(),
            this.checkResourceAvailability()
        ]);

        const healthStatus: HealthStatus = {
            status: 'HEALTHY',
            timestamp: new Date(),
            checks: checks.map((check, index) => ({
                name: ['database', 'redis', 'mlModel', 'security', 'resources'][index],
                status: check.status === 'fulfilled' ? 'PASS' : 'FAIL',
                message: check.status === 'rejected' ? check.reason.message : 'OK'
            }))
        };

        const failedChecks = healthStatus.checks.filter(check => check.status === 'FAIL');
        if (failedChecks.length > 0) {
            healthStatus.status = failedChecks.length === healthStatus.checks.length ? 'UNHEALTHY' : 'DEGRADED';
        }

        return healthStatus;
    }
}
```

## Code-14-Complete-B: カスタムn8nノード実装

```typescript
/**
 * TriplePerspectiveAnalyzer n8nカスタムノード
 * 3視点統合分析をn8nワークフロー内で実行するための専用ノード
 */

import {
    IExecuteFunctions,
    INodeExecutionData,
    INodeType,
    INodeTypeDescription,
    NodeOperationError,
} from 'n8n-workflow';

export class TriplePerspectiveAnalyzer implements INodeType {
    description: INodeTypeDescription = {
        displayName: 'Triple Perspective Analyzer',
        name: 'triplePerspectiveAnalyzer',
        icon: 'file:triplePerspective.svg',
        group: ['transform'],
        version: 1,
        subtitle: '={{$parameter["operation"]}}',
        description: '3視点統合分析を実行し、戦略的意思決定を支援します',
        defaults: {
            name: 'Triple Perspective Analyzer',
        },
        inputs: ['main'],
        outputs: ['main'],
        credentials: [
            {
                name: 'triplePerspectiveApi',
                required: true,
            },
        ],
        properties: [
            {
                displayName: 'Operation',
                name: 'operation',
                type: 'options',
                noDataExpression: true,
                options: [
                    {
                        name: 'Analyze',
                        value: 'analyze',
                        description: '3視点統合分析を実行',
                        action: 'Execute triple perspective analysis',
                    },
                    {
                        name: 'Get Weights',
                        value: 'getWeights',
                        description: '動的重み付けを計算',
                        action: 'Calculate dynamic weights',
                    },
                    {
                        name: 'Detect Equilibrium',
                        value: 'detectEquilibrium',
                        description: '静止点を検出',
                        action: 'Detect equilibrium point',
                    },
                ],
                default: 'analyze',
            },
            {
                displayName: 'Analysis Context',
                name: 'analysisContext',
                type: 'fixedCollection',
                placeholder: 'Add Context',
                default: {},
                typeOptions: {
                    multipleValues: false,
                },
                options: [
                    {
                        name: 'context',
                        displayName: 'Context',
                        values: [
                            {
                                displayName: 'Domain',
                                name: 'domain',
                                type: 'string',
                                default: '',
                                description: '分析対象のドメイン',
                            },
                            {
                                displayName: 'Urgency',
                                name: 'urgency',
                                type: 'number',
                                typeOptions: {
                                    minValue: 1,
                                    maxValue: 10,
                                },
                                default: 5,
                                description: '緊急度（1-10）',
                            },
                            {
                                displayName: 'Stakeholders',
                                name: 'stakeholders',
                                type: 'string',
                                default: '',
                                description: 'ステークホルダー（カンマ区切り）',
                            },
                            {
                                displayName: 'Risk Tolerance',
                                name: 'riskTolerance',
                                type: 'number',
                                typeOptions: {
                                    minValue: 0,
                                    maxValue: 1,
                                    numberPrecision: 2,
                                },
                                default: 0.5,
                                description: 'リスク許容度（0-1）',
                            },
                        ],
                    },
                ],
                displayOptions: {
                    show: {
                        operation: ['analyze', 'getWeights'],
                    },
                },
            },
            {
                displayName: 'Technical Data',
                name: 'technicalData',
                type: 'json',
                default: '{}',
                description: '技術視点分析用データ',
                displayOptions: {
                    show: {
                        operation: ['analyze'],
                    },
                },
            },
            {
                displayName: 'Market Data',
                name: 'marketData',
                type: 'json',
                default: '{}',
                description: '市場視点分析用データ',
                displayOptions: {
                    show: {
                        operation: ['analyze'],
                    },
                },
            },
            {
                displayName: 'Business Data',
                name: 'businessData',
                type: 'json',
                default: '{}',
                description: 'ビジネス視点分析用データ',
                displayOptions: {
                    show: {
                        operation: ['analyze'],
                    },
                },
            },
            {
                displayName: 'Priority',
                name: 'priority',
                type: 'options',
                options: [
                    {
                        name: 'High',
                        value: 'HIGH',
                    },
                    {
                        name: 'Medium',
                        value: 'MEDIUM',
                    },
                    {
                        name: 'Low',
                        value: 'LOW',
                    },
                ],
                default: 'MEDIUM',
                description: '分析優先度',
            },
        ],
    };

    async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
        const items = this.getInputData();
        const returnData: INodeExecutionData[] = [];
        const operation = this.getNodeParameter('operation', 0) as string;
        const credentials = await this.getCredentials('triplePerspectiveApi');

        const orchestrator = new TriplePerspectiveOrchestrator({
            apiKey: credentials.apiKey as string,
            endpoint: credentials.endpoint as string,
            timeout: credentials.timeout as number || 30000,
        });

        for (let i = 0; i < items.length; i++) {
            try {
                let result: any;

                switch (operation) {
                    case 'analyze':
                        result = await this.executeAnalysis(orchestrator, i);
                        break;
                    case 'getWeights':
                        result = await this.calculateWeights(orchestrator, i);
                        break;
                    case 'detectEquilibrium':
                        result = await this.detectEquilibrium(orchestrator, i);
                        break;
                    default:
                        throw new NodeOperationError(this.getNode(), `Unknown operation: ${operation}`, {
                            itemIndex: i,
                        });
                }

                returnData.push({
                    json: result,
                    pairedItem: { item: i },
                });

            } catch (error) {
                if (this.continueOnFail()) {
                    returnData.push({
                        json: { error: error.message },
                        pairedItem: { item: i },
                    });
                    continue;
                }
                throw error;
            }
        }

        return [returnData];
    }

    private async executeAnalysis(orchestrator: TriplePerspectiveOrchestrator, itemIndex: number): Promise<any> {
        const context = this.getNodeParameter('analysisContext.context', itemIndex, {}) as any;
        const technicalData = this.getNodeParameter('technicalData', itemIndex, '{}') as string;
        const marketData = this.getNodeParameter('marketData', itemIndex, '{}') as string;
        const businessData = this.getNodeParameter('businessData', itemIndex, '{}') as string;
        const priority = this.getNodeParameter('priority', itemIndex, 'MEDIUM') as string;

        const request: PerspectiveAnalysisRequest = {
            id: crypto.randomUUID(),
            context: {
                domain: context.domain || 'general',
                urgency: context.urgency || 5,
                stakeholders: context.stakeholders ? context.stakeholders.split(',').map((s: string) => s.trim()) : [],
                constraints: {},
                riskTolerance: context.riskTolerance || 0.5,
                businessObjectives: [],
            },
            priority: priority as 'HIGH' | 'MEDIUM' | 'LOW',
            requester: {
                id: this.getExecutionId(),
                name: 'n8n-workflow',
                role: 'system',
            },
            securityContext: {
                permissions: ['read', 'analyze'],
                classification: 'internal',
            },
        };

        // データ統合
        request.technicalData = JSON.parse(technicalData);
        request.marketData = JSON.parse(marketData);
        request.businessData = JSON.parse(businessData);

        const result = await orchestrator.executeIntegratedAnalysis(request);

        return {
            analysisId: result.metadata.analysisId,
            recommendation: result.recommendation,
            confidence: result.confidence,
            consensusScore: result.consensusScore,
            balancePoint: result.balancePoint,
            risks: result.risks,
            alternatives: result.alternatives,
            executionPlan: result.executionPlan,
            qualityMetrics: result.qualityMetrics,
            timestamp: result.metadata.timestamp,
        };
    }

    private async calculateWeights(orchestrator: TriplePerspectiveOrchestrator, itemIndex: number): Promise<any> {
        const context = this.getNodeParameter('analysisContext.context', itemIndex, {}) as any;

        const analysisContext = {
            domain: context.domain || 'general',
            urgency: context.urgency || 5,
            stakeholders: context.stakeholders ? context.stakeholders.split(',').map((s: string) => s.trim()) : [],
            constraints: {},
            riskTolerance: context.riskTolerance || 0.5,
            businessObjectives: [],
        };

        const weights = await orchestrator.calculateDynamicWeights(analysisContext);

        return {
            weights,
            context: analysisContext,
            timestamp: new Date(),
        };
    }

    private async detectEquilibrium(orchestrator: TriplePerspectiveOrchestrator, itemIndex: number): Promise<any> {
        const inputData = this.getInputData()[itemIndex].json;
        
        if (!inputData.perspectiveResults || !inputData.weights) {
            throw new NodeOperationError(this.getNode(), 'Perspective results and weights are required for equilibrium detection', {
                itemIndex,
            });
        }

        const balancePoint = await orchestrator.detectEquilibriumPoint(
            inputData.perspectiveResults,
            inputData.weights
        );

        return {
            balancePoint,
            convergence: true,
            timestamp: new Date(),
        };
    }
}
```

## Code-14-Complete-C: 検証環境構築スクリプト

```bash
#!/bin/bash
# 3視点統合n8n基盤検証環境構築スクリプト

set -e

echo "=== 3視点統合n8n基盤検証環境構築開始 ==="

# 環境変数設定
export NODE_ENV=development
export N8N_BASIC_AUTH_ACTIVE=true
export N8N_BASIC_AUTH_USER=admin
export N8N_BASIC_AUTH_PASSWORD=admin123
export DB_TYPE=postgresdb
export DB_POSTGRESDB_HOST=localhost
export DB_POSTGRESDB_PORT=5432
export DB_POSTGRESDB_DATABASE=n8n
export DB_POSTGRESDB_USER=n8n
export DB_POSTGRESDB_PASSWORD=n8n123

# 必要なディレクトリ作成
mkdir -p ./verification-environment/{docker,custom-nodes,workflows,data,logs,config}

# Docker Compose設定
cat > ./verification-environment/docker/docker-compose.yml << 'EOF'
version: '3.8'

services:
  postgres:
    image: postgres:15
    restart: always
    environment:
      POSTGRES_DB: n8n
      POSTGRES_USER: n8n
      POSTGRES_PASSWORD: n8n123
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U n8n"]
      interval: 10s
      timeout: 5s
      retries: 5

  redis:
    image: redis:7-alpine
    restart: always
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5

  n8n:
    image: n8nio/n8n:latest
    restart: always
    environment:
      - DB_TYPE=postgresdb
      - DB_POSTGRESDB_HOST=postgres
      - DB_POSTGRESDB_PORT=5432
      - DB_POSTGRESDB_DATABASE=n8n
      - DB_POSTGRESDB_USER=n8n
      - DB_POSTGRESDB_PASSWORD=n8n123
      - N8N_BASIC_AUTH_ACTIVE=true
      - N8N_BASIC_AUTH_USER=admin
      - N8N_BASIC_AUTH_PASSWORD=admin123
      - N8N_HOST=localhost
      - N8N_PORT=5678
      - N8N_PROTOCOL=http
      - WEBHOOK_URL=http://localhost:5678/
      - GENERIC_TIMEZONE=Asia/Tokyo
      - N8N_CUSTOM_EXTENSIONS=/home/node/.n8n/custom
    ports:
      - "5678:5678"
    volumes:
      - n8n_data:/home/node/.n8n
      - ./custom-nodes:/home/node/.n8n/custom
      - ./workflows:/home/node/.n8n/workflows
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:5678/healthz"]
      interval: 30s
      timeout: 10s
      retries: 3

  ml-service:
    build:
      context: ./ml-service
      dockerfile: Dockerfile
    restart: always
    environment:
      - REDIS_URL=redis://redis:6379
      - MODEL_PATH=/app/models
    ports:
      - "8080:8080"
    volumes:
      - ./data/models:/app/models
      - ./logs:/app/logs
    depends_on:
      redis:
        condition: service_healthy

volumes:
  postgres_data:
  redis_data:
  n8n_data:
EOF

# カスタムノードパッケージ設定
cat > ./verification-environment/custom-nodes/package.json << 'EOF'
{
  "name": "n8n-nodes-triple-perspective",
  "version": "1.0.0",
  "description": "3視点統合分析用カスタムn8nノード",
  "main": "index.js",
  "scripts": {
    "build": "tsc",
    "dev": "tsc --watch",
    "test": "jest",
    "lint": "eslint . --ext .ts"
  },
  "keywords": ["n8n", "nodes", "triple-perspective", "analysis"],
  "author": "Triple Perspective Team",
  "license": "MIT",
  "dependencies": {
    "n8n-workflow": "^1.0.0",
    "axios": "^1.0.0",
    "lodash": "^4.17.21",
    "moment": "^2.29.4",
    "uuid": "^9.0.0"
  },
  "devDependencies": {
    "@types/node": "^18.0.0",
    "@types/jest": "^29.0.0",
    "@typescript-eslint/eslint-plugin": "^5.0.0",
    "@typescript-eslint/parser": "^5.0.0",
    "eslint": "^8.0.0",
    "jest": "^29.0.0",
    "typescript": "^4.9.0"
  },
  "n8n": {
    "n8nNodesApiVersion": 1,
    "credentials": [
      "dist/credentials/TriplePerspectiveApi.credentials.js"
    ],
    "nodes": [
      "dist/nodes/TriplePerspectiveAnalyzer/TriplePerspectiveAnalyzer.node.js",
      "dist/nodes/PerspectiveWeightCalculator/PerspectiveWeightCalculator.node.js",
      "dist/nodes/ConsensusPointDetector/ConsensusPointDetector.node.js",
      "dist/nodes/DataQualityValidator/DataQualityValidator.node.js"
    ]
  }
}
EOF

# TypeScript設定
cat > ./verification-environment/custom-nodes/tsconfig.json << 'EOF'
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "commonjs",
    "lib": ["ES2020"],
    "declaration": true,
    "outDir": "./dist",
    "rootDir": "./src",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true,
    "experimentalDecorators": true,
    "emitDecoratorMetadata": true
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist", "**/*.test.ts"]
}
EOF

# 機械学習サービス用Dockerfile
mkdir -p ./verification-environment/ml-service
cat > ./verification-environment/ml-service/Dockerfile << 'EOF'
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 8080

CMD ["python", "app.py"]
EOF

# 機械学習サービス依存関係
cat > ./verification-environment/ml-service/requirements.txt << 'EOF'
fastapi==0.104.1
uvicorn==0.24.0
redis==5.0.1
numpy==1.24.3
pandas==2.0.3
scikit-learn==1.3.0
tensorflow==2.13.0
pydantic==2.4.2
python-multipart==0.0.6
aioredis==2.0.1
prometheus-client==0.17.1
structlog==23.1.0
EOF

# テストワークフロー作成
cat > ./verification-environment/workflows/basic_triple_perspective_workflow.json << 'EOF'
{
  "name": "Basic Triple Perspective Analysis",
  "nodes": [
    {
      "parameters": {
        "operation": "analyze",
        "analysisContext": {
          "context": {
            "domain": "technology",
            "urgency": 7,
            "stakeholders": "engineering,product,business",
            "riskTolerance": 0.6
          }
        },
        "technicalData": "{\"performance\": 85, \"complexity\": 6, \"maintainability\": 7}",
        "marketData": "{\"demand\": 8, \"competition\": 6, \"growth\": 9}",
        "businessData": "{\"revenue\": 1000000, \"cost\": 600000, \"roi\": 0.67}",
        "priority": "HIGH"
      },
      "id": "triple-perspective-analyzer",
      "name": "Triple Perspective Analyzer",
      "type": "n8n-nodes-triple-perspective.triplePerspectiveAnalyzer",
      "typeVersion": 1,
      "position": [500, 300]
    },
    {
      "parameters": {},
      "id": "start",
      "name": "Start",
      "type": "n8n-nodes-base.start",
      "typeVersion": 1,
      "position": [300, 300]
    }
  ],
  "connections": {
    "Start": {
      "main": [
        [
          {
            "node": "Triple Perspective Analyzer",
            "type": "main",
            "index": 0
          }
        ]
      ]
    }
  }
}
EOF

# 環境構築実行
echo "Docker環境を起動しています..."
cd ./verification-environment/docker
docker-compose up -d

echo "カスタムノードをビルドしています..."
cd ../custom-nodes
npm install
npm run build

echo "機械学習サービスを構築しています..."
cd ../ml-service
docker build -t triple-perspective-ml .

echo "=== 検証環境構築完了 ==="
echo "n8n管理画面: http://localhost:5678"
echo "ユーザー名: admin"
echo "パスワード: admin123"
echo ""
echo "PostgreSQL: localhost:5432"
echo "Redis: localhost:6379"
echo "ML Service: localhost:8080"
echo ""
echo "検証環境の準備が完了しました。"
EOF

chmod +x ./verification-environment/setup.sh
```

## Code-14-Complete-D: 統合テストスイート

```typescript
/**
 * 3視点統合n8n基盤統合テストスイート
 * エンドツーエンドテストによる品質保証
 */

import { describe, test, expect, beforeAll, afterAll } from '@jest/globals';
import { TriplePerspectiveOrchestrator } from '../src/orchestrator';
import { TestDataGenerator } from './utils/testDataGenerator';
import { MockServices } from './utils/mockServices';

describe('Triple Perspective Integration Tests', () => {
    let orchestrator: TriplePerspectiveOrchestrator;
    let testDataGenerator: TestDataGenerator;
    let mockServices: MockServices;

    beforeAll(async () => {
        mockServices = new MockServices();
        await mockServices.initialize();

        orchestrator = new TriplePerspectiveOrchestrator({
            logger: mockServices.logger,
            redis: mockServices.redis,
            database: mockServices.database,
            ml: mockServices.mlService,
            security: mockServices.securityManager,
            audit: mockServices.auditTrail,
            monitoring: mockServices.performanceMonitor,
            failover: mockServices.failoverManager,
        });

        testDataGenerator = new TestDataGenerator();
    });

    afterAll(async () => {
        await mockServices.cleanup();
    });

    describe('基本的な3視点統合分析', () => {
        test('正常な分析要求の処理', async () => {
            const request = testDataGenerator.generateAnalysisRequest({
                domain: 'technology',
                urgency: 7,
                stakeholders: ['engineering', 'product', 'business'],
                riskTolerance: 0.6,
            });

            const result = await orchestrator.executeIntegratedAnalysis(request);

            expect(result).toBeDefined();
            expect(result.recommendation).toBeTruthy();
            expect(result.confidence).toBeGreaterThan(0);
            expect(result.confidence).toBeLessThanOrEqual(1);
            expect(result.balancePoint).toHaveLength(3);
            expect(result.balancePoint.reduce((a, b) => a + b, 0)).toBeCloseTo(1, 2);
        });

        test('高優先度分析の迅速処理', async () => {
            const request = testDataGenerator.generateAnalysisRequest({
                priority: 'HIGH',
                urgency: 9,
            });

            const startTime = Date.now();
            const result = await orchestrator.executeIntegratedAnalysis(request);
            const executionTime = Date.now() - startTime;

            expect(result).toBeDefined();
            expect(executionTime).toBeLessThan(5000); // 5秒以内
        });

        test('複雑な分析コンテキストの処理', async () => {
            const request = testDataGenerator.generateComplexAnalysisRequest();

            const result = await orchestrator.executeIntegratedAnalysis(request);

            expect(result).toBeDefined();
            expect(result.alternatives).toBeDefined();
            expect(result.alternatives.length).toBeGreaterThan(0);
            expect(result.executionPlan).toBeDefined();
            expect(result.executionPlan.length).toBeGreaterThan(0);
        });
    });

    describe('動的重み付け機能', () => {
        test('緊急度に応じた重み調整', async () => {
            const lowUrgencyContext = testDataGenerator.generateAnalysisContext({ urgency: 2 });
            const highUrgencyContext = testDataGenerator.generateAnalysisContext({ urgency: 9 });

            const lowUrgencyWeights = await orchestrator.calculateDynamicWeights(lowUrgencyContext);
            const highUrgencyWeights = await orchestrator.calculateDynamicWeights(highUrgencyContext);

            expect(lowUrgencyWeights).toHaveLength(3);
            expect(highUrgencyWeights).toHaveLength(3);
            expect(lowUrgencyWeights).not.toEqual(highUrgencyWeights);
        });

        test('ドメイン特性による重み調整', async () => {
            const techContext = testDataGenerator.generateAnalysisContext({ domain: 'technology' });
            const marketContext = testDataGenerator.generateAnalysisContext({ domain: 'marketing' });
            const businessContext = testDataGenerator.generateAnalysisContext({ domain: 'finance' });

            const techWeights = await orchestrator.calculateDynamicWeights(techContext);
            const marketWeights = await orchestrator.calculateDynamicWeights(marketContext);
            const businessWeights = await orchestrator.calculateDynamicWeights(businessContext);

            // 技術ドメインでは技術視点の重みが高い
            expect(techWeights[0]).toBeGreaterThan(techWeights[1]);
            expect(techWeights[0]).toBeGreaterThan(techWeights[2]);

            // マーケティングドメインでは市場視点の重みが高い
            expect(marketWeights[1]).toBeGreaterThan(marketWeights[0]);
            expect(marketWeights[1]).toBeGreaterThan(marketWeights[2]);

            // 財務ドメインではビジネス視点の重みが高い
            expect(businessWeights[2]).toBeGreaterThan(businessWeights[0]);
            expect(businessWeights[2]).toBeGreaterThan(businessWeights[1]);
        });
    });

    describe('静止点検出機能', () => {
        test('合意可能な静止点の検出', async () => {
            const perspectiveResults = testDataGenerator.generateConvergentPerspectiveResults();
            const weights = [0.33, 0.33, 0.34];

            const balancePoint = await orchestrator.detectEquilibriumPoint(perspectiveResults, weights);

            expect(balancePoint).toHaveLength(3);
            expect(balancePoint.reduce((a, b) => a + b, 0)).toBeCloseTo(1, 2);
            expect(balancePoint.every(point => point >= 0 && point <= 1)).toBe(true);
        });

        test('矛盾する視点での静止点検出', async () => {
            const perspectiveResults = testDataGenerator.generateConflictingPerspectiveResults();
            const weights = [0.33, 0.33, 0.34];

            const balancePoint = await orchestrator.detectEquilibriumPoint(perspectiveResults, weights);

            expect(balancePoint).toHaveLength(3);
            // 矛盾する場合でも有効な解を返す
            expect(balancePoint.reduce((a, b) => a + b, 0)).toBeCloseTo(1, 2);
        });
    });

    describe('エラーハンドリングと復旧', () => {
        test('タイムアウトエラーの処理', async () => {
            const request = testDataGenerator.generateAnalysisRequest();
            mockServices.simulateTimeout();

            await expect(orchestrator.executeIntegratedAnalysis(request))
                .rejects.toThrow('Analysis timeout');
        });

        test('部分的な視点分析失敗の処理', async () => {
            const request = testDataGenerator.generateAnalysisRequest();
            mockServices.simulatePartialFailure('technical');

            const result = await orchestrator.executeIntegratedAnalysis(request);

            expect(result).toBeDefined();
            expect(result.qualityMetrics.dataCompleteness).toBeLessThan(1);
            expect(result.metadata.warnings).toContain('technical_analysis_failed');
        });

        test('フェイルオーバー機能', async () => {
            const request = testDataGenerator.generateAnalysisRequest();
            mockServices.simulateSystemFailure();

            const result = await orchestrator.executeIntegratedAnalysis(request);

            expect(result).toBeDefined();
            expect(result.metadata.failoverExecuted).toBe(true);
        });
    });

    describe('性能とスケーラビリティ', () => {
        test('並列分析の性能', async () => {
            const requests = Array.from({ length: 10 }, () => 
                testDataGenerator.generateAnalysisRequest()
            );

            const startTime = Date.now();
            const results = await Promise.all(
                requests.map(request => orchestrator.executeIntegratedAnalysis(request))
            );
            const totalTime = Date.now() - startTime;

            expect(results).toHaveLength(10);
            expect(results.every(result => result !== undefined)).toBe(true);
            expect(totalTime).toBeLessThan(15000); // 15秒以内で10件処理
        });

        test('メモリ使用量の監視', async () => {
            const initialMemory = process.memoryUsage().heapUsed;

            // 大量の分析を実行
            for (let i = 0; i < 50; i++) {
                const request = testDataGenerator.generateAnalysisRequest();
                await orchestrator.executeIntegratedAnalysis(request);
            }

            const finalMemory = process.memoryUsage().heapUsed;
            const memoryIncrease = finalMemory - initialMemory;

            // メモリ増加が100MB以下であることを確認
            expect(memoryIncrease).toBeLessThan(100 * 1024 * 1024);
        });
    });

    describe('セキュリティ統合', () => {
        test('認証済み要求の処理', async () => {
            const request = testDataGenerator.generateAuthenticatedRequest();

            const result = await orchestrator.executeIntegratedAnalysis(request);

            expect(result).toBeDefined();
            expect(result.metadata.securityValidated).toBe(true);
        });

        test('未認証要求の拒否', async () => {
            const request = testDataGenerator.generateUnauthenticatedRequest();

            await expect(orchestrator.executeIntegratedAnalysis(request))
                .rejects.toThrow('Authentication required');
        });

        test('権限不足要求の拒否', async () => {
            const request = testDataGenerator.generateUnauthorizedRequest();

            await expect(orchestrator.executeIntegratedAnalysis(request))
                .rejects.toThrow('Insufficient permissions');
        });
    });

    describe('監査証跡', () => {
        test('分析実行の監査記録', async () => {
            const request = testDataGenerator.generateAnalysisRequest();

            const result = await orchestrator.executeIntegratedAnalysis(request);

            const auditRecords = await mockServices.auditTrail.getRecords(request.id);
            expect(auditRecords).toBeDefined();
            expect(auditRecords.length).toBeGreaterThan(0);
            expect(auditRecords[0].action).toBe('analysis_started');
            expect(auditRecords[auditRecords.length - 1].action).toBe('analysis_completed');
        });

        test('エラー発生時の監査記録', async () => {
            const request = testDataGenerator.generateAnalysisRequest();
            mockServices.simulateError();

            await expect(orchestrator.executeIntegratedAnalysis(request))
                .rejects.toThrow();

            const auditRecords = await mockServices.auditTrail.getRecords(request.id);
            expect(auditRecords.some(record => record.action === 'analysis_error')).toBe(true);
        });
    });
});
```

これらの完全実装コードにより、第14章で解説した3視点統合n8n基盤の理論を実際に稼働可能なシステムとして実現できます。各コードは実際のプロダクション環境での使用を想定し、エンタープライズレベルの要件を満たす品質と性能を確保しています。

