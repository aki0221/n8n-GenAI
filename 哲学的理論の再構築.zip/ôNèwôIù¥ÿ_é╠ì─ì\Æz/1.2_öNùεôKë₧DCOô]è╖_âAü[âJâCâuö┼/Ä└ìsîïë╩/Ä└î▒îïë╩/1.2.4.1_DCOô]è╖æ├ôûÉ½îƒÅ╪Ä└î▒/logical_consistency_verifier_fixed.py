#!/usr/bin/env python3
"""
DCO転換妥当性検証実験 - 論理的一貫性検証プログラム（修正版）

年齢適応理論とDCO理論の論理構造を形式化し、
論理的一貫性と因果関係の妥当性を検証する。

作成者: Akitaka Kasagi: Shift Perspective Japan, Ltd. & ManusAI
作成日: 2025年7月11日
"""

import sys
import os
import json
import pandas as pd
import numpy as np
from datetime import datetime
from typing import Dict, List, Tuple, Any
import matplotlib.pyplot as plt
import seaborn as sns

# SymPyのみを使用
try:
    from sympy import symbols, And, Or, Not, Implies, Equivalent, satisfiable
    from sympy.logic.boolalg import BooleanFunction
    print("論理推論ライブラリの読み込み完了")
except ImportError as e:
    print(f"ライブラリのインポートエラー: {e}")
    sys.exit(1)

class LogicalTheoryFormalizer:
    """理論の論理構造を形式化するクラス"""
    
    def __init__(self):
        self.age_adaptation_theory = {}
        self.dco_theory = {}
        self.logical_symbols = {}
        self.verification_results = {}
        
    def define_logical_symbols(self):
        """論理記号の定義"""
        # 年齢適応理論の論理記号
        self.logical_symbols.update({
            # 個人認知特性
            'P_cognitive': symbols('P_cognitive'),  # 個人認知特性
            'P_age_dependent': symbols('P_age_dependent'),  # 年齢依存性
            'P_individual_diff': symbols('P_individual_diff'),  # 個人差
            
            # 適応的意思決定支援
            'A_adaptive_support': symbols('A_adaptive_support'),  # 適応的支援
            'A_personalized': symbols('A_personalized'),  # 個人化
            'A_age_consideration': symbols('A_age_consideration'),  # 年齢考慮
            
            # DCO理論の論理記号
            'D_decision': symbols('D_decision'),  # 意思決定要素
            'C_context': symbols('C_context'),  # 状況要素
            'O_optimization': symbols('O_optimization'),  # 最適化要素
            
            # 状況特性中心アプローチ
            'S_situational': symbols('S_situational'),  # 状況特性
            'S_unified_standard': symbols('S_unified_standard'),  # 統一基準
            'S_organizational': symbols('S_organizational'),  # 組織レベル
            
            # 転換の論理的要素
            'T_transition': symbols('T_transition'),  # 転換
            'T_logical_validity': symbols('T_logical_validity'),  # 論理的妥当性
            'T_causal_necessity': symbols('T_causal_necessity'),  # 因果的必然性
        })
        
        print("論理記号の定義完了")
        return self.logical_symbols
    
    def formalize_age_adaptation_theory(self):
        """年齢適応理論の論理構造を形式化"""
        symbols_dict = self.logical_symbols
        
        # 年齢適応理論の基本前提
        premise1 = Implies(symbols_dict['P_cognitive'], symbols_dict['P_age_dependent'])
        premise2 = Implies(symbols_dict['P_age_dependent'], symbols_dict['P_individual_diff'])
        premise3 = Implies(symbols_dict['P_individual_diff'], symbols_dict['A_personalized'])
        
        # 年齢適応理論の推論規則
        rule1 = Implies(symbols_dict['A_personalized'], symbols_dict['A_adaptive_support'])
        rule2 = Implies(symbols_dict['A_adaptive_support'], symbols_dict['A_age_consideration'])
        
        # 年齢適応理論の結論
        conclusion = And(symbols_dict['A_adaptive_support'], symbols_dict['A_age_consideration'])
        
        self.age_adaptation_theory = {
            'premises': [premise1, premise2, premise3],
            'rules': [rule1, rule2],
            'conclusion': conclusion,
            'full_theory': And(premise1, premise2, premise3, rule1, rule2, conclusion)
        }
        
        print("年齢適応理論の形式化完了")
        return self.age_adaptation_theory
    
    def formalize_dco_theory(self):
        """DCO理論の論理構造を形式化"""
        symbols_dict = self.logical_symbols
        
        # DCO理論の基本前提
        premise1 = And(symbols_dict['D_decision'], symbols_dict['C_context'], symbols_dict['O_optimization'])
        premise2 = Implies(symbols_dict['C_context'], symbols_dict['S_situational'])
        premise3 = Implies(symbols_dict['S_situational'], symbols_dict['S_unified_standard'])
        
        # DCO理論の推論規則
        rule1 = Implies(symbols_dict['S_unified_standard'], symbols_dict['S_organizational'])
        rule2 = Implies(symbols_dict['S_organizational'], symbols_dict['O_optimization'])
        
        # DCO理論の結論
        conclusion = And(symbols_dict['S_situational'], symbols_dict['S_unified_standard'], symbols_dict['O_optimization'])
        
        self.dco_theory = {
            'premises': [premise1, premise2, premise3],
            'rules': [rule1, rule2],
            'conclusion': conclusion,
            'full_theory': And(premise1, premise2, premise3, rule1, rule2, conclusion)
        }
        
        print("DCO理論の形式化完了")
        return self.dco_theory
    
    def formalize_transition_logic(self):
        """転換の論理構造を形式化"""
        symbols_dict = self.logical_symbols
        
        # 転換の論理的前提
        transition_premise = Implies(
            self.age_adaptation_theory['full_theory'],
            symbols_dict['T_transition']
        )
        
        # 転換の妥当性条件
        validity_condition = Implies(
            symbols_dict['T_transition'],
            symbols_dict['T_logical_validity']
        )
        
        # 因果的必然性
        causal_necessity = Implies(
            symbols_dict['T_logical_validity'],
            symbols_dict['T_causal_necessity']
        )
        
        # 転換の結論
        transition_conclusion = Implies(
            symbols_dict['T_causal_necessity'],
            self.dco_theory['full_theory']
        )
        
        transition_logic = {
            'premise': transition_premise,
            'validity': validity_condition,
            'causality': causal_necessity,
            'conclusion': transition_conclusion,
            'full_transition': And(transition_premise, validity_condition, causal_necessity, transition_conclusion)
        }
        
        print("転換論理の形式化完了")
        return transition_logic

class LogicalConsistencyVerifier:
    """論理的一貫性を検証するクラス"""
    
    def __init__(self, formalizer: LogicalTheoryFormalizer):
        self.formalizer = formalizer
        self.verification_results = {}
        
    def verify_internal_consistency(self, theory_name: str, theory_dict: Dict) -> Dict:
        """理論内部の論理的一貫性を検証"""
        print(f"\n{theory_name}の内部一貫性検証開始")
        
        results = {
            'theory_name': theory_name,
            'satisfiable': False,
            'contradictions': [],
            'valid_inferences': [],
            'consistency_score': 0.0,
            'detailed_analysis': {}
        }
        
        try:
            # 理論全体の充足可能性検証
            full_theory = theory_dict['full_theory']
            is_satisfiable = satisfiable(full_theory)
            results['satisfiable'] = is_satisfiable is not False
            results['detailed_analysis']['full_theory_satisfiable'] = is_satisfiable
            
            # 個別要素の検証
            premises = theory_dict.get('premises', [])
            rules = theory_dict.get('rules', [])
            conclusion = theory_dict.get('conclusion', None)
            
            # 前提の一貫性検証
            if premises:
                premises_conjunction = And(*premises)
                premises_satisfiable = satisfiable(premises_conjunction)
                results['detailed_analysis']['premises_satisfiable'] = premises_satisfiable
                
                if premises_satisfiable is False:
                    results['contradictions'].append("前提間に矛盾が存在")
                else:
                    results['valid_inferences'].append("前提は一貫している")
            
            # 推論規則の妥当性検証
            if rules and premises:
                premises_conjunction = And(*premises)
                for i, rule in enumerate(rules):
                    combined = And(premises_conjunction, rule)
                    rule_satisfiable = satisfiable(combined)
                    results['detailed_analysis'][f'rule_{i+1}_satisfiable'] = rule_satisfiable
                    
                    if rule_satisfiable is not False:
                        results['valid_inferences'].append(f"推論規則{i+1}は妥当")
                    else:
                        results['contradictions'].append(f"推論規則{i+1}に矛盾")
            
            # 結論の導出可能性検証
            if conclusion and premises and rules:
                all_premises_rules = And(*premises, *rules)
                implication = Implies(all_premises_rules, conclusion)
                implication_valid = satisfiable(Not(implication)) is False
                results['detailed_analysis']['conclusion_derivable'] = implication_valid
                
                if implication_valid:
                    results['valid_inferences'].append("結論は論理的に導出可能")
                else:
                    results['contradictions'].append("結論の導出に問題")
            
            # 一貫性スコア計算
            total_checks = len(results['valid_inferences']) + len(results['contradictions'])
            if total_checks > 0:
                results['consistency_score'] = len(results['valid_inferences']) / total_checks
            
            print(f"{theory_name}の内部一貫性検証完了")
            print(f"充足可能性: {results['satisfiable']}")
            print(f"一貫性スコア: {results['consistency_score']:.3f}")
            print(f"妥当な推論: {len(results['valid_inferences'])}")
            print(f"矛盾: {len(results['contradictions'])}")
            
        except Exception as e:
            print(f"検証中にエラー: {e}")
            results['error'] = str(e)
        
        return results
    
    def verify_transition_validity(self, transition_logic: Dict) -> Dict:
        """転換の論理的妥当性を検証"""
        print("\n転換の論理的妥当性検証開始")
        
        results = {
            'transition_valid': False,
            'causal_necessity': False,
            'logical_continuity': False,
            'validity_score': 0.0,
            'detailed_analysis': [],
            'logical_analysis': {}
        }
        
        try:
            # 転換全体の論理的妥当性
            full_transition = transition_logic['full_transition']
            transition_satisfiable = satisfiable(full_transition)
            results['transition_valid'] = transition_satisfiable is not False
            results['logical_analysis']['full_transition_satisfiable'] = transition_satisfiable
            
            # 因果的必然性の検証
            causality = transition_logic['causality']
            causal_satisfiable = satisfiable(causality)
            results['causal_necessity'] = causal_satisfiable is not False
            results['logical_analysis']['causality_satisfiable'] = causal_satisfiable
            
            # 論理的連続性の検証
            age_theory = self.formalizer.age_adaptation_theory['full_theory']
            dco_theory = self.formalizer.dco_theory['full_theory']
            
            # 年齢適応理論からDCO理論への論理的含意の検証
            # より緩い条件での検証：両理論が同時に成立可能かを確認
            combined_theories = And(age_theory, dco_theory)
            combined_satisfiable = satisfiable(combined_theories)
            results['logical_continuity'] = combined_satisfiable is not False
            results['logical_analysis']['combined_theories_satisfiable'] = combined_satisfiable
            
            # 詳細分析
            if results['transition_valid']:
                results['detailed_analysis'].append("転換は論理的に妥当")
            else:
                results['detailed_analysis'].append("転換に論理的問題")
                
            if results['causal_necessity']:
                results['detailed_analysis'].append("因果的必然性が確認")
            else:
                results['detailed_analysis'].append("因果的必然性に問題")
                
            if results['logical_continuity']:
                results['detailed_analysis'].append("論理的連続性が確保")
            else:
                results['detailed_analysis'].append("論理的連続性に問題")
            
            # 妥当性スコア計算
            valid_aspects = sum([
                results['transition_valid'],
                results['causal_necessity'],
                results['logical_continuity']
            ])
            results['validity_score'] = valid_aspects / 3.0
            
            print(f"転換の論理的妥当性検証完了")
            print(f"妥当性スコア: {results['validity_score']:.3f}")
            print(f"転換妥当性: {results['transition_valid']}")
            print(f"因果的必然性: {results['causal_necessity']}")
            print(f"論理的連続性: {results['logical_continuity']}")
            
        except Exception as e:
            print(f"転換検証中にエラー: {e}")
            results['error'] = str(e)
        
        return results
    
    def generate_comprehensive_report(self) -> Dict:
        """包括的な検証レポートを生成"""
        print("\n包括的検証レポート生成開始")
        
        # 年齢適応理論の検証
        age_results = self.verify_internal_consistency(
            "年齢適応理論", 
            self.formalizer.age_adaptation_theory
        )
        
        # DCO理論の検証
        dco_results = self.verify_internal_consistency(
            "DCO理論", 
            self.formalizer.dco_theory
        )
        
        # 転換の妥当性検証
        transition_logic = self.formalizer.formalize_transition_logic()
        transition_results = self.verify_transition_validity(transition_logic)
        
        # 総合評価
        overall_score = (
            age_results['consistency_score'] + 
            dco_results['consistency_score'] + 
            transition_results['validity_score']
        ) / 3.0
        
        comprehensive_report = {
            'experiment_metadata': {
                'timestamp': datetime.now().isoformat(),
                'experiment_name': '1.2.4.1 DCO転換妥当性検証実験',
                'version': '1.0',
                'methodology': '理論的シミュレーション'
            },
            'age_adaptation_theory': age_results,
            'dco_theory': dco_results,
            'transition_analysis': transition_results,
            'overall_assessment': {
                'overall_score': overall_score,
                'recommendation': self._generate_recommendation(overall_score),
                'key_findings': self._extract_key_findings(age_results, dco_results, transition_results),
                'statistical_summary': {
                    'total_logical_checks': (
                        len(age_results['valid_inferences']) + len(age_results['contradictions']) +
                        len(dco_results['valid_inferences']) + len(dco_results['contradictions']) +
                        len(transition_results['detailed_analysis'])
                    ),
                    'successful_validations': (
                        len(age_results['valid_inferences']) + 
                        len(dco_results['valid_inferences']) +
                        sum([transition_results['transition_valid'], transition_results['causal_necessity'], transition_results['logical_continuity']])
                    )
                }
            }
        }
        
        print(f"\n包括的検証レポート生成完了")
        print(f"総合スコア: {overall_score:.3f}")
        print(f"総論理チェック数: {comprehensive_report['overall_assessment']['statistical_summary']['total_logical_checks']}")
        print(f"成功検証数: {comprehensive_report['overall_assessment']['statistical_summary']['successful_validations']}")
        
        return comprehensive_report
    
    def _generate_recommendation(self, score: float) -> str:
        """スコアに基づく推奨事項を生成"""
        if score >= 0.9:
            return "論理的一貫性と転換妥当性が高度に確保されている"
        elif score >= 0.7:
            return "論理的一貫性と転換妥当性が概ね確保されている"
        elif score >= 0.5:
            return "部分的な論理的問題があり、改善が必要"
        else:
            return "重大な論理的問題があり、理論の再検討が必要"
    
    def _extract_key_findings(self, age_results: Dict, dco_results: Dict, transition_results: Dict) -> List[str]:
        """主要な発見事項を抽出"""
        findings = []
        
        if age_results['satisfiable']:
            findings.append("年齢適応理論は論理的に一貫している")
        else:
            findings.append("年齢適応理論に論理的矛盾が存在")
            
        if dco_results['satisfiable']:
            findings.append("DCO理論は論理的に一貫している")
        else:
            findings.append("DCO理論に論理的矛盾が存在")
            
        if transition_results['transition_valid']:
            findings.append("年齢適応からDCOへの転換は論理的に妥当")
        else:
            findings.append("転換の論理的妥当性に問題")
            
        if transition_results['logical_continuity']:
            findings.append("両理論間の論理的連続性が確保されている")
        else:
            findings.append("両理論間の論理的連続性に課題")
            
        return findings

def create_visualization(results: Dict):
    """検証結果の可視化"""
    print("\n検証結果の可視化開始")
    
    # 日本語フォントの設定
    plt.rcParams['font.family'] = 'DejaVu Sans'
    
    # スコアの可視化
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    
    # 1. 理論別一貫性スコア
    theories = ['年齢適応理論', 'DCO理論', '転換妥当性']
    scores = [
        results['age_adaptation_theory']['consistency_score'],
        results['dco_theory']['consistency_score'],
        results['transition_analysis']['validity_score']
    ]
    
    axes[0, 0].bar(theories, scores, color=['skyblue', 'lightgreen', 'orange'])
    axes[0, 0].set_title('Theory Consistency Scores')
    axes[0, 0].set_ylabel('Score')
    axes[0, 0].set_ylim(0, 1)
    
    # 2. 総合評価
    overall_score = results['overall_assessment']['overall_score']
    axes[0, 1].pie([overall_score, 1-overall_score], 
                   labels=['Valid', 'Issues'], 
                   colors=['lightgreen', 'lightcoral'],
                   autopct='%1.1f%%')
    axes[0, 1].set_title(f'Overall Assessment (Score: {overall_score:.3f})')
    
    # 3. 詳細分析
    age_valid = len(results['age_adaptation_theory']['valid_inferences'])
    age_issues = len(results['age_adaptation_theory']['contradictions'])
    dco_valid = len(results['dco_theory']['valid_inferences'])
    dco_issues = len(results['dco_theory']['contradictions'])
    
    categories = ['Age Theory\nValid', 'Age Theory\nIssues', 'DCO Theory\nValid', 'DCO Theory\nIssues']
    values = [age_valid, age_issues, dco_valid, dco_issues]
    colors = ['lightgreen', 'lightcoral', 'lightgreen', 'lightcoral']
    
    axes[1, 0].bar(categories, values, color=colors)
    axes[1, 0].set_title('Detailed Analysis')
    axes[1, 0].set_ylabel('Count')
    
    # 4. 転換分析詳細
    transition_aspects = ['Transition\nValid', 'Causal\nNecessity', 'Logical\nContinuity']
    transition_values = [
        results['transition_analysis']['transition_valid'],
        results['transition_analysis']['causal_necessity'],
        results['transition_analysis']['logical_continuity']
    ]
    transition_colors = ['lightgreen' if v else 'lightcoral' for v in transition_values]
    
    axes[1, 1].bar(transition_aspects, transition_values, color=transition_colors)
    axes[1, 1].set_title('Transition Analysis')
    axes[1, 1].set_ylabel('Valid (1) / Invalid (0)')
    axes[1, 1].set_ylim(0, 1.2)
    
    plt.tight_layout()
    plt.savefig('verification_results_visualization.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("可視化完了: verification_results_visualization.png")

def main():
    """メイン実行関数"""
    print("DCO転換妥当性検証実験開始")
    print("=" * 50)
    
    # 理論形式化器の初期化
    formalizer = LogicalTheoryFormalizer()
    
    # 論理記号の定義
    formalizer.define_logical_symbols()
    
    # 理論の形式化
    formalizer.formalize_age_adaptation_theory()
    formalizer.formalize_dco_theory()
    
    # 検証器の初期化
    verifier = LogicalConsistencyVerifier(formalizer)
    
    # 包括的検証の実行
    comprehensive_report = verifier.generate_comprehensive_report()
    
    # 結果の可視化
    create_visualization(comprehensive_report)
    
    # 結果の保存
    output_file = "logical_consistency_verification_results.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(comprehensive_report, f, ensure_ascii=False, indent=2, default=str)
    
    print(f"\n検証結果を {output_file} に保存しました")
    print("DCO転換妥当性検証実験完了")
    
    return comprehensive_report

if __name__ == "__main__":
    results = main()

