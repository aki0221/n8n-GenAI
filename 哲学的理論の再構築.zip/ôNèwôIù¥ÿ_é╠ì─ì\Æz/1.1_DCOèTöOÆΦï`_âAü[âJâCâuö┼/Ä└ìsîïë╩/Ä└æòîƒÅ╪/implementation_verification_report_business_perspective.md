# DCO実装コード検証実験レポート（ビジネス視点版）

**検証日時**: 2025-07-10T00:08:05.532220
**総合結果**: 8/8 テスト成功 (100.0%)
**総実行時間**: 102.6988秒

## テスト詳細

| テスト名 | ステータス | 詳細 | 実行時間(s) |
|---|---|---|---:|
| Quantifier Initialization | Passed | 初期化成功: confidence_level=0.99 | 0.000019 |
| Quantifier Fit | Passed | パラメータ推定完了: 5業界 | 0.016629 |
| Quantifier Quantify | Passed | 定量化成功: DCOスコア=215390.77 | 1.009972 |
| Updater Initialization | Passed | 初期化成功: 5業界のパラメータ | 0.000009 |
| Updater Update | Passed | 更新成功: IT業界B1平均 76.86 -> 76.94 | 0.006036 |
| Industry Adaptation | Passed | 業界間パラメータ差分平均: 17.95 | 0.000153 |
| Error Handling | Passed | 未訓練モデルでValueErrorを正常に捕捉 | 0.000129 |
| Performance | Passed | fit時間: 0.0147s, 平均quantify時間: 1.016509s | 101.665814 |
