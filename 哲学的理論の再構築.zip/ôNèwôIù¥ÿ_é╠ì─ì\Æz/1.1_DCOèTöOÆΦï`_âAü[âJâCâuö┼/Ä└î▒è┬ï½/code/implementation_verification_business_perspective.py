#!/usr/bin/env python3.11
"""
DCO概念定義検証実験 - 実装コード検証実験（1.1.3.2）ビジネス視点修正版

作成日: 2025年7月10日
修正日: 2025年7月10日（ビジネス視点対応）
作成者: Manus AI
目的: StatisticalDCOQuantifierクラス等の実装コードの動作検証

修正内容: ファイナンス視点→ビジネス視点への全面修正

検証項目:
1. StatisticalDCOQuantifierクラスの機能検証
2. DynamicDCOUpdaterクラスの動作検証
3. 業界特性適応機構の実装検証
4. エラーハンドリング・例外処理の検証
5. 性能・効率性の基本検証
6. ビジネス視点特有の実装検証
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from scipy.optimize import minimize
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
import warnings
import time
import traceback
from datetime import datetime
import json

warnings.filterwarnings("ignore")

# 日本語フォント設定
plt.rcParams["font.family"] = "DejaVu Sans"
plt.rcParams["figure.figsize"] = (12, 8)
plt.rcParams["font.size"] = 10

class StatisticalDCOQuantifierBusinessPerspective:
    """統計的DCO定量化クラス（ビジネス視点版）"""

    def __init__(self, confidence_level=0.95):
        """
        初期化

        Parameters:
        confidence_level (float): 信頼水準（デフォルト: 0.95）
        """
        self.confidence_level = confidence_level
        self.alpha = 1 - confidence_level
        self.fitted = False
        self.industry_params = {}
        self.global_params = {}

        # 3視点×8次元の定義（ビジネス視点修正版）
        self.perspective_dims = {
            "Market": [
                "M1_MarketShare", "M2_CustomerSatisfaction", "M3_BrandValue", "M4_CompetitiveAdvantage",
                "M5_MarketGrowthRate", "M6_PriceCompetitiveness", "M7_CustomerLoyalty", "M8_MarketPenetration"
            ],
            "Technology": [
                "T1_InnovationLevel", "T2_RnDEfficiency", "T3_DigitalTransformation", "T4_IPPortfolio",
                "T5_TechnicalCompetitiveness", "T6_SystemIntegration", "T7_TechnicalRiskManagement", "T8_TechnicalSustainability"
            ],
            "Business": [
                "B1_BusinessCognition", "B2_BusinessValue", "B3_BusinessTime", "B4_BusinessOrganization",
                "B5_BusinessResources", "B6_BusinessEnvironment", "B7_BusinessEmotion", "B8_BusinessSociety"
            ]
        }

        self.all_dimensions = []
        for dims in self.perspective_dims.values():
            self.all_dimensions.extend(dims)

    def fit(self, data):
        """
        データに基づくパラメータ推定

        Parameters:
        data (pd.DataFrame): 企業データ
        """
        try:
            print("StatisticalDCOQuantifier: パラメータ推定開始...")

            # 業界別パラメータ推定
            for industry in data["Industry"].unique():
                industry_data = data[data["Industry"] == industry][self.all_dimensions]

                # 基本統計量
                means = industry_data.mean()
                stds = industry_data.std()

                # 信頼区間計算
                n = len(industry_data)
                t_critical = stats.t.ppf(1 - self.alpha / 2, df=n - 1)

                confidence_intervals = {}
                for dim in self.all_dimensions:
                    margin_error = t_critical * stds[dim] / np.sqrt(n)
                    ci_lower = means[dim] - margin_error
                    ci_upper = means[dim] + margin_error
                    confidence_intervals[dim] = (ci_lower, ci_upper)

                self.industry_params[industry] = {
                    "means": means,
                    "stds": stds,
                    "confidence_intervals": confidence_intervals,
                    "n_samples": n
                }

            # 全体パラメータ推定
            global_data = data[self.all_dimensions]
            self.global_params = {
                "means": global_data.mean(),
                "stds": global_data.std(),
                "correlation_matrix": global_data.corr()
            }

            self.fitted = True
            print("パラメータ推定完了")

        except Exception as e:
            print(f"エラー: パラメータ推定中に問題が発生しました - {e}")
            traceback.print_exc()
            self.fitted = False

    def quantify(self, company_data):
        """
        単一企業のDCOスコアを定量化

        Parameters:
        company_data (pd.Series): 企業データ

        Returns:
        dict: 定量化結果
        """
        if not self.fitted:
            raise ValueError("モデルが訓練されていません。fit()メソッドを先に呼び出してください。")

        try:
            industry = company_data["Industry"]
            params = self.industry_params.get(industry, self.global_params)

            # 各視点のスコア計算
            scores = {}
            for perspective, dims in self.perspective_dims.items():
                perspective_values = company_data[dims]
                perspective_mean = perspective_values.mean()
                scores[f"{perspective}_Score"] = perspective_mean

            # DCOスコア計算
            dco_score = (
                scores["Market_Score"] *
                scores["Technology_Score"] *
                scores["Business_Score"]
            )

            # 信頼区間（モンテカルロ法）
            mc_scores = []
            for _ in range(1000):
                simulated_data = {}
                for dim in self.all_dimensions:
                    mean = params["means"][dim]
                    std = params["stds"][dim]
                    simulated_data[dim] = np.random.normal(mean, std)

                simulated_df = pd.Series(simulated_data)
                sim_market_score = simulated_df[self.perspective_dims["Market"]].mean()
                sim_tech_score = simulated_df[self.perspective_dims["Technology"]].mean()
                sim_business_score = simulated_df[self.perspective_dims["Business"]].mean()
                mc_scores.append(sim_market_score * sim_tech_score * sim_business_score)

            dco_ci_lower = np.percentile(mc_scores, (self.alpha / 2) * 100)
            dco_ci_upper = np.percentile(mc_scores, (1 - self.alpha / 2) * 100)

            return {
                "DCO_Score": dco_score,
                "DCO_Confidence_Interval": (dco_ci_lower, dco_ci_upper),
                "Market_Score": scores["Market_Score"],
                "Technology_Score": scores["Technology_Score"],
                "Business_Score": scores["Business_Score"]
            }

        except Exception as e:
            print(f"エラー: DCOスコア定量化中に問題が発生しました - {e}")
            traceback.print_exc()
            return None

class DynamicDCOUpdaterBusinessPerspective:
    """動的DCO更新クラス（ベイズ更新）- ビジネス視点版"""

    def __init__(self, initial_params):
        """
        初期化

        Parameters:
        initial_params (dict): 初期パラメータ（StatisticalDCOQuantifierの推定結果）
        """
        self.params = initial_params
        
        # ビジネス視点の全次元要素を定義
        self.all_dimensions = [
            'M1_MarketShare', 'M2_CustomerSatisfaction', 'M3_BrandValue', 'M4_CompetitiveAdvantage',
            'M5_MarketGrowthRate', 'M6_PriceCompetitiveness', 'M7_CustomerLoyalty', 'M8_MarketPenetration',
            'T1_InnovationLevel', 'T2_RnDEfficiency', 'T3_DigitalTransformation', 'T4_IPPortfolio',
            'T5_TechnicalCompetitiveness', 'T6_SystemIntegration', 'T7_TechnicalRiskManagement', 'T8_TechnicalSustainability',
            'B1_BusinessCognition', 'B2_BusinessValue', 'B3_BusinessTime', 'B4_BusinessOrganization',
            'B5_BusinessResources', 'B6_BusinessEnvironment', 'B7_BusinessEmotion', 'B8_BusinessSociety'
        ]

    def update(self, new_data):
        """
        新しいデータでパラメータをベイズ更新

        Parameters:
        new_data (pd.DataFrame): 新しい企業データ

        Returns:
        dict: 更新されたパラメータ
        """
        try:
            print("DynamicDCOUpdater: パラメータ更新開始...")

            for industry in new_data["Industry"].unique():
                if industry not in self.params:
                    print(f"警告: {industry}業界の初期パラメータが存在しません。スキップします。")
                    continue

                industry_new_data = new_data[new_data["Industry"] == industry]
                n_new = len(industry_new_data)

                # 事前分布パラメータ
                prior_means = self.params[industry]["means"]
                prior_stds = self.params[industry]["stds"]
                n_prior = self.params[industry]["n_samples"]

                # 新しいデータの統計量
                new_means = industry_new_data[self.all_dimensions].mean()

                # 事後分布パラメータ（平均）
                posterior_means = (n_prior * prior_means + n_new * new_means) / (n_prior + n_new)

                # パラメータ更新
                self.params[industry]["means"] = posterior_means
                self.params[industry]["n_samples"] += n_new

            print("パラメータ更新完了")
            return self.params

        except Exception as e:
            print(f"エラー: パラメータ更新中に問題が発生しました - {e}")
            traceback.print_exc()
            return None

class ImplementationVerificationBusinessPerspective:
    """実装コード検証実験クラス（ビジネス視点版）"""

    def __init__(self, data_path="../data/synthetic_dco_dataset_business_perspective.csv"):
        """
        初期化
        """
        self.data_path = data_path
        self.df = None
        self.quantifier = None
        self.updater = None
        self.results = {"tests": [], "summary": {}}

    def load_data(self):
        """
        データ読み込み
        """
        try:
            self.df = pd.read_csv(self.data_path)
            return True
        except FileNotFoundError:
            print(f"エラー: データファイルが見つかりません - {self.data_path}")
            return False

    def run_all_tests(self):
        """
        すべての検証テストを実行
        """
        if not self.load_data():
            return

        test_functions = [
            self.test_quantifier_initialization,
            self.test_quantifier_fit,
            self.test_quantifier_quantify,
            self.test_updater_initialization,
            self.test_updater_update,
            self.test_industry_adaptation,
            self.test_error_handling,
            self.test_performance
        ]

        for test_func in test_functions:
            try:
                result = test_func()
                self.results["tests"].append(result)
            except Exception as e:
                self.results["tests"].append({
                    "test_name": test_func.__name__,
                    "status": "Failed",
                    "details": f"予期せぬエラー: {e}"
                })

        self.generate_summary()

    def test_quantifier_initialization(self):
        """StatisticalDCOQuantifierクラスの初期化テスト"""
        start_time = time.time()
        try:
            self.quantifier = StatisticalDCOQuantifierBusinessPerspective(confidence_level=0.99)
            status = "Passed" if self.quantifier.confidence_level == 0.99 else "Failed"
            details = f"初期化成功: confidence_level={self.quantifier.confidence_level}"
        except Exception as e:
            status = "Failed"
            details = f"初期化失敗: {e}"
        return {
            "test_name": "Quantifier Initialization",
            "status": status,
            "details": details,
            "execution_time": time.time() - start_time
        }

    def test_quantifier_fit(self):
        """StatisticalDCOQuantifierクラスのfitメソッドテスト"""
        start_time = time.time()
        try:
            self.quantifier = StatisticalDCOQuantifierBusinessPerspective()
            self.quantifier.fit(self.df)
            status = "Passed" if self.quantifier.fitted else "Failed"
            details = f"パラメータ推定完了: {len(self.quantifier.industry_params)}業界"
        except Exception as e:
            status = "Failed"
            details = f"fitメソッド失敗: {e}"
        return {
            "test_name": "Quantifier Fit",
            "status": status,
            "details": details,
            "execution_time": time.time() - start_time
        }

    def test_quantifier_quantify(self):
        """StatisticalDCOQuantifierクラスのquantifyメソッドテスト"""
        start_time = time.time()
        try:
            if not (self.quantifier and self.quantifier.fitted):
                self.test_quantifier_fit()
            
            sample_company = self.df.iloc[0]
            result = self.quantifier.quantify(sample_company)
            
            status = "Passed" if isinstance(result, dict) and "DCO_Score" in result else "Failed"
            details = f"定量化成功: DCOスコア={result['DCO_Score']:.2f}"
        except Exception as e:
            status = "Failed"
            details = f"quantifyメソッド失敗: {e}"
        return {
            "test_name": "Quantifier Quantify",
            "status": status,
            "details": details,
            "execution_time": time.time() - start_time
        }

    def test_updater_initialization(self):
        """DynamicDCOUpdaterクラスの初期化テスト"""
        start_time = time.time()
        try:
            if not (self.quantifier and self.quantifier.fitted):
                self.test_quantifier_fit()
            
            self.updater = DynamicDCOUpdaterBusinessPerspective(self.quantifier.industry_params)
            status = "Passed" if self.updater.params else "Failed"
            details = f"初期化成功: {len(self.updater.params)}業界のパラメータ"
        except Exception as e:
            status = "Failed"
            details = f"初期化失敗: {e}"
        return {
            "test_name": "Updater Initialization",
            "status": status,
            "details": details,
            "execution_time": time.time() - start_time
        }

    def test_updater_update(self):
        """DynamicDCOUpdaterクラスのupdateメソッドテスト"""
        start_time = time.time()
        try:
            if not self.updater:
                self.test_updater_initialization()
            
            new_data = self.df.sample(n=100, random_state=42)
            initial_mean = self.updater.params["IT"]["means"]["B1_BusinessCognition"]
            
            updated_params = self.updater.update(new_data)
            updated_mean = updated_params["IT"]["means"]["B1_BusinessCognition"]
            
            status = "Passed" if initial_mean != updated_mean else "Failed"
            details = f"更新成功: IT業界B1平均 {initial_mean:.2f} -> {updated_mean:.2f}"
        except Exception as e:
            status = "Failed"
            details = f"updateメソッド失敗: {e}"
        return {
            "test_name": "Updater Update",
            "status": status,
            "details": details,
            "execution_time": time.time() - start_time
        }

    def test_industry_adaptation(self):
        """業界特性適応機構のテスト"""
        start_time = time.time()
        try:
            if not (self.quantifier and self.quantifier.fitted):
                self.test_quantifier_fit()
            
            it_params = self.quantifier.industry_params["IT"]["means"]
            retail_params = self.quantifier.industry_params["Retail"]["means"]
            
            diff = (it_params - retail_params).abs().mean()
            status = "Passed" if diff > 1.0 else "Failed"
            details = f"業界間パラメータ差分平均: {diff:.2f}"
        except Exception as e:
            status = "Failed"
            details = f"業界特性適応テスト失敗: {e}"
        return {
            "test_name": "Industry Adaptation",
            "status": status,
            "details": details,
            "execution_time": time.time() - start_time
        }

    def test_error_handling(self):
        """エラーハンドリングのテスト"""
        start_time = time.time()
        try:
            quantifier = StatisticalDCOQuantifierBusinessPerspective()
            # 未訓練モデルでquantifyを呼び出す
            try:
                quantifier.quantify(self.df.iloc[0])
                status = "Failed"
                details = "ValueErrorが発生しませんでした"
            except ValueError:
                status = "Passed"
                details = "未訓練モデルでValueErrorを正常に捕捉"
        except Exception as e:
            status = "Failed"
            details = f"エラーハンドリングテスト失敗: {e}"
        return {
            "test_name": "Error Handling",
            "status": status,
            "details": details,
            "execution_time": time.time() - start_time
        }

    def test_performance(self):
        """性能・効率性の基本テスト"""
        start_time = time.time()
        try:
            quantifier = StatisticalDCOQuantifierBusinessPerspective()
            
            # fitの性能
            fit_start = time.time()
            quantifier.fit(self.df)
            fit_time = time.time() - fit_start
            
            # quantifyの性能
            quantify_times = []
            for i in range(100):
                q_start = time.time()
                quantifier.quantify(self.df.iloc[i])
                quantify_times.append(time.time() - q_start)
            avg_quantify_time = np.mean(quantify_times)
            
            status = "Passed"
            details = f"fit時間: {fit_time:.4f}s, 平均quantify時間: {avg_quantify_time:.6f}s"
        except Exception as e:
            status = "Failed"
            details = f"性能テスト失敗: {e}"
        return {
            "test_name": "Performance",
            "status": status,
            "details": details,
            "execution_time": time.time() - start_time
        }

    def generate_summary(self):
        """
        検証結果の要約を生成
        """
        passed_tests = sum(1 for r in self.results["tests"] if r["status"] == "Passed")
        total_tests = len(self.results["tests"])
        pass_rate = (passed_tests / total_tests) * 100 if total_tests > 0 else 0

        total_time = sum(r["execution_time"] for r in self.results["tests"])

        self.results["summary"] = {
            "total_tests": total_tests,
            "passed_tests": passed_tests,
            "failed_tests": total_tests - passed_tests,
            "pass_rate_percent": pass_rate,
            "total_execution_time_seconds": total_time,
            "timestamp": datetime.now().isoformat()
        }

    def save_report(self, output_dir="../results"):
        """
        検証レポートを保存
        """
        import os
        os.makedirs(output_dir, exist_ok=True)

        # JSONレポート
        json_path = os.path.join(output_dir, "implementation_verification_details_business_perspective.json")
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(self.results, f, indent=2, ensure_ascii=False)

        # Markdownレポート
        md_path = os.path.join(output_dir, "implementation_verification_report_business_perspective.md")
        with open(md_path, "w", encoding="utf-8") as f:
            f.write("# DCO実装コード検証実験レポート（ビジネス視点版）\n\n")
            f.write(f"**検証日時**: {self.results['summary']['timestamp']}\n")
            f.write(f"**総合結果**: {self.results['summary']['passed_tests']}/{self.results['summary']['total_tests']} テスト成功 ({self.results['summary']['pass_rate_percent']:.1f}%)\n")
            f.write(f"**総実行時間**: {self.results['summary']['total_execution_time_seconds']:.4f}秒\n\n")
            f.write("## テスト詳細\n\n")
            f.write("| テスト名 | ステータス | 詳細 | 実行時間(s) |\n")
            f.write("|---|---|---|---:|\n")
            for r in self.results["tests"]:
                f.write(f"| {r['test_name']} | {r['status']} | {r['details']} | {r['execution_time']:.6f} |\n")

        print(f"レポート保存完了:")
        print(f"  JSON: {json_path}")
        print(f"  Markdown: {md_path}")

def main():
    """メイン実行関数"""
    print("DCO実装コード検証実験（ビジネス視点版）")
    print("=" * 60)

    verifier = ImplementationVerificationBusinessPerspective()
    verifier.run_all_tests()
    verifier.save_report()

    print("\n" + "=" * 60)
    print("実装コード検証実験完了（ビジネス視点版）")

if __name__ == "__main__":
    main()

