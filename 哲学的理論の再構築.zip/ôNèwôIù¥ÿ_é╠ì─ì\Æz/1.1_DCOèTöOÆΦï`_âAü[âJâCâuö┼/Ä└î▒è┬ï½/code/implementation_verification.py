#!/usr/bin/env python3.11
"""
DCO概念定義検証実験 - 実装コード検証実験（1.1.3.2）

作成日: 2025年7月10日
作成者: Manus AI
目的: StatisticalDCOQuantifierクラス等の実装コードの動作検証

検証項目:
1. StatisticalDCOQuantifierクラスの機能検証
2. DynamicDCOUpdaterクラスの動作検証
3. 業界特性適応機構の実装検証
4. エラーハンドリング・例外処理の検証
5. 性能・効率性の基本検証
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from scipy.optimize import minimize
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
import warnings
import time
import traceback
from datetime import datetime
import json

warnings.filterwarnings('ignore')

# 日本語フォント設定
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['figure.figsize'] = (12, 8)
plt.rcParams['font.size'] = 10

class StatisticalDCOQuantifier:
    """統計的DCO定量化クラス"""
    
    def __init__(self, confidence_level=0.95):
        """
        初期化
        
        Parameters:
        confidence_level (float): 信頼水準（デフォルト: 0.95）
        """
        self.confidence_level = confidence_level
        self.alpha = 1 - confidence_level
        self.fitted = False
        self.industry_params = {}
        self.global_params = {}
        
        # 3視点×8次元の定義
        self.perspective_dims = {
            'Market': [
                'M1_MarketShare', 'M2_CustomerSatisfaction', 'M3_BrandValue', 'M4_CompetitiveAdvantage',
                'M5_MarketGrowthRate', 'M6_PriceCompetitiveness', 'M7_CustomerLoyalty', 'M8_MarketPenetration'
            ],
            'Technology': [
                'T1_InnovationLevel', 'T2_RnDEfficiency', 'T3_DigitalTransformation', 'T4_IPPortfolio',
                'T5_TechnicalCompetitiveness', 'T6_SystemIntegration', 'T7_TechnicalRiskManagement', 'T8_TechnicalSustainability'
            ],
            'Finance': [
                'F1_Profitability', 'F2_Liquidity', 'F3_Stability', 'F4_GrowthPotential',
                'F5_Efficiency', 'F6_Leverage', 'F7_ROI', 'F8_CashFlow'
            ]
        }
        
        self.all_dimensions = []
        for dims in self.perspective_dims.values():
            self.all_dimensions.extend(dims)
    
    def fit(self, data):
        """
        データに基づくパラメータ推定
        
        Parameters:
        data (pd.DataFrame): 企業データ
        """
        try:
            print("StatisticalDCOQuantifier: パラメータ推定開始...")
            
            # 業界別パラメータ推定
            for industry in data['Industry'].unique():
                industry_data = data[data['Industry'] == industry][self.all_dimensions]
                
                # 基本統計量
                means = industry_data.mean()
                stds = industry_data.std()
                
                # 信頼区間計算
                n = len(industry_data)
                t_critical = stats.t.ppf(1 - self.alpha/2, df=n-1)
                
                confidence_intervals = {}
                for dim in self.all_dimensions:
                    margin_error = t_critical * stds[dim] / np.sqrt(n)
                    ci_lower = means[dim] - margin_error
                    ci_upper = means[dim] + margin_error
                    confidence_intervals[dim] = (ci_lower, ci_upper)
                
                # 相関行列
                correlation_matrix = industry_data.corr()
                
                self.industry_params[industry] = {
                    'means': means.to_dict(),
                    'stds': stds.to_dict(),
                    'confidence_intervals': confidence_intervals,
                    'correlation_matrix': correlation_matrix,
                    'sample_size': n
                }
            
            # 全体パラメータ推定
            global_data = data[self.all_dimensions]
            self.global_params = {
                'means': global_data.mean().to_dict(),
                'stds': global_data.std().to_dict(),
                'correlation_matrix': global_data.corr(),
                'sample_size': len(global_data)
            }
            
            self.fitted = True
            print("StatisticalDCOQuantifier: パラメータ推定完了")
            
        except Exception as e:
            print(f"StatisticalDCOQuantifier: パラメータ推定エラー - {str(e)}")
            raise
    
    def calculate_dco_score(self, company_data, industry=None):
        """
        DCOスコア計算
        
        Parameters:
        company_data (dict or pd.Series): 企業の24次元データ
        industry (str): 業界名（指定時は業界特性を考慮）
        
        Returns:
        dict: DCOスコア結果
        """
        if not self.fitted:
            raise ValueError("モデルが学習されていません。fit()を先に実行してください。")
        
        try:
            # データ準備
            if isinstance(company_data, pd.Series):
                company_data = company_data.to_dict()
            
            # 視点別スコア計算
            perspective_scores = {}
            for perspective, dimensions in self.perspective_dims.items():
                scores = [company_data[dim] for dim in dimensions if dim in company_data]
                if scores:
                    perspective_scores[perspective] = np.mean(scores)
                else:
                    perspective_scores[perspective] = 0.0
            
            # DCO統合スコア計算（3要素の乗算）
            quality = perspective_scores['Market']
            efficiency = perspective_scores['Technology'] 
            risk_management = perspective_scores['Finance']
            
            # 正規化（0-1スケール）
            quality_norm = quality / 100.0
            efficiency_norm = efficiency / 100.0
            risk_management_norm = risk_management / 100.0
            
            # DCO = Quality × Efficiency × Risk Management
            dco_score = quality_norm * efficiency_norm * risk_management_norm
            
            # 業界調整（指定時）
            adjusted_score = dco_score
            if industry and industry in self.industry_params:
                industry_mean = np.mean(list(self.industry_params[industry]['means'].values()))
                global_mean = np.mean(list(self.global_params['means'].values()))
                adjustment_factor = global_mean / industry_mean if industry_mean > 0 else 1.0
                adjusted_score = dco_score * adjustment_factor
            
            # 不確実性推定
            uncertainty = self.estimate_uncertainty(company_data, industry)
            
            return {
                'dco_score': dco_score,
                'adjusted_dco_score': adjusted_score,
                'perspective_scores': perspective_scores,
                'quality_component': quality_norm,
                'efficiency_component': efficiency_norm,
                'risk_management_component': risk_management_norm,
                'uncertainty': uncertainty,
                'industry': industry
            }
            
        except Exception as e:
            print(f"DCOスコア計算エラー: {str(e)}")
            raise
    
    def estimate_uncertainty(self, company_data, industry=None):
        """不確実性推定"""
        try:
            if industry and industry in self.industry_params:
                params = self.industry_params[industry]
            else:
                params = self.global_params
            
            # 各次元の不確実性
            uncertainties = []
            for dim in self.all_dimensions:
                if dim in company_data and dim in params['stds']:
                    # 標準誤差に基づく不確実性
                    std_error = params['stds'][dim] / np.sqrt(params['sample_size'])
                    uncertainties.append(std_error)
            
            # 平均不確実性
            avg_uncertainty = np.mean(uncertainties) if uncertainties else 0.0
            
            return {
                'average_uncertainty': avg_uncertainty,
                'dimension_uncertainties': dict(zip(self.all_dimensions[:len(uncertainties)], uncertainties))
            }
            
        except Exception as e:
            print(f"不確実性推定エラー: {str(e)}")
            return {'average_uncertainty': 0.0, 'dimension_uncertainties': {}}

class DynamicDCOUpdater:
    """動的DCO更新クラス"""
    
    def __init__(self, learning_rate=0.1, decay_factor=0.95):
        """
        初期化
        
        Parameters:
        learning_rate (float): 学習率
        decay_factor (float): 減衰係数
        """
        self.learning_rate = learning_rate
        self.decay_factor = decay_factor
        self.update_history = []
        self.current_weights = None
        
    def initialize_weights(self, n_dimensions=24):
        """重み初期化"""
        self.current_weights = np.ones(n_dimensions) / n_dimensions
        return self.current_weights.copy()
    
    def update_weights(self, performance_feedback, environmental_changes=None):
        """
        重み更新
        
        Parameters:
        performance_feedback (np.array): 性能フィードバック
        environmental_changes (dict): 環境変化情報
        
        Returns:
        np.array: 更新された重み
        """
        try:
            if self.current_weights is None:
                self.initialize_weights()
            
            # 性能フィードバックに基づく更新
            if len(performance_feedback) == len(self.current_weights):
                gradient = performance_feedback - np.mean(performance_feedback)
                self.current_weights += self.learning_rate * gradient
            
            # 環境変化に基づく調整
            if environmental_changes:
                for dim_idx, change_factor in environmental_changes.items():
                    if 0 <= dim_idx < len(self.current_weights):
                        self.current_weights[dim_idx] *= change_factor
            
            # 正規化
            self.current_weights = np.maximum(self.current_weights, 0.01)  # 最小値制限
            self.current_weights /= np.sum(self.current_weights)  # 正規化
            
            # 履歴記録
            self.update_history.append({
                'timestamp': datetime.now(),
                'weights': self.current_weights.copy(),
                'learning_rate': self.learning_rate
            })
            
            # 学習率減衰
            self.learning_rate *= self.decay_factor
            
            return self.current_weights.copy()
            
        except Exception as e:
            print(f"重み更新エラー: {str(e)}")
            raise
    
    def get_adaptation_metrics(self):
        """適応メトリクス取得"""
        if not self.update_history:
            return {}
        
        # 重みの変化量
        if len(self.update_history) > 1:
            weight_changes = []
            for i in range(1, len(self.update_history)):
                prev_weights = self.update_history[i-1]['weights']
                curr_weights = self.update_history[i]['weights']
                change = np.linalg.norm(curr_weights - prev_weights)
                weight_changes.append(change)
            
            avg_change = np.mean(weight_changes)
            stability = 1.0 / (1.0 + avg_change)  # 安定性指標
        else:
            avg_change = 0.0
            stability = 1.0
        
        return {
            'total_updates': len(self.update_history),
            'average_weight_change': avg_change,
            'stability_index': stability,
            'current_learning_rate': self.learning_rate,
            'weight_entropy': -np.sum(self.current_weights * np.log(self.current_weights + 1e-10))
        }

class IndustryAdaptationMechanism:
    """業界特性適応機構"""
    
    def __init__(self):
        """初期化"""
        self.industry_profiles = {}
        self.adaptation_rules = {}
        self.performance_history = {}
    
    def create_industry_profile(self, industry_data, industry_name):
        """業界プロファイル作成"""
        try:
            # 統計的特性
            profile = {
                'means': industry_data.mean().to_dict(),
                'stds': industry_data.std().to_dict(),
                'correlations': industry_data.corr().to_dict(),
                'sample_size': len(industry_data),
                'created_at': datetime.now()
            }
            
            # 特徴的パターン抽出
            # 各視点の重要度
            perspective_importance = {}
            for perspective, dimensions in {
                'Market': ['M1_MarketShare', 'M2_CustomerSatisfaction', 'M3_BrandValue', 'M4_CompetitiveAdvantage',
                          'M5_MarketGrowthRate', 'M6_PriceCompetitiveness', 'M7_CustomerLoyalty', 'M8_MarketPenetration'],
                'Technology': ['T1_InnovationLevel', 'T2_RnDEfficiency', 'T3_DigitalTransformation', 'T4_IPPortfolio',
                              'T5_TechnicalCompetitiveness', 'T6_SystemIntegration', 'T7_TechnicalRiskManagement', 'T8_TechnicalSustainability'],
                'Finance': ['F1_Profitability', 'F2_Liquidity', 'F3_Stability', 'F4_GrowthPotential',
                           'F5_Efficiency', 'F6_Leverage', 'F7_ROI', 'F8_CashFlow']
            }.items():
                available_dims = [dim for dim in dimensions if dim in industry_data.columns]
                if available_dims:
                    perspective_scores = industry_data[available_dims].mean(axis=1)
                    perspective_importance[perspective] = {
                        'mean_score': perspective_scores.mean(),
                        'variability': perspective_scores.std(),
                        'relative_importance': perspective_scores.mean() / industry_data.mean().mean()
                    }
            
            profile['perspective_importance'] = perspective_importance
            
            self.industry_profiles[industry_name] = profile
            return profile
            
        except Exception as e:
            print(f"業界プロファイル作成エラー: {str(e)}")
            raise
    
    def adapt_to_industry(self, base_scores, target_industry):
        """業界適応"""
        try:
            if target_industry not in self.industry_profiles:
                return base_scores  # 適応情報がない場合はそのまま返す
            
            profile = self.industry_profiles[target_industry]
            adapted_scores = base_scores.copy()
            
            # 業界特性に基づく調整
            for perspective, importance_info in profile['perspective_importance'].items():
                adjustment_factor = importance_info['relative_importance']
                
                # 該当する次元のスコアを調整
                perspective_dims = {
                    'Market': ['M1_MarketShare', 'M2_CustomerSatisfaction', 'M3_BrandValue', 'M4_CompetitiveAdvantage',
                              'M5_MarketGrowthRate', 'M6_PriceCompetitiveness', 'M7_CustomerLoyalty', 'M8_MarketPenetration'],
                    'Technology': ['T1_InnovationLevel', 'T2_RnDEfficiency', 'T3_DigitalTransformation', 'T4_IPPortfolio',
                                  'T5_TechnicalCompetitiveness', 'T6_SystemIntegration', 'T7_TechnicalRiskManagement', 'T8_TechnicalSustainability'],
                    'Finance': ['F1_Profitability', 'F2_Liquidity', 'F3_Stability', 'F4_GrowthPotential',
                               'F5_Efficiency', 'F6_Leverage', 'F7_ROI', 'F8_CashFlow']
                }
                
                if perspective in perspective_dims:
                    for dim in perspective_dims[perspective]:
                        if dim in adapted_scores:
                            adapted_scores[dim] *= adjustment_factor
            
            return adapted_scores
            
        except Exception as e:
            print(f"業界適応エラー: {str(e)}")
            return base_scores

class ImplementationVerificationSuite:
    """実装検証スイート"""
    
    def __init__(self, data_path='../data/synthetic_dco_dataset.csv'):
        """初期化"""
        self.data_path = data_path
        self.data = None
        self.test_results = {}
        self.performance_metrics = {}
        
    def load_test_data(self):
        """テストデータ読み込み"""
        print("テストデータ読み込み中...")
        self.data = pd.read_csv(self.data_path)
        print(f"データ読み込み完了: {len(self.data)} レコード")
        
    def test_statistical_dco_quantifier(self):
        """StatisticalDCOQuantifierクラステスト"""
        print("\n" + "="*50)
        print("1. StatisticalDCOQuantifierクラス検証中...")
        print("="*50)
        
        test_results = {
            'test_name': 'StatisticalDCOQuantifier',
            'start_time': datetime.now(),
            'tests': []
        }
        
        try:
            # インスタンス作成テスト
            quantifier = StatisticalDCOQuantifier(confidence_level=0.95)
            test_results['tests'].append({
                'test': 'インスタンス作成',
                'status': 'PASS',
                'message': 'インスタンス作成成功'
            })
            
            # フィッティングテスト
            start_time = time.time()
            quantifier.fit(self.data)
            fit_time = time.time() - start_time
            
            test_results['tests'].append({
                'test': 'パラメータ推定',
                'status': 'PASS',
                'message': f'パラメータ推定成功 (実行時間: {fit_time:.3f}秒)',
                'execution_time': fit_time
            })
            
            # DCOスコア計算テスト
            sample_company = self.data.iloc[0]
            dimensions = [col for col in self.data.columns if col.startswith(('M', 'T', 'F')) and '_' in col]
            company_data = sample_company[dimensions]
            
            start_time = time.time()
            dco_result = quantifier.calculate_dco_score(company_data, industry=sample_company['Industry'])
            calc_time = time.time() - start_time
            
            test_results['tests'].append({
                'test': 'DCOスコア計算',
                'status': 'PASS',
                'message': f'DCOスコア計算成功 (実行時間: {calc_time:.3f}秒)',
                'execution_time': calc_time,
                'result_sample': {
                    'dco_score': dco_result['dco_score'],
                    'adjusted_dco_score': dco_result['adjusted_dco_score'],
                    'uncertainty': dco_result['uncertainty']['average_uncertainty']
                }
            })
            
            # バッチ処理テスト
            batch_size = 100
            batch_data = self.data.head(batch_size)
            
            start_time = time.time()
            batch_results = []
            for _, row in batch_data.iterrows():
                company_data = row[dimensions]
                result = quantifier.calculate_dco_score(company_data, industry=row['Industry'])
                batch_results.append(result['dco_score'])
            batch_time = time.time() - start_time
            
            avg_time_per_company = batch_time / batch_size
            
            test_results['tests'].append({
                'test': 'バッチ処理性能',
                'status': 'PASS',
                'message': f'バッチ処理成功 ({batch_size}社, 平均{avg_time_per_company*1000:.2f}ms/社)',
                'execution_time': batch_time,
                'avg_time_per_company': avg_time_per_company
            })
            
            # エラーハンドリングテスト
            try:
                # 不正データでのテスト
                invalid_data = {'invalid_dim': 50}
                quantifier.calculate_dco_score(invalid_data)
                test_results['tests'].append({
                    'test': 'エラーハンドリング',
                    'status': 'FAIL',
                    'message': '不正データに対してエラーが発生しませんでした'
                })
            except:
                test_results['tests'].append({
                    'test': 'エラーハンドリング',
                    'status': 'PASS',
                    'message': '不正データに対して適切にエラーハンドリングされました'
                })
            
        except Exception as e:
            test_results['tests'].append({
                'test': '例外処理',
                'status': 'FAIL',
                'message': f'予期しないエラー: {str(e)}',
                'traceback': traceback.format_exc()
            })
        
        test_results['end_time'] = datetime.now()
        test_results['duration'] = (test_results['end_time'] - test_results['start_time']).total_seconds()
        
        self.test_results['statistical_dco_quantifier'] = test_results
        
        # 結果表示
        passed_tests = sum(1 for test in test_results['tests'] if test['status'] == 'PASS')
        total_tests = len(test_results['tests'])
        print(f"StatisticalDCOQuantifier検証結果: {passed_tests}/{total_tests} テスト合格")
        
        return test_results
    
    def test_dynamic_dco_updater(self):
        """DynamicDCOUpdaterクラステスト"""
        print("\n" + "="*50)
        print("2. DynamicDCOUpdaterクラス検証中...")
        print("="*50)
        
        test_results = {
            'test_name': 'DynamicDCOUpdater',
            'start_time': datetime.now(),
            'tests': []
        }
        
        try:
            # インスタンス作成テスト
            updater = DynamicDCOUpdater(learning_rate=0.1, decay_factor=0.95)
            test_results['tests'].append({
                'test': 'インスタンス作成',
                'status': 'PASS',
                'message': 'インスタンス作成成功'
            })
            
            # 重み初期化テスト
            initial_weights = updater.initialize_weights(24)
            if len(initial_weights) == 24 and abs(np.sum(initial_weights) - 1.0) < 1e-10:
                test_results['tests'].append({
                    'test': '重み初期化',
                    'status': 'PASS',
                    'message': f'重み初期化成功 (合計: {np.sum(initial_weights):.6f})'
                })
            else:
                test_results['tests'].append({
                    'test': '重み初期化',
                    'status': 'FAIL',
                    'message': f'重み初期化失敗 (長さ: {len(initial_weights)}, 合計: {np.sum(initial_weights)})'
                })
            
            # 重み更新テスト
            performance_feedback = np.random.normal(0.5, 0.1, 24)
            environmental_changes = {0: 1.2, 5: 0.8, 10: 1.1}  # 一部次元の変化
            
            start_time = time.time()
            updated_weights = updater.update_weights(performance_feedback, environmental_changes)
            update_time = time.time() - start_time
            
            if len(updated_weights) == 24 and abs(np.sum(updated_weights) - 1.0) < 1e-10:
                test_results['tests'].append({
                    'test': '重み更新',
                    'status': 'PASS',
                    'message': f'重み更新成功 (実行時間: {update_time:.3f}秒)',
                    'execution_time': update_time
                })
            else:
                test_results['tests'].append({
                    'test': '重み更新',
                    'status': 'FAIL',
                    'message': f'重み更新失敗 (合計: {np.sum(updated_weights)})'
                })
            
            # 複数回更新テスト
            for i in range(5):
                feedback = np.random.normal(0.5, 0.1, 24)
                updater.update_weights(feedback)
            
            metrics = updater.get_adaptation_metrics()
            if metrics['total_updates'] == 6:  # 初回 + 5回
                test_results['tests'].append({
                    'test': '複数回更新',
                    'status': 'PASS',
                    'message': f'複数回更新成功 (更新回数: {metrics["total_updates"]})',
                    'metrics': metrics
                })
            else:
                test_results['tests'].append({
                    'test': '複数回更新',
                    'status': 'FAIL',
                    'message': f'更新回数不一致 (期待: 6, 実際: {metrics["total_updates"]})'
                })
            
        except Exception as e:
            test_results['tests'].append({
                'test': '例外処理',
                'status': 'FAIL',
                'message': f'予期しないエラー: {str(e)}',
                'traceback': traceback.format_exc()
            })
        
        test_results['end_time'] = datetime.now()
        test_results['duration'] = (test_results['end_time'] - test_results['start_time']).total_seconds()
        
        self.test_results['dynamic_dco_updater'] = test_results
        
        # 結果表示
        passed_tests = sum(1 for test in test_results['tests'] if test['status'] == 'PASS')
        total_tests = len(test_results['tests'])
        print(f"DynamicDCOUpdater検証結果: {passed_tests}/{total_tests} テスト合格")
        
        return test_results
    
    def test_industry_adaptation_mechanism(self):
        """IndustryAdaptationMechanismクラステスト"""
        print("\n" + "="*50)
        print("3. IndustryAdaptationMechanismクラス検証中...")
        print("="*50)
        
        test_results = {
            'test_name': 'IndustryAdaptationMechanism',
            'start_time': datetime.now(),
            'tests': []
        }
        
        try:
            # インスタンス作成テスト
            adapter = IndustryAdaptationMechanism()
            test_results['tests'].append({
                'test': 'インスタンス作成',
                'status': 'PASS',
                'message': 'インスタンス作成成功'
            })
            
            # 業界プロファイル作成テスト
            dimensions = [col for col in self.data.columns if col.startswith(('M', 'T', 'F')) and '_' in col]
            
            profiles_created = 0
            for industry in self.data['Industry'].unique():
                industry_data = self.data[self.data['Industry'] == industry][dimensions]
                
                start_time = time.time()
                profile = adapter.create_industry_profile(industry_data, industry)
                profile_time = time.time() - start_time
                
                if profile and 'means' in profile and 'perspective_importance' in profile:
                    profiles_created += 1
            
            if profiles_created == self.data['Industry'].nunique():
                test_results['tests'].append({
                    'test': '業界プロファイル作成',
                    'status': 'PASS',
                    'message': f'全業界プロファイル作成成功 ({profiles_created}業界)',
                    'profiles_created': profiles_created
                })
            else:
                test_results['tests'].append({
                    'test': '業界プロファイル作成',
                    'status': 'FAIL',
                    'message': f'プロファイル作成失敗 (作成: {profiles_created}, 期待: {self.data["Industry"].nunique()})'
                })
            
            # 業界適応テスト
            sample_scores = self.data.iloc[0][dimensions].to_dict()
            target_industry = self.data.iloc[0]['Industry']
            
            start_time = time.time()
            adapted_scores = adapter.adapt_to_industry(sample_scores, target_industry)
            adapt_time = time.time() - start_time
            
            if adapted_scores and len(adapted_scores) == len(sample_scores):
                test_results['tests'].append({
                    'test': '業界適応',
                    'status': 'PASS',
                    'message': f'業界適応成功 (実行時間: {adapt_time:.3f}秒)',
                    'execution_time': adapt_time
                })
            else:
                test_results['tests'].append({
                    'test': '業界適応',
                    'status': 'FAIL',
                    'message': '業界適応失敗'
                })
            
            # 未知業界への適応テスト
            unknown_adapted = adapter.adapt_to_industry(sample_scores, 'Unknown_Industry')
            if unknown_adapted == sample_scores:
                test_results['tests'].append({
                    'test': '未知業界処理',
                    'status': 'PASS',
                    'message': '未知業界に対して適切に元スコアを返しました'
                })
            else:
                test_results['tests'].append({
                    'test': '未知業界処理',
                    'status': 'FAIL',
                    'message': '未知業界処理が不適切です'
                })
            
        except Exception as e:
            test_results['tests'].append({
                'test': '例外処理',
                'status': 'FAIL',
                'message': f'予期しないエラー: {str(e)}',
                'traceback': traceback.format_exc()
            })
        
        test_results['end_time'] = datetime.now()
        test_results['duration'] = (test_results['end_time'] - test_results['start_time']).total_seconds()
        
        self.test_results['industry_adaptation_mechanism'] = test_results
        
        # 結果表示
        passed_tests = sum(1 for test in test_results['tests'] if test['status'] == 'PASS')
        total_tests = len(test_results['tests'])
        print(f"IndustryAdaptationMechanism検証結果: {passed_tests}/{total_tests} テスト合格")
        
        return test_results
    
    def test_integration(self):
        """統合テスト"""
        print("\n" + "="*50)
        print("4. 統合テスト実施中...")
        print("="*50)
        
        test_results = {
            'test_name': 'Integration',
            'start_time': datetime.now(),
            'tests': []
        }
        
        try:
            # 全コンポーネント統合テスト
            quantifier = StatisticalDCOQuantifier()
            updater = DynamicDCOUpdater()
            adapter = IndustryAdaptationMechanism()
            
            # データ準備
            dimensions = [col for col in self.data.columns if col.startswith(('M', 'T', 'F')) and '_' in col]
            
            # 1. 統計的定量化器の学習
            quantifier.fit(self.data)
            
            # 2. 業界適応機構の準備
            for industry in self.data['Industry'].unique():
                industry_data = self.data[self.data['Industry'] == industry][dimensions]
                adapter.create_industry_profile(industry_data, industry)
            
            # 3. 動的更新器の初期化
            updater.initialize_weights(len(dimensions))
            
            # 4. 統合処理テスト
            test_companies = self.data.head(10)
            integration_results = []
            
            start_time = time.time()
            for _, company in test_companies.iterrows():
                # 基本DCOスコア計算
                company_data = company[dimensions]
                dco_result = quantifier.calculate_dco_score(company_data, industry=company['Industry'])
                
                # 業界適応
                adapted_scores = adapter.adapt_to_industry(company_data.to_dict(), company['Industry'])
                
                # 動的更新（模擬フィードバック）
                feedback = np.random.normal(0.5, 0.1, len(dimensions))
                updated_weights = updater.update_weights(feedback)
                
                integration_results.append({
                    'company_id': company['CompanyID'],
                    'industry': company['Industry'],
                    'dco_score': dco_result['dco_score'],
                    'adapted': len(adapted_scores) == len(dimensions),
                    'weights_updated': len(updated_weights) == len(dimensions)
                })
            
            integration_time = time.time() - start_time
            
            # 結果検証
            successful_integrations = sum(1 for r in integration_results 
                                        if r['adapted'] and r['weights_updated'])
            
            if successful_integrations == len(test_companies):
                test_results['tests'].append({
                    'test': '統合処理',
                    'status': 'PASS',
                    'message': f'統合処理成功 ({len(test_companies)}社, 実行時間: {integration_time:.3f}秒)',
                    'execution_time': integration_time,
                    'companies_processed': len(test_companies)
                })
            else:
                test_results['tests'].append({
                    'test': '統合処理',
                    'status': 'FAIL',
                    'message': f'統合処理失敗 (成功: {successful_integrations}/{len(test_companies)})'
                })
            
            # 性能メトリクス
            avg_time_per_company = integration_time / len(test_companies)
            throughput = len(test_companies) / integration_time
            
            self.performance_metrics['integration'] = {
                'avg_time_per_company': avg_time_per_company,
                'throughput_companies_per_second': throughput,
                'total_processing_time': integration_time
            }
            
            test_results['tests'].append({
                'test': '性能メトリクス',
                'status': 'PASS',
                'message': f'性能測定完了 (平均{avg_time_per_company*1000:.2f}ms/社, スループット{throughput:.2f}社/秒)',
                'metrics': self.performance_metrics['integration']
            })
            
        except Exception as e:
            test_results['tests'].append({
                'test': '例外処理',
                'status': 'FAIL',
                'message': f'予期しないエラー: {str(e)}',
                'traceback': traceback.format_exc()
            })
        
        test_results['end_time'] = datetime.now()
        test_results['duration'] = (test_results['end_time'] - test_results['start_time']).total_seconds()
        
        self.test_results['integration'] = test_results
        
        # 結果表示
        passed_tests = sum(1 for test in test_results['tests'] if test['status'] == 'PASS')
        total_tests = len(test_results['tests'])
        print(f"統合テスト結果: {passed_tests}/{total_tests} テスト合格")
        
        return test_results
    
    def generate_verification_report(self):
        """検証レポート生成"""
        print("\n" + "="*50)
        print("5. 検証レポート生成中...")
        print("="*50)
        
        report = []
        report.append("# DCO概念定義検証実験 - 実装コード検証結果レポート")
        report.append(f"\n**実施日**: {datetime.now().strftime('%Y年%m月%d日')}")
        report.append(f"**検証対象**: StatisticalDCOQuantifier, DynamicDCOUpdater, IndustryAdaptationMechanism")
        
        # 各テスト結果のサマリー
        total_tests = 0
        total_passed = 0
        
        for test_name, test_result in self.test_results.items():
            if 'tests' in test_result:
                passed = sum(1 for test in test_result['tests'] if test['status'] == 'PASS')
                total = len(test_result['tests'])
                total_tests += total
                total_passed += passed
                
                report.append(f"\n## {test_result['test_name']}クラス検証結果")
                report.append(f"- **合格率**: {passed}/{total} ({passed/total*100:.1f}%)")
                report.append(f"- **実行時間**: {test_result['duration']:.3f}秒")
                
                # 個別テスト結果
                for test in test_result['tests']:
                    status_icon = "✅" if test['status'] == 'PASS' else "❌"
                    report.append(f"  - {status_icon} **{test['test']}**: {test['message']}")
        
        # 総合評価
        overall_pass_rate = total_passed / total_tests * 100 if total_tests > 0 else 0
        report.append(f"\n## 総合評価")
        report.append(f"- **全体合格率**: {total_passed}/{total_tests} ({overall_pass_rate:.1f}%)")
        
        if overall_pass_rate >= 90:
            evaluation = "優秀"
        elif overall_pass_rate >= 80:
            evaluation = "良好"
        elif overall_pass_rate >= 70:
            evaluation = "許容可能"
        else:
            evaluation = "要改善"
        
        report.append(f"- **総合評価**: {evaluation}")
        
        # 性能メトリクス
        if self.performance_metrics:
            report.append(f"\n## 性能メトリクス")
            for metric_name, metrics in self.performance_metrics.items():
                report.append(f"### {metric_name}")
                for key, value in metrics.items():
                    if isinstance(value, float):
                        report.append(f"- **{key}**: {value:.3f}")
                    else:
                        report.append(f"- **{key}**: {value}")
        
        # 推奨事項
        report.append(f"\n## 推奨事項")
        if overall_pass_rate >= 90:
            report.append("- 実装コードは高品質で、本格運用に適しています")
            report.append("- 継続的な性能監視とメンテナンスを推奨します")
        elif overall_pass_rate >= 80:
            report.append("- 実装コードは概ね良好ですが、失敗したテストの改善を推奨します")
            report.append("- 本格運用前に追加テストを実施することを推奨します")
        else:
            report.append("- 実装コードに重要な問題があります")
            report.append("- 失敗したテストの原因調査と修正が必要です")
            report.append("- 本格運用前に包括的な見直しを推奨します")
        
        # レポート保存
        report_text = "\n".join(report)
        with open('../results/implementation_verification_report.md', 'w', encoding='utf-8') as f:
            f.write(report_text)
        
        # 詳細結果をJSONで保存
        with open('../results/implementation_verification_details.json', 'w', encoding='utf-8') as f:
            # datetime オブジェクトを文字列に変換
            serializable_results = {}
            for key, value in self.test_results.items():
                serializable_results[key] = self._make_serializable(value)
            
            json.dump({
                'test_results': serializable_results,
                'performance_metrics': self.performance_metrics,
                'summary': {
                    'total_tests': total_tests,
                    'total_passed': total_passed,
                    'overall_pass_rate': overall_pass_rate,
                    'evaluation': evaluation
                }
            }, f, indent=2, ensure_ascii=False)
        
        print("検証レポート生成完了")
        return report_text
    
    def _make_serializable(self, obj):
        """JSON シリアライズ可能な形式に変換"""
        if isinstance(obj, datetime):
            return obj.isoformat()
        elif isinstance(obj, dict):
            return {key: self._make_serializable(value) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [self._make_serializable(item) for item in obj]
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, (np.integer, np.floating)):
            return obj.item()
        else:
            return obj
    
    def run_all_verification_tests(self):
        """全検証テスト実行"""
        print("DCO概念定義検証実験 - 実装コード検証開始")
        print("="*60)
        
        # データ読み込み
        self.load_test_data()
        
        # 各テスト実行
        self.test_statistical_dco_quantifier()
        self.test_dynamic_dco_updater()
        self.test_industry_adaptation_mechanism()
        self.test_integration()
        
        # レポート生成
        report = self.generate_verification_report()
        
        print("\n" + "="*60)
        print("実装コード検証完了")
        print("="*60)
        
        return self.test_results, self.performance_metrics, report

def main():
    """メイン実行関数"""
    verifier = ImplementationVerificationSuite()
    test_results, performance_metrics, report = verifier.run_all_verification_tests()
    
    print("\n実装コード検証結果:")
    print(report)
    
    return test_results, performance_metrics, report

if __name__ == "__main__":
    test_results, performance_metrics, report = main()

