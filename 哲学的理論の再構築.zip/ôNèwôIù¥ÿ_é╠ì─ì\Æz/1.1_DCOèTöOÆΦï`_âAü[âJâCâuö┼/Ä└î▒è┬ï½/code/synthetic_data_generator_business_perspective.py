#!/usr/bin/env python3.11
"""
DCO概念定義検証実験 - 合成データ生成プログラム（ビジネス視点修正版）

作成日: 2025年7月10日
修正日: 2025年7月10日（ビジネス視点対応）
作成者: Manus AI
目的: DCO理論検証のための統計的に妥当な合成企業データの生成

修正内容: ファイナンス視点→ビジネス視点への全面修正

データ仕様:
- 企業数: 1,000社（業界別200社×5業界）
- 時系列: 3年分（2022-2024年）
- 次元数: 24次元（3視点×8次元）
- 総レコード数: 3,000レコード
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from datetime import datetime
import json
import os

# 乱数シード固定（再現性確保）
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

class SyntheticDataGeneratorBusinessPerspective:
    """DCO理論検証用合成データ生成クラス（ビジネス視点版）"""
    
    def __init__(self):
        """初期化"""
        self.industries = ['Manufacturing', 'Finance', 'IT', 'Retail', 'Energy']
        self.years = [2022, 2023, 2024]
        self.companies_per_industry = 200
        self.total_companies = len(self.industries) * self.companies_per_industry
        
        # 3視点×8次元の定義（ビジネス視点修正版）
        self.dimensions = {
            'Market': [
                'M1_MarketShare', 'M2_CustomerSatisfaction', 'M3_BrandValue', 'M4_CompetitiveAdvantage',
                'M5_MarketGrowthRate', 'M6_PriceCompetitiveness', 'M7_CustomerLoyalty', 'M8_MarketPenetration'
            ],
            'Technology': [
                'T1_InnovationLevel', 'T2_RnDEfficiency', 'T3_DigitalTransformation', 'T4_IPPortfolio',
                'T5_TechnicalCompetitiveness', 'T6_SystemIntegration', 'T7_TechnicalRiskManagement', 'T8_TechnicalSustainability'
            ],
            'Business': [
                'B1_BusinessCognition', 'B2_BusinessValue', 'B3_BusinessTime', 'B4_BusinessOrganization',
                'B5_BusinessResources', 'B6_BusinessEnvironment', 'B7_BusinessEmotion', 'B8_BusinessSociety'
            ]
        }
        
        # 業界特性パラメータ（平均値）- ビジネス視点修正版
        self.industry_means = {
            'Manufacturing': {
                'Market': [65, 60, 55, 70, 45, 60, 65, 55],
                'Technology': [55, 60, 50, 65, 60, 75, 70, 60],
                'Business': [70, 65, 60, 80, 85, 75, 65, 70]  # 高い組織能力、優れた経営資源配分
            },
            'Finance': {
                'Market': [60, 65, 70, 60, 50, 55, 80, 65],
                'Technology': [50, 55, 80, 60, 55, 70, 75, 65],
                'Business': [85, 70, 65, 75, 70, 90, 80, 75]  # 高い市場機会認識、優れた規制環境適応
            },
            'IT': {
                'Market': [55, 70, 65, 75, 85, 70, 60, 60],
                'Technology': [90, 85, 95, 80, 85, 80, 70, 75],
                'Business': [75, 80, 90, 70, 85, 65, 70, 85]  # 優れた戦略的タイミング、高い能力開発
            },
            'Retail': {
                'Market': [70, 75, 60, 65, 60, 80, 70, 85],
                'Technology': [45, 50, 60, 40, 45, 55, 60, 50],
                'Business': [65, 90, 70, 65, 70, 60, 85, 80]  # 高い顧客価値創出、優れたブランド価値
            },
            'Energy': {
                'Market': [60, 55, 65, 80, 40, 50, 65, 55],
                'Technology': [60, 65, 55, 70, 65, 70, 75, 90],
                'Business': [80, 70, 65, 85, 75, 70, 65, 90]  # 高い競争環境理解、強い社会的責任
            }
        }
        
        # 標準偏差（業界内変動）
        self.industry_stds = {industry: 12 for industry in self.industries}
        
        # 相関構造パラメータ
        self.intra_perspective_correlation = 0.5  # 視点内相関
        self.inter_perspective_correlation = 0.25  # 視点間相関
        self.temporal_correlation = 0.8  # 時系列相関
        
        # ビジネス視点特有の相関
        self.business_specific_correlations = {
            'B1_B6': 0.7,  # 事業認知と事業環境の強い相関
            'B2_B7': 0.5,  # 事業価値と事業感情の中程度相関
            'B4_B5': 0.8,  # 事業組織と事業リソースの強い相関
            'B8_others': 0.4  # 事業社会と他次元の中程度相関
        }
        
    def generate_correlation_matrix(self):
        """24次元の相関行列を生成（ビジネス視点特有の相関を含む）"""
        n_dims = 24
        correlation_matrix = np.eye(n_dims)
        
        # 視点内相関の設定
        for perspective_idx, perspective in enumerate(['Market', 'Technology', 'Business']):
            start_idx = perspective_idx * 8
            end_idx = start_idx + 8
            
            for i in range(start_idx, end_idx):
                for j in range(start_idx, end_idx):
                    if i != j:
                        correlation_matrix[i, j] = self.intra_perspective_correlation
        
        # 視点間相関の設定
        for i in range(n_dims):
            for j in range(n_dims):
                if i != j and correlation_matrix[i, j] == 0:
                    correlation_matrix[i, j] = self.inter_perspective_correlation
        
        # ビジネス視点特有の相関を設定
        business_start = 16  # ビジネス視点の開始インデックス
        
        # B1-B6相関（事業認知-事業環境）
        correlation_matrix[business_start + 0, business_start + 5] = self.business_specific_correlations['B1_B6']
        correlation_matrix[business_start + 5, business_start + 0] = self.business_specific_correlations['B1_B6']
        
        # B2-B7相関（事業価値-事業感情）
        correlation_matrix[business_start + 1, business_start + 6] = self.business_specific_correlations['B2_B7']
        correlation_matrix[business_start + 6, business_start + 1] = self.business_specific_correlations['B2_B7']
        
        # B4-B5相関（事業組織-事業リソース）
        correlation_matrix[business_start + 3, business_start + 4] = self.business_specific_correlations['B4_B5']
        correlation_matrix[business_start + 4, business_start + 3] = self.business_specific_correlations['B4_B5']
        
        # B8と他次元の相関（事業社会）
        for i in range(business_start, business_start + 7):
            correlation_matrix[business_start + 7, i] = self.business_specific_correlations['B8_others']
            correlation_matrix[i, business_start + 7] = self.business_specific_correlations['B8_others']
        
        return correlation_matrix
    
    def generate_company_data(self, industry, company_id, correlation_matrix):
        """単一企業の3年分データを生成"""
        company_data = []
        
        # 企業固有の特性（時系列で一貫）
        company_bias = np.random.normal(0, 5, 24)  # 企業固有のバイアス
        
        for year in self.years:
            # 年次データの基準値を生成
            base_values = []
            
            for perspective_idx, perspective in enumerate(['Market', 'Technology', 'Business']):
                perspective_means = self.industry_means[industry][perspective]
                perspective_values = []
                
                for dim_idx, mean_val in enumerate(perspective_means):
                    # 業界平均 + 企業固有バイアス + 年次変動
                    year_factor = 1 + (year - 2022) * 0.02  # 年次成長要因
                    noise = np.random.normal(0, self.industry_stds[industry])
                    
                    value = mean_val * year_factor + company_bias[perspective_idx * 8 + dim_idx] + noise
                    value = max(0, min(100, value))  # [0, 100]に制限
                    perspective_values.append(value)
                
                base_values.extend(perspective_values)
            
            # 相関構造を適用
            base_values = np.array(base_values)
            
            # 時系列相関の適用（前年データとの相関）
            if year > 2022:
                prev_values = company_data[-1][4:]  # 前年の値
                temporal_factor = self.temporal_correlation
                base_values = temporal_factor * np.array(prev_values) + (1 - temporal_factor) * base_values
            
            # レコード作成
            record = [company_id, industry, year, f"Company_{company_id:04d}"] + base_values.tolist()
            company_data.append(record)
        
        return company_data
    
    def generate_dataset(self):
        """完全なデータセットを生成"""
        print("合成データセット生成開始...")
        
        # 相関行列生成
        correlation_matrix = self.generate_correlation_matrix()
        
        # 列名定義
        columns = ['CompanyID', 'Industry', 'Year', 'CompanyName']
        for perspective in ['Market', 'Technology', 'Business']:
            columns.extend(self.dimensions[perspective])
        
        # データ生成
        all_data = []
        company_id = 1
        
        for industry in self.industries:
            print(f"  {industry}業界のデータ生成中...")
            
            for _ in range(self.companies_per_industry):
                company_data = self.generate_company_data(industry, company_id, correlation_matrix)
                all_data.extend(company_data)
                company_id += 1
        
        # DataFrame作成
        df = pd.DataFrame(all_data, columns=columns)
        
        # 各視点のスコア計算（8次元の平均）
        df['Market_Score'] = df[[col for col in columns if col.startswith('M')]].mean(axis=1)
        df['Technology_Score'] = df[[col for col in columns if col.startswith('T')]].mean(axis=1)
        df['Business_Score'] = df[[col for col in columns if col.startswith('B')]].mean(axis=1)
        
        # DCOスコア計算（3要素の乗算統合）
        df['DCO_Score'] = (
            df['Technology_Score'] * 
            df['Market_Score'] * 
            df['Business_Score']
        )
        
        print(f"データセット生成完了: {len(df)}レコード")
        return df, correlation_matrix
    
    def save_dataset(self, df, correlation_matrix, output_dir):
        """データセットとメタデータを保存"""
        os.makedirs(output_dir, exist_ok=True)
        
        # メインデータセット保存
        dataset_path = os.path.join(output_dir, 'synthetic_dco_dataset_business_perspective.csv')
        df.to_csv(dataset_path, index=False)
        print(f"データセット保存: {dataset_path}")
        
        # 相関行列保存
        correlation_path = os.path.join(output_dir, 'correlation_matrix_business_perspective.csv')
        correlation_df = pd.DataFrame(correlation_matrix)
        correlation_df.to_csv(correlation_path, index=False)
        print(f"相関行列保存: {correlation_path}")
        
        # メタデータ保存
        metadata = {
            'generation_date': datetime.now().isoformat(),
            'random_seed': RANDOM_SEED,
            'total_records': len(df),
            'total_companies': self.total_companies,
            'industries': self.industries,
            'years': self.years,
            'dimensions': self.dimensions,
            'industry_means': self.industry_means,
            'correlations': {
                'intra_perspective': self.intra_perspective_correlation,
                'inter_perspective': self.inter_perspective_correlation,
                'temporal': self.temporal_correlation,
                'business_specific': self.business_specific_correlations
            },
            'modification': 'Business Perspective (B1-B8) replacing Finance Perspective (F1-F8)'
        }
        
        metadata_path = os.path.join(output_dir, 'dataset_metadata_business_perspective.json')
        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2, ensure_ascii=False)
        print(f"メタデータ保存: {metadata_path}")
        
        return dataset_path, correlation_path, metadata_path
    
    def generate_summary_statistics(self, df):
        """データセットの要約統計を生成"""
        print("\\n=== データセット要約統計 ===")
        
        # 基本統計
        print(f"総レコード数: {len(df)}")
        print(f"企業数: {df['CompanyID'].nunique()}")
        print(f"業界数: {df['Industry'].nunique()}")
        print(f"年数: {df['Year'].nunique()}")
        
        # 業界別統計
        print("\\n業界別レコード数:")
        print(df['Industry'].value_counts().sort_index())
        
        # 次元別統計
        dimension_cols = [col for col in df.columns if any(col.startswith(prefix) for prefix in ['M', 'T', 'B'])]
        print(f"\\n次元数: {len(dimension_cols)}")
        
        # スコア統計
        score_cols = ['Market_Score', 'Technology_Score', 'Business_Score', 'DCO_Score']
        print("\\nスコア統計:")
        print(df[score_cols].describe())
        
        return df[dimension_cols].describe(), df[score_cols].describe()

def main():
    """メイン実行関数"""
    print("DCO概念定義検証実験 - 合成データ生成（ビジネス視点版）")
    print("=" * 60)
    
    # データ生成器初期化
    generator = SyntheticDataGeneratorBusinessPerspective()
    
    # データセット生成
    df, correlation_matrix = generator.generate_dataset()
    
    # 要約統計生成
    dim_stats, score_stats = generator.generate_summary_statistics(df)
    
    # データ保存
    output_dir = '../data'
    dataset_path, correlation_path, metadata_path = generator.save_dataset(df, correlation_matrix, output_dir)
    
    print("\\n" + "=" * 60)
    print("合成データ生成完了（ビジネス視点版）")
    print(f"データセット: {dataset_path}")
    print(f"相関行列: {correlation_path}")
    print(f"メタデータ: {metadata_path}")
    
    return df, correlation_matrix

if __name__ == "__main__":
    df, correlation_matrix = main()

