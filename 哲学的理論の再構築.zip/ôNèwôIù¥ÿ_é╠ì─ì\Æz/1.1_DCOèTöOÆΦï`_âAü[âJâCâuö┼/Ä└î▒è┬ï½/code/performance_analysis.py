#!/usr/bin/env python3.11
"""
DCO概念定義検証実験 - 性能分析と妥当性検証

作成日: 2025年7月10日
作成者: Manus AI
目的: 処理速度の妥当性分析と複雑性検証

検証項目:
1. 実験データ量の妥当性分析
2. ロジック複雑性の実装確認
3. 相関ベクトル処理の詳細検証
4. スケーラビリティテスト
5. 計算量クラス分析
"""

import numpy as np
import pandas as pd
import time
import psutil
import os
import cProfile
import pstats
import io
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns

class PerformanceAnalyzer:
    """性能分析クラス"""
    
    def __init__(self):
        """初期化"""
        self.analysis_results = {}
        self.profiling_data = {}
        
    def analyze_data_volume_impact(self):
        """データ量の影響分析"""
        print("="*60)
        print("1. データ量の影響分析")
        print("="*60)
        
        # 異なるデータサイズでの性能測定
        data_sizes = [100, 500, 1000, 2000, 3000, 5000, 10000]
        processing_times = []
        memory_usage = []
        
        # 基準データ読み込み
        base_data = pd.read_csv('../data/synthetic_dco_dataset.csv')
        dimensions = [col for col in base_data.columns if col.startswith(('M', 'T', 'F')) and '_' in col]
        
        for size in data_sizes:
            print(f"データサイズ {size} での性能測定中...")
            
            # データサイズ調整
            if size <= len(base_data):
                test_data = base_data.head(size)
            else:
                # データ拡張（重複を含む）
                repeat_factor = (size // len(base_data)) + 1
                expanded_data = pd.concat([base_data] * repeat_factor, ignore_index=True)
                test_data = expanded_data.head(size)
            
            # メモリ使用量測定開始
            process = psutil.Process(os.getpid())
            memory_before = process.memory_info().rss / 1024 / 1024  # MB
            
            # 処理時間測定
            start_time = time.time()
            
            # StatisticalDCOQuantifier処理
            from implementation_verification import StatisticalDCOQuantifier
            quantifier = StatisticalDCOQuantifier()
            quantifier.fit(test_data)
            
            # サンプル企業での計算
            sample_companies = test_data.head(min(100, size))
            for _, company in sample_companies.iterrows():
                company_data = company[dimensions]
                result = quantifier.calculate_dco_score(company_data, industry=company['Industry'])
            
            end_time = time.time()
            
            # メモリ使用量測定終了
            memory_after = process.memory_info().rss / 1024 / 1024  # MB
            
            processing_time = end_time - start_time
            memory_used = memory_after - memory_before
            
            processing_times.append(processing_time)
            memory_usage.append(memory_used)
            
            print(f"  データサイズ: {size}, 処理時間: {processing_time:.3f}秒, メモリ使用量: {memory_used:.2f}MB")
        
        # 結果分析
        self.analysis_results['data_volume_impact'] = {
            'data_sizes': data_sizes,
            'processing_times': processing_times,
            'memory_usage': memory_usage,
            'time_complexity_analysis': self._analyze_time_complexity(data_sizes, processing_times)
        }
        
        # 可視化
        self._plot_scalability_analysis(data_sizes, processing_times, memory_usage)
        
        return self.analysis_results['data_volume_impact']
    
    def analyze_logic_complexity(self):
        """ロジック複雑性分析"""
        print("\n" + "="*60)
        print("2. ロジック複雑性分析")
        print("="*60)
        
        # 詳細プロファイリング実行
        profiler = cProfile.Profile()
        
        # テストデータ準備
        data = pd.read_csv('../data/synthetic_dco_dataset.csv')
        dimensions = [col for col in data.columns if col.startswith(('M', 'T', 'F')) and '_' in col]
        
        # プロファイリング開始
        profiler.enable()
        
        # 複雑な処理の実行
        from implementation_verification import StatisticalDCOQuantifier, IndustryAdaptationMechanism
        
        # 1. 統計的定量化器の詳細処理
        quantifier = StatisticalDCOQuantifier()
        quantifier.fit(data)
        
        # 2. 業界適応機構の詳細処理
        adapter = IndustryAdaptationMechanism()
        for industry in data['Industry'].unique():
            industry_data = data[data['Industry'] == industry][dimensions]
            adapter.create_industry_profile(industry_data, industry)
        
        # 3. 複雑な計算処理
        test_companies = data.head(100)
        for _, company in test_companies.iterrows():
            company_data = company[dimensions]
            
            # DCOスコア計算（相関行列処理を含む）
            result = quantifier.calculate_dco_score(company_data, industry=company['Industry'])
            
            # 業界適応処理
            adapted_scores = adapter.adapt_to_industry(company_data.to_dict(), company['Industry'])
        
        profiler.disable()
        
        # プロファイリング結果分析
        s = io.StringIO()
        ps = pstats.Stats(profiler, stream=s).sort_stats('cumulative')
        ps.print_stats(20)  # 上位20関数
        
        profiling_output = s.getvalue()
        
        # 関数別実行時間分析
        function_stats = []
        lines = profiling_output.split('\n')
        for line in lines:
            if 'function calls' in line or 'primitive calls' in line:
                continue
            if line.strip() and not line.startswith('ncalls'):
                parts = line.split()
                if len(parts) >= 6:
                    try:
                        ncalls = parts[0]
                        tottime = float(parts[1])
                        cumtime = float(parts[3])
                        filename_function = ' '.join(parts[5:])
                        function_stats.append({
                            'ncalls': ncalls,
                            'tottime': tottime,
                            'cumtime': cumtime,
                            'function': filename_function
                        })
                    except (ValueError, IndexError):
                        continue
        
        self.analysis_results['logic_complexity'] = {
            'profiling_output': profiling_output,
            'function_stats': function_stats[:10],  # 上位10関数
            'total_function_calls': len(function_stats)
        }
        
        print("ロジック複雑性分析完了")
        print(f"分析対象関数数: {len(function_stats)}")
        
        return self.analysis_results['logic_complexity']
    
    def analyze_correlation_processing(self):
        """相関ベクトル処理の詳細検証"""
        print("\n" + "="*60)
        print("3. 相関ベクトル処理の詳細検証")
        print("="*60)
        
        # テストデータ準備
        data = pd.read_csv('../data/synthetic_dco_dataset.csv')
        dimensions = [col for col in data.columns if col.startswith(('M', 'T', 'F')) and '_' in col]
        
        correlation_analysis = {}
        
        # 1. 相関行列計算の実装確認
        print("相関行列計算の実装確認中...")
        
        start_time = time.time()
        
        # 全体相関行列
        global_corr = data[dimensions].corr()
        global_corr_time = time.time() - start_time
        
        # 業界別相関行列
        industry_corr_times = {}
        industry_correlations = {}
        
        for industry in data['Industry'].unique():
            start_time = time.time()
            industry_data = data[data['Industry'] == industry][dimensions]
            industry_corr = industry_data.corr()
            industry_corr_time = time.time() - start_time
            
            industry_corr_times[industry] = industry_corr_time
            industry_correlations[industry] = industry_corr
        
        correlation_analysis['correlation_computation'] = {
            'global_correlation_time': global_corr_time,
            'industry_correlation_times': industry_corr_times,
            'total_correlation_time': global_corr_time + sum(industry_corr_times.values())
        }
        
        # 2. 相関構造の複雑性分析
        print("相関構造の複雑性分析中...")
        
        # 相関行列の特性分析
        correlation_complexity = {}
        
        # 全体相関の特性
        global_corr_values = global_corr.values
        correlation_complexity['global'] = {
            'matrix_size': global_corr.shape,
            'non_zero_correlations': np.sum(np.abs(global_corr_values) > 0.1),
            'strong_correlations': np.sum(np.abs(global_corr_values) > 0.5),
            'max_correlation': np.max(np.abs(global_corr_values[global_corr_values < 1.0])),
            'mean_abs_correlation': np.mean(np.abs(global_corr_values[global_corr_values < 1.0]))
        }
        
        # 業界別相関の特性
        for industry, corr_matrix in industry_correlations.items():
            corr_values = corr_matrix.values
            correlation_complexity[industry] = {
                'matrix_size': corr_matrix.shape,
                'non_zero_correlations': np.sum(np.abs(corr_values) > 0.1),
                'strong_correlations': np.sum(np.abs(corr_values) > 0.5),
                'max_correlation': np.max(np.abs(corr_values[corr_values < 1.0])),
                'mean_abs_correlation': np.mean(np.abs(corr_values[corr_values < 1.0]))
            }
        
        correlation_analysis['correlation_complexity'] = correlation_complexity
        
        # 3. 相関処理のボトルネック分析
        print("相関処理のボトルネック分析中...")
        
        # 異なる次元数での相関計算時間
        dimension_subsets = [8, 16, 24]  # 1視点、2視点、3視点
        correlation_scaling = {}
        
        for dim_count in dimension_subsets:
            subset_dims = dimensions[:dim_count]
            
            start_time = time.time()
            subset_corr = data[subset_dims].corr()
            subset_time = time.time() - start_time
            
            correlation_scaling[dim_count] = {
                'computation_time': subset_time,
                'matrix_operations': dim_count * (dim_count - 1) / 2  # 相関計算の組み合わせ数
            }
        
        correlation_analysis['correlation_scaling'] = correlation_scaling
        
        self.analysis_results['correlation_processing'] = correlation_analysis
        
        print("相関ベクトル処理検証完了")
        
        return correlation_analysis
    
    def analyze_computational_complexity(self):
        """計算量クラス分析"""
        print("\n" + "="*60)
        print("4. 計算量クラス分析")
        print("="*60)
        
        complexity_analysis = {}
        
        # 1. 理論的計算量分析
        print("理論的計算量分析中...")
        
        theoretical_complexity = {
            'correlation_matrix_computation': 'O(n * d^2)',  # n: サンプル数, d: 次元数
            'dco_score_calculation': 'O(d)',  # 次元数に線形
            'industry_adaptation': 'O(d)',  # 次元数に線形
            'statistical_parameter_estimation': 'O(n * d)',  # サンプル数×次元数
            'overall_complexity': 'O(n * d^2)'  # 相関行列計算が支配的
        }
        
        complexity_analysis['theoretical'] = theoretical_complexity
        
        # 2. 実測計算量分析
        print("実測計算量分析中...")
        
        # 異なるパラメータでの実行時間測定
        sample_sizes = [100, 500, 1000, 2000, 3000]
        dimension_counts = [8, 16, 24]
        
        empirical_results = {}
        
        base_data = pd.read_csv('../data/synthetic_dco_dataset.csv')
        all_dimensions = [col for col in base_data.columns if col.startswith(('M', 'T', 'F')) and '_' in col]
        
        for dim_count in dimension_counts:
            empirical_results[dim_count] = {}
            dimensions = all_dimensions[:dim_count]
            
            for sample_size in sample_sizes:
                if sample_size <= len(base_data):
                    test_data = base_data.head(sample_size)
                else:
                    # データ拡張
                    repeat_factor = (sample_size // len(base_data)) + 1
                    expanded_data = pd.concat([base_data] * repeat_factor, ignore_index=True)
                    test_data = expanded_data.head(sample_size)
                
                # 処理時間測定
                start_time = time.time()
                
                # 相関行列計算
                corr_matrix = test_data[dimensions].corr()
                
                # DCOスコア計算（サンプル）
                sample_companies = test_data.head(min(50, sample_size))
                for _, company in sample_companies.iterrows():
                    company_data = company[dimensions]
                    # 簡易DCOスコア計算
                    perspective_scores = []
                    for i in range(0, len(dimensions), 8):
                        perspective_dims = dimensions[i:i+8]
                        if perspective_dims:
                            scores = [company_data[dim] for dim in perspective_dims if dim in company_data]
                            if scores:
                                perspective_scores.append(np.mean(scores))
                    
                    if len(perspective_scores) >= 3:
                        dco_score = np.prod(perspective_scores[:3]) / (100.0 ** 2)
                
                end_time = time.time()
                processing_time = end_time - start_time
                
                empirical_results[dim_count][sample_size] = processing_time
                
                print(f"  次元数: {dim_count}, サンプル数: {sample_size}, 処理時間: {processing_time:.3f}秒")
        
        complexity_analysis['empirical'] = empirical_results
        
        # 3. 計算量クラスの推定
        print("計算量クラスの推定中...")
        
        complexity_estimation = {}
        
        for dim_count in dimension_counts:
            times = list(empirical_results[dim_count].values())
            sizes = list(empirical_results[dim_count].keys())
            
            # 線形回帰による複雑性推定
            log_sizes = np.log(sizes)
            log_times = np.log(times)
            
            # 最小二乗法
            A = np.vstack([log_sizes, np.ones(len(log_sizes))]).T
            slope, intercept = np.linalg.lstsq(A, log_times, rcond=None)[0]
            
            complexity_estimation[dim_count] = {
                'estimated_exponent': slope,
                'complexity_class': self._classify_complexity(slope),
                'r_squared': self._calculate_r_squared(log_sizes, log_times, slope, intercept)
            }
        
        complexity_analysis['estimation'] = complexity_estimation
        
        self.analysis_results['computational_complexity'] = complexity_analysis
        
        print("計算量クラス分析完了")
        
        return complexity_analysis
    
    def _analyze_time_complexity(self, sizes, times):
        """時間複雑性分析"""
        if len(sizes) < 2 or len(times) < 2:
            return {'error': 'データ不足'}
        
        log_sizes = np.log(sizes)
        log_times = np.log(times)
        
        # 線形回帰
        A = np.vstack([log_sizes, np.ones(len(log_sizes))]).T
        slope, intercept = np.linalg.lstsq(A, log_times, rcond=None)[0]
        
        return {
            'estimated_exponent': slope,
            'complexity_class': self._classify_complexity(slope),
            'r_squared': self._calculate_r_squared(log_sizes, log_times, slope, intercept)
        }
    
    def _classify_complexity(self, exponent):
        """複雑性クラス分類"""
        if exponent < 1.2:
            return 'O(n) - 線形'
        elif exponent < 1.8:
            return 'O(n log n) - 準線形'
        elif exponent < 2.2:
            return 'O(n^2) - 二次'
        elif exponent < 3.2:
            return 'O(n^3) - 三次'
        else:
            return 'O(n^k) - 多項式'
    
    def _calculate_r_squared(self, x, y, slope, intercept):
        """決定係数計算"""
        y_pred = slope * x + intercept
        ss_res = np.sum((y - y_pred) ** 2)
        ss_tot = np.sum((y - np.mean(y)) ** 2)
        return 1 - (ss_res / ss_tot)
    
    def _plot_scalability_analysis(self, sizes, times, memory):
        """スケーラビリティ分析の可視化"""
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
        
        # 処理時間のスケーラビリティ
        ax1.plot(sizes, times, 'bo-', linewidth=2, markersize=8)
        ax1.set_xlabel('Data Size')
        ax1.set_ylabel('Processing Time (seconds)')
        ax1.set_title('Processing Time Scalability')
        ax1.grid(True, alpha=0.3)
        ax1.set_xscale('log')
        ax1.set_yscale('log')
        
        # メモリ使用量のスケーラビリティ
        ax2.plot(sizes, memory, 'ro-', linewidth=2, markersize=8)
        ax2.set_xlabel('Data Size')
        ax2.set_ylabel('Memory Usage (MB)')
        ax2.set_title('Memory Usage Scalability')
        ax2.grid(True, alpha=0.3)
        ax2.set_xscale('log')
        
        plt.tight_layout()
        plt.savefig('../results/scalability_analysis.png', dpi=300, bbox_inches='tight')
        plt.close()
    
    def generate_performance_analysis_report(self):
        """性能分析レポート生成"""
        print("\n" + "="*60)
        print("5. 性能分析レポート生成")
        print("="*60)
        
        report = []
        report.append("# DCO概念定義検証実験 - 性能分析と妥当性検証レポート")
        report.append(f"\n**実施日**: {datetime.now().strftime('%Y年%m月%d日')}")
        report.append("**目的**: 処理速度の妥当性分析と複雑性検証")
        
        # 1. データ量の影響分析結果
        if 'data_volume_impact' in self.analysis_results:
            data_analysis = self.analysis_results['data_volume_impact']
            report.append("\n## 1. データ量の影響分析結果")
            
            max_size = max(data_analysis['data_sizes'])
            max_time = max(data_analysis['processing_times'])
            
            report.append(f"- **最大データサイズ**: {max_size:,} レコード")
            report.append(f"- **最大処理時間**: {max_time:.3f} 秒")
            report.append(f"- **スケーラビリティ**: {data_analysis['time_complexity_analysis']['complexity_class']}")
            report.append(f"- **複雑性指数**: {data_analysis['time_complexity_analysis']['estimated_exponent']:.2f}")
            report.append(f"- **決定係数**: {data_analysis['time_complexity_analysis']['r_squared']:.3f}")
            
            # 性能評価
            if data_analysis['time_complexity_analysis']['estimated_exponent'] < 2.0:
                performance_evaluation = "良好（準線形以下）"
            elif data_analysis['time_complexity_analysis']['estimated_exponent'] < 3.0:
                performance_evaluation = "許容可能（二次程度）"
            else:
                performance_evaluation = "要改善（三次以上）"
            
            report.append(f"- **性能評価**: {performance_evaluation}")
        
        # 2. ロジック複雑性分析結果
        if 'logic_complexity' in self.analysis_results:
            logic_analysis = self.analysis_results['logic_complexity']
            report.append("\n## 2. ロジック複雑性分析結果")
            report.append(f"- **分析対象関数数**: {logic_analysis['total_function_calls']}")
            report.append("- **主要処理関数**:")
            
            for i, func_stat in enumerate(logic_analysis['function_stats'][:5]):
                report.append(f"  {i+1}. {func_stat['function']} (累積時間: {func_stat['cumtime']:.3f}秒)")
        
        # 3. 相関ベクトル処理検証結果
        if 'correlation_processing' in self.analysis_results:
            corr_analysis = self.analysis_results['correlation_processing']
            report.append("\n## 3. 相関ベクトル処理検証結果")
            
            total_corr_time = corr_analysis['correlation_computation']['total_correlation_time']
            report.append(f"- **総相関計算時間**: {total_corr_time:.3f} 秒")
            report.append(f"- **全体相関行列計算時間**: {corr_analysis['correlation_computation']['global_correlation_time']:.3f} 秒")
            
            # 業界別相関計算時間
            industry_times = corr_analysis['correlation_computation']['industry_correlation_times']
            avg_industry_time = np.mean(list(industry_times.values()))
            report.append(f"- **業界別平均計算時間**: {avg_industry_time:.3f} 秒")
            
            # 相関構造の複雑性
            global_complexity = corr_analysis['correlation_complexity']['global']
            report.append(f"- **強い相関の数**: {global_complexity['strong_correlations']}")
            report.append(f"- **平均絶対相関**: {global_complexity['mean_abs_correlation']:.3f}")
        
        # 4. 計算量クラス分析結果
        if 'computational_complexity' in self.analysis_results:
            comp_analysis = self.analysis_results['computational_complexity']
            report.append("\n## 4. 計算量クラス分析結果")
            
            report.append("### 理論的計算量")
            theoretical = comp_analysis['theoretical']
            for operation, complexity in theoretical.items():
                report.append(f"- **{operation}**: {complexity}")
            
            report.append("\n### 実測計算量")
            if 'estimation' in comp_analysis:
                for dim_count, estimation in comp_analysis['estimation'].items():
                    report.append(f"- **{dim_count}次元**: {estimation['complexity_class']} (指数: {estimation['estimated_exponent']:.2f}, R²: {estimation['r_squared']:.3f})")
        
        # 5. 総合評価と結論
        report.append("\n## 5. 総合評価と結論")
        
        # 性能妥当性の判定
        performance_issues = []
        performance_strengths = []
        
        # データ量の影響
        if 'data_volume_impact' in self.analysis_results:
            data_analysis = self.analysis_results['data_volume_impact']
            if data_analysis['time_complexity_analysis']['estimated_exponent'] > 2.5:
                performance_issues.append("データサイズに対する計算量の増加が急激")
            else:
                performance_strengths.append("データサイズに対して良好なスケーラビリティ")
        
        # 相関処理の実装確認
        if 'correlation_processing' in self.analysis_results:
            corr_analysis = self.analysis_results['correlation_processing']
            if corr_analysis['correlation_computation']['total_correlation_time'] > 0.001:
                performance_strengths.append("相関ベクトル処理が適切に実装されている")
            else:
                performance_issues.append("相関処理がバイパスされている可能性")
        
        # 結論
        if len(performance_issues) == 0:
            conclusion = "性能は妥当で、処理速度の高さは実装の効率性によるものと判断されます"
        elif len(performance_issues) <= len(performance_strengths):
            conclusion = "概ね妥当な性能ですが、一部改善の余地があります"
        else:
            conclusion = "性能に重要な問題があり、詳細な見直しが必要です"
        
        report.append(f"### 結論: {conclusion}")
        
        if performance_strengths:
            report.append("\n### 性能の強み")
            for strength in performance_strengths:
                report.append(f"- {strength}")
        
        if performance_issues:
            report.append("\n### 改善が必要な点")
            for issue in performance_issues:
                report.append(f"- {issue}")
        
        # レポート保存
        report_text = "\n".join(report)
        with open('../results/performance_analysis_report.md', 'w', encoding='utf-8') as f:
            f.write(report_text)
        
        print("性能分析レポート生成完了")
        return report_text
    
    def run_comprehensive_performance_analysis(self):
        """包括的性能分析実行"""
        print("DCO概念定義検証実験 - 性能分析と妥当性検証開始")
        print("="*70)
        
        # 各分析実行
        self.analyze_data_volume_impact()
        self.analyze_logic_complexity()
        self.analyze_correlation_processing()
        self.analyze_computational_complexity()
        
        # レポート生成
        report = self.generate_performance_analysis_report()
        
        print("\n" + "="*70)
        print("性能分析と妥当性検証完了")
        print("="*70)
        
        return self.analysis_results, report

def main():
    """メイン実行関数"""
    analyzer = PerformanceAnalyzer()
    analysis_results, report = analyzer.run_comprehensive_performance_analysis()
    
    print("\n性能分析結果:")
    print(report)
    
    return analysis_results, report

if __name__ == "__main__":
    analysis_results, report = main()

