#!/usr/bin/env python3.11
"""
DCO概念定義検証実験 - 統計的検定実験（1.1.3.1）

作成日: 2025年7月10日
作成者: Manus AI
目的: 24次元要素の正規性検定、信頼性分析、適合度検定

検証項目:
1. 正規性検定（Shapiro-Wilk検定、Kolmogorov-Smirnov検定）
2. 信頼性分析（Cronbach's α）
3. 適合度検定（相関構造の妥当性）
4. 業界間差異検定（ANOVA、Kruskal-Wallis検定）
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from scipy.stats import shapiro, kstest, normaltest, anderson
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestRegressor
import warnings
warnings.filterwarnings('ignore')

# 日本語フォント設定
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['figure.figsize'] = (12, 8)
plt.rcParams['font.size'] = 10

class StatisticalValidationTests:
    """統計的検定実験クラス"""
    
    def __init__(self, data_path='../data/synthetic_dco_dataset.csv'):
        """初期化"""
        self.data_path = data_path
        self.df = None
        self.dimensions = None
        self.results = {}
        
        # 3視点×8次元の定義
        self.perspective_dims = {
            'Market': [
                'M1_MarketShare', 'M2_CustomerSatisfaction', 'M3_BrandValue', 'M4_CompetitiveAdvantage',
                'M5_MarketGrowthRate', 'M6_PriceCompetitiveness', 'M7_CustomerLoyalty', 'M8_MarketPenetration'
            ],
            'Technology': [
                'T1_InnovationLevel', 'T2_RnDEfficiency', 'T3_DigitalTransformation', 'T4_IPPortfolio',
                'T5_TechnicalCompetitiveness', 'T6_SystemIntegration', 'T7_TechnicalRiskManagement', 'T8_TechnicalSustainability'
            ],
            'Finance': [
                'F1_Profitability', 'F2_Liquidity', 'F3_Stability', 'F4_GrowthPotential',
                'F5_Efficiency', 'F6_Leverage', 'F7_ROI', 'F8_CashFlow'
            ]
        }
        
        # 全次元リスト
        self.all_dimensions = []
        for dims in self.perspective_dims.values():
            self.all_dimensions.extend(dims)
    
    def load_data(self):
        """データ読み込み"""
        print("データ読み込み中...")
        self.df = pd.read_csv(self.data_path)
        print(f"データ読み込み完了: {len(self.df)} レコード, {len(self.df.columns)} 列")
        
        # 基本情報表示
        print(f"業界数: {self.df['Industry'].nunique()}")
        print(f"企業数: {self.df['CompanyID'].nunique()}")
        print(f"年数: {self.df['Year'].nunique()}")
        print(f"業界別企業数:")
        print(self.df.groupby('Industry')['CompanyID'].nunique())
    
    def test_normality(self):
        """正規性検定"""
        print("\n" + "="*50)
        print("1. 正規性検定実施中...")
        print("="*50)
        
        normality_results = []
        
        for dimension in self.all_dimensions:
            data = self.df[dimension].dropna()
            
            # Shapiro-Wilk検定（サンプルサイズが大きい場合は部分サンプル）
            if len(data) > 5000:
                sample_data = np.random.choice(data, 5000, replace=False)
            else:
                sample_data = data
            
            shapiro_stat, shapiro_p = shapiro(sample_data)
            
            # Kolmogorov-Smirnov検定
            ks_stat, ks_p = kstest(data, 'norm', args=(data.mean(), data.std()))
            
            # D'Agostino-Pearson検定
            dagostino_stat, dagostino_p = normaltest(data)
            
            # Anderson-Darling検定
            anderson_result = anderson(data, dist='norm')
            anderson_stat = anderson_result.statistic
            anderson_critical = anderson_result.critical_values[2]  # 5%水準
            anderson_significant = anderson_stat > anderson_critical
            
            result = {
                'Dimension': dimension,
                'N': len(data),
                'Mean': data.mean(),
                'Std': data.std(),
                'Skewness': stats.skew(data),
                'Kurtosis': stats.kurtosis(data),
                'Shapiro_Stat': shapiro_stat,
                'Shapiro_p': shapiro_p,
                'Shapiro_Normal': shapiro_p > 0.05,
                'KS_Stat': ks_stat,
                'KS_p': ks_p,
                'KS_Normal': ks_p > 0.05,
                'DAgostino_Stat': dagostino_stat,
                'DAgostino_p': dagostino_p,
                'DAgostino_Normal': dagostino_p > 0.05,
                'Anderson_Stat': anderson_stat,
                'Anderson_Critical': anderson_critical,
                'Anderson_Normal': not anderson_significant
            }
            
            normality_results.append(result)
        
        normality_df = pd.DataFrame(normality_results)
        
        # 結果保存
        normality_df.to_csv('../results/normality_test_results.csv', index=False)
        
        # サマリー統計
        normal_count = {
            'Shapiro': normality_df['Shapiro_Normal'].sum(),
            'KS': normality_df['KS_Normal'].sum(),
            'DAgostino': normality_df['DAgostino_Normal'].sum(),
            'Anderson': normality_df['Anderson_Normal'].sum()
        }
        
        print(f"正規性を満たす次元数（24次元中）:")
        for test, count in normal_count.items():
            print(f"  {test}検定: {count}/24 ({count/24*100:.1f}%)")
        
        self.results['normality'] = normality_df
        return normality_df
    
    def test_reliability(self):
        """信頼性分析（Cronbach's α）"""
        print("\n" + "="*50)
        print("2. 信頼性分析実施中...")
        print("="*50)
        
        reliability_results = []
        
        # 視点別信頼性分析
        for perspective, dimensions in self.perspective_dims.items():
            data = self.df[dimensions].dropna()
            
            # Cronbach's α計算
            alpha = self.calculate_cronbach_alpha(data)
            
            # 項目削除時のα
            alpha_if_deleted = []
            for dim in dimensions:
                temp_data = data.drop(columns=[dim])
                alpha_deleted = self.calculate_cronbach_alpha(temp_data)
                alpha_if_deleted.append(alpha_deleted)
            
            result = {
                'Perspective': perspective,
                'N_Items': len(dimensions),
                'N_Cases': len(data),
                'Cronbach_Alpha': alpha,
                'Alpha_Interpretation': self.interpret_alpha(alpha),
                'Min_Alpha_if_Deleted': min(alpha_if_deleted),
                'Max_Alpha_if_Deleted': max(alpha_if_deleted)
            }
            
            reliability_results.append(result)
        
        # 全体の信頼性
        all_data = self.df[self.all_dimensions].dropna()
        overall_alpha = self.calculate_cronbach_alpha(all_data)
        
        overall_result = {
            'Perspective': 'Overall',
            'N_Items': len(self.all_dimensions),
            'N_Cases': len(all_data),
            'Cronbach_Alpha': overall_alpha,
            'Alpha_Interpretation': self.interpret_alpha(overall_alpha),
            'Min_Alpha_if_Deleted': np.nan,
            'Max_Alpha_if_Deleted': np.nan
        }
        
        reliability_results.append(overall_result)
        
        reliability_df = pd.DataFrame(reliability_results)
        
        # 結果保存
        reliability_df.to_csv('../results/reliability_analysis_results.csv', index=False)
        
        print("信頼性分析結果:")
        for _, row in reliability_df.iterrows():
            print(f"  {row['Perspective']}: α = {row['Cronbach_Alpha']:.3f} ({row['Alpha_Interpretation']})")
        
        self.results['reliability'] = reliability_df
        return reliability_df
    
    def calculate_cronbach_alpha(self, data):
        """Cronbach's α計算"""
        # 項目数
        k = data.shape[1]
        
        # 各項目の分散
        item_variances = data.var(axis=0, ddof=1)
        
        # 総合得点の分散
        total_variance = data.sum(axis=1).var(ddof=1)
        
        # Cronbach's α
        alpha = (k / (k - 1)) * (1 - item_variances.sum() / total_variance)
        
        return alpha
    
    def interpret_alpha(self, alpha):
        """Cronbach's α解釈"""
        if alpha >= 0.9:
            return "Excellent"
        elif alpha >= 0.8:
            return "Good"
        elif alpha >= 0.7:
            return "Acceptable"
        elif alpha >= 0.6:
            return "Questionable"
        else:
            return "Poor"
    
    def test_correlation_structure(self):
        """相関構造の適合度検定"""
        print("\n" + "="*50)
        print("3. 相関構造適合度検定実施中...")
        print("="*50)
        
        # 実際の相関行列
        actual_corr = self.df[self.all_dimensions].corr()
        
        # 理論的相関行列（設計値）
        theoretical_corr = self.generate_theoretical_correlation()
        
        # 相関行列の比較
        correlation_diff = actual_corr - theoretical_corr
        
        # 統計的検定
        # Mantel検定（相関行列間の相関）
        mantel_r, mantel_p = self.mantel_test(actual_corr.values, theoretical_corr.values)
        
        # RV係数（相関行列間の類似度）
        rv_coefficient = self.rv_coefficient(actual_corr.values, theoretical_corr.values)
        
        # 結果
        correlation_results = {
            'Mantel_r': mantel_r,
            'Mantel_p': mantel_p,
            'Mantel_Significant': mantel_p < 0.05,
            'RV_Coefficient': rv_coefficient,
            'Mean_Absolute_Difference': np.abs(correlation_diff.values).mean(),
            'Max_Absolute_Difference': np.abs(correlation_diff.values).max(),
            'RMSE': np.sqrt(np.mean(correlation_diff.values**2))
        }
        
        print(f"相関構造適合度:")
        print(f"  Mantel検定: r = {mantel_r:.3f}, p = {mantel_p:.3f}")
        print(f"  RV係数: {rv_coefficient:.3f}")
        print(f"  平均絶対差: {correlation_results['Mean_Absolute_Difference']:.3f}")
        print(f"  RMSE: {correlation_results['RMSE']:.3f}")
        
        # 相関行列保存
        actual_corr.to_csv('../results/actual_correlation_matrix.csv')
        theoretical_corr.to_csv('../results/theoretical_correlation_matrix.csv')
        correlation_diff.to_csv('../results/correlation_difference_matrix.csv')
        
        # 結果保存
        pd.DataFrame([correlation_results]).to_csv('../results/correlation_structure_results.csv', index=False)
        
        self.results['correlation'] = correlation_results
        return correlation_results
    
    def generate_theoretical_correlation(self):
        """理論的相関行列生成"""
        n_dims = len(self.all_dimensions)
        theoretical_corr = np.eye(n_dims)
        
        # 視点内相関（0.5）
        intra_corr = 0.5
        # 視点間相関（0.25）
        inter_corr = 0.25
        
        for i in range(n_dims):
            for j in range(n_dims):
                if i != j:
                    i_perspective = i // 8
                    j_perspective = j // 8
                    
                    if i_perspective == j_perspective:
                        theoretical_corr[i, j] = intra_corr
                    else:
                        theoretical_corr[i, j] = inter_corr
        
        return pd.DataFrame(theoretical_corr, 
                          index=self.all_dimensions, 
                          columns=self.all_dimensions)
    
    def mantel_test(self, matrix1, matrix2, permutations=1000):
        """Mantel検定"""
        # 対角要素を除外
        mask = ~np.eye(matrix1.shape[0], dtype=bool)
        vec1 = matrix1[mask]
        vec2 = matrix2[mask]
        
        # 実際の相関
        actual_r = np.corrcoef(vec1, vec2)[0, 1]
        
        # 順列検定
        n = matrix1.shape[0]
        null_rs = []
        
        for _ in range(permutations):
            # 行列2をランダムに並び替え
            perm_indices = np.random.permutation(n)
            perm_matrix2 = matrix2[perm_indices][:, perm_indices]
            perm_vec2 = perm_matrix2[mask]
            
            null_r = np.corrcoef(vec1, perm_vec2)[0, 1]
            null_rs.append(null_r)
        
        # p値計算
        p_value = np.sum(np.array(null_rs) >= actual_r) / permutations
        
        return actual_r, p_value
    
    def rv_coefficient(self, matrix1, matrix2):
        """RV係数計算"""
        # 中心化
        n = matrix1.shape[0]
        H = np.eye(n) - np.ones((n, n)) / n
        
        X1 = H @ matrix1 @ H
        X2 = H @ matrix2 @ H
        
        # RV係数
        numerator = np.trace(X1 @ X2)
        denominator = np.sqrt(np.trace(X1 @ X1) * np.trace(X2 @ X2))
        
        return numerator / denominator
    
    def test_industry_differences(self):
        """業界間差異検定"""
        print("\n" + "="*50)
        print("4. 業界間差異検定実施中...")
        print("="*50)
        
        industry_test_results = []
        
        for dimension in self.all_dimensions:
            # 業界別データ
            industry_groups = [group[dimension].values for name, group in self.df.groupby('Industry')]
            
            # ANOVA（正規性仮定）
            f_stat, anova_p = stats.f_oneway(*industry_groups)
            
            # Kruskal-Wallis検定（非パラメトリック）
            kw_stat, kw_p = stats.kruskal(*industry_groups)
            
            # 効果量（eta squared）
            ss_between = sum(len(group) * (np.mean(group) - np.mean(self.df[dimension]))**2 
                           for group in industry_groups)
            ss_total = np.sum((self.df[dimension] - np.mean(self.df[dimension]))**2)
            eta_squared = ss_between / ss_total
            
            result = {
                'Dimension': dimension,
                'F_Statistic': f_stat,
                'ANOVA_p': anova_p,
                'ANOVA_Significant': anova_p < 0.05,
                'KW_Statistic': kw_stat,
                'KW_p': kw_p,
                'KW_Significant': kw_p < 0.05,
                'Eta_Squared': eta_squared,
                'Effect_Size': self.interpret_eta_squared(eta_squared)
            }
            
            industry_test_results.append(result)
        
        industry_df = pd.DataFrame(industry_test_results)
        
        # 結果保存
        industry_df.to_csv('../results/industry_differences_results.csv', index=False)
        
        # サマリー
        anova_significant = industry_df['ANOVA_Significant'].sum()
        kw_significant = industry_df['KW_Significant'].sum()
        
        print(f"業界間有意差のある次元数:")
        print(f"  ANOVA: {anova_significant}/24 ({anova_significant/24*100:.1f}%)")
        print(f"  Kruskal-Wallis: {kw_significant}/24 ({kw_significant/24*100:.1f}%)")
        
        self.results['industry_differences'] = industry_df
        return industry_df
    
    def interpret_eta_squared(self, eta_squared):
        """効果量解釈"""
        if eta_squared >= 0.14:
            return "Large"
        elif eta_squared >= 0.06:
            return "Medium"
        elif eta_squared >= 0.01:
            return "Small"
        else:
            return "Negligible"
    
    def generate_visualizations(self):
        """可視化生成"""
        print("\n" + "="*50)
        print("5. 可視化生成中...")
        print("="*50)
        
        # 1. 正規性検定結果の可視化
        self.plot_normality_results()
        
        # 2. 信頼性分析結果の可視化
        self.plot_reliability_results()
        
        # 3. 相関行列ヒートマップ
        self.plot_correlation_heatmaps()
        
        # 4. 業界間差異の可視化
        self.plot_industry_differences()
        
        print("可視化完了")
    
    def plot_normality_results(self):
        """正規性検定結果の可視化"""
        if 'normality' not in self.results:
            return
        
        normality_df = self.results['normality']
        
        # 正規性検定結果のバープロット
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        tests = ['Shapiro', 'KS', 'DAgostino', 'Anderson']
        for i, test in enumerate(tests):
            ax = axes[i//2, i%2]
            normal_col = f'{test}_Normal'
            
            counts = normality_df[normal_col].value_counts()
            colors = ['red' if not x else 'green' for x in counts.index]
            
            ax.bar(['Non-Normal', 'Normal'], [counts.get(False, 0), counts.get(True, 0)], 
                   color=colors, alpha=0.7)
            ax.set_title(f'{test} Test Results')
            ax.set_ylabel('Number of Dimensions')
            
            # パーセンテージ表示
            total = len(normality_df)
            for j, (label, count) in enumerate(zip(['Non-Normal', 'Normal'], 
                                                 [counts.get(False, 0), counts.get(True, 0)])):
                if count > 0:
                    ax.text(j, count + 0.5, f'{count/total*100:.1f}%', 
                           ha='center', va='bottom')
        
        plt.tight_layout()
        plt.savefig('../results/normality_test_visualization.png', dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_reliability_results(self):
        """信頼性分析結果の可視化"""
        if 'reliability' not in self.results:
            return
        
        reliability_df = self.results['reliability']
        
        # Cronbach's αのバープロット
        fig, ax = plt.subplots(figsize=(10, 6))
        
        perspectives = reliability_df['Perspective'].values
        alphas = reliability_df['Cronbach_Alpha'].values
        
        colors = ['green' if alpha >= 0.7 else 'orange' if alpha >= 0.6 else 'red' 
                 for alpha in alphas]
        
        bars = ax.bar(perspectives, alphas, color=colors, alpha=0.7)
        
        # 基準線
        ax.axhline(y=0.7, color='red', linestyle='--', alpha=0.5, label='Acceptable (0.7)')
        ax.axhline(y=0.8, color='orange', linestyle='--', alpha=0.5, label='Good (0.8)')
        ax.axhline(y=0.9, color='green', linestyle='--', alpha=0.5, label='Excellent (0.9)')
        
        ax.set_title("Cronbach's Alpha by Perspective")
        ax.set_ylabel("Cronbach's Alpha")
        ax.set_ylim(0, 1)
        ax.legend()
        
        # 値表示
        for bar, alpha in zip(bars, alphas):
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01, 
                   f'{alpha:.3f}', ha='center', va='bottom')
        
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig('../results/reliability_analysis_visualization.png', dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_correlation_heatmaps(self):
        """相関行列ヒートマップ"""
        if 'correlation' not in self.results:
            return
        
        # 実際の相関行列
        actual_corr = pd.read_csv('../results/actual_correlation_matrix.csv', index_col=0)
        theoretical_corr = pd.read_csv('../results/theoretical_correlation_matrix.csv', index_col=0)
        
        fig, axes = plt.subplots(1, 2, figsize=(20, 8))
        
        # 実際の相関行列
        sns.heatmap(actual_corr, annot=False, cmap='RdBu_r', center=0, 
                   square=True, ax=axes[0], vmin=-1, vmax=1)
        axes[0].set_title('Actual Correlation Matrix')
        
        # 理論的相関行列
        sns.heatmap(theoretical_corr, annot=False, cmap='RdBu_r', center=0, 
                   square=True, ax=axes[1], vmin=-1, vmax=1)
        axes[1].set_title('Theoretical Correlation Matrix')
        
        plt.tight_layout()
        plt.savefig('../results/correlation_matrices_visualization.png', dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_industry_differences(self):
        """業界間差異の可視化"""
        if 'industry_differences' not in self.results:
            return
        
        industry_df = self.results['industry_differences']
        
        # 効果量の分布
        fig, ax = plt.subplots(figsize=(10, 6))
        
        eta_squared = industry_df['Eta_Squared'].values
        effect_sizes = industry_df['Effect_Size'].values
        
        # 効果量別の色分け
        color_map = {'Negligible': 'gray', 'Small': 'blue', 'Medium': 'orange', 'Large': 'red'}
        colors = [color_map[size] for size in effect_sizes]
        
        ax.scatter(range(len(eta_squared)), eta_squared, c=colors, alpha=0.7, s=50)
        
        # 基準線
        ax.axhline(y=0.01, color='blue', linestyle='--', alpha=0.5, label='Small (0.01)')
        ax.axhline(y=0.06, color='orange', linestyle='--', alpha=0.5, label='Medium (0.06)')
        ax.axhline(y=0.14, color='red', linestyle='--', alpha=0.5, label='Large (0.14)')
        
        ax.set_title('Effect Sizes (Eta Squared) for Industry Differences')
        ax.set_xlabel('Dimension Index')
        ax.set_ylabel('Eta Squared')
        ax.legend()
        
        plt.tight_layout()
        plt.savefig('../results/industry_differences_visualization.png', dpi=300, bbox_inches='tight')
        plt.close()
    
    def generate_summary_report(self):
        """統計的検定実験サマリーレポート生成"""
        print("\n" + "="*50)
        print("6. サマリーレポート生成中...")
        print("="*50)
        
        report = []
        report.append("# DCO概念定義検証実験 - 統計的検定実験結果サマリー")
        report.append(f"\n**実施日**: {pd.Timestamp.now().strftime('%Y年%m月%d日')}")
        report.append(f"**データセット**: {len(self.df)} レコード（{self.df['CompanyID'].nunique()} 企業 × {self.df['Year'].nunique()} 年）")
        report.append(f"**検証次元数**: {len(self.all_dimensions)} 次元（3視点×8次元）")
        
        # 1. 正規性検定結果
        if 'normality' in self.results:
            normality_df = self.results['normality']
            report.append("\n## 1. 正規性検定結果")
            
            for test in ['Shapiro', 'KS', 'DAgostino', 'Anderson']:
                normal_count = normality_df[f'{test}_Normal'].sum()
                percentage = normal_count / len(normality_df) * 100
                report.append(f"- **{test}検定**: {normal_count}/24次元が正規分布に従う ({percentage:.1f}%)")
            
            report.append(f"\n**総合評価**: 24次元中、平均{normality_df[['Shapiro_Normal', 'KS_Normal', 'DAgostino_Normal', 'Anderson_Normal']].sum(axis=1).mean():.1f}次元が正規性を満たす")
        
        # 2. 信頼性分析結果
        if 'reliability' in self.results:
            reliability_df = self.results['reliability']
            report.append("\n## 2. 信頼性分析結果（Cronbach's α）")
            
            for _, row in reliability_df.iterrows():
                if row['Perspective'] != 'Overall':
                    report.append(f"- **{row['Perspective']}視点**: α = {row['Cronbach_Alpha']:.3f} ({row['Alpha_Interpretation']})")
            
            overall_alpha = reliability_df[reliability_df['Perspective'] == 'Overall']['Cronbach_Alpha'].iloc[0]
            overall_interp = reliability_df[reliability_df['Perspective'] == 'Overall']['Alpha_Interpretation'].iloc[0]
            report.append(f"- **全体**: α = {overall_alpha:.3f} ({overall_interp})")
        
        # 3. 相関構造適合度
        if 'correlation' in self.results:
            corr_results = self.results['correlation']
            report.append("\n## 3. 相関構造適合度検定結果")
            report.append(f"- **Mantel検定**: r = {corr_results['Mantel_r']:.3f}, p = {corr_results['Mantel_p']:.3f}")
            report.append(f"- **RV係数**: {corr_results['RV_Coefficient']:.3f}")
            report.append(f"- **平均絶対差**: {corr_results['Mean_Absolute_Difference']:.3f}")
            report.append(f"- **RMSE**: {corr_results['RMSE']:.3f}")
        
        # 4. 業界間差異検定
        if 'industry_differences' in self.results:
            industry_df = self.results['industry_differences']
            anova_sig = industry_df['ANOVA_Significant'].sum()
            kw_sig = industry_df['KW_Significant'].sum()
            
            report.append("\n## 4. 業界間差異検定結果")
            report.append(f"- **ANOVA有意差**: {anova_sig}/24次元 ({anova_sig/24*100:.1f}%)")
            report.append(f"- **Kruskal-Wallis有意差**: {kw_sig}/24次元 ({kw_sig/24*100:.1f}%)")
            
            large_effects = industry_df[industry_df['Effect_Size'] == 'Large'].shape[0]
            medium_effects = industry_df[industry_df['Effect_Size'] == 'Medium'].shape[0]
            report.append(f"- **大効果量**: {large_effects}次元, **中効果量**: {medium_effects}次元")
        
        # 5. 総合評価
        report.append("\n## 5. 総合評価")
        report.append("### 統計的妥当性")
        
        if 'normality' in self.results and 'reliability' in self.results:
            # 正規性の総合評価
            avg_normality = self.results['normality'][['Shapiro_Normal', 'KS_Normal', 'DAgostino_Normal', 'Anderson_Normal']].mean().mean()
            if avg_normality >= 0.7:
                normality_eval = "良好"
            elif avg_normality >= 0.5:
                normality_eval = "中程度"
            else:
                normality_eval = "要改善"
            
            # 信頼性の総合評価
            overall_alpha = self.results['reliability'][self.results['reliability']['Perspective'] == 'Overall']['Cronbach_Alpha'].iloc[0]
            if overall_alpha >= 0.8:
                reliability_eval = "良好"
            elif overall_alpha >= 0.7:
                reliability_eval = "許容可能"
            else:
                reliability_eval = "要改善"
            
            report.append(f"- **正規性**: {normality_eval} (平均{avg_normality*100:.1f}%の次元が正規性を満たす)")
            report.append(f"- **信頼性**: {reliability_eval} (全体α = {overall_alpha:.3f})")
        
        if 'correlation' in self.results:
            rv_coef = self.results['correlation']['RV_Coefficient']
            if rv_coef >= 0.8:
                structure_eval = "良好"
            elif rv_coef >= 0.6:
                structure_eval = "中程度"
            else:
                structure_eval = "要改善"
            
            report.append(f"- **相関構造**: {structure_eval} (RV係数 = {rv_coef:.3f})")
        
        # レポート保存
        report_text = "\n".join(report)
        with open('../results/statistical_validation_summary.md', 'w', encoding='utf-8') as f:
            f.write(report_text)
        
        print("サマリーレポート生成完了")
        return report_text
    
    def run_all_tests(self):
        """全検定実行"""
        print("DCO概念定義検証実験 - 統計的検定実験開始")
        print("="*60)
        
        # データ読み込み
        self.load_data()
        
        # 各検定実行
        self.test_normality()
        self.test_reliability()
        self.test_correlation_structure()
        self.test_industry_differences()
        
        # 可視化生成
        self.generate_visualizations()
        
        # サマリーレポート生成
        summary = self.generate_summary_report()
        
        print("\n" + "="*60)
        print("統計的検定実験完了")
        print("="*60)
        
        return self.results, summary

def main():
    """メイン実行関数"""
    validator = StatisticalValidationTests()
    results, summary = validator.run_all_tests()
    
    print("\n統計的検定実験結果:")
    print(summary)
    
    return results, summary

if __name__ == "__main__":
    results, summary = main()

