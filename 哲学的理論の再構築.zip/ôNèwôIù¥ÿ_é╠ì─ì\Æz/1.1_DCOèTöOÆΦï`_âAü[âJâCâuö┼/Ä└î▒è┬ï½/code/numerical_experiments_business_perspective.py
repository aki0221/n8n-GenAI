#!/usr/bin/env python3
"""
数値実験・性能評価プログラム (1.1.3.3) ビジネス視点修正版
DCO概念定義検証実験の最終段階

修正内容: ファイナンス視点→ビジネス視点への全面修正

目的:
- モンテカルロシミュレーションによる不確実性評価
- 交差検証による予測精度評価
- 大規模データセットでの性能評価
- 総合的な実験結果の統合分析
- ビジネス視点特有の評価指標の検証

実験環境:
- Python 3.11.0rc1
- NumPy 1.24.3, Pandas 2.0.3, Scikit-learn 1.3.0
- 合成データセット: 3,000レコード（1,000社×3年分）
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import cross_val_score, KFold, train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler
import json
import time
import os
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# 実験環境設定
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

class NumericalExperimentSuiteBusinessPerspective:
    """数値実験・性能評価の統合実行クラス（ビジネス視点版）"""
    
    def __init__(self, data_path):
        """
        初期化
        
        Args:
            data_path (str): 合成データセットのパス
        """
        self.data_path = data_path
        self.data = None
        self.results = {}
        self.experiment_start_time = datetime.now()
        
    def load_data(self):
        """データセットの読み込み"""
        print("データセット読み込み中...")
        self.data = pd.read_csv(self.data_path)
        print(f"データセット読み込み完了: {self.data.shape}")
        
        # 実際の列名を確認して使用（ビジネス視点版）
        available_cols = self.data.columns.tolist()
        tech_cols_actual = [col for col in available_cols if col.startswith('T') and '_' in col]
        market_cols_actual = [col for col in available_cols if col.startswith('M') and '_' in col]
        business_cols_actual = [col for col in available_cols if col.startswith('B') and '_' in col]
        
        # 各視点のスコア計算（8次元の平均）
        self.data['Technology_Score'] = self.data[tech_cols_actual].mean(axis=1)
        self.data['Market_Score'] = self.data[market_cols_actual].mean(axis=1)
        self.data['Business_Score'] = self.data[business_cols_actual].mean(axis=1)
        
        # DCOスコア計算（3要素の乗算統合）
        self.data['DCO_Score'] = (
            self.data['Technology_Score'] * 
            self.data['Market_Score'] * 
            self.data['Business_Score']
        )
        
        return self.data
    
    def monte_carlo_simulation(self, n_simulations=1000):
        """
        モンテカルロシミュレーションによる不確実性評価
        
        Args:
            n_simulations (int): シミュレーション回数
            
        Returns:
            dict: シミュレーション結果
        """
        print(f"モンテカルロシミュレーション開始 (n={n_simulations})...")
        start_time = time.time()
        
        # 基準統計量
        base_stats = {
            'Technology_Score': {
                'mean': self.data['Technology_Score'].mean(),
                'std': self.data['Technology_Score'].std()
            },
            'Market_Score': {
                'mean': self.data['Market_Score'].mean(),
                'std': self.data['Market_Score'].std()
            },
            'Business_Score': {
                'mean': self.data['Business_Score'].mean(),
                'std': self.data['Business_Score'].std()
            }
        }
        
        # シミュレーション実行
        simulated_dco_scores = []
        for _ in range(n_simulations):
            # 各視点のスコアをサンプリング
            tech_score = np.random.normal(
                base_stats['Technology_Score']['mean'],
                base_stats['Technology_Score']['std']
            )
            market_score = np.random.normal(
                base_stats['Market_Score']['mean'],
                base_stats['Market_Score']['std']
            )
            business_score = np.random.normal(
                base_stats['Business_Score']['mean'],
                base_stats['Business_Score']['std']
            )
            
            # DCOスコア計算
            dco_score = tech_score * market_score * business_score
            simulated_dco_scores.append(dco_score)
        
        simulated_dco_scores = np.array(simulated_dco_scores)
        execution_time = time.time() - start_time
        
        # 統計分析
        results = {
            'n_simulations': n_simulations,
            'execution_time_seconds': execution_time,
            'dco_score_statistics': {
                'mean': float(np.mean(simulated_dco_scores)),
                'std': float(np.std(simulated_dco_scores)),
                'min': float(np.min(simulated_dco_scores)),
                'max': float(np.max(simulated_dco_scores)),
                'median': float(np.median(simulated_dco_scores)),
                'q25': float(np.percentile(simulated_dco_scores, 25)),
                'q75': float(np.percentile(simulated_dco_scores, 75)),
                'coefficient_of_variation': float(np.std(simulated_dco_scores) / np.mean(simulated_dco_scores))
            },
            'confidence_intervals': {
                '95%': [
                    float(np.percentile(simulated_dco_scores, 2.5)),
                    float(np.percentile(simulated_dco_scores, 97.5))
                ],
                '99%': [
                    float(np.percentile(simulated_dco_scores, 0.5)),
                    float(np.percentile(simulated_dco_scores, 99.5))
                ]
            }
        }
        
        print(f"モンテカルロシミュレーション完了 ({execution_time:.3f}秒)")
        return results
    
    def cross_validation_analysis(self, cv_folds=5):
        """
        交差検証による予測精度評価
        
        Args:
            cv_folds (int): 交差検証の分割数
            
        Returns:
            dict: 交差検証結果
        """
        print(f"交差検証分析開始 ({cv_folds}-fold)...")
        start_time = time.time()
        
        # 特徴量とターゲットの準備
        feature_cols = [col for col in self.data.columns 
                       if col.startswith(('T', 'M', 'B')) and '_' in col]
        X = self.data[feature_cols]
        y = self.data['DCO_Score']
        
        # 標準化
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # 交差検証実行
        model = RandomForestRegressor(n_estimators=100, random_state=RANDOM_SEED)
        cv_scores = cross_val_score(model, X_scaled, y, cv=cv_folds, scoring='r2')
        
        # 詳細分析のための分割実行
        kfold = KFold(n_splits=cv_folds, shuffle=True, random_state=RANDOM_SEED)
        fold_results = []
        
        for fold_idx, (train_idx, val_idx) in enumerate(kfold.split(X_scaled)):
            X_train, X_val = X_scaled[train_idx], X_scaled[val_idx]
            y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]
            
            model_fold = RandomForestRegressor(n_estimators=100, random_state=RANDOM_SEED)
            model_fold.fit(X_train, y_train)
            y_pred = model_fold.predict(X_val)
            
            fold_result = {
                'fold': fold_idx + 1,
                'r2_score': r2_score(y_val, y_pred),
                'mse': mean_squared_error(y_val, y_pred),
                'mae': mean_absolute_error(y_val, y_pred),
                'n_train': len(X_train),
                'n_val': len(X_val)
            }
            fold_results.append(fold_result)
        
        execution_time = time.time() - start_time
        
        results = {
            'cv_folds': cv_folds,
            'execution_time_seconds': execution_time,
            'overall_scores': {
                'mean_r2': float(np.mean(cv_scores)),
                'std_r2': float(np.std(cv_scores)),
                'min_r2': float(np.min(cv_scores)),
                'max_r2': float(np.max(cv_scores))
            },
            'fold_details': fold_results,
            'feature_importance': {
                'n_features': len(feature_cols),
                'feature_names': feature_cols
            }
        }
        
        print(f"交差検証分析完了 ({execution_time:.3f}秒)")
        return results
    
    def scalability_analysis(self, max_records=10000, step_size=1000):
        """
        スケーラビリティ分析
        
        Args:
            max_records (int): 最大レコード数
            step_size (int): ステップサイズ
            
        Returns:
            dict: スケーラビリティ分析結果
        """
        print(f"スケーラビリティ分析開始 (最大{max_records}レコード)...")
        start_time = time.time()
        
        # データサイズを段階的に増加させて処理時間を測定
        record_sizes = list(range(step_size, min(max_records, len(self.data)) + 1, step_size))
        scalability_results = []
        
        for n_records in record_sizes:
            subset_data = self.data.head(n_records)
            
            # 処理時間測定
            process_start = time.time()
            
            # DCOスコア計算
            tech_cols = [col for col in subset_data.columns if col.startswith('T') and '_' in col]
            market_cols = [col for col in subset_data.columns if col.startswith('M') and '_' in col]
            business_cols = [col for col in subset_data.columns if col.startswith('B') and '_' in col]
            
            tech_scores = subset_data[tech_cols].mean(axis=1)
            market_scores = subset_data[market_cols].mean(axis=1)
            business_scores = subset_data[business_cols].mean(axis=1)
            dco_scores = tech_scores * market_scores * business_scores
            
            # 相関行列計算
            correlation_matrix = subset_data[tech_cols + market_cols + business_cols].corr()
            
            process_time = time.time() - process_start
            
            scalability_results.append({
                'n_records': n_records,
                'processing_time_seconds': process_time,
                'processing_time_per_record': process_time / n_records,
                'dco_score_mean': float(dco_scores.mean()),
                'dco_score_std': float(dco_scores.std()),
                'correlation_matrix_size': correlation_matrix.shape[0]
            })
        
        execution_time = time.time() - start_time
        
        # スケーラビリティ指標計算
        times = [r['processing_time_seconds'] for r in scalability_results]
        sizes = [r['n_records'] for r in scalability_results]
        
        # 線形回帰でスケーラビリティを評価
        from sklearn.linear_model import LinearRegression
        lr = LinearRegression()
        lr.fit(np.array(sizes).reshape(-1, 1), times)
        
        results = {
            'max_records_tested': max(record_sizes),
            'execution_time_seconds': execution_time,
            'scalability_details': scalability_results,
            'scalability_metrics': {
                'linear_coefficient': float(lr.coef_[0]),
                'linear_intercept': float(lr.intercept_),
                'r2_linearity': float(lr.score(np.array(sizes).reshape(-1, 1), times)),
                'max_throughput_records_per_second': float(max(sizes) / max(times)) if max(times) > 0 else 0
            }
        }
        
        print(f"スケーラビリティ分析完了 ({execution_time:.3f}秒)")
        return results
    
    def industry_comparison_analysis(self):
        """
        業界間比較分析
        
        Returns:
            dict: 業界間比較結果
        """
        print("業界間比較分析開始...")
        start_time = time.time()
        
        industry_results = {}
        
        for industry in self.data['Industry'].unique():
            industry_data = self.data[self.data['Industry'] == industry]
            
            industry_results[industry] = {
                'n_companies': len(industry_data),
                'dco_score_statistics': {
                    'mean': float(industry_data['DCO_Score'].mean()),
                    'std': float(industry_data['DCO_Score'].std()),
                    'min': float(industry_data['DCO_Score'].min()),
                    'max': float(industry_data['DCO_Score'].max()),
                    'median': float(industry_data['DCO_Score'].median())
                },
                'perspective_scores': {
                    'Technology_Score': {
                        'mean': float(industry_data['Technology_Score'].mean()),
                        'std': float(industry_data['Technology_Score'].std())
                    },
                    'Market_Score': {
                        'mean': float(industry_data['Market_Score'].mean()),
                        'std': float(industry_data['Market_Score'].std())
                    },
                    'Business_Score': {
                        'mean': float(industry_data['Business_Score'].mean()),
                        'std': float(industry_data['Business_Score'].std())
                    }
                }
            }
        
        execution_time = time.time() - start_time
        
        results = {
            'n_industries': len(industry_results),
            'execution_time_seconds': execution_time,
            'industry_details': industry_results
        }
        
        print(f"業界間比較分析完了 ({execution_time:.3f}秒)")
        return results
    
    def run_all_experiments(self):
        """
        すべての数値実験を実行
        
        Returns:
            dict: 統合実験結果
        """
        print("=" * 60)
        print("DCO数値実験・性能評価開始（ビジネス視点版）")
        print("=" * 60)
        
        # データ読み込み
        self.load_data()
        
        # 各実験の実行
        self.results['monte_carlo'] = self.monte_carlo_simulation()
        self.results['cross_validation'] = self.cross_validation_analysis()
        self.results['scalability'] = self.scalability_analysis()
        self.results['industry_comparison'] = self.industry_comparison_analysis()
        
        # 実験メタデータ
        self.results['experiment_metadata'] = {
            'start_time': self.experiment_start_time.isoformat(),
            'end_time': datetime.now().isoformat(),
            'total_execution_time_seconds': (datetime.now() - self.experiment_start_time).total_seconds(),
            'dataset_shape': list(self.data.shape),
            'random_seed': RANDOM_SEED,
            'perspective_type': 'Business Perspective'
        }
        
        return self.results
    
    def save_results(self, output_dir="../results"):
        """
        実験結果を保存
        
        Args:
            output_dir (str): 出力ディレクトリ
        """
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        # JSON結果保存
        json_path = os.path.join(output_dir, "numerical_experiment_results_business_perspective.json")
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, indent=2, ensure_ascii=False)
        
        # スケーラビリティ分析の可視化
        self.create_scalability_plot(output_dir)
        
        print(f"実験結果保存完了: {json_path}")
    
    def create_scalability_plot(self, output_dir):
        """
        スケーラビリティ分析の可視化
        
        Args:
            output_dir (str): 出力ディレクトリ
        """
        if 'scalability' not in self.results:
            return
        
        scalability_data = self.results['scalability']['scalability_details']
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
        
        # 処理時間 vs データサイズ
        sizes = [d['n_records'] for d in scalability_data]
        times = [d['processing_time_seconds'] for d in scalability_data]
        
        ax1.plot(sizes, times, 'b-o', linewidth=2, markersize=6)
        ax1.set_xlabel('Number of Records')
        ax1.set_ylabel('Processing Time (seconds)')
        ax1.set_title('Processing Time vs Dataset Size')
        ax1.grid(True, alpha=0.3)
        
        # レコードあたり処理時間
        times_per_record = [d['processing_time_per_record'] for d in scalability_data]
        
        ax2.plot(sizes, times_per_record, 'r-s', linewidth=2, markersize=6)
        ax2.set_xlabel('Number of Records')
        ax2.set_ylabel('Processing Time per Record (seconds)')
        ax2.set_title('Processing Time per Record vs Dataset Size')
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        plot_path = os.path.join(output_dir, "scalability_analysis_business_perspective.png")
        plt.savefig(plot_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"スケーラビリティ分析グラフ保存: {plot_path}")

def main():
    """メイン実行関数"""
    # データパス設定
    data_path = "../data/synthetic_dco_dataset_business_perspective.csv"
    
    # 実験実行
    experiment = NumericalExperimentSuiteBusinessPerspective(data_path)
    results = experiment.run_all_experiments()
    experiment.save_results()
    
    # 結果サマリー表示
    print("\n" + "=" * 60)
    print("実験結果サマリー（ビジネス視点版）")
    print("=" * 60)
    
    mc_results = results['monte_carlo']
    cv_results = results['cross_validation']
    scale_results = results['scalability']
    industry_results = results['industry_comparison']
    
    print(f"モンテカルロシミュレーション:")
    print(f"  実行時間: {mc_results['execution_time_seconds']:.3f}秒")
    print(f"  DCOスコア平均: {mc_results['dco_score_statistics']['mean']:.2f}")
    print(f"  変動係数: {mc_results['dco_score_statistics']['coefficient_of_variation']:.3f}")
    print(f"  95%信頼区間: [{mc_results['confidence_intervals']['95%'][0]:.2f}, {mc_results['confidence_intervals']['95%'][1]:.2f}]")
    
    print(f"\n交差検証分析:")
    print(f"  実行時間: {cv_results['execution_time_seconds']:.3f}秒")
    print(f"  R²スコア: {cv_results['overall_scores']['mean_r2']:.3f} ± {cv_results['overall_scores']['std_r2']:.3f}")
    print(f"  特徴量数: {cv_results['feature_importance']['n_features']}")
    
    print(f"\nスケーラビリティ分析:")
    print(f"  実行時間: {scale_results['execution_time_seconds']:.3f}秒")
    print(f"  最大テストレコード数: {scale_results['max_records_tested']:,}")
    print(f"  最大スループット: {scale_results['scalability_metrics']['max_throughput_records_per_second']:,.0f} レコード/秒")
    print(f"  線形性R²: {scale_results['scalability_metrics']['r2_linearity']:.3f}")
    
    print(f"\n業界間比較分析:")
    print(f"  実行時間: {industry_results['execution_time_seconds']:.3f}秒")
    print(f"  分析業界数: {industry_results['n_industries']}")
    
    print(f"\n総実行時間: {results['experiment_metadata']['total_execution_time_seconds']:.3f}秒")
    print("=" * 60)
    print("数値実験・性能評価完了（ビジネス視点版）")

if __name__ == "__main__":
    main()

