#!/usr/bin/env python3
"""
統計的品質改善プログラム（ビジネス視点版）
DCO理論の統計的妥当性を改善するための包括的分析・修正ツール
"""

import pandas as pd
import numpy as np
from scipy import stats
from sklearn.preprocessing import StandardScaler, PowerTransformer
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_selection import SelectKBest, f_regression
import warnings
warnings.filterwarnings('ignore')

class StatisticalQualityImprover:
    """統計的品質改善クラス"""
    
    def __init__(self, data_path):
        """初期化"""
        self.data = pd.read_csv(data_path)
        self.improved_data = None
        self.improvement_log = []
        
    def calculate_cronbach_alpha(self, data):
        """Cronbach's α計算"""
        n_items = data.shape[1]
        if n_items < 2:
            return 0.0
        item_variances = data.var(axis=0, ddof=1)
        total_variance = data.sum(axis=1).var(ddof=1)
        if total_variance == 0:
            return 0.0
        alpha = (n_items / (n_items - 1)) * (1 - item_variances.sum() / total_variance)
        return alpha
        
    def analyze_reliability_issues(self):
        """信頼性問題の詳細分析"""
        print("=" * 60)
        print("信頼性問題の詳細分析")
        print("=" * 60)
        
        # ビジネス視点の項目間相関分析
        business_cols = [col for col in self.data.columns if col.startswith('B')]
        business_data = self.data[business_cols]
        
        print("\n1. ビジネス視点項目間相関マトリックス:")
        corr_matrix = business_data.corr()
        print(corr_matrix.round(3))
        
        # 負の相関項目の特定
        print("\n2. 負の相関項目の特定:")
        negative_corr_pairs = []
        for i in range(len(business_cols)):
            for j in range(i+1, len(business_cols)):
                corr_val = corr_matrix.iloc[i, j]
                if corr_val < -0.1:
                    negative_corr_pairs.append((business_cols[i], business_cols[j], corr_val))
                    print(f"  {business_cols[i]} - {business_cols[j]}: r={corr_val:.3f}")
        
        # 項目削除時の信頼性変化
        print("\n3. 項目削除時の信頼性変化分析:")
        
        base_alpha = self.calculate_cronbach_alpha(business_data)
        print(f"  ベース信頼性: α={base_alpha:.3f}")
        
        improvement_candidates = []
        for col in business_cols:
            temp_data = business_data.drop(columns=[col])
            temp_alpha = self.calculate_cronbach_alpha(temp_data)
            improvement = temp_alpha - base_alpha
            improvement_candidates.append((col, temp_alpha, improvement))
            print(f"  {col}削除時: α={temp_alpha:.3f} (改善: {improvement:+.3f})")
        
        # 最も改善効果の高い項目を特定
        improvement_candidates.sort(key=lambda x: x[2], reverse=True)
        self.improvement_log.append({
            'analysis': 'reliability_issues',
            'base_alpha': base_alpha,
            'best_improvement': improvement_candidates[0],
            'negative_correlations': negative_corr_pairs
        })
        
        return improvement_candidates
    
    def improve_data_distribution(self):
        """データ分布の改善"""
        print("\n=" * 60)
        print("データ分布の改善")
        print("=" * 60)
        
        self.improved_data = self.data.copy()
        
        # 各列の分布改善
        numeric_cols = self.data.select_dtypes(include=[np.number]).columns
        transformation_log = []
        
        for col in numeric_cols:
            if col in ['Year', 'DCO_Score']:  # スキップする列
                continue
                
            original_data = self.data[col].values
            
            # 正規性テスト（改善前）
            _, p_shapiro_before = stats.shapiro(original_data[:5000] if len(original_data) > 5000 else original_data)
            
            # 複数の変換手法を試行
            transformations = {
                'log': np.log1p(original_data - original_data.min() + 1),
                'sqrt': np.sqrt(original_data - original_data.min() + 1),
                'box_cox': None,
                'yeo_johnson': None
            }
            
            # Box-Cox変換（正の値のみ）
            if (original_data > 0).all():
                try:
                    transformations['box_cox'], _ = stats.boxcox(original_data)
                except:
                    pass
            
            # Yeo-Johnson変換
            try:
                pt = PowerTransformer(method='yeo-johnson')
                transformations['yeo_johnson'] = pt.fit_transform(original_data.reshape(-1, 1)).flatten()
            except:
                pass
            
            # 最適な変換を選択
            best_transformation = 'original'
            best_p_value = p_shapiro_before
            best_data = original_data
            
            for trans_name, trans_data in transformations.items():
                if trans_data is not None:
                    try:
                        _, p_shapiro = stats.shapiro(trans_data[:5000] if len(trans_data) > 5000 else trans_data)
                        if p_shapiro > best_p_value:
                            best_transformation = trans_name
                            best_p_value = p_shapiro
                            best_data = trans_data
                    except:
                        continue
            
            # 改善されたデータを適用
            if best_transformation != 'original':
                self.improved_data[col] = best_data
                transformation_log.append({
                    'column': col,
                    'transformation': best_transformation,
                    'p_before': p_shapiro_before,
                    'p_after': best_p_value,
                    'improvement': best_p_value - p_shapiro_before
                })
                print(f"  {col}: {best_transformation}変換 (p: {p_shapiro_before:.4f} → {best_p_value:.4f})")
        
        self.improvement_log.append({
            'analysis': 'distribution_improvement',
            'transformations': transformation_log
        })
        
        return transformation_log
    
    def optimize_feature_selection(self):
        """特徴量選択の最適化"""
        print("\n=" * 60)
        print("特徴量選択の最適化")
        print("=" * 60)
        
        # 目的変数の設定
        target = self.improved_data['DCO_Score']
        
        # 特徴量の準備
        feature_cols = [col for col in self.improved_data.columns 
                       if col.startswith(('M', 'T', 'B')) and col != 'DCO_Score']
        features = self.improved_data[feature_cols]
        
        # 特徴量重要度分析
        rf = RandomForestRegressor(n_estimators=100, random_state=42)
        rf.fit(features, target)
        
        feature_importance = pd.DataFrame({
            'feature': feature_cols,
            'importance': rf.feature_importances_
        }).sort_values('importance', ascending=False)
        
        print("\n1. 特徴量重要度ランキング:")
        for idx, row in feature_importance.head(10).iterrows():
            print(f"  {row['feature']}: {row['importance']:.4f}")
        
        # 統計的特徴量選択
        selector = SelectKBest(score_func=f_regression, k=15)
        selected_features = selector.fit_transform(features, target)
        selected_feature_names = [feature_cols[i] for i in selector.get_support(indices=True)]
        
        print(f"\n2. 統計的特徴量選択結果（上位15特徴量）:")
        for feature in selected_feature_names:
            print(f"  {feature}")
        
        # 予測性能の評価
        cv_scores_all = cross_val_score(rf, features, target, cv=5, scoring='r2')
        cv_scores_selected = cross_val_score(rf, selected_features, target, cv=5, scoring='r2')
        
        print(f"\n3. 予測性能比較:")
        print(f"  全特徴量使用: R² = {cv_scores_all.mean():.4f} ± {cv_scores_all.std():.4f}")
        print(f"  選択特徴量使用: R² = {cv_scores_selected.mean():.4f} ± {cv_scores_selected.std():.4f}")
        
        self.improvement_log.append({
            'analysis': 'feature_optimization',
            'feature_importance': feature_importance.to_dict('records'),
            'selected_features': selected_feature_names,
            'cv_scores_all': cv_scores_all.mean(),
            'cv_scores_selected': cv_scores_selected.mean()
        })
        
        return selected_feature_names, cv_scores_selected.mean()
    
    def recalculate_reliability(self):
        """改善後の信頼性再計算"""
        print("\n=" * 60)
        print("改善後の信頼性再計算")
        print("=" * 60)
        
        # 各視点の信頼性計算
        perspectives = ['M', 'T', 'B']
        perspective_names = ['Market', 'Technology', 'Business']
        
        reliability_results = {}
        
        for persp, name in zip(perspectives, perspective_names):
            cols = [col for col in self.improved_data.columns if col.startswith(persp)]
            data = self.improved_data[cols]
            
            alpha = self.calculate_cronbach_alpha(data)
            
            # 信頼性レベルの判定
            if alpha >= 0.9:
                level = "Excellent"
            elif alpha >= 0.8:
                level = "Good"
            elif alpha >= 0.7:
                level = "Acceptable"
            elif alpha >= 0.6:
                level = "Poor"
            else:
                level = "Unacceptable"
            
            reliability_results[name] = {
                'alpha': alpha,
                'level': level,
                'n_items': len(cols)
            }
            
            print(f"  {name}視点: α={alpha:.3f} ({level})")
        
        self.improvement_log.append({
            'analysis': 'improved_reliability',
            'results': reliability_results
        })
        
        return reliability_results
    
    def generate_improvement_report(self):
        """改善報告書の生成"""
        print("\n=" * 60)
        print("統計的品質改善報告書")
        print("=" * 60)
        
        # 改善前後の比較
        original_business_cols = [col for col in self.data.columns if col.startswith('B')]
        improved_business_cols = [col for col in self.improved_data.columns if col.startswith('B')]
        
        alpha_before = self.calculate_cronbach_alpha(self.data[original_business_cols])
        alpha_after = self.calculate_cronbach_alpha(self.improved_data[improved_business_cols])
        
        print(f"\n【改善効果サマリー】")
        print(f"  ビジネス視点信頼性: {alpha_before:.3f} → {alpha_after:.3f} (改善: {alpha_after - alpha_before:+.3f})")
        
        # 正規性の改善
        normality_improvements = [log for log in self.improvement_log if log['analysis'] == 'distribution_improvement']
        if normality_improvements:
            trans_count = len(normality_improvements[0]['transformations'])
            print(f"  分布改善適用: {trans_count}項目")
        
        # 特徴量選択の効果
        feature_improvements = [log for log in self.improvement_log if log['analysis'] == 'feature_optimization']
        if feature_improvements:
            cv_improvement = feature_improvements[0]['cv_scores_selected'] - feature_improvements[0]['cv_scores_all']
            print(f"  予測精度改善: {cv_improvement:+.3f}")
        
        # 改善データの保存
        output_path = '../data/synthetic_dco_dataset_improved.csv'
        self.improved_data.to_csv(output_path, index=False)
        print(f"\n改善データ保存: {output_path}")
        
        return {
            'alpha_improvement': alpha_after - alpha_before,
            'improved_data_path': output_path,
            'improvement_log': self.improvement_log
        }

def main():
    """メイン実行関数"""
    print("統計的品質改善プログラム開始")
    print("=" * 60)
    
    # データ読み込み
    data_path = '../data/synthetic_dco_dataset_business_perspective.csv'
    improver = StatisticalQualityImprover(data_path)
    
    # 段階的改善実行
    print("\n【段階1】信頼性問題の分析")
    reliability_candidates = improver.analyze_reliability_issues()
    
    print("\n【段階2】データ分布の改善")
    transformation_log = improver.improve_data_distribution()
    
    print("\n【段階3】特徴量選択の最適化")
    selected_features, cv_score = improver.optimize_feature_selection()
    
    print("\n【段階4】改善後信頼性の再計算")
    improved_reliability = improver.recalculate_reliability()
    
    print("\n【段階5】改善報告書の生成")
    improvement_summary = improver.generate_improvement_report()
    
    print("\n統計的品質改善完了")
    return improvement_summary

if __name__ == "__main__":
    main()

