#!/usr/bin/env python3.11
"""
DCO概念定義検証実験 - 合成データ生成プログラム

作成日: 2025年7月10日
作成者: Manus AI
目的: DCO理論検証のための統計的に妥当な合成企業データの生成

データ仕様:
- 企業数: 1,000社（業界別200社×5業界）
- 時系列: 3年分（2022-2024年）
- 次元数: 24次元（3視点×8次元）
- 総レコード数: 3,000レコード
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from datetime import datetime
import json
import os

# 乱数シード固定（再現性確保）
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

class SyntheticDataGenerator:
    """DCO理論検証用合成データ生成クラス"""
    
    def __init__(self):
        """初期化"""
        self.industries = ['Manufacturing', 'Finance', 'IT', 'Retail', 'Energy']
        self.years = [2022, 2023, 2024]
        self.companies_per_industry = 200
        self.total_companies = len(self.industries) * self.companies_per_industry
        
        # 3視点×8次元の定義
        self.dimensions = {
            'Market': [
                'M1_MarketShare', 'M2_CustomerSatisfaction', 'M3_BrandValue', 'M4_CompetitiveAdvantage',
                'M5_MarketGrowthRate', 'M6_PriceCompetitiveness', 'M7_CustomerLoyalty', 'M8_MarketPenetration'
            ],
            'Technology': [
                'T1_InnovationLevel', 'T2_RnDEfficiency', 'T3_DigitalTransformation', 'T4_IPPortfolio',
                'T5_TechnicalCompetitiveness', 'T6_SystemIntegration', 'T7_TechnicalRiskManagement', 'T8_TechnicalSustainability'
            ],
            'Finance': [
                'F1_Profitability', 'F2_Liquidity', 'F3_Stability', 'F4_GrowthPotential',
                'F5_Efficiency', 'F6_Leverage', 'F7_ROI', 'F8_CashFlow'
            ]
        }
        
        # 業界特性パラメータ（平均値）
        self.industry_means = {
            'Manufacturing': {
                'Market': [65, 60, 55, 70, 45, 60, 65, 55],
                'Technology': [55, 60, 50, 65, 60, 75, 70, 60],
                'Finance': [65, 60, 75, 50, 70, 55, 60, 65]
            },
            'Finance': {
                'Market': [60, 65, 70, 60, 50, 55, 80, 65],
                'Technology': [50, 55, 80, 60, 55, 70, 75, 65],
                'Finance': [70, 85, 80, 55, 65, 70, 75, 80]
            },
            'IT': {
                'Market': [55, 70, 65, 75, 85, 70, 60, 60],
                'Technology': [90, 85, 95, 80, 85, 80, 70, 75],
                'Finance': [60, 55, 50, 90, 75, 45, 80, 70]
            },
            'Retail': {
                'Market': [70, 75, 60, 65, 60, 80, 70, 85],
                'Technology': [45, 50, 60, 40, 45, 55, 60, 50],
                'Finance': [55, 65, 60, 65, 85, 60, 65, 70]
            },
            'Energy': {
                'Market': [60, 55, 65, 80, 40, 50, 65, 55],
                'Technology': [60, 65, 55, 70, 65, 70, 75, 90],
                'Finance': [70, 70, 90, 45, 60, 75, 65, 75]
            }
        }
        
        # 標準偏差（業界内変動）
        self.industry_stds = {industry: 12 for industry in self.industries}
        
        # 相関構造パラメータ
        self.intra_perspective_correlation = 0.5  # 視点内相関
        self.inter_perspective_correlation = 0.25  # 視点間相関
        self.temporal_correlation = 0.8  # 時系列相関
        
    def generate_correlation_matrix(self):
        """24次元の相関行列を生成"""
        n_dims = 24
        correlation_matrix = np.eye(n_dims)
        
        # 視点内相関の設定
        for perspective_idx, perspective in enumerate(['Market', 'Technology', 'Finance']):
            start_idx = perspective_idx * 8
            end_idx = start_idx + 8
            
            for i in range(start_idx, end_idx):
                for j in range(start_idx, end_idx):
                    if i != j:
                        correlation_matrix[i, j] = self.intra_perspective_correlation
        
        # 視点間相関の設定
        for i in range(n_dims):
            for j in range(n_dims):
                if i != j:
                    i_perspective = i // 8
                    j_perspective = j // 8
                    if i_perspective != j_perspective:
                        correlation_matrix[i, j] = self.inter_perspective_correlation
        
        return correlation_matrix
    
    def generate_company_data(self, industry, company_id, correlation_matrix):
        """単一企業の3年分データを生成"""
        n_dims = 24
        n_years = len(self.years)
        
        # 業界特性に基づく平均値ベクトル
        means = []
        for perspective in ['Market', 'Technology', 'Finance']:
            means.extend(self.industry_means[industry][perspective])
        means = np.array(means)
        
        # 標準偏差ベクトル
        stds = np.full(n_dims, self.industry_stds[industry])
        
        # 多変量正規分布からの初年度データ生成
        base_data = np.random.multivariate_normal(means, 
                                                 correlation_matrix * (self.industry_stds[industry] ** 2),
                                                 size=1)[0]
        
        # 0-100範囲にクリッピング
        base_data = np.clip(base_data, 0, 100)
        
        # 時系列データ生成（前年度データに基づく）
        company_data = []
        for year_idx, year in enumerate(self.years):
            if year_idx == 0:
                year_data = base_data.copy()
            else:
                # 前年度データに基づく変動
                noise = np.random.normal(0, self.industry_stds[industry] * 0.3, n_dims)
                year_data = (self.temporal_correlation * company_data[year_idx - 1] + 
                           (1 - self.temporal_correlation) * means + noise)
                year_data = np.clip(year_data, 0, 100)
            
            company_data.append(year_data)
        
        return np.array(company_data)
    
    def generate_dataset(self):
        """完全なデータセットを生成"""
        print(f"合成データ生成開始 (乱数シード: {RANDOM_SEED})")
        
        # 相関行列生成
        correlation_matrix = self.generate_correlation_matrix()
        
        # データ格納用リスト
        data_records = []
        
        # 企業ID生成
        company_id = 1
        
        for industry in self.industries:
            print(f"業界 '{industry}' のデータ生成中...")
            
            for company_idx in range(self.companies_per_industry):
                # 企業データ生成
                company_data = self.generate_company_data(industry, company_id, correlation_matrix)
                
                # 年次データをレコードに変換
                for year_idx, year in enumerate(self.years):
                    record = {
                        'CompanyID': company_id,
                        'Industry': industry,
                        'Year': year,
                        'CompanyName': f'{industry}_{company_idx+1:03d}'
                    }
                    
                    # 24次元データを追加
                    dim_idx = 0
                    for perspective, dimensions in self.dimensions.items():
                        for dimension in dimensions:
                            record[dimension] = round(company_data[year_idx][dim_idx], 2)
                            dim_idx += 1
                    
                    data_records.append(record)
                
                company_id += 1
        
        # DataFrameに変換
        df = pd.DataFrame(data_records)
        
        print(f"データ生成完了: {len(df)} レコード")
        return df, correlation_matrix
    
    def save_dataset(self, df, correlation_matrix, output_dir='../data'):
        """データセットを保存"""
        os.makedirs(output_dir, exist_ok=True)
        
        # メインデータセット保存
        csv_path = os.path.join(output_dir, 'synthetic_dco_dataset.csv')
        df.to_csv(csv_path, index=False, encoding='utf-8')
        print(f"データセット保存: {csv_path}")
        
        # 相関行列保存
        corr_path = os.path.join(output_dir, 'correlation_matrix.csv')
        pd.DataFrame(correlation_matrix).to_csv(corr_path, index=False)
        print(f"相関行列保存: {corr_path}")
        
        # メタデータ保存
        metadata = {
            'generation_date': datetime.now().isoformat(),
            'random_seed': RANDOM_SEED,
            'total_records': len(df),
            'total_companies': self.total_companies,
            'companies_per_industry': self.companies_per_industry,
            'industries': self.industries,
            'years': self.years,
            'dimensions': self.dimensions,
            'industry_means': self.industry_means,
            'industry_stds': self.industry_stds,
            'correlation_parameters': {
                'intra_perspective_correlation': self.intra_perspective_correlation,
                'inter_perspective_correlation': self.inter_perspective_correlation,
                'temporal_correlation': self.temporal_correlation
            }
        }
        
        metadata_path = os.path.join(output_dir, 'dataset_metadata.json')
        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2, ensure_ascii=False)
        print(f"メタデータ保存: {metadata_path}")
        
        return csv_path, corr_path, metadata_path
    
    def generate_summary_statistics(self, df, output_dir='../results'):
        """基本統計量を生成"""
        os.makedirs(output_dir, exist_ok=True)
        
        # 業界別統計
        industry_stats = df.groupby('Industry').agg({
            'CompanyID': 'count',
            **{dim: ['mean', 'std', 'min', 'max'] 
               for perspective_dims in self.dimensions.values() 
               for dim in perspective_dims}
        }).round(2)
        
        stats_path = os.path.join(output_dir, 'industry_statistics.csv')
        industry_stats.to_csv(stats_path, encoding='utf-8')
        print(f"業界別統計保存: {stats_path}")
        
        # 全体統計
        overall_stats = df.describe().round(2)
        overall_path = os.path.join(output_dir, 'overall_statistics.csv')
        overall_stats.to_csv(overall_path, encoding='utf-8')
        print(f"全体統計保存: {overall_path}")
        
        return stats_path, overall_path

def main():
    """メイン実行関数"""
    print("=" * 60)
    print("DCO概念定義検証実験 - 合成データ生成")
    print("=" * 60)
    
    # データ生成器初期化
    generator = SyntheticDataGenerator()
    
    # データセット生成
    df, correlation_matrix = generator.generate_dataset()
    
    # データ保存
    csv_path, corr_path, metadata_path = generator.save_dataset(df, correlation_matrix)
    
    # 統計量生成
    stats_path, overall_path = generator.generate_summary_statistics(df)
    
    print("\n" + "=" * 60)
    print("合成データ生成完了")
    print("=" * 60)
    print(f"データセット: {csv_path}")
    print(f"相関行列: {corr_path}")
    print(f"メタデータ: {metadata_path}")
    print(f"業界別統計: {stats_path}")
    print(f"全体統計: {overall_path}")
    
    return df, correlation_matrix

if __name__ == "__main__":
    df, correlation_matrix = main()

