#!/usr/bin/env python3.11
"""
DCO概念定義検証実験 - 統計的検定実験（1.1.3.1）ビジネス視点修正版

作成日: 2025年7月10日
修正日: 2025年7月10日（ビジネス視点対応）
作成者: Manus AI
目的: 24次元要素の正規性検定、信頼性分析、適合度検定

修正内容: ファイナンス視点→ビジネス視点への全面修正

検証項目:
1. 正規性検定（Shapiro-Wilk検定、Kolmogorov-Smirnov検定）
2. 信頼性分析（Cronbach's α）
3. 適合度検定（相関構造の妥当性）
4. 業界間差異検定（ANOVA、Kruskal-Wallis検定）
5. ビジネス視点特有の検定（構成概念妥当性、因子分析）
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from scipy.stats import shapiro, kstest, normaltest, anderson, f_oneway, kruskal
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA, FactorAnalysis
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
import warnings
warnings.filterwarnings('ignore')

# 日本語フォント設定
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['figure.figsize'] = (12, 8)
plt.rcParams['font.size'] = 10

class StatisticalValidationTestsBusinessPerspective:
    """統計的検定実験クラス（ビジネス視点版）"""
    
    def __init__(self, data_path='../data/synthetic_dco_dataset_business_perspective.csv'):
        """初期化"""
        self.data_path = data_path
        self.df = None
        self.dimensions = None
        self.results = {}
        
        # 3視点×8次元の定義（ビジネス視点修正版）
        self.perspective_dims = {
            'Market': [
                'M1_MarketShare', 'M2_CustomerSatisfaction', 'M3_BrandValue', 'M4_CompetitiveAdvantage',
                'M5_MarketGrowthRate', 'M6_PriceCompetitiveness', 'M7_CustomerLoyalty', 'M8_MarketPenetration'
            ],
            'Technology': [
                'T1_InnovationLevel', 'T2_RnDEfficiency', 'T3_DigitalTransformation', 'T4_IPPortfolio',
                'T5_TechnicalCompetitiveness', 'T6_SystemIntegration', 'T7_TechnicalRiskManagement', 'T8_TechnicalSustainability'
            ],
            'Business': [
                'B1_BusinessCognition', 'B2_BusinessValue', 'B3_BusinessTime', 'B4_BusinessOrganization',
                'B5_BusinessResources', 'B6_BusinessEnvironment', 'B7_BusinessEmotion', 'B8_BusinessSociety'
            ]
        }
        
        # ビジネス視点要素の詳細定義
        self.business_dimension_details = {
            'B1_BusinessCognition': '事業認知次元（市場機会認識、競争環境理解）',
            'B2_BusinessValue': '事業価値次元（顧客価値創出、ステークホルダー価値）',
            'B3_BusinessTime': '事業時間次元（事業ライフサイクル、戦略的タイミング）',
            'B4_BusinessOrganization': '事業組織次元（組織能力、経営体制）',
            'B5_BusinessResources': '事業リソース次元（経営資源配分、能力開発）',
            'B6_BusinessEnvironment': '事業環境次元（規制環境、業界構造）',
            'B7_BusinessEmotion': '事業感情次元（企業文化、ブランド価値）',
            'B8_BusinessSociety': '事業社会次元（社会的責任、持続可能性）'
        }
        
        # 全次元リスト
        self.all_dimensions = []
        for dims in self.perspective_dims.values():
            self.all_dimensions.extend(dims)
    
    def load_data(self):
        """データ読み込み"""
        print("データ読み込み中...")
        self.df = pd.read_csv(self.data_path)
        print(f"データ読み込み完了: {len(self.df)} レコード, {len(self.df.columns)} 列")
        
        # 基本情報表示
        print(f"業界数: {self.df['Industry'].nunique()}")
        print(f"企業数: {self.df['CompanyID'].nunique()}")
        print(f"年数: {self.df['Year'].nunique()}")
        print(f"業界別企業数:")
        print(self.df.groupby('Industry')['CompanyID'].nunique())
    
    def test_normality(self):
        """正規性検定"""
        print("\\n" + "="*50)
        print("1. 正規性検定実施中...")
        print("="*50)
        
        normality_results = []
        
        for dimension in self.all_dimensions:
            data = self.df[dimension].dropna()
            
            # Shapiro-Wilk検定（サンプルサイズが大きい場合は部分サンプル）
            if len(data) > 5000:
                sample_data = np.random.choice(data, 5000, replace=False)
            else:
                sample_data = data
            
            shapiro_stat, shapiro_p = shapiro(sample_data)
            
            # Kolmogorov-Smirnov検定
            ks_stat, ks_p = kstest(data, 'norm', args=(data.mean(), data.std()))
            
            # D'Agostino-Pearson検定
            dagostino_stat, dagostino_p = normaltest(data)
            
            # Anderson-Darling検定
            anderson_result = anderson(data, dist='norm')
            anderson_stat = anderson_result.statistic
            anderson_critical = anderson_result.critical_values[2]  # 5%水準
            anderson_significant = anderson_stat > anderson_critical
            
            # 結果記録
            result = {
                'Dimension': dimension,
                'Perspective': dimension[0] + ('usiness' if dimension.startswith('B') else ('arket' if dimension.startswith('M') else 'echnology')),
                'N': len(data),
                'Mean': data.mean(),
                'Std': data.std(),
                'Skewness': stats.skew(data),
                'Kurtosis': stats.kurtosis(data),
                'Shapiro_Stat': shapiro_stat,
                'Shapiro_P': shapiro_p,
                'Shapiro_Normal': shapiro_p > 0.05,
                'KS_Stat': ks_stat,
                'KS_P': ks_p,
                'KS_Normal': ks_p > 0.05,
                'DAgostino_Stat': dagostino_stat,
                'DAgostino_P': dagostino_p,
                'DAgostino_Normal': dagostino_p > 0.05,
                'Anderson_Stat': anderson_stat,
                'Anderson_Critical': anderson_critical,
                'Anderson_Normal': not anderson_significant
            }
            
            normality_results.append(result)
            
            # 進捗表示
            perspective = result['Perspective']
            normal_count = sum([result['Shapiro_Normal'], result['KS_Normal'], 
                              result['DAgostino_Normal'], result['Anderson_Normal']])
            print(f"  {dimension} ({perspective}): {normal_count}/4 検定で正規性確認")
        
        # 結果をDataFrameに変換
        normality_df = pd.DataFrame(normality_results)
        
        # 要約統計
        total_dims = len(normality_results)
        shapiro_normal = sum(normality_df['Shapiro_Normal'])
        ks_normal = sum(normality_df['KS_Normal'])
        dagostino_normal = sum(normality_df['DAgostino_Normal'])
        anderson_normal = sum(normality_df['Anderson_Normal'])
        
        print(f"\\n正規性検定結果要約:")
        print(f"  Shapiro-Wilk: {shapiro_normal}/{total_dims} ({shapiro_normal/total_dims*100:.1f}%)")
        print(f"  Kolmogorov-Smirnov: {ks_normal}/{total_dims} ({ks_normal/total_dims*100:.1f}%)")
        print(f"  D'Agostino-Pearson: {dagostino_normal}/{total_dims} ({dagostino_normal/total_dims*100:.1f}%)")
        print(f"  Anderson-Darling: {anderson_normal}/{total_dims} ({anderson_normal/total_dims*100:.1f}%)")
        
        # ビジネス視点特有の分析
        business_dims = normality_df[normality_df['Perspective'] == 'Business']
        business_normal_rate = business_dims[['Shapiro_Normal', 'KS_Normal', 'DAgostino_Normal', 'Anderson_Normal']].mean().mean()
        print(f"  ビジネス視点平均正規性: {business_normal_rate*100:.1f}%")
        
        self.results['normality'] = normality_df
        return normality_df
    
    def test_reliability(self):
        """信頼性分析（Cronbach's α）"""
        print("\\n" + "="*50)
        print("2. 信頼性分析実施中...")
        print("="*50)
        
        reliability_results = []
        
        for perspective, dimensions in self.perspective_dims.items():
            # 視点内の全次元データ
            perspective_data = self.df[dimensions].dropna()
            
            # Cronbach's α計算
            def cronbach_alpha(data):
                n_items = data.shape[1]
                item_variances = data.var(axis=0, ddof=1).sum()
                total_variance = data.sum(axis=1).var(ddof=1)
                alpha = (n_items / (n_items - 1)) * (1 - item_variances / total_variance)
                return alpha
            
            alpha = cronbach_alpha(perspective_data)
            
            # 項目削除時のα
            alpha_if_deleted = []
            for i, dim in enumerate(dimensions):
                subset_data = perspective_data.drop(columns=[dim])
                alpha_deleted = cronbach_alpha(subset_data)
                alpha_if_deleted.append(alpha_deleted)
            
            # 項目間相関
            item_correlations = perspective_data.corr()
            mean_inter_item_correlation = item_correlations.values[np.triu_indices_from(item_correlations.values, k=1)].mean()
            
            result = {
                'Perspective': perspective,
                'N_Items': len(dimensions),
                'N_Cases': len(perspective_data),
                'Cronbach_Alpha': alpha,
                'Mean_Inter_Item_Correlation': mean_inter_item_correlation,
                'Alpha_If_Deleted': alpha_if_deleted,
                'Reliability_Level': 'Excellent' if alpha >= 0.9 else 'Good' if alpha >= 0.8 else 'Acceptable' if alpha >= 0.7 else 'Poor'
            }
            
            reliability_results.append(result)
            
            print(f"  {perspective}視点:")
            print(f"    Cronbach's α: {alpha:.3f} ({result['Reliability_Level']})")
            print(f"    項目間平均相関: {mean_inter_item_correlation:.3f}")
            print(f"    項目数: {len(dimensions)}, ケース数: {len(perspective_data)}")
        
        # ビジネス視点の詳細分析
        business_result = [r for r in reliability_results if r['Perspective'] == 'Business'][0]
        print(f"\\nビジネス視点詳細分析:")
        print(f"  信頼性レベル: {business_result['Reliability_Level']}")
        print(f"  Cronbach's α: {business_result['Cronbach_Alpha']:.3f}")
        
        # 項目削除時の影響
        business_dims = self.perspective_dims['Business']
        print(f"  項目削除時のα:")
        for i, (dim, alpha_del) in enumerate(zip(business_dims, business_result['Alpha_If_Deleted'])):
            dim_name = self.business_dimension_details[dim].split('（')[0]
            print(f"    {dim} ({dim_name}): {alpha_del:.3f}")
        
        self.results['reliability'] = reliability_results
        return reliability_results
    
    def test_construct_validity(self):
        """構成概念妥当性検定（ビジネス視点特有）"""
        print("\\n" + "="*50)
        print("3. 構成概念妥当性検定実施中...")
        print("="*50)
        
        # ビジネス視点データ
        business_data = self.df[self.perspective_dims['Business']].dropna()
        
        # 因子分析
        fa = FactorAnalysis(n_components=3, random_state=42)
        fa.fit(business_data)
        
        # 因子負荷量
        factor_loadings = pd.DataFrame(
            fa.components_.T,
            columns=['Factor1', 'Factor2', 'Factor3'],
            index=self.perspective_dims['Business']
        )
        
        # KMO測度（標本妥当性）
        def kmo_test(data):
            corr_matrix = data.corr()
            partial_corr_matrix = pd.DataFrame(
                np.linalg.pinv(corr_matrix),
                index=corr_matrix.index,
                columns=corr_matrix.columns
            )
            
            # KMO計算
            sum_sq_corr = np.sum(np.square(corr_matrix.values))
            sum_sq_partial = np.sum(np.square(partial_corr_matrix.values))
            kmo = sum_sq_corr / (sum_sq_corr + sum_sq_partial)
            return kmo
        
        kmo_value = kmo_test(business_data)
        
        # Bartlett球面性検定
        from scipy.stats import chi2
        n, p = business_data.shape
        corr_matrix = business_data.corr()
        det_corr = np.linalg.det(corr_matrix)
        bartlett_stat = -((n - 1) - (2 * p + 5) / 6) * np.log(det_corr)
        bartlett_df = p * (p - 1) / 2
        bartlett_p = 1 - chi2.cdf(bartlett_stat, bartlett_df)
        
        print(f"  因子分析結果:")
        print(f"    KMO測度: {kmo_value:.3f}")
        print(f"    Bartlett検定: χ²={bartlett_stat:.2f}, p={bartlett_p:.3f}")
        print(f"    因子数: 3")
        
        print(f"\\n  因子負荷量:")
        for dim in self.perspective_dims['Business']:
            dim_name = self.business_dimension_details[dim].split('（')[0]
            loadings = factor_loadings.loc[dim]
            max_loading = loadings.abs().max()
            max_factor = loadings.abs().idxmax()
            print(f"    {dim} ({dim_name}): {max_factor}={loadings[max_factor]:.3f}")
        
        # 収束妥当性・判別妥当性
        business_corr = business_data.corr()
        
        # 特定の相関関係の検証
        b1_b6_corr = business_corr.loc['B1_BusinessCognition', 'B6_BusinessEnvironment']
        b2_b7_corr = business_corr.loc['B2_BusinessValue', 'B7_BusinessEmotion']
        b4_b5_corr = business_corr.loc['B4_BusinessOrganization', 'B5_BusinessResources']
        
        print(f"\\n  ビジネス視点特有の相関:")
        print(f"    B1-B6 (認知-環境): r={b1_b6_corr:.3f}")
        print(f"    B2-B7 (価値-感情): r={b2_b7_corr:.3f}")
        print(f"    B4-B5 (組織-リソース): r={b4_b5_corr:.3f}")
        
        construct_validity_result = {
            'kmo_value': kmo_value,
            'bartlett_stat': bartlett_stat,
            'bartlett_p': bartlett_p,
            'factor_loadings': factor_loadings,
            'business_correlations': {
                'B1_B6': b1_b6_corr,
                'B2_B7': b2_b7_corr,
                'B4_B5': b4_b5_corr
            }
        }
        
        self.results['construct_validity'] = construct_validity_result
        return construct_validity_result
    
    def test_industry_differences(self):
        """業界間差異検定"""
        print("\\n" + "="*50)
        print("4. 業界間差異検定実施中...")
        print("="*50)
        
        industry_results = []
        
        for dimension in self.all_dimensions:
            # 業界別データ
            industry_groups = [self.df[self.df['Industry'] == industry][dimension].dropna() 
                             for industry in self.df['Industry'].unique()]
            
            # ANOVA（正規性仮定）
            f_stat, f_p = f_oneway(*industry_groups)
            
            # Kruskal-Wallis検定（非パラメトリック）
            h_stat, h_p = kruskal(*industry_groups)
            
            # 効果量（η²）
            ss_between = sum(len(group) * (np.mean(group) - np.mean(self.df[dimension]))**2 
                           for group in industry_groups)
            ss_total = np.sum((self.df[dimension] - np.mean(self.df[dimension]))**2)
            eta_squared = ss_between / ss_total
            
            result = {
                'Dimension': dimension,
                'F_Statistic': f_stat,
                'F_P_Value': f_p,
                'F_Significant': f_p < 0.05,
                'H_Statistic': h_stat,
                'H_P_Value': h_p,
                'H_Significant': h_p < 0.05,
                'Eta_Squared': eta_squared,
                'Effect_Size': 'Large' if eta_squared >= 0.14 else 'Medium' if eta_squared >= 0.06 else 'Small'
            }
            
            industry_results.append(result)
            
            perspective = dimension[0] + ('usiness' if dimension.startswith('B') else ('arket' if dimension.startswith('M') else 'echnology'))
            print(f"  {dimension} ({perspective}): F={f_stat:.2f}, p={f_p:.3f}, η²={eta_squared:.3f}")
        
        # 結果要約
        industry_df = pd.DataFrame(industry_results)
        f_significant = sum(industry_df['F_Significant'])
        h_significant = sum(industry_df['H_Significant'])
        total_dims = len(industry_results)
        
        print(f"\\n業界間差異検定結果要約:")
        print(f"  ANOVA有意: {f_significant}/{total_dims} ({f_significant/total_dims*100:.1f}%)")
        print(f"  Kruskal-Wallis有意: {h_significant}/{total_dims} ({h_significant/total_dims*100:.1f}%)")
        
        # ビジネス視点の業界間差異
        business_results = industry_df[industry_df['Dimension'].str.startswith('B')]
        business_significant = sum(business_results['F_Significant'])
        print(f"  ビジネス視点有意差: {business_significant}/8 ({business_significant/8*100:.1f}%)")
        
        self.results['industry_differences'] = industry_df
        return industry_df
    
    def generate_summary_report(self):
        """統計的検定結果の要約レポート生成"""
        print("\\n" + "="*60)
        print("統計的検定実験結果要約レポート（ビジネス視点版）")
        print("="*60)
        
        # 1. 正規性検定要約
        normality_df = self.results['normality']
        normal_rates = {
            'Shapiro-Wilk': normality_df['Shapiro_Normal'].mean(),
            'Kolmogorov-Smirnov': normality_df['KS_Normal'].mean(),
            'DAgostino-Pearson': normality_df['DAgostino_Normal'].mean(),
            'Anderson-Darling': normality_df['Anderson_Normal'].mean()
        }
        
        print(f"\\n1. 正規性検定結果:")
        for test, rate in normal_rates.items():
            print(f"   {test}: {rate*100:.1f}%")
        
        overall_normality = np.mean(list(normal_rates.values()))
        print(f"   総合正規性: {overall_normality*100:.1f}%")
        
        # 2. 信頼性分析要約
        reliability_results = self.results['reliability']
        print(f"\\n2. 信頼性分析結果:")
        for result in reliability_results:
            print(f"   {result['Perspective']}視点: α={result['Cronbach_Alpha']:.3f} ({result['Reliability_Level']})")
        
        # 3. 構成概念妥当性要約
        construct_result = self.results['construct_validity']
        print(f"\\n3. 構成概念妥当性結果:")
        print(f"   KMO測度: {construct_result['kmo_value']:.3f}")
        print(f"   Bartlett検定: p={construct_result['bartlett_p']:.3f}")
        
        # 4. 業界間差異要約
        industry_df = self.results['industry_differences']
        print(f"\\n4. 業界間差異検定結果:")
        print(f"   ANOVA有意率: {industry_df['F_Significant'].mean()*100:.1f}%")
        print(f"   Kruskal-Wallis有意率: {industry_df['H_Significant'].mean()*100:.1f}%")
        
        # 5. ビジネス視点特有の結果
        business_normality = normality_df[normality_df['Perspective'] == 'Business']
        business_normal_rate = business_normality[['Shapiro_Normal', 'KS_Normal', 'DAgostino_Normal', 'Anderson_Normal']].mean().mean()
        business_reliability = [r for r in reliability_results if r['Perspective'] == 'Business'][0]
        business_industry_diff = industry_df[industry_df['Dimension'].str.startswith('B')]
        
        print(f"\\n5. ビジネス視点特有の結果:")
        print(f"   正規性: {business_normal_rate*100:.1f}%")
        print(f"   信頼性: α={business_reliability['Cronbach_Alpha']:.3f}")
        print(f"   業界間差異: {business_industry_diff['F_Significant'].mean()*100:.1f}%")
        
        # 総合評価
        print(f"\\n6. 総合評価:")
        quality_score = (
            overall_normality * 0.3 +
            (business_reliability['Cronbach_Alpha'] / 1.0) * 0.3 +
            (construct_result['kmo_value'] / 1.0) * 0.2 +
            (business_industry_diff['F_Significant'].mean()) * 0.2
        )
        print(f"   統計的品質スコア: {quality_score*100:.1f}%")
        
        quality_level = 'Excellent' if quality_score >= 0.8 else 'Good' if quality_score >= 0.7 else 'Acceptable' if quality_score >= 0.6 else 'Poor'
        print(f"   品質レベル: {quality_level}")
        
        return {
            'normality_rates': normal_rates,
            'reliability_results': reliability_results,
            'construct_validity': construct_result,
            'industry_differences': industry_df,
            'business_specific': {
                'normality_rate': business_normal_rate,
                'reliability': business_reliability['Cronbach_Alpha'],
                'industry_diff_rate': business_industry_diff['F_Significant'].mean()
            },
            'quality_score': quality_score,
            'quality_level': quality_level
        }
    
    def save_results(self, output_dir='../results'):
        """結果保存"""
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        # 正規性検定結果
        normality_path = os.path.join(output_dir, 'normality_test_results_business_perspective.csv')
        self.results['normality'].to_csv(normality_path, index=False)
        
        # 信頼性分析結果
        reliability_path = os.path.join(output_dir, 'reliability_analysis_results_business_perspective.csv')
        reliability_df = pd.DataFrame(self.results['reliability'])
        reliability_df.to_csv(reliability_path, index=False)
        
        # 業界間差異結果
        industry_path = os.path.join(output_dir, 'industry_differences_results_business_perspective.csv')
        self.results['industry_differences'].to_csv(industry_path, index=False)
        
        print(f"\\n結果保存完了:")
        print(f"  正規性検定: {normality_path}")
        print(f"  信頼性分析: {reliability_path}")
        print(f"  業界間差異: {industry_path}")
        
        return normality_path, reliability_path, industry_path

def main():
    """メイン実行関数"""
    print("DCO概念定義検証実験 - 統計的検定実験（ビジネス視点版）")
    print("=" * 60)
    
    # 検定実行
    validator = StatisticalValidationTestsBusinessPerspective()
    validator.load_data()
    
    # 各検定実行
    validator.test_normality()
    validator.test_reliability()
    validator.test_construct_validity()
    validator.test_industry_differences()
    
    # 要約レポート生成
    summary = validator.generate_summary_report()
    
    # 結果保存
    validator.save_results()
    
    print("\\n" + "=" * 60)
    print("統計的検定実験完了（ビジネス視点版）")
    
    return validator, summary

if __name__ == "__main__":
    validator, summary = main()

