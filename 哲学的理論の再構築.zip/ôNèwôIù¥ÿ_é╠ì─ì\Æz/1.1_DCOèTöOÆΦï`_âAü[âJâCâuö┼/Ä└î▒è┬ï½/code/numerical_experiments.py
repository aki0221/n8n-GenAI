#!/usr/bin/env python3
"""
数値実験・性能評価プログラム (1.1.3.3)
DCO概念定義検証実験の最終段階

目的:
- モンテカルロシミュレーションによる不確実性評価
- 交差検証による予測精度評価
- 大規模データセットでの性能評価
- 総合的な実験結果の統合分析

実験環境:
- Python 3.11.0rc1
- NumPy 1.24.3, Pandas 2.0.3, Scikit-learn 1.3.0
- 合成データセット: 3,000レコード（1,000社×3年分）
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import cross_val_score, KFold, train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler
import json
import time
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# 実験環境設定
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

class NumericalExperimentSuite:
    """数値実験・性能評価の統合実行クラス"""
    
    def __init__(self, data_path):
        """
        初期化
        
        Args:
            data_path (str): 合成データセットのパス
        """
        self.data_path = data_path
        self.data = None
        self.results = {}
        self.experiment_start_time = datetime.now()
        
    def load_data(self):
        """データセットの読み込み"""
        print("データセット読み込み中...")
        self.data = pd.read_csv(self.data_path)
        print(f"データセット読み込み完了: {self.data.shape}")
        
        # 各視点のスコア計算（8次元の平均）
        technology_cols = [f'T{i}_' + col for i, col in enumerate([
            'InnovationLevel', 'RnDEfficiency', 'DigitalTransformation', 'IPPortfolio',
            'TechnicalCompetitiveness', 'SystemIntegration', 'TechnicalRiskManagement', 'TechnicalSustainability'
        ], 1)]
        market_cols = [f'M{i}_' + col for i, col in enumerate([
            'MarketShare', 'CustomerSatisfaction', 'BrandValue', 'CompetitiveAdvantage',
            'MarketGrowthRate', 'PriceCompetitiveness', 'CustomerLoyalty', 'MarketPenetration'
        ], 1)]
        finance_cols = [f'F{i}_' + col for i, col in enumerate([
            'Profitability', 'Liquidity', 'Stability', 'GrowthPotential',
            'Efficiency', 'Leverage', 'ROI', 'CashFlow'
        ], 1)]
        
        # 実際の列名を確認して使用
        available_cols = self.data.columns.tolist()
        tech_cols_actual = [col for col in available_cols if col.startswith('T') and '_' in col]
        market_cols_actual = [col for col in available_cols if col.startswith('M') and '_' in col]
        finance_cols_actual = [col for col in available_cols if col.startswith('F') and '_' in col]
        
        # 各視点のスコア計算
        self.data['Technology_Score'] = self.data[tech_cols_actual].mean(axis=1)
        self.data['Market_Score'] = self.data[market_cols_actual].mean(axis=1)
        self.data['Finance_Score'] = self.data[finance_cols_actual].mean(axis=1)
        
        # DCOスコア計算（3要素の乗算統合）
        self.data['DCO_Score'] = (
            self.data['Technology_Score'] * 
            self.data['Market_Score'] * 
            self.data['Finance_Score']
        )
        
        return self.data
    
    def monte_carlo_simulation(self, n_simulations=1000):
        """
        モンテカルロシミュレーションによる不確実性評価
        
        Args:
            n_simulations (int): シミュレーション回数
            
        Returns:
            dict: シミュレーション結果
        """
        print(f"モンテカルロシミュレーション実行中 (n={n_simulations})...")
        start_time = time.time()
        
        # 各次元の統計量を計算
        dimensions = [col for col in self.data.columns if col.startswith(('Technology_', 'Market_', 'Finance_'))]
        
        simulation_results = []
        dco_scores = []
        
        for i in range(n_simulations):
            # 各次元からランダムサンプリング
            simulated_data = {}
            
            for dim in dimensions:
                # 元データの分布パラメータを使用
                mean = self.data[dim].mean()
                std = self.data[dim].std()
                simulated_data[dim] = np.random.normal(mean, std, 100)
            
            # DCOスコア計算
            tech_score = np.mean([simulated_data[col] for col in dimensions if col.startswith('Technology_')])
            market_score = np.mean([simulated_data[col] for col in dimensions if col.startswith('Market_')])
            finance_score = np.mean([simulated_data[col] for col in dimensions if col.startswith('Finance_')])
            
            dco_score = tech_score * market_score * finance_score
            dco_scores.append(dco_score)
            
            simulation_results.append({
                'simulation_id': i,
                'technology_score': tech_score,
                'market_score': market_score,
                'finance_score': finance_score,
                'dco_score': dco_score
            })
        
        execution_time = time.time() - start_time
        
        # 統計的分析
        dco_scores = np.array(dco_scores)
        
        results = {
            'n_simulations': n_simulations,
            'execution_time': execution_time,
            'dco_statistics': {
                'mean': float(np.mean(dco_scores)),
                'std': float(np.std(dco_scores)),
                'min': float(np.min(dco_scores)),
                'max': float(np.max(dco_scores)),
                'percentile_5': float(np.percentile(dco_scores, 5)),
                'percentile_95': float(np.percentile(dco_scores, 95)),
                'confidence_interval_95': [
                    float(np.percentile(dco_scores, 2.5)),
                    float(np.percentile(dco_scores, 97.5))
                ]
            },
            'simulation_data': simulation_results[:100]  # 最初の100件のみ保存
        }
        
        self.results['monte_carlo'] = results
        print(f"モンテカルロシミュレーション完了 (実行時間: {execution_time:.3f}秒)")
        
        return results
    
    def cross_validation_analysis(self, cv_folds=5):
        """
        交差検証による予測精度評価
        
        Args:
            cv_folds (int): 交差検証の分割数
            
        Returns:
            dict: 交差検証結果
        """
        print(f"交差検証分析実行中 (CV={cv_folds})...")
        start_time = time.time()
        
        # 特徴量とターゲットの準備
        feature_cols = [col for col in self.data.columns if col.startswith(('Technology_', 'Market_', 'Finance_'))]
        X = self.data[feature_cols]
        y = self.data['DCO_Score']
        
        # 標準化
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # 複数のモデルで評価
        models = {
            'RandomForest': RandomForestRegressor(n_estimators=100, random_state=RANDOM_SEED),
        }
        
        cv_results = {}
        
        for model_name, model in models.items():
            # 交差検証実行
            kfold = KFold(n_splits=cv_folds, shuffle=True, random_state=RANDOM_SEED)
            
            # R²スコア
            r2_scores = cross_val_score(model, X_scaled, y, cv=kfold, scoring='r2')
            
            # 負の平均二乗誤差
            neg_mse_scores = cross_val_score(model, X_scaled, y, cv=kfold, scoring='neg_mean_squared_error')
            mse_scores = -neg_mse_scores
            
            # 負の平均絶対誤差
            neg_mae_scores = cross_val_score(model, X_scaled, y, cv=kfold, scoring='neg_mean_absolute_error')
            mae_scores = -neg_mae_scores
            
            cv_results[model_name] = {
                'r2_scores': r2_scores.tolist(),
                'r2_mean': float(np.mean(r2_scores)),
                'r2_std': float(np.std(r2_scores)),
                'mse_scores': mse_scores.tolist(),
                'mse_mean': float(np.mean(mse_scores)),
                'mse_std': float(np.std(mse_scores)),
                'mae_scores': mae_scores.tolist(),
                'mae_mean': float(np.mean(mae_scores)),
                'mae_std': float(np.std(mae_scores))
            }
        
        execution_time = time.time() - start_time
        
        results = {
            'cv_folds': cv_folds,
            'execution_time': execution_time,
            'feature_count': len(feature_cols),
            'sample_count': len(X),
            'models': cv_results
        }
        
        self.results['cross_validation'] = results
        print(f"交差検証分析完了 (実行時間: {execution_time:.3f}秒)")
        
        return results
    
    def scalability_analysis(self, sample_sizes=[100, 500, 1000, 2000, 3000]):
        """
        スケーラビリティ分析
        
        Args:
            sample_sizes (list): 分析対象のサンプルサイズ
            
        Returns:
            dict: スケーラビリティ分析結果
        """
        print("スケーラビリティ分析実行中...")
        start_time = time.time()
        
        scalability_results = []
        
        for sample_size in sample_sizes:
            if sample_size > len(self.data):
                continue
                
            # サンプルデータの作成
            sample_data = self.data.sample(n=sample_size, random_state=RANDOM_SEED)
            
            # 処理時間測定
            process_start = time.time()
            
            # DCOスコア計算
            dco_scores = (
                sample_data['Technology_Score'] * 
                sample_data['Market_Score'] * 
                sample_data['Finance_Score']
            )
            
            # 統計量計算
            stats = {
                'mean': float(dco_scores.mean()),
                'std': float(dco_scores.std()),
                'min': float(dco_scores.min()),
                'max': float(dco_scores.max())
            }
            
            process_time = time.time() - process_start
            
            scalability_results.append({
                'sample_size': sample_size,
                'processing_time': process_time,
                'time_per_record': process_time / sample_size,
                'throughput': sample_size / process_time,
                'statistics': stats
            })
            
            print(f"  サンプルサイズ {sample_size}: {process_time:.4f}秒 ({process_time/sample_size*1000:.3f}ms/レコード)")
        
        execution_time = time.time() - start_time
        
        results = {
            'execution_time': execution_time,
            'sample_sizes': sample_sizes,
            'scalability_data': scalability_results
        }
        
        self.results['scalability'] = results
        print(f"スケーラビリティ分析完了 (実行時間: {execution_time:.3f}秒)")
        
        return results
    
    def industry_comparison_analysis(self):
        """業界間比較分析"""
        print("業界間比較分析実行中...")
        start_time = time.time()
        
        industry_results = {}
        
        for industry in self.data['Industry'].unique():
            industry_data = self.data[self.data['Industry'] == industry]
            
            # DCOスコア統計
            dco_stats = {
                'count': len(industry_data),
                'mean': float(industry_data['DCO_Score'].mean()),
                'std': float(industry_data['DCO_Score'].std()),
                'min': float(industry_data['DCO_Score'].min()),
                'max': float(industry_data['DCO_Score'].max()),
                'percentile_25': float(industry_data['DCO_Score'].quantile(0.25)),
                'percentile_75': float(industry_data['DCO_Score'].quantile(0.75))
            }
            
            # 3要素別統計
            element_stats = {}
            for element in ['Technology_Score', 'Market_Score', 'Finance_Score']:
                element_stats[element] = {
                    'mean': float(industry_data[element].mean()),
                    'std': float(industry_data[element].std())
                }
            
            industry_results[industry] = {
                'dco_statistics': dco_stats,
                'element_statistics': element_stats
            }
        
        execution_time = time.time() - start_time
        
        results = {
            'execution_time': execution_time,
            'industry_count': len(industry_results),
            'industries': industry_results
        }
        
        self.results['industry_comparison'] = results
        print(f"業界間比較分析完了 (実行時間: {execution_time:.3f}秒)")
        
        return results
    
    def generate_visualizations(self, output_dir):
        """可視化の生成"""
        print("可視化生成中...")
        
        # スケーラビリティ分析のグラフ
        if 'scalability' in self.results:
            plt.figure(figsize=(12, 8))
            
            scalability_data = self.results['scalability']['scalability_data']
            sample_sizes = [d['sample_size'] for d in scalability_data]
            processing_times = [d['processing_time'] for d in scalability_data]
            time_per_record = [d['time_per_record'] * 1000 for d in scalability_data]  # ms単位
            
            # 2つのサブプロット
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
            
            # 総処理時間
            ax1.plot(sample_sizes, processing_times, 'bo-', linewidth=2, markersize=8)
            ax1.set_xlabel('サンプルサイズ')
            ax1.set_ylabel('総処理時間 (秒)')
            ax1.set_title('スケーラビリティ分析: 総処理時間')
            ax1.grid(True, alpha=0.3)
            
            # レコードあたり処理時間
            ax2.plot(sample_sizes, time_per_record, 'ro-', linewidth=2, markersize=8)
            ax2.set_xlabel('サンプルサイズ')
            ax2.set_ylabel('レコードあたり処理時間 (ms)')
            ax2.set_title('スケーラビリティ分析: 効率性')
            ax2.grid(True, alpha=0.3)
            
            plt.tight_layout()
            plt.savefig(f'{output_dir}/scalability_analysis.png', dpi=300, bbox_inches='tight')
            plt.close()
        
        print("可視化生成完了")
    
    def run_complete_experiment(self, output_dir):
        """完全な数値実験の実行"""
        print("=== DCO概念定義検証実験 - 数値実験・性能評価 (1.1.3.3) ===")
        print(f"実験開始時刻: {self.experiment_start_time}")
        
        # データ読み込み
        self.load_data()
        
        # 各実験の実行
        self.monte_carlo_simulation(n_simulations=1000)
        self.cross_validation_analysis(cv_folds=5)
        self.scalability_analysis()
        self.industry_comparison_analysis()
        
        # 可視化生成
        self.generate_visualizations(output_dir)
        
        # 総合結果の保存
        experiment_end_time = datetime.now()
        total_execution_time = (experiment_end_time - self.experiment_start_time).total_seconds()
        
        summary_results = {
            'experiment_metadata': {
                'start_time': self.experiment_start_time.isoformat(),
                'end_time': experiment_end_time.isoformat(),
                'total_execution_time': total_execution_time,
                'data_shape': list(self.data.shape),
                'random_seed': RANDOM_SEED
            },
            'experiment_results': self.results
        }
        
        # 結果保存
        with open(f'{output_dir}/numerical_experiment_results.json', 'w', encoding='utf-8') as f:
            json.dump(summary_results, f, ensure_ascii=False, indent=2)
        
        print(f"\n=== 実験完了 ===")
        print(f"総実行時間: {total_execution_time:.2f}秒")
        print(f"結果保存先: {output_dir}")
        
        return summary_results

def main():
    """メイン実行関数"""
    # パス設定
    data_path = "/code/triple-perspective-ai-radar/n8n-GenAI-main/①哲学的理論の体系化プロジェクト/実験/data/synthetic_dco_dataset.csv"
    output_dir = "/code/triple-perspective-ai-radar/n8n-GenAI-main/①哲学的理論の体系化プロジェクト/実験/results"
    
    # 実験実行
    experiment = NumericalExperimentSuite(data_path)
    results = experiment.run_complete_experiment(output_dir)
    
    return results

if __name__ == "__main__":
    results = main()

